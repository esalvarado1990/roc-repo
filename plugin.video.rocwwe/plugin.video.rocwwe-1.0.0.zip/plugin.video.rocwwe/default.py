import json, os, sys, urllib.parse
import xbmcaddon, xbmcgui, xbmcplugin

ADDON = xbmcaddon.Addon()
DATA = os.path.join(ADDON.getAddonInfo("path"), "resources", "data", "ppv_events.json")

def load():
    try:
        with open(DATA, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def root(handle):
    evs = load()
    years = sorted({e["date"][:4] for e in evs}, reverse=True)
    for y in years:
        n = sum(1 for e in evs if e["date"].startswith(y))
        li = xbmcgui.ListItem(label="%s  (%d events)" % (y, n))
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?year=" + y, li, True)
    xbmcplugin.endOfDirectory(handle)

def year(handle, y):
    for e in [e for e in load() if e["date"].startswith(y)]:
        label = "%s  -  %s" % (e["date"], e["name"])
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": e["name"], "plot": "%s (%s) - tap to jump into the Wrestling section and search this event." % (e["name"], e["date"])})
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?play=1", li, False)
    xbmcplugin.endOfDirectory(handle)

def play():
    import xbmc
    xbmc.executebuiltin("ActivateWindow(Videos,plugin://plugin.video.purelywrestling/,return)")

def router():
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    if "year" in params:
        year(handle, params["year"])
    elif "play" in params:
        play()
    else:
        root(handle)

router()
