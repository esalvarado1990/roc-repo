# -*- coding: utf-8 -*-
"""
script.rocui playback tools (v3.2.0, Eric 2026-10-24 16:36-16:39):

  source_select  — OSD SOURCES button: re-pick the playing title's
                   source. Re-runs the originating addon's play entry
                   when its plugin path is recoverable (its own
                   source-select screen shows the full grouped list);
                   otherwise hands the title to TMDb Helper's player
                   selection by ID. The service seeks back to the
                   stored position when the new source starts.
                   Honest limit (research report Q5): playback always
                   restarts; Scrubs V2 / The Crew expose no documented
                   re-entry, so they take the TMDb Helper fallback.
  resume_play    — play the resume checkpoint (Resume Keeper), seek
                   applied by the service.
  detail_resume_play — detail-page RESUME button (8002): per-title
                   history position + per-title source memory for
                   THIS title (never the one-title global checkpoint),
                   fallback PlayMedia(RocStage.Path) with the seek
                   armed. 0.5.17 Stage 2 skin wiring.
  resume_clear   — dismiss the checkpoint.
  episodes_panel — OSD EPISODES / COLLECTION button: Netflix-style
                   season/episode list for TV, TMDB collection parts
                   in order for movies; a pick plays through the
                   originating addon's rules first (its play entry /
                   TMDb Helper player), the same source/quality
                   behavior pack he runs.

  0.5.15 (Hand B player-fix, 2026-11-05, item 2b): resume routes
  consult the per-title SOURCE MEMORY (rocui_common.source_save /
  source_load_for) before any of the routes above — the remembered
  source is replayed directly at the saved position, verified
  advancing, and only a source that will not start falls back to
  the full hunt. source_select gained a direct RocPlay picker
  route (no auto flag) for titles whose snapshot path is a
  resolved URL.
"""
import re
import time
from six.moves import urllib_parse

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover - importable outside Kodi
    xbmc = xbmcgui = xbmcvfs = None

import rocui_common as rc

TMDBH = "plugin://plugin.video.themoviedb.helper/"


def _tmdb_play_path(snap, tmdb_id=None, season=None, episode=None):
    tmdb_id = tmdb_id or rc.snapshot_tmdb_id(snap)
    is_tv = bool(snap.get("showtitle")) or snap.get("type") == "episode"
    if tmdb_id:
        if is_tv:
            s = season if season is not None else snap.get("season", -1)
            e = episode if episode is not None else snap.get("episode", -1)
            path = ("%s?info=play&tmdb_type=tv&tmdb_id=%s"
                    % (TMDBH, tmdb_id))
            if s is not None and s >= 0:
                path += "&season=%d" % s
            if e is not None and e >= 0:
                path += "&episode=%d" % e
            return path
        return "%s?info=play&tmdb_type=movie&tmdb_id=%s" % (TMDBH, tmdb_id)
    if snap.get("imdb"):
        return "%s?info=play&tmdb_type=%s&imdb_id=%s" % (
            TMDBH, "tv" if is_tv else "movie", snap["imdb"])
    return ""


def _open_path(path, stop_first=False):
    if stop_first:
        try:
            xbmc.Player().stop()
        except Exception:
            pass
    if "info=play" in path:
        # A TMDBH play path must be PLAYED as a file, not browsed:
        # opened as a Videos directory (ActivateWindow) it returns
        # an empty listing, and PlayMedia browses it the same way
        # — both dead-ended Resume silently on the Dell
        # 2026-10-26. Player().play() hands TMDBH the file-mode
        # invocation its play flow answers (the same route
        # JSON-RPC Player.Open takes, proven live the same day:
        # default player -> rocplay -> advancing playhead).
        xbmc.Player().play(path)
    elif path.startswith("plugin://"):
        xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % path)
    else:
        xbmc.executebuiltin("PlayMedia(%s)" % path)


# ----------------------------------------------------------------------
# remembered-source direct play (0.5.15, Hand B player-fix, item 2b)
# ----------------------------------------------------------------------
def _snap_listitem(snap):
    """A ListItem carrying the snapshot's identity (title / show /
    S / E / year + unique IDs), the RocPlay _listitem shape, so a
    direct-URL replay keeps the service's snapshot, history and OSD
    metadata exactly as the original play had them."""
    li = xbmcgui.ListItem(label=snap.get("title") or
                          snap.get("showtitle") or "Play")
    is_tv = bool(snap.get("showtitle")) or snap.get("type") == "episode"
    info = {"title": snap.get("title") or "",
            "year": int(snap.get("year") or 0),
            "mediatype": "episode" if is_tv else "movie"}
    if is_tv:
        info.update({
            "tvshowtitle": snap.get("showtitle") or "",
            "season": int(snap.get("season", -1))
            if int(snap.get("season", -1)) >= 0 else 0,
            "episode": int(snap.get("episode", -1))
            if int(snap.get("episode", -1)) >= 0 else 0})
    li.setInfo("video", info)
    ids = {}
    if snap.get("imdb"):
        ids["imdb"] = str(snap["imdb"])
    if snap.get("tmdb"):
        ids["tmdb"] = str(snap["tmdb"])
    if ids:
        li.setUniqueIDs(ids, "imdb" if "imdb" in ids else "tmdb")
    if snap.get("thumb"):
        li.setArt({"thumb": snap["thumb"]})
    return li


def _verify_advancing(player, timeout_s=25.0):
    """RocPlay's own definition of 'plays', reused: playback is up
    and the playhead advances (sampled over a 4s window), or the
    pending seek has already landed the playhead near the resume
    target. Bounded; returns False on timeout/failure."""
    monitor = xbmc.Monitor()
    start = time.time()
    first = None
    while time.time() - start < timeout_s:
        if monitor.abortRequested():
            return False
        try:
            if player.isPlayingVideo():
                t = float(player.getTime())
                if first is None:
                    first = (time.time(), t)
                elif time.time() - first[0] >= 4.0:
                    return t > first[1] or t >= 30.0
        except Exception:
            pass
        monitor.waitForAbort(0.5)
    return False


def _play_remembered(entry, snap, position):
    """Go straight back to the remembered source for this title at
    `position`. True only when that source verifiably plays;
    False means the caller falls back to the full source hunt
    (the seek stays armed either way, so the fallback resumes at
    the same spot)."""
    if not entry:
        return False
    rc.seek_arm(position, rc.snapshot_display(snap))
    origin = entry.get("origin_path") or ""
    if origin.startswith("plugin://"):
        rc.log("resume: remembered origin %s" % origin[:120])
        xbmc.executebuiltin("PlayMedia(%s)" % origin)
        return True
    url = entry.get("url") or ""
    if url.startswith(("http://", "https://")):
        rc.log("resume: remembered source %s" % url[:120])
        player = xbmc.Player()
        player.play(url, _snap_listitem(snap))
        if _verify_advancing(player):
            return True
        rc.log("resume: remembered source would not start; "
               "falling back to the source hunt")
        try:
            player.stop()
        except Exception:
            pass
        # Re-arm: the stop may have raced the service's applier,
        # and the fallback hunt below needs a fresh timestamp.
        rc.seek_arm(position, rc.snapshot_display(snap))
    return False


# ----------------------------------------------------------------------
# source re-pick (item 2)
# ----------------------------------------------------------------------
def source_select():
    snap = rc.now_playing_snapshot()
    if not snap:
        rc.notify("Nothing is playing to re-pick", ok=False)
        return
    try:
        pos = xbmc.Player().getTime()
    except Exception:
        pos = 0
    if pos > 5:
        rc.seek_arm(pos, rc.snapshot_display(snap))
    path = snap.get("path") or ""
    if path.startswith("plugin://"):
        # The originating addon's own play entry: re-running it makes
        # the addon rescrape and show its source list (Seren-family
        # getSources; Crew/Scrubs show their lists at play).
        rc.log("source_select: re-running origin %s" % path[:120])
        xbmc.executebuiltin("PlayMedia(%s)" % path)
        rc.notify("Re-picking sources - same title, full list")
        return
    # 0.5.15: a RocPlay title's snapshot path is the RESOLVED stream
    # URL, never the plugin invocation, so the branch above can
    # never fire for the house player. Drive RocPlay directly with
    # the snapshot's own parameters and NO auto flag — that is the
    # one invocation that shows its merged source picker (the
    # default template now carries auto=1 for one-click plays).
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.rocplay)"):
        q = {"action": "play",
             "title": snap.get("title") or snap.get("showtitle") or "",
             "year": snap.get("year") or "",
             "imdb": snap.get("imdb") or "",
             "tmdb": snap.get("tmdb") or ""}
        if snap.get("showtitle") or snap.get("type") == "episode":
            q.update({"tvshowtitle": snap.get("showtitle") or "",
                      "season": snap.get("season", -1)
                      if snap.get("season", -1) >= 0 else "",
                      "episode": snap.get("episode", -1)
                      if snap.get("episode", -1) >= 0 else ""})
        roc_url = ("plugin://plugin.video.rocplay/?%s"
                   % urllib_parse.urlencode(
                       {k: v for k, v in q.items() if v != ""}))
        rc.log("source_select: RocPlay picker %s" % roc_url[:120])
        xbmc.executebuiltin("PlayMedia(%s)" % roc_url)
        rc.notify("Re-picking sources - same title, full list")
        return
    tmdb_path = _tmdb_play_path(snap)
    if tmdb_path:
        rc.log("source_select: TMDb Helper fallback for %s"
               % rc.snapshot_display(snap))
        _open_path(tmdb_path, stop_first=True)
        rc.notify("Pick a player - its full source list opens")
        return
    if snap.get("title"):
        query = urllib_parse.quote_plus(snap["title"])
        # 0.5.5: typed search — Helper 5.4.16's search route
        # requires tmdb_type; the untyped URL died inside the
        # Helper with a TypeError (same defect as rocui_common's
        # 0.5.4 collection paths). Type from the snapshot, the
        # _tmdb_play_path rule: a show title or an episode snap
        # is TV, anything else is a movie.
        is_tv = bool(snap.get("showtitle")) or \
            snap.get("type") == "episode"
        _open_path("%s?info=search&tmdb_type=%s&query=%s"
                   % (TMDBH, "tv" if is_tv else "movie", query),
                   stop_first=True)
        rc.notify("Pick the title - then a player for sources")
        return
    rc.notify("This one cannot be re-picked", ok=False)


# ----------------------------------------------------------------------
# resume keeper actions (item 3)
# ----------------------------------------------------------------------
def resume_play():
    data = rc.resume_load()
    snap = data.get("snap") or {}
    if not snap or not data.get("position"):
        rc.notify("Nothing saved to resume", ok=False)
        return
    # 0.5.15 (item 2b): the remembered source goes FIRST. The routes
    # below this block are the pre-fix behaviour — every one of them
    # re-runs the full source hunt, because the checkpoint's stored
    # path is the resolved stream URL and the http(s) branch below
    # refuses it. The source memory is what the hunt is being
    # skipped WITH: the exact source that played last time.
    entry = rc.source_load_for(snap)
    if entry and _play_remembered(entry, snap, data["position"]):
        rc.notify("Resuming %s" % rc.snapshot_display(snap)[:60])
        return
    rc.seek_arm(data["position"], rc.snapshot_display(snap))
    path = snap.get("path") or ""
    if path.startswith("plugin://"):
        addon_id = path.split("/")[2] if len(path.split("/")) > 2 else ""
        if addon_id and xbmc.getCondVisibility(
                "System.HasAddon(%s)" % addon_id):
            xbmc.executebuiltin("PlayMedia(%s)" % path)
            rc.notify("Resuming %s" % rc.snapshot_display(snap)[:60])
            return
    if path and not path.startswith(("http://", "https://")) \
            and xbmcvfs.exists(path):
        xbmc.executebuiltin("PlayMedia(%s)" % path)
        rc.notify("Resuming %s" % rc.snapshot_display(snap)[:60])
        return
    tmdb_path = _tmdb_play_path(snap)
    if tmdb_path:
        _open_path(tmdb_path)
        rc.notify("Pick the player - it resumes at your spot")
        return
    rc.notify("This one cannot be re-opened automatically", ok=False)


def resume_clear():
    rc.resume_delete()
    rc.log("resume checkpoint cleared by user")


# ----------------------------------------------------------------------
# detail page-kind determination (merge leg 3, episode-page guard fix)
# ----------------------------------------------------------------------
def _detail_page_kind(dbtype, tmdb_type, title, tvshowtitle,
                      season, episode):
    """Classify a detail page from its staged RocStage props:
    "episode", "show", or "other".

    WHY keyed off the episode-shaped props and not TmdbType alone:
    a page staged from an EPISODE item (Continue Watching, a season
    list) does not carry one reliable TmdbType — "tv" on the CW
    route, "episode" or "" elsewhere — while its episode shape IS
    constant, because stage_open copies the clicked item's own
    infolabels verbatim (_STAGE_FIELDS): DBType is "episode", and
    TVShowTitle / Season / Episode describe the EPISODE (Title may
    be the episode's own title, not the show's). A SHOW page is the
    reverse shape: TmdbType "tv", DBType "tvshow", TVShowTitle
    empty. stage_open mirroring the progress target into a show
    page's Season/Episode does NOT make it an episode page, because
    TVShowTitle stays empty there — that empty term is what keeps
    plain show pages on the show branch below. Anything else
    (movies, music items, an empty stage) is "other" and keeps the
    guarded actions' original refusal.

    The shape clause's last term (coordinator ruling, checker
    item 4): Title must DIFFER from TVShowTitle. A Helper-fed show
    row can carry TVShowTitle == its own Title, and with the target
    mirrored into Season/Episode such a page otherwise reads as an
    episode page — and the episode branch plays the STAGED S/E,
    which breaks detail_main_play's contract of recomputing the
    target fresh at click time whenever progress has moved since
    the page opened. Same string = the show's own page; a genuine
    episode page names the episode in Title and the show in
    TVShowTitle. The DBType clause above needs no such term: it is
    the primary signal and covers Helper items whose mediatype is
    episode, whatever their titles."""
    if (dbtype or "") == "episode":
        return "episode"
    if season and episode and tvshowtitle and title != tvshowtitle:
        return "episode"
    if (tmdb_type or "") == "tv":
        return "show"
    return "other"


def _staged_int(value):
    """A staged Season/Episode prop (a string) as an int; -1 when
    absent or unparseable, the same 'unknown' the snapshots carry."""
    try:
        return int(value)
    except Exception:
        return -1


def _detail_episode_play(title, tmdb_id, staged_path, tvshowtitle,
                         season_prop, episode_prop):
    """PLAY on a page staged from an EPISODE item: play THE STAGED
    EPISODE — never the show's progress target, which can be a
    different (newer) episode than the one Eric opened. Attempts,
    in order:
      (a) the staged episode IS the show's current resume target ->
          the show branch's resume machinery verbatim (per-episode
          source memory via _play_remembered first, else seek_arm +
          the Helper path), so a half-watched CW episode resumes at
          his spot with its remembered source;
      (b) the item's own plugin path (RocStage.Path) via _open_path
          — the route a normal click on the item takes. stage_open
          already diverted folders away from the detail window, so
          this Path is a playable leaf, never a directory;
      (c) the Helper play path built for exactly this episode.
    No route -> the honest cannot-play notify. Never the show-pages
    toast: this IS a TV page, just an episode-shaped one — that
    toast was the batch-2 defect (PLAY/SEASONS dead on every page
    opened from an episode item)."""
    showtitle = tvshowtitle or title
    if not showtitle:
        rc.notify("This episode cannot be played yet", ok=False)
        return False
    season = _staged_int(season_prop)
    episode = _staged_int(episode_prop)
    snap = {"showtitle": showtitle, "type": "episode",
            "season": season, "episode": episode}
    if season >= 0 and episode >= 0:
        target = rc.show_progress_target(showtitle, tmdb_id)
        if target["season"] == season and target["episode"] == episode \
                and target["kind"] == "resume" \
                and target["position"] > 0:
            path = _tmdb_play_path(snap, tmdb_id=tmdb_id or None,
                                   season=season, episode=episode)
            if not path:
                rc.notify("This episode cannot be played yet",
                          ok=False)
                return False
            entry = rc.source_for_episode(showtitle, tmdb_id or None,
                                          season, episode)
            if entry and _play_remembered(entry, snap,
                                          target["position"]):
                return True
            rc.seek_arm(target["position"],
                        "%s %s" % (showtitle, target["tag"]))
            _open_path(path)
            return True
    if staged_path.startswith("plugin://"):
        _open_path(staged_path)
        return True
    path = _tmdb_play_path(snap, tmdb_id=tmdb_id or None,
                           season=season, episode=episode)
    if path:
        _open_path(path)
        return True
    rc.notify("This episode cannot be played yet", ok=False)
    return False


# ----------------------------------------------------------------------
# resume-PLAY detail action (0.5.8, Eric Nov 1 10:07/10:32)
# ----------------------------------------------------------------------
def detail_main_play():
    """Click-time action for the show-page main button. Recomputes
    the target FRESH at click time (never trusts the stage_open-time
    label — progress may have moved since the page opened), then
    plays via _tmdb_play_path + seek_arm, the same route resume_play
    proves: Helper play, service applies the pending seek once the
    stream rolls. TV titles only; the skin does not call this for
    movies (their PLAY+RESUME pair is untouched by this build).

    Merge leg 3: a page staged from an EPISODE item is also a TV
    page — it routes to _detail_episode_play (the staged episode,
    not the show target) instead of dying on the guard below. The
    guard itself is unchanged for show pages and for everything
    that is not a TV page at all."""
    if xbmc is None or xbmcgui is None:
        return False
    try:
        win = xbmcgui.Window(11124)
        title = win.getProperty("RocStage.Title") or ""
        tmdb_id = win.getProperty("RocStage.TmdbId") or ""
        tmdb_type = win.getProperty("RocStage.TmdbType") or ""
        staged_path = win.getProperty("RocStage.Path") or ""
        dbtype = win.getProperty("RocStage.DBType") or ""
        tvshowtitle = win.getProperty("RocStage.TVShowTitle") or ""
        season_prop = win.getProperty("RocStage.Season") or ""
        episode_prop = win.getProperty("RocStage.Episode") or ""
    except Exception as exc:
        rc.log("detail_main_play: detail props unreadable: %s" % exc)
        return False
    if _detail_page_kind(dbtype, tmdb_type, title, tvshowtitle,
                         season_prop, episode_prop) == "episode":
        return _detail_episode_play(title, tmdb_id, staged_path,
                                    tvshowtitle, season_prop,
                                    episode_prop)
    if tmdb_type != "tv" or not title:
        rc.notify("This button is for show pages", ok=False)
        return False
    target = rc.show_progress_target(title, tmdb_id)
    season, episode = target["season"], target["episode"]
    snap = {"showtitle": title, "type": "episode",
            "season": season, "episode": episode}
    path = _tmdb_play_path(snap, tmdb_id=tmdb_id or None,
                           season=season, episode=episode)
    if not path:
        rc.notify("This show cannot be played yet", ok=False)
        return False
    if target["kind"] == "resume" and target["position"] > 0:
        # 0.5.15 (item 2b): Eric's exact complaint — backing out and
        # returning re-ran the whole source hunt and lost his spot.
        # If the source memory holds the source that played THIS
        # episode, go straight back to it at the saved position;
        # the Helper hunt below stays as the fallback only.
        entry = rc.source_for_episode(title, tmdb_id or None,
                                      season, episode)
        if entry and _play_remembered(entry, snap,
                                      target["position"]):
            return True
        rc.seek_arm(target["position"], "%s %s" % (title, target["tag"]))
    _open_path(path)
    # Loop 116: success toast KILLED per Eric 2026-11-02 06:49 —
    # pressing play just plays, no pop-up. Error notifies stay.
    return True


# ----------------------------------------------------------------------
# detail RESUME action (0.5.17, Stage 2 skin wiring, 2026-11-05)
# ----------------------------------------------------------------------
def _movie_resume_position(title, tmdb_id=""):
    """Newest per-title history position (seconds) for one movie,
    or 0. Matches on the normalised title; when both the detail
    page and the history snap carry a TMDb id they must agree.
    Gated by the same house floors as show_progress_target: a
    sub-45s / sub-2% blip and a finished title (>=97% or <=90s
    remaining) report no position, so the caller falls back to a
    plain play from the start. Never raises."""
    want = rc._norm_show_title(title)
    if not want:
        return 0.0
    best = None
    for e in rc._history_entries_all():
        snap = e.get("snap") or {}
        if snap.get("showtitle") or snap.get("type") == "episode":
            continue
        if rc._norm_show_title(snap.get("title") or "") != want:
            continue
        sid = str(snap.get("tmdb") or "")
        if tmdb_id and sid and sid != str(tmdb_id):
            continue
        try:
            ts = float(e.get("ts") or 0)
        except Exception:
            ts = 0.0
        if best is None or ts >= best[0]:
            best = (ts, e)
    if best is None:
        return 0.0
    e = best[1]
    try:
        position = float(e.get("position") or 0)
        duration = float(e.get("duration") or 0)
        pct = float(e.get("pct") or 0)
    except Exception:
        return 0.0
    if duration <= 0:
        pct = 0.0
    if position <= rc.SHOW_PROGRESS_FLOOR_POS or \
            pct < rc.SHOW_PROGRESS_FLOOR_PCT:
        return 0.0
    remaining = duration - position if duration > 0 else 999999.0
    if remaining <= rc.SHOW_FINISHED_REMAIN or \
            pct >= rc.SHOW_FINISHED_PCT:
        return 0.0
    return position


def detail_resume_play():
    """Click-time action for the detail page RESUME button (8002).
    Deliberately does NOT read the global resume checkpoint
    (rc.resume_load): that holds ONE title, and this page may be
    for a different title than last-played — the old 8002 route
    had the same hole the other way (PlayMedia(Path) with no seek
    at all). The position comes from the per-title history for
    THIS title — show_progress_target for TV, _movie_resume_
    position for movies — and the source from the per-title source
    memory for THIS title/episode. When memory holds the source,
    replay it directly at the position via _play_remembered; a
    source that will not start falls through to the old behaviour.
    Fallback is exactly the button's old behaviour — PlayMedia
    (RocStage.Path) — with the seek armed when a position is
    known, so the service lands the playhead at the resume spot.
    No props / no path / no position: plain PlayMedia(Path) or a
    notify, never a crash."""
    if xbmc is None or xbmcgui is None:
        return False
    try:
        win = xbmcgui.Window(11124)
        title = win.getProperty("RocStage.Title") or ""
        tmdb_id = win.getProperty("RocStage.TmdbId") or ""
        tmdb_type = win.getProperty("RocStage.TmdbType") or ""
        path = win.getProperty("RocStage.Path") or ""
    except Exception as exc:
        rc.log("detail_resume_play: detail props unreadable: %s" % exc)
        return False
    if not title or not path:
        rc.notify("Nothing to resume here", ok=False)
        return False
    if tmdb_type == "tv":
        target = rc.show_progress_target(title, tmdb_id)
        season, episode = target["season"], target["episode"]
        position = target["position"]
        snap = {"showtitle": title, "type": "episode",
                "season": season, "episode": episode,
                "tmdb": tmdb_id or ""}
        entry = rc.source_for_episode(title, tmdb_id or None,
                                      season, episode)
        display = "%s %s" % (title, target["tag"])
    else:
        position = _movie_resume_position(title, tmdb_id)
        snap = {"title": title, "type": "movie",
                "tmdb": tmdb_id or ""}
        entry = rc.source_load_for(snap)
        display = title
    if entry and position > 0 and _play_remembered(entry, snap, position):
        rc.notify("Resuming %s" % display[:60])
        return True
    if position > 0:
        rc.seek_arm(position, display)
    xbmc.executebuiltin("PlayMedia(%s)" % path)
    return True


# ----------------------------------------------------------------------
# detail SEASONS action (0.5.9, Loop 81 skin wiring)
# ----------------------------------------------------------------------
def detail_seasons():
    """Detail-driven season/episode picker for a show page. Unlike
    episodes_panel() (which needs something PLAYING), this reads the
    detail window's own RocStage props and drives _panel_tv() with a
    synthetic snap, so it works from the detail page with nothing
    playing. TV titles only; the skin gates the button the same way
    (TV title, TmdbId present; hidden only where the RESUME button shows).

    Merge leg 3: on a page staged from an EPISODE item the picker
    is for the episode's SHOW, so it drives _panel_tv with the same
    snap shape as the show branch, keyed on TVShowTitle (Title is
    the episode's own title there and would resolve the wrong — or
    no — show). The one episode shape that keeps the refusal: no
    TVShowTitle AND not TV-staged, because then no prop on the page
    names the show at all."""
    if xbmc is None or xbmcgui is None:
        return False
    try:
        win = xbmcgui.Window(11124)
        title = win.getProperty("RocStage.Title") or ""
        tmdb_id = win.getProperty("RocStage.TmdbId") or ""
        tmdb_type = win.getProperty("RocStage.TmdbType") or ""
        dbtype = win.getProperty("RocStage.DBType") or ""
        tvshowtitle = win.getProperty("RocStage.TVShowTitle") or ""
        season_prop = win.getProperty("RocStage.Season") or ""
        episode_prop = win.getProperty("RocStage.Episode") or ""
    except Exception as exc:
        rc.log("detail_seasons: detail props unreadable: %s" % exc)
        return False
    if _detail_page_kind(dbtype, tmdb_type, title, tvshowtitle,
                         season_prop, episode_prop) == "episode" \
            and (tvshowtitle or tmdb_type == "tv"):
        showtitle = tvshowtitle or title
        if not showtitle:
            rc.notify("This button is for show pages", ok=False)
            return False
        snap = {"showtitle": showtitle, "type": "episode",
                "season": -1, "episode": -1, "tmdb": tmdb_id}
        _panel_tv(snap)
        return True
    if tmdb_type != "tv" or not title or not tmdb_id:
        rc.notify("This button is for show pages", ok=False)
        return False
    snap = {"showtitle": title, "type": "episode",
            "season": -1, "episode": -1, "tmdb": tmdb_id}
    _panel_tv(snap)
    return True


# ----------------------------------------------------------------------
# episodes / collection panel (item 4)
# ----------------------------------------------------------------------
def _library_watched():
    """Watched-state sets from the local library: IMDb ids of watched
    movies, (title, year) of watched movies, and (showtitle, season,
    episode) of watched episodes. Watched state is only marked where
    this data actually exists — plugin plays leave no trace here."""
    watched_ids, watched_eps, watched_titles = set(), set(), set()
    try:
        res = rc._rpc("VideoLibrary.GetMovies", {
            "properties": ["imdbnumber", "playcount", "title", "year"]})
        for m in (res.get("movies") or []):
            if m.get("playcount", 0) > 0:
                if m.get("imdbnumber"):
                    watched_ids.add(str(m["imdbnumber"]))
                watched_titles.add(((m.get("title") or "").lower(),
                                    m.get("year", 0)))
        res = rc._rpc("VideoLibrary.GetEpisodes", {
            "properties": ["showtitle", "season", "episode", "playcount"]})
        for e in (res.get("episodes") or []):
            if e.get("playcount", 0) > 0:
                watched_eps.add(((e.get("showtitle") or "").lower(),
                                 e.get("season", -1), e.get("episode", -1)))
    except Exception as exc:
        rc.log("watched lookup failed: %s" % exc)
    return watched_ids, watched_eps, watched_titles


def _pick_dialog(heading, items):
    """items: list of (label, label2, icon). Returns index or -1."""
    lis = []
    for label, label2, icon in items:
        li = xbmcgui.ListItem(label=label, label2=label2)
        if icon:
            li.setArt({"thumb": icon})
        lis.append(li)
    return xbmcgui.Dialog().select(heading, lis, useDetails=True)


def _origin_template_play(snap, season=None, episode=None, tmdb_id=None):
    """Play a sibling (another episode / another collection part)
    through the ORIGINATING addon's play entry when its URL pattern
    is recoverable: substitute the season/episode or tmdb_id params
    in the path the current title was launched with. Returns True
    when a route fired."""
    path = snap.get("path") or ""
    if not path.startswith("plugin://"):
        return False
    new = path
    if season is not None:
        new2 = re.sub(r"([?&]season=)\d+", r"\g<1>%d" % season, new)
        new2 = re.sub(r"([?&]s=)\d+", r"\g<1>%d" % season, new2)
        if new2 != new:
            new = new2
    if episode is not None:
        new2 = re.sub(r"([?&]episode=)\d+", r"\g<1>%d" % episode, new)
        new2 = re.sub(r"([?&]e=)\d+", r"\g<1>%d" % episode, new2)
        if new2 != new:
            new = new2
    if tmdb_id is not None:
        new2 = re.sub(r"([?&]tmdb_id=)\d+", r"\g<1>%s" % tmdb_id, new)
        if new2 != new:
            new = new2
    if new != path:
        rc.log("episodes_panel: origin template %s" % new[:120])
        xbmc.executebuiltin("PlayMedia(%s)" % new)
        return True
    if "plugin.video.themoviedb.helper" in path:
        # Launched via TMDb Helper but params didn't match the
        # substitution patterns; its canonical play path is the
        # same door with the same rules.
        tp = _tmdb_play_path(snap, tmdb_id=tmdb_id,
                              season=season, episode=episode)
        if tp:
            _open_path(tp)
            return True
    return False


def _panel_tv(snap):
    tmdb_id = rc.snapshot_tmdb_id(snap)
    if not tmdb_id:
        rc.notify("No show data for this one", ok=False)
        return
    show = rc.tmdb_get("tv/%s" % tmdb_id)
    if not show:
        rc.notify("Show data did not load", ok=False)
        return
    seasons = [s for s in (show.get("seasons") or [])
               if s.get("season_number", 0) > 0]
    seasons.sort(key=lambda s: s["season_number"])
    if not seasons:
        rc.notify("No seasons found", ok=False)
        return
    cur_s = snap.get("season", -1)
    items = []
    for s in seasons:
        mark = "  (you are here)" if s["season_number"] == cur_s else ""
        items.append(("Season %d%s" % (s["season_number"], mark),
                      "%d episodes" % (s.get("episode_count") or 0), ""))
    idx = _pick_dialog(show.get("name") or snap["showtitle"], items)
    if idx < 0:
        return
    season_no = seasons[idx]["season_number"]
    data = rc.tmdb_get("tv/%s/season/%d" % (tmdb_id, season_no))
    episodes = (data or {}).get("episodes") or []
    if not episodes:
        rc.notify("Episodes did not load", ok=False)
        return
    _, watched_eps, _ = _library_watched()
    show_key = (snap.get("showtitle") or show.get("name") or "").lower()
    items = []
    for ep in episodes:
        eno = ep.get("episode_number", 0)
        label = "%d. %s" % (eno, ep.get("name") or "Episode %d" % eno)
        if season_no == cur_s and eno == snap.get("episode", -1):
            label += "  (playing)"
        elif (show_key, season_no, eno) in watched_eps:
            label += "  (watched)"
        still = ep.get("still_path") or ""
        icon = ("https://image.tmdb.org/t/p/w300" + still) if still else ""
        items.append((label, ep.get("air_date") or "", icon))
    idx = _pick_dialog("Season %d" % season_no, items)
    if idx < 0:
        return
    ep_no = episodes[idx].get("episode_number", 0)
    if season_no == cur_s and ep_no == snap.get("episode", -1):
        return
    if _origin_template_play(snap, season=season_no, episode=ep_no):
        return
    tp = _tmdb_play_path(snap, tmdb_id=tmdb_id,
                         season=season_no, episode=ep_no)
    if tp:
        _open_path(tp)
        return
    rc.notify("This episode cannot be opened from here", ok=False)


def _panel_movie(snap):
    tmdb_id = rc.snapshot_tmdb_id(snap)
    if not tmdb_id:
        rc.notify("No collection data for this one", ok=False)
        return
    detail = rc.tmdb_get("movie/%s" % tmdb_id)
    coll = (detail or {}).get("belongs_to_collection") or {}
    if not coll.get("id"):
        rc.notify("This movie is not part of a collection", ok=False)
        return
    data = rc.tmdb_get("collection/%d" % coll["id"])
    parts = [p for p in ((data or {}).get("parts") or [])
             if p.get("release_date")]
    parts.sort(key=lambda p: p["release_date"])
    if len(parts) < 2:
        rc.notify("No other parts in this collection", ok=False)
        return
    _, _, watched_titles = _library_watched()
    items = []
    for p in parts:
        label = p.get("title") or ""
        if str(p.get("id")) == str(tmdb_id):
            label += "  (playing)"
        elif ((p.get("title") or "").lower(),
              int((p.get("release_date") or "0")[:4] or 0)) in watched_titles:
            label += "  (watched)"
        poster = p.get("poster_path") or ""
        icon = ("https://image.tmdb.org/t/p/w185" + poster) if poster else ""
        items.append((label, (p.get("release_date") or "")[:4], icon))
    idx = _pick_dialog(coll.get("name") or "Collection", items)
    if idx < 0:
        return
    part = parts[idx]
    if str(part.get("id")) == str(tmdb_id):
        return
    if _origin_template_play(snap, tmdb_id=str(part["id"])):
        return
    tp = _tmdb_play_path({"title": part.get("title") or "",
                          "showtitle": "", "type": "movie"},
                         tmdb_id=str(part["id"]))
    if tp:
        _open_path(tp)
        return
    rc.notify("That part cannot be opened from here", ok=False)


def episodes_panel():
    snap = rc.now_playing_snapshot()
    if not snap:
        rc.notify("Nothing is playing", ok=False)
        return
    if snap.get("showtitle") or snap.get("type") == "episode":
        _panel_tv(snap)
    else:
        _panel_movie(snap)
