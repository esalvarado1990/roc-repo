# -*- coding: utf-8 -*-
"""
script.rocui -- Internet Archive doors (ARCHIVE FIX 2026-11-09).

In-house replacement for plugin.video.iatheater's load-bearing
surface (see ARCHIVE-FIX-PLAN.md): keyword search, item expansion,
click-and-play resolution, the Fringe root menu, and the baked
Classic Looney Tunes shelf -- all over archive.org's DOCUMENTED
public APIs, called directly:

  * Advanced Search:  https://archive.org/advancedsearch.php
    (the retired add-on searched through the undocumented internal
    beta endpoint services/search/beta/page_production/ instead)
  * Metadata API:     https://archive.org/metadata/<identifier>
  * Thumbnails:       https://archive.org/services/img/<identifier>
  * Downloads:        https://archive.org/download/<id>/<file>
    (or https://<workable_server><dir>/<file> from the item's own
    metadata, the shape the retired add-on resolved)

Plain urllib + a User-Agent header, 20 s timeouts, and a small TTL
JSON cache in rocui's profile data (the AUGUST_MUSIC_CACHE pattern
in rocui_common). No key, no account, no login.

Ported from the retired add-on (read firsthand, main.py):
  * _has_playable_media -- the format-marker check, verbatim lists;
  * the movie/tv NOT-lists + duration floors (movie >= 45 min,
    tv >= 5 min) -- applied ONLY to interactive search results
    (plan step 1: the baked panels keep pure keyword semantics, so
    sports / Tech N9ne rows do not change character); in-house the
    interactive video search carries the movie NOT-list in the
    query itself (the add-on's own technique) and the 45-minute
    floor client-side;
  * the episode/track filename grouping regexes (for ia_item
    labels);
  * the seeded collection lists (feature_films, film_noir,
    SciFi_Horror, animationandcartoons, vhsvault, etree, 78rpm...)
    as data (COLLECTIONS below).

NOT ported (plan section 1): the add-on's own resume store /
Continue Watching (superseded by rocui's history store), favorites,
downloads, search history, and the 1.5 s splash screen.

File pick rule (deterministic, no dialog -- CLICK-AND-PLAY):
video prefers source=original files, then h.264/.mp4, then the
greatest height; audio prefers .mp3/.flac by size.
"""
import hashlib
import json
import os
import re
import time
import urllib.parse
import urllib.request
from html import unescape

try:
    import rocui_common as rc
except Exception:  # outside the addon (harness) -- degrade logging
    rc = None

BASE_URL = "https://archive.org/"
ADV_SEARCH_URL = BASE_URL + "advancedsearch.php"
METADATA_URL = BASE_URL + "metadata/%s"
IMG_URL = BASE_URL + "services/img/%s"
DOWNLOAD_URL = BASE_URL + "download/%s/%s"
UA = "RocOS/1.0 (script.rocui; Internet Archive doors)"
TIMEOUT = 20
CACHE_FILE = "ia_cache.json"
CACHE_TTL = 3600  # seconds

LT_IDENTIFIER = "ltmm-publicdomain"

VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.mov', '.m4v', '.vob', '.iso',
              '.wmv', '.mpg', '.mpeg', '.flv', '.m2ts', '.ts', '.webm',
              '.ogv')
AUDIO_EXTS = ('.mp3', '.flac', '.ogg', '.m4a', '.wav', '.opus',
              '.aac', '.wma', '.aiff', '.aif', '.shn', '.m4b', '.ape',
              '.wv', '.iso')
# Ported verbatim from the retired add-on's Main.__init__.
VIDEO_MARKERS = ['mp4', 'mkv', 'avi', 'mov', 'm4v', 'h.264', 'h264',
                 'mpeg', 'matroska', 'vp8', 'vp9', 'webm', 'vob',
                 'iso', 'wmv', 'mpg', 'flv', 'm2ts', 'ts', 'ogv']
AUDIO_MARKERS = ['mp3', 'flac', 'ogg', 'm4a', 'wav', 'vorbis',
                 'audio', 'opus', 'aac', 'wma', 'aiff', 'aif', 'shn',
                 'm4b', 'ape', 'wv', 'iso']

# Ported verbatim from search_word()'s movie/tv branches.
NOT_MOVIE = ('(trailer OR teaser OR promo OR clip OR snippet OR '
             '"short film" OR sample OR review OR intro OR menu OR '
             'extras OR bonus OR preview OR previews OR fandub OR '
             '"fan dub" OR "fan edit" OR "fan project" OR '
             '"screen recording")')
NOT_TV = ('(promo OR clip OR commercial OR bumper OR advert OR '
          '"tv spot" OR teaser OR trailer OR intro OR menu OR '
          'extras OR bonus OR preview OR previews OR fandub OR '
          '"fan dub" OR "fan edit" OR "fan project" OR '
          '"screen recording")')
MOVIE_FLOOR_MIN = 45.0
TV_FLOOR_MIN = 5.0

# Ported collection lists (the add-on's cat_video / cat_audio seed
# data): (slug, label, sublabel, media).
COLLECTIONS = [
    ("feature_films", "Feature Films", "Classic full length movies",
     "video"),
    ("film_noir", "Film Noir", "Classic film noir", "video"),
    ("SciFi_Horror", "Sci-Fi / Horror", "Sci-Fi and Horror films",
     "video"),
    ("animationandcartoons", "Animation & Cartoons",
     "Classic cartoons", "video"),
    ("vhsvault", "The VHS Vault", "Raw VHS captures and preservation",
     "video"),
    ("opensource_movies", "Community Video",
     "General video and movie uploads", "video"),
    ("classic_tv", "Classic TV", "Vintage television broadcasts",
     "video"),
    ("comedy_films", "Comedy Films", "Comedy films", "video"),
    ("bmovies", "B-Movies", "B-movie classics", "video"),
    ("etree", "Live Music Archive (Concerts)",
     "Lossless concert recordings", "audio"),
    ("78rpm", "78 RPMs & Cylinder Recordings",
     "Vintage 78 RPM records", "audio"),
    ("opensource_audio", "Community Audio",
     "Uncurated audio and music uploads", "audio"),
    ("album_recordings", "Long Playing Records (Vinyl)",
     "Vinyl LP preservation project", "audio"),
    ("netlabels", "Netlabels (Indie Albums)",
     "Independent netlabel releases", "audio"),
    ("podcasts", "Podcasts & Radio", "Podcasts and radio broadcasts",
     "audio"),
]

# Ported episode/track grouping regexes (expand_item labels).
_RE_S_E = re.compile(r's\s*(\d+)[._ -]*e\s*(\d+)')
_RE_X = re.compile(r'(\d+)\s*x\s*(\d+)')
_RE_EP = re.compile(r'(?:ep|episode)[._ -]*(\d+)')
_RE_TRACK = re.compile(r'^(?:track\s*)?(\d{1,3})[\s._-]')


def _log(msg):
    if rc is not None:
        try:
            rc.log("ia: %s" % msg)
            return
        except Exception:
            pass


def _safe_int(val):
    try:
        return int(float(val))
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------
# HTTP + TTL JSON cache (profile data, rocui_common helpers)
# ---------------------------------------------------------------------------
def _fetch_json(url):
    """GET one URL as JSON. None on any failure -- never raises.
    This is the single HTTP choke point (harnesses stub it)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8", "replace"))
    except Exception as exc:
        _log("fetch failed %s: %s" % (url[:120], exc))
        return None


def _cache_get(key):
    if rc is None:
        return None
    try:
        store = rc._read_json(CACHE_FILE)
        entry = (store or {}).get(key)
        if not entry:
            return None
        if time.time() - float(entry.get("ts") or 0) > CACHE_TTL:
            return None
        return entry.get("data")
    except Exception:
        return None


def _cache_set(key, data):
    if rc is None:
        return
    try:
        store = rc._read_json(CACHE_FILE) or {}
        store[key] = {"ts": time.time(), "data": data}
        rc._write_json(CACHE_FILE, store)
    except Exception:
        pass


def _cached_fetch(url):
    key = "u:" + hashlib.sha1(url.encode("utf-8")).hexdigest()
    hit = _cache_get(key)
    if hit is not None:
        return hit
    data = _fetch_json(url)
    if data is not None:
        _cache_set(key, data)
    return data


# ---------------------------------------------------------------------------
# Junk filters, ported from the retired add-on
# ---------------------------------------------------------------------------
def _has_playable_media(fields, content_type):
    """The add-on's format check, ported: a hit with NO format field
    passes (its own rule); otherwise the format list must carry a
    marker for the requested content type."""
    formats = (fields or {}).get('format', [])
    if not formats:
        return True
    if isinstance(formats, str):
        formats = [formats]
    formats_str = " ".join(str(f).lower() for f in formats)
    if content_type == 'video':
        return any(m in formats_str for m in VIDEO_MARKERS)
    if content_type == 'audio':
        return any(m in formats_str for m in AUDIO_MARKERS)
    return any(m in formats_str for m in VIDEO_MARKERS + AUDIO_MARKERS)


def _parse_duration_to_minutes(duration_data):
    """Ported: numeric values are SECONDS; 'H:MM:SS'/'MM:SS' strings
    are clock times. None when unparseable."""
    if not duration_data:
        return None
    try:
        if isinstance(duration_data, list):
            duration_data = duration_data[0]
        d_str = str(duration_data).strip()
        if d_str.replace('.', '', 1).isdigit():
            return float(d_str) / 60.0
        parts = d_str.split(':')
        if len(parts) == 3:
            return int(parts[0]) * 60 + int(parts[1]) \
                + float(parts[2]) / 60.0
        if len(parts) == 2:
            return int(parts[0]) + float(parts[1]) / 60.0
    except Exception:
        pass
    return None


def _is_collection_doc(doc):
    mediatypes = (doc or {}).get('mediatype', [])
    if isinstance(mediatypes, list):
        return any('collection' in str(m).lower() for m in mediatypes)
    return 'collection' in str(mediatypes).lower()


def _first(value):
    if isinstance(value, list):
        return value[0] if value else ''
    return value or ''


# ---------------------------------------------------------------------------
# Advanced Search (documented API)
# ---------------------------------------------------------------------------
def build_adv_query(q, media, collection=None, interactive=False):
    """The advancedsearch q string for one door. Keyword semantics
    are the baked panels' own (collections=none == search
    everything); a collection door scopes with collection:<slug>;
    the mediatype clause is the door's own media kind. Interactive
    video searches additionally carry the ported movie NOT-list."""
    clauses = []
    q = (q or "").strip()
    if q:
        clauses.append("(%s)" % q)
    if collection:
        clauses.append("collection:%s" % collection)
    if interactive and media == "video" and q:
        clauses.append("NOT title:%s" % NOT_MOVIE)
        clauses.append("NOT subject:%s" % NOT_MOVIE)
    clauses.append("mediatype:%s" % ("audio" if media == "audio"
                                     else "movies"))
    return " AND ".join(clauses)


def adv_search(q, media="video", page=1, collection=None,
               interactive=False):
    """One advancedsearch.php page -> {'docs': [...], 'total': int}
    (RAW docs, unfiltered), or None when the API does not answer."""
    query = build_adv_query(q, media, collection, interactive)
    params = [("q", query),
              ("fl[]", "identifier"), ("fl[]", "title"),
              ("fl[]", "description"), ("fl[]", "format"),
              ("fl[]", "mediatype"), ("fl[]", "year"),
              ("fl[]", "duration"), ("fl[]", "length"),
              ("rows", "100"), ("page", str(max(1, int(page or 1)))),
              ("output", "json")]
    url = ADV_SEARCH_URL + "?" + urllib.parse.urlencode(params)
    data = _cached_fetch(url)
    if not isinstance(data, dict):
        return None
    resp = data.get("response") or {}
    return {"docs": resp.get("docs") or [],
            "total": _safe_int(resp.get("numFound"))}


def search_items(q, media="video", page=1, collection=None,
                 interactive=False):
    """Filtered search rows for one directory page:
    {'items': [{identifier, title, plot, year}], 'total': int,
     'error': bool}. _has_playable_media always applies; the
    duration floors apply ONLY when interactive (plan step 1)."""
    data = adv_search(q, media, page, collection, interactive)
    if data is None:
        return {"items": [], "total": 0, "error": True}
    content_type = "audio" if media == "audio" else "video"
    items = []
    for doc in data["docs"]:
        if not isinstance(doc, dict):
            continue
        is_coll = _is_collection_doc(doc)
        if not is_coll and not _has_playable_media(doc, content_type):
            continue
        if interactive and not is_coll and media == "video":
            dur = _parse_duration_to_minutes(
                doc.get('duration') or doc.get('length'))
            if dur is not None and dur < MOVIE_FLOOR_MIN:
                continue
        ident = _first(doc.get('identifier'))
        if not ident:
            continue
        title = _first(doc.get('title')) or ident
        plot = _first(doc.get('description'))
        try:
            plot = unescape(plot) if plot else ''
        except Exception:
            plot = plot or ''
        items.append({
            "identifier": ident,
            "title": title,
            "plot": plot,
            "year": _safe_int(_first(doc.get('year'))) or None,
            "is_collection": is_coll,
            "thumb": IMG_URL % urllib.parse.quote(str(ident), safe=""),
        })
    return {"items": items, "total": data["total"], "error": False}


# ---------------------------------------------------------------------------
# Metadata API: item expansion + playback resolution
# ---------------------------------------------------------------------------
def item_metadata(identifier):
    """The item's full Metadata API record (TTL-cached), or None."""
    if not identifier:
        return None
    data = _cached_fetch(METADATA_URL % urllib.parse.quote(
        str(identifier), safe=""))
    return data if isinstance(data, dict) else None


def episode_tag(filename):
    """Ported grouping tag: SxxEyy / EPnn / Track nnn, else the
    cleaned filename stem."""
    clean = (filename or "").split('/')[-1].lower()
    m = _RE_S_E.search(clean)
    if m:
        return "S%02dE%02d" % (int(m.group(1)), int(m.group(2)))
    m = _RE_X.search(clean)
    if m:
        return "S%02dE%02d" % (int(m.group(1)), int(m.group(2)))
    m = _RE_EP.search(clean)
    if m:
        return "EP%02d" % int(m.group(1))
    m = _RE_TRACK.search(clean)
    if m:
        return "Track %03d" % int(m.group(1))
    return clean.rsplit('.', 1)[0]


def clean_file_label(file_dict):
    """ia_item row label: the file's own title tag when the metadata
    carries one, else its cleaned filename."""
    title = (file_dict or {}).get('title')
    if isinstance(title, list):
        title = title[0] if title else ''
    if title:
        return str(title)
    name = (file_dict or {}).get('name') or ''
    return episode_tag(name)


def playable_files(identifier, media="video"):
    """The item's playable files (metadata order), each a plain dict
    {name, title, size, height, source, format}. The retired add-on
    excluded IA derivatives ('.ia.' in the name) from expand_item;
    that exclusion is NOT ported -- derivatives are legitimate
    encodes and the deterministic pick ranks them (an original
    always beats its derivative)."""
    jd = item_metadata(identifier)
    if not jd or 'files' not in jd:
        return []
    exts = AUDIO_EXTS if media == "audio" else VIDEO_EXTS
    out = []
    for f in jd.get('files') or []:
        name = f.get('name') or ''
        if not name.lower().endswith(exts):
            continue
        out.append({
            "name": name,
            "title": f.get('title') or '',
            "size": _safe_int(f.get('size')),
            "height": _safe_int(f.get('height')),
            "source": str(f.get('source') or ''),
            "format": str(f.get('format') or ''),
        })
    out.sort(key=lambda f: f["name"].lower())
    return out


def pick_file(files, media="video"):
    """Deterministic click-and-play pick (no dialog). Video:
    original source first, then h.264/.mp4, then greatest height
    (size breaks ties). Audio: .mp3/.flac first, by size."""
    if not files:
        return None
    if media == "audio":
        def audio_key(f):
            name = f["name"].lower()
            pref = 0 if (name.endswith(".mp3")
                         or name.endswith(".flac")) else 1
            return (pref, -int(f.get("size") or 0), name)
        return sorted(files, key=audio_key)[0]

    def video_key(f):
        name = f["name"].lower()
        original = 0 if str(f.get("source") or "").lower() \
            == "original" else 1
        h264 = 0 if ("h.264" in str(f.get("format") or "").lower()
                     or name.endswith(".mp4")) else 1
        return (original, h264, -int(f.get("height") or 0),
                -int(f.get("size") or 0), name)
    return sorted(files, key=video_key)[0]


def download_url(identifier, filename, metadata=None):
    """https URL for one file of one item: the metadata's own
    workable server + dir when known (the retired add-on's shape),
    else the canonical archive.org/download form."""
    quoted = urllib.parse.quote(str(filename), safe="/")
    jd = metadata
    if jd:
        servers = jd.get('workable_servers') or []
        item_dir = jd.get('dir') or ''
        if servers and item_dir:
            return "https://%s%s/%s" % (servers[0], item_dir, quoted)
    return DOWNLOAD_URL % (urllib.parse.quote(str(identifier),
                                              safe=""), quoted)


def resolve_url(identifier, filename=None, media="video"):
    """Resolve one play to an https archive.org URL, or None.
    An explicit filename is honored when it names a real file of
    the item (the LT shelf passes the short's original encode, with
    the .ia.mp4 derivative as the resolve-time fallback per plan);
    otherwise the deterministic pick decides."""
    jd = item_metadata(identifier)
    if not jd or 'files' not in jd:
        return None
    files = playable_files(identifier, media)
    if not files:
        return None
    chosen = None
    if filename:
        for f in files:
            if f["name"] == filename:
                chosen = f
                break
        if chosen is None and str(filename).endswith(".mp4"):
            # LT fallback: original missing -> its h.264 derivative
            deriv = filename[:-4] + ".ia.mp4"
            for f in files:
                if f["name"] == deriv:
                    chosen = f
                    break
    if chosen is None:
        chosen = pick_file(files, media)
    if chosen is None:
        return None
    return download_url(identifier, chosen["name"], jd)


# ---------------------------------------------------------------------------
# Classic Looney Tunes shelf (baked dataset, plan section 4)
# ---------------------------------------------------------------------------
_LT_MEM = [None]


def lt_shorts():
    """Rows of resources/data/lt_shorts.json (module-relative, the
    toonime_shelves pattern): [{title, year, file, derivative,
    thumb, thumb_url, note}]. [] when the dataset is missing or
    unparseable -- the shelf then reads empty, never stale."""
    if _LT_MEM[0] is not None:
        return _LT_MEM[0]
    rows = []
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "resources", "data", "lt_shorts.json")
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        shorts = data.get("shorts") if isinstance(data, dict) else data
        if isinstance(shorts, list):
            rows = [r for r in shorts if isinstance(r, dict)
                    and r.get("file")]
    except Exception as exc:
        _log("lt_shorts load failed: %s" % exc)
    _LT_MEM[0] = rows
    return rows
