# -*- coding: utf-8 -*-
"""
script.rocui — WWE Timeline plugin source (Phase 3).

Serves the 447-event WWF/WWE PPV/PLE index to the War Room scrubber
(skin window 1113) as container content:

  plugin://script.rocui/                      -> the years (scrubber rail)
  plugin://script.rocui/?mode=years           -> same
  plugin://script.rocui/?mode=year&year=1998  -> that year's events,
                                                 date order

Year items are real destinations (v3.1.0 Simple Line — Eric,
2026-10-24 02:29/02:47): each year item's path is this same source at
?mode=year&year=YYYY, so clicking a year opens that year's events by
plain plugin navigation. (The v3.0 design used EMPTY paths + a service
focus sync publishing a window property the events pane read; on real
hardware the clicks were dead and the pane froze on the default year.
That machinery is gone from the flow — no Latest-year landing anywhere.)

Event items point at Purely Wrestling's root (plugin.video
.purelywrestling) as folders: selecting one routes there, per the
Phase 3 spec. A per-event deep-link search inside the wrestling addons
is a later refinement and is NOT claimed here.

All data comes from rocui_common's timeline functions over the shipped
resources/data/ppv_events.json — this file is only the xbmc wrapper.
"""
import sys
from urllib.parse import parse_qsl

import xbmcgui
import xbmcplugin

import rocui_common as rc

PURELY_ROOT = "plugin://plugin.video.purelywrestling/"
BADGE_ART = "special://skin/media/rocos-badge-gold.png"


def _params(query):
    if query.startswith("?"):
        query = query[1:]
    return dict(parse_qsl(query))


def build_years(handle, events):
    """One item per year, ascending; each is a folder into that year's
    events (its own ?mode=year path). Label2 carries the era, labeled
    era-correct: WWF for the pre-rename years, WWE after (Eric,
    2026-10-24 02:49). Returns the item count."""
    count = 0
    for year, num in rc.timeline_years(events):
        item = xbmcgui.ListItem(label=str(year))
        item.setLabel2("%s - %d EVENTS" % (rc.timeline_year_era(year), num))
        item.setProperty("year", str(year))
        item.setProperty("era", rc.timeline_year_era(year))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(
            handle, "plugin://script.rocui/?mode=year&year=%s" % year,
            item, True)
        count += 1
    return count


def build_year(handle, events, year):
    """One year's events in date order. Returns the item count."""
    count = 0
    for event in rc.timeline_events_for_year(events, year):
        pretty = rc.format_event_date(event["date"])
        item = xbmcgui.ListItem(label=str(event["name"]))
        item.setLabel2("%s - %s" % (pretty, event.get("promotion", "")))
        item.setProperty("date", str(event["date"]))
        item.setProperty("promotion", str(event.get("promotion", "")))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, PURELY_ROOT, item, True)
        count += 1
    return count


# ---------------------------------------------------------------------------
# v3.4.0 — THE LOOK PASS: stage Collections row + history shelves.
#
#   ?mode=collections&cat=home|movies|tv|wrestling|toonime|sports|music
#       -> Eric's named collections for that stage category (rocui_common
#          COLLECTIONS: his Trakt lists, the Classics catalog, the
#          wrestling eras, horror, Herbie — nothing he didn't name).
#   ?mode=collection&id=<id>
#       -> one collection's members: named titles via TMDb Helper
#          search, era years via the timeline's own year folders.
#   ?mode=history&src=<tokens>   -> the per-profile playback history
#   ?mode=continue&src=<tokens>  -> the same store, unfinished only
#       (Adult shelves pass src=cumination; the stage's per-category
#       Continue Watching passes its addons' tokens.)
# ---------------------------------------------------------------------------
def build_collections(handle, cat):
    count = 0
    for tile in rc.collections_for(cat):
        item = xbmcgui.ListItem(label=tile["label"])
        item.setLabel2(tile["sub"])
        item.setInfo("video", {"plot": tile["plot"]})
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, tile["path"], item, True)
        count += 1
    return count


def build_collection(handle, cid, events):
    count = 0
    for row in rc.collection_detail(cid, events):
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, row["path"], item, True)
        count += 1
    return count


def build_history(handle, src, continue_only):
    count = 0
    for entry in rc.history_filtered(src, continue_only):
        snap = entry.get("snap") or {}
        label = rc.snapshot_display(snap) or snap.get("title") or ""
        if not label:
            continue
        pct = float(entry.get("pct") or 0)
        when = ""
        try:
            import datetime as _dt
            when = _dt.datetime.fromtimestamp(
                float(entry.get("ts") or 0)).strftime("%b %d")
        except Exception:
            when = ""
        label2 = "LEFT OFF %s OF %s%s" % (
            rc.fmt_clock(entry.get("position") or 0),
            rc.fmt_clock(entry.get("duration") or 0),
            (" - " + when) if when else "")
        if pct >= 97.0:
            label2 = "WATCHED IN FULL%s" % ((" - " + when) if when else "")
        item = xbmcgui.ListItem(label=label)
        item.setLabel2(label2)
        item.setProperty("IsPlayable", "true")
        art = {}
        if snap.get("thumb"):
            art["thumb"] = snap["thumb"]
        if snap.get("fanart"):
            art["fanart"] = snap["fanart"]
        if art:
            item.setArt(art)
        xbmcplugin.addDirectoryItem(handle, snap.get("path") or "",
                                    item, False)
        count += 1
    return count


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    handle = int(argv[1]) if len(argv) > 1 else -1
    params = _params(argv[2] if len(argv) > 2 else "")
    events = rc.load_timeline()
    xbmcplugin.setContent(handle, "videos")
    mode = params.get("mode")
    if mode == "year":
        build_year(handle, events, params.get("year"))
    elif mode == "collections":
        build_collections(handle, params.get("cat", "home"))
    elif mode == "collection":
        build_collection(handle, params.get("id", ""), events)
    elif mode == "history":
        build_history(handle, params.get("src", ""), False)
    elif mode == "continue":
        build_history(handle, params.get("src", ""), True)
    else:
        build_years(handle, events)
    xbmcplugin.endOfDirectory(handle)


if __name__ == "__main__":
    main()
