# -*- coding: utf-8 -*-
"""
Roc UI helper (script.rocui) — shared logic for Roc OS Phase 2.

Owns the three things skin XML cannot do honestly:
  1. The Adult PIN gate (salted PBKDF2 hash only — the PIN itself is never
     stored, never logged, and is set by Eric on the device at first use).
  2. The Day/Midday/Night clock (automatic by local time; the dock button
     becomes a manual override that holds until the next light change).
  3. Focus memory (last focused control per window, restored on return) and
     the VPN status surface hook (see the marked section below).

Kodi imports are guarded so this module can be imported and unit-tested
outside Kodi (validation harness) without crashing.
"""
import base64
import datetime
import hashlib
import hmac
import json
import os
import re
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:  # outside Kodi (tests) — functions degrade to no-ops
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None

ADDON_ID = "script.rocui"
SKIN_ID = "skin.rocos"
MODE_SKIN_STRING = "RocOS.Mode"           # Night | Midday | Day (Phase 1 string)
MODE_SOURCE_STRING = "RocOS.ModeSource"   # Auto | Manual (Phase 2)
HOME_WINDOW_ID = 10000

# Daypart bands (local time): Day 07:00-15:59, Midday 16:00-19:59,
# Night 20:00-06:59. "Midday" is the warm transitional band in this house.
DAYPART_BOUNDARIES = [(7, "Day"), (16, "Midday"), (20, "Night")]

PIN_ITERATIONS = 200000
PIN_MIN_LEN = 4
PIN_MAX_LEN = 8

# Windows where focus restore is pointless or harmful (fullscreen players,
# busy/startup surfaces). Everything else gets focus memory.
FOCUS_SKIP_WINDOWS = {0, 12005, 12006, 12009, 12900}


# --------------------------------------------------------------------------
# small utilities
# --------------------------------------------------------------------------
def log(msg, level=None):
    if xbmc is None:
        return
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg),
                 xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


def _data_dir():
    """Addon profile data dir (created on demand). '' when not in Kodi."""
    if xbmcvfs is None:
        return ""
    try:
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(path):
            os.makedirs(path)
        return path
    except Exception as exc:
        log("data dir failed: %s" % exc)
        return ""


def _read_json(name):
    path = os.path.join(_data_dir(), name) if _data_dir() else ""
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        log("read %s failed: %s" % (name, exc))
        return {}


def _write_json(name, data):
    path = os.path.join(_data_dir(), name) if _data_dir() else ""
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log("write %s failed: %s" % (name, exc))
        return False


def notify(message, ms=4500):
    """Plain-words notification. NOTE: builtin args split on commas —
    messages here must never contain one."""
    if xbmc is None:
        return
    try:
        xbmc.executebuiltin("Notification(Roc OS,%s,%d)" % (message, ms))
    except Exception:
        pass


# --------------------------------------------------------------------------
# skin strings (the skin's own settings store — same place Skin.SetString
# writes, so XML conditions and this helper always agree)
# --------------------------------------------------------------------------
def get_skin_string(name):
    if xbmc is not None:
        try:
            value = xbmc.getInfoLabel("Skin.String(%s)" % name)
            if value:
                return value
        except Exception:
            pass
    if xbmcaddon is not None:
        try:
            return xbmcaddon.Addon(SKIN_ID).getSetting(name) or ""
        except Exception:
            pass
    return ""


def set_skin_string(name, value):
    if xbmc is None:
        return
    try:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (name, value))
    except Exception as exc:
        log("Skin.SetString %s failed: %s" % (name, exc))


# --------------------------------------------------------------------------
# Day / Midday / Night
# --------------------------------------------------------------------------
def daypart_for(moment):
    """moment: datetime.datetime -> 'Day' | 'Midday' | 'Night'."""
    hour = moment.hour
    if 7 <= hour < 16:
        return "Day"
    if 16 <= hour < 20:
        return "Midday"
    return "Night"


def next_boundary(moment):
    """Epoch seconds of the next daypart change strictly after `moment`."""
    candidates = []
    for day_offset in (0, 1):
        day = (moment + datetime.timedelta(days=day_offset)).date()
        for hour, _name in DAYPART_BOUNDARIES:
            cand = datetime.datetime.combine(
                day, datetime.time(hour=hour), tzinfo=moment.tzinfo)
            if cand > moment:
                candidates.append(cand)
    return int(min(candidates).timestamp())


def _state():
    return _read_json("rocui-state.json")


def _save_state(state):
    return _write_json("rocui-state.json", state)


def manual_override(now=None):
    """Active manual mode dict {'mode':..., 'until': epoch} or None."""
    now = time.time() if now is None else now
    manual = _state().get("manual") or {}
    try:
        if manual.get("mode") and float(manual.get("until", 0)) > now:
            return manual
    except Exception:
        pass
    return None


def sync_daypart(now_dt=None):
    """Apply the automatic daypart unless a manual override is alive.

    Returns the effective mode. Safe to call often (service loop + Home
    onload); only writes skin strings when something actually changes.
    """
    now_dt = now_dt or datetime.datetime.now().astimezone()
    manual = manual_override(now_dt.timestamp())
    if manual:
        if get_skin_string(MODE_SOURCE_STRING) != "Manual":
            set_skin_string(MODE_SOURCE_STRING, "Manual")
        if get_skin_string(MODE_SKIN_STRING) != manual["mode"]:
            set_skin_string(MODE_SKIN_STRING, manual["mode"])
        return manual["mode"]
    # override expired (or never existed): clear it and go automatic
    state = _state()
    if state.get("manual"):
        state.pop("manual", None)
        _save_state(state)
    auto = daypart_for(now_dt)
    if get_skin_string(MODE_SOURCE_STRING) != "Auto":
        set_skin_string(MODE_SOURCE_STRING, "Auto")
    if get_skin_string(MODE_SKIN_STRING) != auto:
        set_skin_string(MODE_SKIN_STRING, auto)
    return auto


def mode_cycle():
    """Dock light button: advance the mode and hold it as a manual
    override until the next automatic light change."""
    order = {"Night": "Midday", "Midday": "Day", "Day": "Night"}
    now_dt = datetime.datetime.now().astimezone()
    current = get_skin_string(MODE_SKIN_STRING) or daypart_for(now_dt)
    new_mode = order.get(current, "Night")
    state = _state()
    state["manual"] = {"mode": new_mode, "until": next_boundary(now_dt)}
    _save_state(state)
    set_skin_string(MODE_SKIN_STRING, new_mode)
    set_skin_string(MODE_SOURCE_STRING, "Manual")
    notify("Light set to %s - manual until the next light change" % new_mode,
           3000)
    return new_mode


# --------------------------------------------------------------------------
# Adult PIN gate — the PIN is Eric's, set on-device at first use.
# Only a salted PBKDF2-HMAC-SHA256 hash is stored (addon profile data).
# --------------------------------------------------------------------------
def derive_pin(pin, salt, iterations=PIN_ITERATIONS):
    return hashlib.pbkdf2_hmac(
        "sha256", pin.encode("utf-8"), salt, int(iterations), dklen=32)


def _pin_record():
    return _read_json("pin.json")


def pin_is_set():
    rec = _pin_record()
    return bool(rec.get("hash") and rec.get("salt"))


def _save_pin(pin):
    salt = os.urandom(16)
    rec = {
        "version": 1,
        "kdf": "pbkdf2_sha256",
        "iterations": PIN_ITERATIONS,
        "salt": base64.b64encode(salt).decode("ascii"),
        "hash": base64.b64encode(
            derive_pin(pin, salt, PIN_ITERATIONS)).decode("ascii"),
        "created": int(time.time()),
    }
    return _write_json("pin.json", rec)


def verify_pin(pin, rec=None):
    rec = rec if rec is not None else _pin_record()
    if not rec.get("hash"):
        return False
    try:
        salt = base64.b64decode(rec["salt"])
        expected = base64.b64decode(rec["hash"])
        actual = derive_pin(pin, salt, rec.get("iterations", PIN_ITERATIONS))
        return hmac.compare_digest(actual, expected)
    except Exception as exc:
        log("verify_pin failed: %s" % exc)
        return False


def _prompt_pin(heading):
    """Masked PIN prompt. Returns the entered string, or None on cancel."""
    if xbmcgui is None:
        return None
    dialog = xbmcgui.Dialog()
    try:
        input_type = getattr(xbmcgui, "INPUT_PASSWORD", None)
        if input_type is not None:
            value = dialog.input(heading, type=input_type)
        else:
            value = dialog.numeric(0, heading)
    except Exception as exc:
        log("pin prompt failed: %s" % exc)
        return None
    if value is None or value == "":
        return None
    return value.strip()


def _valid_new_pin(pin):
    return bool(pin) and pin.isdigit() and PIN_MIN_LEN <= len(pin) <= PIN_MAX_LEN


def _set_pin_flow():
    """First use: Eric sets his own PIN (entered twice)."""
    notify("First use - set your own PIN for the adult door", 5000)
    first = _prompt_pin("Set your PIN (4-8 digits)")
    if first is None:
        return False
    if not _valid_new_pin(first):
        notify("PIN must be 4 to 8 digits - nothing was set", 5000)
        return False
    second = _prompt_pin("Enter that PIN again to confirm")
    if second is None:
        return False
    if second != first:
        notify("Those PINs did not match - nothing was set", 5000)
        return False
    if not _save_pin(first):
        notify("Could not save the PIN on this device", 5000)
        return False
    notify("PIN set - the adult door is yours now", 4000)
    return True


def _verify_pin_flow():
    pin = _prompt_pin("Enter your PIN")
    if pin is None:
        return False
    if verify_pin(pin):
        return True
    notify("Wrong PIN - the door stays shut", 4000)
    return False


_ADDON_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


def adult_gate(target="plugin.video.cumination"):
    """Route the Home adult tile/dock stop through the PIN gate.

    First use sets the PIN, later uses verify it; only then does the
    adult addon open. `target` is an addon id, never a path.
    """
    target = (target or "").strip()
    if not _ADDON_ID_RE.match(target):
        log("adult_gate refused malformed target: %r" % target)
        notify("That adult door is not wired right - nothing opened", 5000)
        return False
    if not pin_is_set():
        if not _set_pin_flow():
            return False
    elif not _verify_pin_flow():
        return False
    if xbmc is not None:
        xbmc.executebuiltin(
            "ActivateWindow(Videos,plugin://%s/,return)" % target)
    return True


def reset_pin():
    """Change the PIN: current PIN first, then the set flow."""
    if pin_is_set() and not _verify_pin_flow():
        return False
    return _set_pin_flow()


# --------------------------------------------------------------------------
# Focus memory — last focused control per window, restored on return.
# Stored in the addon profile data; the service owns reads/writes.
# --------------------------------------------------------------------------
def load_focus_memory():
    data = _read_json("focus-memory.json")
    return data if isinstance(data, dict) else {}


def save_focus_memory(memory):
    return _write_json("focus-memory.json", memory)


def current_window_and_focus():
    """(window_id, focus_id) or (None, None) when the API is unavailable."""
    if xbmcgui is None:
        return None, None
    try:
        win_id = xbmcgui.getCurrentWindowId()
        if not win_id:
            return None, None
        focus_id = xbmcgui.Window(win_id).getFocusId()
        return int(win_id), int(focus_id or 0)
    except Exception:
        return None, None


def restore_focus(win_id, focus_id):
    if xbmcgui is None or not focus_id:
        return False
    try:
        xbmcgui.Window(int(win_id)).setFocusId(int(focus_id))
        return True
    except Exception as exc:
        log("restore_focus %s/%s failed: %s" % (win_id, focus_id, exc))
        return False


# ==========================================================================
# VPN STATUS HOOK — Phase 2 preparation ONLY.
#
# detect_vpn_state() is the single, clearly-marked place that decides what
# the dock shield shows. Contract: it returns ("on" | "off" | "unknown",
# source-string). It may only say "on" when a tunnel interface is actually
# present (and up, where the platform exposes state). When the platform
# exposes nothing readable it returns "unknown" — and the skin renders
# "unknown" with the OFF shield, never the lit one. No fake ON, ever.
#
# Signals, in order:
#   1. /sys/class/net (Linux + Android): tun*/tap*/wg*/ppp* interfaces,
#      with operstate/carrier checked where readable.
#   2. /proc/net/dev (Linux + Android fallback): tunnel interface present.
#   3. Anything else (incl. Windows): "unknown" — adapter enumeration is
#      deliberately NOT faked here; it lands with the on-device phase,
#      where the R26 both-states hardware gate also lives.
# ==========================================================================
_TUN_PREFIXES = ("tun", "tap", "wg", "ppp")


def _tun_names_from_listing(names):
    return [n for n in names if n.startswith(_TUN_PREFIXES)]


def detect_vpn_state():
    if os.name == "nt":
        return "unknown", "windows-adapter-enumeration-not-implemented"
    sysfs = "/sys/class/net"
    try:
        if os.path.isdir(sysfs):
            names = os.listdir(sysfs)
            tuns = _tun_names_from_listing(names)
            if not tuns:
                return "off", "sysfs:no-tunnel-interface"
            for name in tuns:
                state = ""
                try:
                    with open(os.path.join(sysfs, name, "operstate"),
                              "r", encoding="utf-8") as fh:
                        state = fh.read().strip().lower()
                except Exception:
                    state = ""
                if state in ("", "up", "unknown"):
                    # Android often reports operstate 'unknown' for a live
                    # tun; presence + not-down is the honest positive here.
                    if state != "down":
                        return "on", "sysfs:%s(%s)" % (name, state or "?")
            return "off", "sysfs:tunnel-interface-down"
    except Exception as exc:
        log("vpn sysfs check failed: %s" % exc)
    try:
        with open("/proc/net/dev", "r", encoding="utf-8") as fh:
            names = []
            for line in fh:
                if ":" in line:
                    names.append(line.split(":", 1)[0].strip())
            tuns = _tun_names_from_listing(names)
            if tuns:
                return "on", "proc-net-dev:%s" % tuns[0]
            if names:
                return "off", "proc-net-dev:no-tunnel-interface"
    except Exception as exc:
        log("vpn /proc check failed: %s" % exc)
    return "unknown", "no-readable-network-signal"


def publish_vpn_state():
    """Write the VPN surface properties onto the Home window (10000).

    Skin reads Window(10000).Property(RocVPN.State) etc. 'unknown' is a
    real published state — the skin maps it to the OFF shield + 'VPN ?'.
    """
    state, source = detect_vpn_state()
    if xbmcgui is not None:
        try:
            home = xbmcgui.Window(HOME_WINDOW_ID)
            home.setProperty("RocVPN.State", state)
            home.setProperty("RocVPN.On", "true" if state == "on" else "false")
            home.setProperty("RocVPN.Source", source)
            home.setProperty(
                "RocVPN.Label",
                {"on": "VPN ON", "off": "VPN OFF"}.get(state, "VPN ?"))
            home.setProperty("RocVPN.Checked", str(int(time.time())))
        except Exception as exc:
            log("publish_vpn_state failed: %s" % exc)
    return state, source
