# -*- coding: utf-8 -*-
"""
script.rocui — service entry point (starts at login).

Loop duties:
  * Daypart clock: keep Skin.String(RocOS.Mode) on the automatic
    Day/Midday/Night band unless Eric's manual override is alive.
  * Focus memory: remember the last focused control per window and
    restore it once when he returns to that window (design bible §2.2 /
    §5.2 — focus is never lost on screen transitions).
  * VPN surface: re-check the tunnel state and publish it to the Home
    window properties the dock shield reads (Phase 2 preparation — the
    hardware both-states gate is a later on-device phase).

Everything is best-effort and guarded: a helper that cannot read a
signal stays silent instead of breaking the shell.
"""
import time

import xbmc

import rocui_common as rc

POLL_SECONDS = 0.3
DAYPART_EVERY = 20.0   # seconds between daypart syncs
VPN_EVERY = 10.0       # seconds between VPN re-checks
FOCUS_STABLE = 1.2     # focus must rest this long before it is remembered
RESTORE_WINDOW = 1.5   # restore only within this long after a window opens


class RocUIService(object):
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.focus_memory = rc.load_focus_memory()
        self.current_window = None
        self.window_opened_at = 0.0
        self.restored_for = None        # (window_id, opened_at) already done
        self.pending_focus = None       # (window_id, focus_id, since)
        self.last_daypart = 0.0
        self.last_vpn = 0.0

    # ------------------------------------------------------------- focus
    def _flush_pending(self):
        if not self.pending_focus:
            return
        win_id, focus_id, _since = self.pending_focus
        key = str(win_id)
        if self.focus_memory.get(key, {}).get("focus") != focus_id:
            self.focus_memory[key] = {
                "focus": focus_id, "updated": int(time.time())}
            rc.save_focus_memory(self.focus_memory)
        self.pending_focus = None

    def _focus_tick(self, now):
        win_id, focus_id = rc.current_window_and_focus()
        if win_id is None:
            return
        if win_id != self.current_window:
            # window changed: remember where we left the old one, then
            # restore where he left this one (once, promptly).
            self._flush_pending()
            self.current_window = win_id
            self.window_opened_at = now
            self.restored_for = None
        if win_id in rc.FOCUS_SKIP_WINDOWS:
            self.pending_focus = None
            return
        # restore pass — once per window entry, inside the entry window
        stored = self.focus_memory.get(str(win_id), {}).get("focus")
        if (stored and focus_id and stored != focus_id
                and self.restored_for != (win_id, self.window_opened_at)
                and now - self.window_opened_at <= RESTORE_WINDOW):
            if rc.restore_focus(win_id, stored):
                self.restored_for = (win_id, self.window_opened_at)
                focus_id = stored
        # remember pass — only focus that rests counts (skim = travel)
        if focus_id:
            if (not self.pending_focus
                    or self.pending_focus[0] != win_id
                    or self.pending_focus[1] != focus_id):
                self.pending_focus = (win_id, focus_id, now)
            elif now - self.pending_focus[2] >= FOCUS_STABLE:
                self._flush_pending()

    # -------------------------------------------------------------- main
    def run(self):
        rc.log("service starting")
        rc.sync_daypart()
        rc.publish_vpn_state()
        self.last_daypart = time.monotonic()
        self.last_vpn = time.monotonic()
        while not self.monitor.abortRequested():
            now = time.monotonic()
            try:
                self._focus_tick(now)
            except Exception as exc:  # never take the shell down with us
                rc.log("focus tick failed: %s" % exc)
            if now - self.last_daypart >= DAYPART_EVERY:
                self.last_daypart = now
                try:
                    rc.sync_daypart()
                except Exception as exc:
                    rc.log("daypart sync failed: %s" % exc)
            if now - self.last_vpn >= VPN_EVERY:
                self.last_vpn = now
                try:
                    rc.publish_vpn_state()
                except Exception as exc:
                    rc.log("vpn publish failed: %s" % exc)
            if self.monitor.waitForAbort(POLL_SECONDS):
                break
        self._flush_pending()
        rc.log("service stopped")


if __name__ == "__main__":
    RocUIService().run()
