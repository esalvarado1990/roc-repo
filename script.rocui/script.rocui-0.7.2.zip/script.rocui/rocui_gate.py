# -*- coding: utf-8 -*-
"""
script.rocui — the Gate (v0.6.0, Eric's law, 2026-11-05).

On any stick on the Roc Repo channel, NOTHING plays in 2 states:

  1. VPN NOT CONNECTED — the tunnel check (rocui_common.detect_vpn_state)
     must say "on". "off" and "unknown" both close the gate: the house
     rule is VPN-always-first, and "can't confirm it" is not "on".
  2. A ROC REPO UPDATE IS PENDING — installed versions of the add-ons
     the channel serves are compared against the channel's addons.xml.
     A newer version on the channel closes the gate until the update is
     applied. It cannot be skipped or deferred: the gate applies the
     update itself (UpdateAddonRepos + InstallAddon), and a pending
     verdict SURVIVES a Kodi restart (persisted), so rebooting the stick
     is not a skip path.

Enforcement has 2 layers:
  * Route layer (default.py): rocui's own play routes (resume_play,
    source_select) refuse politely with the gate notice.
  * Watchdog layer (service.py): any playback that starts by ANY route
    while the gate is closed is stopped within one service poll, and
    dwell previews never start. This is the hard block — plugin routes
    that never pass through rocui are still governed.

Failure honesty:
  * If the repo has NEVER been reached since boot and no pending verdict
    is on file, the update leg reads "unknown" and does NOT block
    (fail-open). A stick with no network at all must not be bricked by
    its own gate. A pending verdict already on file stays in force
    until a successful re-check clears it.
  * VPN "unknown" DOES block (leg 1). "unknown" means the tunnel
    could not be confirmed, and VPN-first is the older law.
    FIX BATCH 2026-11-10: the old text here claimed the sysfs/proc
    signals are readable on the sticks — false on Fire OS 8, where
    SELinux denies Kodi both reads, which manufactured a PERMANENT
    "unknown" (and a repeating false modal) over a healthy NL
    tunnel. detect_vpn_state now corroborates kernel-blindness with
    the egress-IP witness before it may answer "unknown"; a verdict
    of "off" can likewise come from a verified non-NL egress.

Everything Kodi-facing is guarded exactly like rocui_common: imported
outside Kodi, the pure functions (version compare, addons.xml parse,
decide) still work so the offline harness can test them.
"""
import json
import os
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:  # outside Kodi (tests) — Kodi-facing calls no-op
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None

import rocui_common as rc

# Main channel. A stick pointed at another channel (e.g. the Joe
# channel) overrides this with Skin.String(RocOS.GateRepoURL).
REPO_ADDONS_URL = "https://esalvarado1990.github.io/roc-repo/addons.xml"
REPO_URL_SKIN_STRING = "RocOS.GateRepoURL"

CHECK_FIRST_DELAY = 20.0    # first update check this long after login
CHECK_EVERY = 1800.0        # routine re-check cadence (30 min)
CHECK_RETRY = 300.0         # retry cadence after a failed fetch (5 min)
RECHECK_AFTER_APPLY = 60.0  # re-check this long after an apply round
APPLY_MIN_GAP = 300.0       # never hammer: min seconds between applies
FETCH_TIMEOUT = 10.0        # seconds; a hung repo must not stall us
NOTICE_DIALOG_GAP = 120.0   # a blocked attempt re-dialogs at most this often
NOTICE_EPISODE_REPEAT = 900.0  # FIX BATCH 2026-11-10: within one closed
# episode (same reason + same notice), the toast/dialog may re-fire at
# most this often. The old behaviour re-noticed on EVERY watchdog stop,
# and on sticks whose hubs auto-play dwell previews that meant a fresh
# "Can't confirm the VPN" toast for every preview the watchdog killed —
# the nag Eric hit while simply navigating (2026-11-10 20:10/20:25).

GATE_STATE_FILE = "gate_state.json"

MSG_VPN_OFF = ("VPN is off",
               "Connect Proton VPN first - nothing plays until the "
               "VPN is on.")
MSG_VPN_UNKNOWN = ("Can't confirm the VPN",
                   "RocOS can't see the VPN tunnel. Open Proton VPN "
                   "and make sure it's connected.")
MSG_UPDATE = ("An update is ready",
              "Updating first - then you can watch. Updates can't be "
              "skipped: they're pushed for a reason.")
MSG_UPDATE_STUCK = ("Update didn't take",
                    "The update is still not in. Watching opens as "
                    "soon as it lands - RocOS keeps trying.")


# ==========================================================================
# pure logic (offline-testable)
# ==========================================================================
def version_key(version):
    """'3.4.0' -> (3, 4, 0). Non-numeric tail junk in a segment is
    ignored ('0.5.0a' -> (0, 5, 0)); missing segments read as 0."""
    out = []
    for seg in str(version or "").split("."):
        digits = ""
        for ch in seg:
            if ch.isdigit():
                digits += ch
            else:
                break
        out.append(int(digits) if digits else 0)
    return tuple(out)


def version_newer(candidate, installed):
    """True when candidate is strictly newer than installed."""
    a, b = version_key(candidate), version_key(installed)
    width = max(len(a), len(b))
    a += (0,) * (width - len(a))
    b += (0,) * (width - len(b))
    return a > b


def parse_repo_versions(xml_bytes):
    """addons.xml bytes -> {addon_id: version}. Tolerant: a malformed
    document yields {} rather than raising (the caller treats an empty
    parse of a fetched document as a failed check, never as 'no
    updates pending')."""
    out = {}
    try:
        root = ET.fromstring(xml_bytes)
    except Exception:
        return out
    for el in root.iter("addon"):
        aid, ver = el.get("id"), el.get("version")
        if aid and ver:
            out[aid] = ver
    return out


def pending_updates(repo_versions, installed_versions):
    """{addon_id: (installed, available)} for installed add-ons the
    channel serves a newer version of. installed_versions maps
    addon_id -> version string (only installed add-ons are passed)."""
    out = {}
    for aid, inst in installed_versions.items():
        avail = repo_versions.get(aid)
        if avail and version_newer(avail, inst):
            out[aid] = (inst, avail)
    return out


def decide(vpn_state, update_state):
    """(blocked_reason, title, message). blocked_reason is '' when the
    gate is open, else 'vpn' or 'update'. Leg order is Eric's: VPN
    first, updates second — when both are closed the VPN notice is
    the one shown. update_state is 'ok' | 'pending' | 'unknown';
    'unknown' never blocks (fail-open, see module docstring)."""
    if vpn_state == "off":
        return ("vpn",) + MSG_VPN_OFF
    if vpn_state != "on":
        return ("vpn",) + MSG_VPN_UNKNOWN
    if update_state == "pending":
        return ("update",) + MSG_UPDATE
    return ("", "", "")


# ==========================================================================
# Kodi-facing plumbing (guarded; no-ops outside Kodi)
# ==========================================================================
def _log(msg):
    try:
        rc.log("gate: %s" % msg)
    except Exception:
        pass


def _roc_log(msg, event="gate"):
    try:
        rc.roc_log(msg, event=event)
    except Exception:
        pass


def repo_addons_url():
    """The channel this stick follows: skin-string override, else the
    main Roc Repo channel."""
    try:
        override = rc.get_skin_string(REPO_URL_SKIN_STRING)
        if override:
            return override
    except Exception:
        pass
    return REPO_ADDONS_URL


def fetch_repo_versions(url):
    """GET the channel's addons.xml -> {addon_id: version}, or None on
    any failure (network, HTTP, parse). A fetched-but-empty parse is a
    failure too — it must never read as 'no updates'."""
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "script.rocui-gate"})
        with urllib.request.urlopen(req, timeout=FETCH_TIMEOUT) as fh:
            data = fh.read()
        versions = parse_repo_versions(data)
        return versions if versions else None
    except Exception as exc:
        _log("repo fetch failed (%s): %s" % (url, exc))
        return None


def installed_version(addon_id):
    """Installed version string, or None when the add-on is absent."""
    if xbmcaddon is None:
        return None
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version") or None
    except Exception:
        return None


def _state_path():
    if xbmcvfs is not None:
        try:
            return xbmcvfs.translatePath(
                "special://profile/addon_data/%s/%s"
                % (rc.ADDON_ID, GATE_STATE_FILE))
        except Exception:
            pass
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        GATE_STATE_FILE)


class GateKeeper(object):
    """Owns the gate verdict for the service loop.

    Callables are injectable so the offline harness can drive the whole
    state machine without Kodi: fetch_fn(url)->dict|None,
    installed_fn(addon_id)->str|None, vpn_fn()->(state, source).
    """

    def __init__(self, fetch_fn=None, installed_fn=None, vpn_fn=None,
                 state_path=None):
        self._fetch_fn = fetch_fn or fetch_repo_versions
        self._installed_fn = installed_fn or installed_version
        self._vpn_fn = vpn_fn or rc.detect_vpn_state
        self._state_path = state_path or _state_path()
        # live verdict
        self.reason = ""            # '' | 'vpn' | 'update'
        self.title = ""
        self.message = ""
        self.vpn_state = "unknown"
        # update leg
        self.pending = {}           # addon_id -> (installed, available)
        self.ever_ok = False        # a repo check has succeeded at least once
        self.apply_rounds = 0       # apply rounds against the current set
        self._pending_stamp = ""    # identity of the pending set applied to
        # scheduling
        self._next_check = None     # monotonic deadline; set by begin()
        self._last_apply = 0.0
        self._fetching = False
        self._fetch_result = None   # (versions dict | None) when done
        # notices
        self._last_notice_reason = ""
        self._last_dialog_at = 0.0
        self._notice_episode = ""   # reason|title of the live episode
        self._notice_last_at = 0.0  # monotonic time of its last notice
        # WEDGE FIX (2026-11-08): a closed gate no longer raises its
        # modal dialog from here — show_notice() only toasts and sets
        # this flag. The service loop dispatches the dialog through a
        # one-shot script process, and only over a hub-class window.
        self.dialog_pending = False
        self._was_playing_blocked = False
        self._load_state()

    # ---------------------------------------------------------- persist
    def _pending_key(self):
        return ",".join(sorted(self.pending))

    def _save_state(self):
        data = {"pending": sorted(self.pending),
                "ever_ok": bool(self.ever_ok),
                "saved": int(time.time())}
        try:
            folder = os.path.dirname(self._state_path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            with open(self._state_path, "w", encoding="utf-8") as fh:
                json.dump(data, fh)
        except Exception as exc:
            _log("state save failed: %s" % exc)

    def _load_state(self):
        try:
            with open(self._state_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if data.get("ever_ok"):
                self.ever_ok = True
            for aid in data.get("pending") or []:
                # versions re-read live on the first check; the id list
                # alone keeps the gate closed across a restart.
                self.pending[aid] = ("", "")
        except Exception:
            pass  # no file yet = fresh stick; honest default

    # ------------------------------------------------------------ checks
    def begin(self, now=None):
        now = time.monotonic() if now is None else now
        self._next_check = now + CHECK_FIRST_DELAY
        self.evaluate()
        _roc_log("Gate armed (vpn=%s, update=%s)"
                 % (self.vpn_state, self.update_state()))

    def update_state(self):
        if self.pending:
            return "pending"
        return "ok" if self.ever_ok else "unknown"

    def _start_fetch(self):
        if self._fetching:
            return
        self._fetching = True
        url = repo_addons_url()

        def _run():
            try:
                self._fetch_result = self._fetch_fn(url)
            except Exception:
                self._fetch_result = None
            self._fetching = False

        threading.Thread(target=_run, daemon=True).start()

    def _failed_fetch(self, now):
        self._next_check = now + CHECK_RETRY

    def _maybe_apply(self, now):
        if not self.pending:
            return
        if now - self._last_apply < APPLY_MIN_GAP:
            return
        self._last_apply = now
        self.apply_rounds += 1
        self._pending_stamp = self._pending_key()
        if xbmc is not None:
            try:
                xbmc.executebuiltin("UpdateAddonRepos")
                for aid in sorted(self.pending):
                    xbmc.executebuiltin("InstallAddon(%s)" % aid)
            except Exception as exc:
                _log("apply failed: %s" % exc)
        _roc_log("Gate: update apply round %d for: %s"
                 % (self.apply_rounds, ", ".join(sorted(self.pending))))
        self._next_check = now + RECHECK_AFTER_APPLY

    # ------------------------------------------------------------- tick
    def tick(self, now=None):
        """Called by the service ~every 5s. Drives checks, applies and
        verdict publication. Never raises."""
        now = time.monotonic() if now is None else now
        try:
            if self._fetch_result is not None:
                versions = self._fetch_result
                self._fetch_result = None
                if versions:
                    self._consume_versions(versions, now)
                    self._next_check = now + CHECK_EVERY \
                        if not self.pending else self._next_check
                else:
                    self._failed_fetch(now)
            if self._next_check is not None and now >= self._next_check \
                    and not self._fetching:
                self._start_fetch()
                # give the fetch a moment on the next ticks; deadline
                # moves out so we don't stack fetches
                self._next_check = now + CHECK_RETRY
            self.evaluate()
        except Exception as exc:
            _log("tick failed: %s" % exc)

    def _consume_versions(self, versions, now):
        installed = {}
        for aid in versions:
            inst = self._installed_fn(aid)
            if inst:
                installed[aid] = inst
        new_pending = pending_updates(versions, installed)
        key = ",".join(sorted(new_pending))
        if key != self._pending_stamp:
            self.apply_rounds = 0
        self.pending = new_pending
        self.ever_ok = True
        self._save_state()
        if self.pending:
            _roc_log("Gate: update pending: %s"
                     % ", ".join("%s %s->%s" % (a, i, v)
                                 for a, (i, v) in
                                 sorted(self.pending.items())))
            self._maybe_apply(now)

    # ---------------------------------------------------------- verdict
    def evaluate(self):
        try:
            self.vpn_state, _src = self._vpn_fn()
        except Exception:
            self.vpn_state = "unknown"
        ustate = self.update_state()
        if self.reason == "update" and ustate == "pending" \
                and self.apply_rounds >= 3:
            reason, title, message = "update", MSG_UPDATE_STUCK[0], \
                MSG_UPDATE_STUCK[1]
        else:
            reason, title, message = decide(self.vpn_state, ustate)
        changed = reason != self.reason
        self.reason, self.title, self.message = reason, title, message
        if changed and reason:
            _roc_log("Gate CLOSED (%s): %s" % (reason, title))
            # toast + dialog_pending only — never a modal on this
            # (the service loop) thread; see show_notice().
            self.show_notice()
        elif changed:
            # gate restored: any undelivered dialog is moot, and the
            # notice episode ends — a later closure is a NEW episode
            # and earns its one notice again.
            self.dialog_pending = False
            self._notice_episode = ""
            _roc_log("Gate OPEN")
        self._publish()
        return self.reason

    def is_open(self):
        return self.reason == ""

    def _publish(self):
        if xbmcgui is None:
            return
        try:
            home = xbmcgui.Window(rc.HOME_WINDOW_ID)
            home.setProperty("RocGate.State",
                             "open" if not self.reason else self.reason)
            home.setProperty("RocGate.Title", self.title)
            home.setProperty("RocGate.Message", self.message)
            home.setProperty("RocGate.Pending",
                             ",".join(sorted(self.pending)))
            home.setProperty("RocGate.DialogPending",
                             "1" if self.dialog_pending else "")
            home.setProperty("RocGate.Checked", str(int(time.time())))
        except Exception as exc:
            _log("publish failed: %s" % exc)

    # ---------------------------------------------------------- notices
    def show_notice(self):
        """Toast only — this method must NEVER raise a modal dialog.

        WEDGE FIX (2026-11-08): the old body ended in a synchronous,
        unbounded modal OK-dialog call on the rocui service's single
        loop thread. When the gate closed at 2026-11-07 09:41 with the
        episode detail window (1124) in the foreground, that modal
        never presented, the call never returned, and the whole
        service (watchdog, gate ticks, VPN surface) parked forever —
        the GUI died with it and only a force-stop recovered Kodi.

        Now: fire-and-forget toast, set dialog_pending, and let the
        service loop dispatch the real modal later — via the one-shot
        action=gate_dialog route (route_gate_refuse), and only while
        a hub-class window is foreground. The RocGate.DialogPending
        window property mirrors the flag via _publish()."""
        if not self.reason:
            return
        # FIX BATCH 2026-11-10: episode latch. One closure = one
        # episode; inside it, re-notices (watchdog stops, dwell
        # previews, repeated route refusals) are swallowed until
        # NOTICE_EPISODE_REPEAT has passed. The gate still BLOCKS
        # every attempt — only the nagging is rationed.
        episode = "%s|%s" % (self.reason, self.title)
        now = time.monotonic()
        if episode == self._notice_episode \
                and (now - self._notice_last_at) < NOTICE_EPISODE_REPEAT:
            return
        self._notice_episode = episode
        self._notice_last_at = now
        self.dialog_pending = True
        self._last_notice_reason = self.reason
        if xbmcgui is None:
            return
        try:
            xbmcgui.Dialog().notification(
                self.title, self.message, xbmcgui.NOTIFICATION_WARNING,
                6000)
        except Exception:
            pass

    # --------------------------------------------------------- watchdog
    def watchdog(self):
        """Called every service poll (~0.3s). If anything is playing
        while the gate is closed, stop it and say why. Covers every
        playback route, including ones that never pass through rocui.
        Returns True when it stopped something."""
        if self.reason == "" or xbmc is None:
            self._was_playing_blocked = False
            return False
        try:
            player = xbmc.Player()
            if not player.isPlaying():
                self._was_playing_blocked = False
                return False
            player.stop()
            _roc_log("Gate: playback stopped (%s)" % self.reason)
            # toast + dialog_pending only (wedge fix): the modal is
            # dispatched off this thread by the service loop.
            self.show_notice()
            self._was_playing_blocked = True
            return True
        except Exception as exc:
            _log("watchdog failed: %s" % exc)
            return False


# ==========================================================================
# route layer (default.py one-shot processes)
# ==========================================================================
def route_gate_open():
    """Cheap read for RunScript actions: the service publishes the
    verdict on the Home window. No property yet (service not up) reads
    as open — the watchdog closes the gap within a poll once the
    service is running."""
    if xbmcgui is None:
        return True
    try:
        state = xbmcgui.Window(rc.HOME_WINDOW_ID).getProperty(
            "RocGate.State")
        return state in ("", "open")
    except Exception:
        return True


def route_gate_refuse():
    """Show the gate notice from a one-shot script process."""
    title, message = "RocOS", "The gate is closed."
    if xbmcgui is not None:
        try:
            home = xbmcgui.Window(rc.HOME_WINDOW_ID)
            title = home.getProperty("RocGate.Title") or title
            message = home.getProperty("RocGate.Message") or message
            xbmcgui.Dialog().ok(title, message)
            return
        except Exception:
            pass
    _log("gate refused a route (no dialog available)")
