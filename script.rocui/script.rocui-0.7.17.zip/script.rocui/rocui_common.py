# -*- coding: utf-8 -*-
"""
Roc UI helper (script.rocui) — shared logic for Roc OS Phase 2.

Owns the three things skin XML cannot do honestly:
  1. The Adult PIN gate (salted PBKDF2 hash only — the PIN itself is never
     stored, never logged, and is set by Eric on the device at first use).
  2. The Day/Midday/Night clock (automatic by local time; the dock button
     becomes a manual override that holds until the next light change).
  3. Focus memory (last focused control per window, restored on return) and
     the VPN status surface hook (see the marked section below).

Kodi imports are guarded so this module can be imported and unit-tested
outside Kodi (validation harness) without crashing.
"""
import base64
import datetime
import hashlib
import hmac
import json
import os
import re
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:  # outside Kodi (tests) — functions degrade to no-ops
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None

ADDON_ID = "script.rocui"
SKIN_ID = "skin.rocos"
MODE_SKIN_STRING = "RocOS.Mode"           # Night | Midday | Day (Phase 1 string)
MODE_SOURCE_STRING = "RocOS.ModeSource"   # Auto | Manual (Phase 2)
HOME_WINDOW_ID = 10000

# Daypart bands (local time): Day 07:00-15:59, Midday 16:00-19:59,
# Night 20:00-06:59. "Midday" is the warm transitional band in this house.
DAYPART_BOUNDARIES = [(7, "Day"), (16, "Midday"), (20, "Night")]

PIN_ITERATIONS = 200000
PIN_MIN_LEN = 4
PIN_MAX_LEN = 8

# Windows where focus restore is pointless or harmful (fullscreen players,
# busy/startup surfaces). Everything else gets focus memory.
FOCUS_SKIP_WINDOWS = {0, 12005, 12006, 12009, 12900}


# --------------------------------------------------------------------------
# small utilities
# --------------------------------------------------------------------------
def log(msg, level=None):
    if xbmc is None:
        return
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg),
                 xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


def _data_dir():
    """Addon profile data dir (created on demand). '' when not in Kodi."""
    if xbmcvfs is None:
        return ""
    try:
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(path):
            os.makedirs(path)
        return path
    except Exception as exc:
        log("data dir failed: %s" % exc)
        return ""


def _master_data_dir():
    """Addon MASTER-profile data dir (created on demand). Identical
    from every profile context — special://masterprofile always
    resolves to the master profile's directory, while
    special://profile follows the currently loaded profile."""
    if xbmcvfs is None:
        return ""
    try:
        path = xbmcvfs.translatePath(
            "special://masterprofile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(path):
            os.makedirs(path)
        return path
    except Exception as exc:
        log("master data dir failed: %s" % exc)
        return ""


def _read_json(name):
    path = os.path.join(_data_dir(), name) if _data_dir() else ""
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        log("read %s failed: %s" % (name, exc))
        return {}


def _write_json(name, data):
    path = os.path.join(_data_dir(), name) if _data_dir() else ""
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log("write %s failed: %s" % (name, exc))
        return False


def notify(title, msg=None, ok=True, ms=None):
    """Roc notification standard (G7, v3.3.0).

    New style:  notify("Heading", "Body text", ok=True/False)
      success (ok=True)  auto-dismisses after ~15s (15000ms)
      failure (ok=False) stays ~60s (60000ms) with a high-contrast icon
    Legacy style notify("some text", 4500) still works: an int second
    argument is taken as an explicit duration and always wins.
    """
    if isinstance(msg, (int, float)) and not isinstance(msg, bool):
        ms = msg
        msg = None
    if ms is None:
        if msg is not None:
            ms = 15000 if ok else 60000
        else:
            ms = 4500 if ok else 60000
    heading = "Roc OS" if msg is not None else "Roc OS"
    body = msg if msg is not None else title
    if msg is not None and title and title != "Roc OS":
        heading = title
    if xbmc is None:
        return
    # xbmcgui.Dialog().notification takes a real icon path; the old
    # builtin form is the fallback (its args split on commas, so the
    # fallback path strips them).
    if xbmcgui is not None:
        try:
            icon = ""
            try:
                base = xbmcvfs.translatePath(
                    "special://home/addons/%s/icon.png" % ADDON_ID)
                icon = base if ok else base
                if not ok:
                    warn = xbmcvfs.translatePath(
                        "special://skin/media/rocos-vpn-off.png")
                    if warn and os.path.isfile(warn):
                        icon = warn
            except Exception:
                icon = ""
            xbmcgui.Dialog().notification(heading, body, icon, int(ms))
            return
        except Exception:
            pass
    try:
        safe = str(body).replace(",", " ")
        xbmc.executebuiltin(
            "Notification(%s,%s,%d)" % (heading.replace(",", " "), safe,
                                        int(ms)))
    except Exception:
        pass


# --------------------------------------------------------------------------
# Source availability — the zero-source shelf filter
# (ZERO-SOURCE SHELF lane, 2026-11-17; Eric's order 13:18, extended
# 13:19: the test is zero WORKING sources — "sources that don't
# work count too").
#
# RocPlay stamps per-DEVICE availability verdicts as it pours
# (plugin.video.rocplay 0.2.13): availability.json in RocPlay's
# MASTER-profile data dir — device-level because a title's source
# truth belongs to this device and its exit (the .159 diagnosis:
# the same title's shelf was empty on one exit, full on another),
# never to one profile, and never shared across devices. This
# module only READS that file. A title leaves the browse shelves
# when — and only when — its verdict is a proven "zero" (a
# complete pour found zero working sources; "working" already
# discounts death-marked sources on RocPlay's side). Unknown /
# unchecked / unreadable = SHOWN: suppression never happens on
# missing data, and no catalog data is ever edited or deleted —
# this is a display filter over a verdict cache, nothing else.
#
# Scope, exactly:
#   FILTERED (browse shelves): spotlight_items, movie_row_items,
#     tv_row_items, toonime_shelf_items, collection_detail —
#     together they serve Home (spotlight + the NEW rows), the
#     hub rows rocui serves, the Toonime shelves and the
#     collections.
#   NEVER FILTERED: search (search_items / unified_search_items —
#     search results are not a shelf; a suppressed title stays
#     findable and playable, which is also one of its revival
#     paths), the history/continue feeds (Continue Watching is
#     exempt by Eric's word — an in-progress title never vanishes,
#     whatever its source state), the Archive doors (a different
#     source universe; the wells know nothing about it), August's
#     music (not video sources), and every feed service.rocsync
#     serves (the hub CW zones — exempt, and not this addon's
#     rows to touch).
#
# Re-check cadence (the restore path — a verdict is re-earned,
# never permanent): shelf builds note the titles they serve into
# avail_queue.json (this addon's master data); the service tick
# (avail_service_tick below, driven from service.py) fires
# RocPlay's avail_check for at most one due title per
# AVAIL_FIRE_GAP_S and only while nothing is playing — unknown
# titles first, then zero verdicts older than
# AVAIL_ZERO_RECHECK_S (24 h: sources come back, and a restored
# title reappears on the shelf by itself), then ok verdicts older
# than AVAIL_OK_REFRESH_S (7 days). Real plays stamp fresher
# verdicts on their own, so the tick mostly serves titles nobody
# has played lately.
# --------------------------------------------------------------------------
AVAIL_ADDON_ID = "plugin.video.rocplay"
AVAIL_FILE = "availability.json"
AVAIL_QUEUE_FILE = "avail_queue.json"
AVAIL_OK_REFRESH_S = 7 * 24 * 3600
AVAIL_ZERO_RECHECK_S = 24 * 3600
AVAIL_FIRE_GAP_S = 120
AVAIL_FIRED_RETRY_S = 3600
_AVAIL_MEM = [None, None]   # (mtime, verdicts dict)


def _avail_cache_path():
    if xbmcvfs is None:
        return ""
    try:
        return xbmcvfs.translatePath(
            "special://masterprofile/addon_data/%s/%s"
            % (AVAIL_ADDON_ID, AVAIL_FILE))
    except Exception:
        return ""


def avail_verdicts():
    """{key: verdict entry} from RocPlay's availability file on
    THIS device. {} on any failure — the fail direction is always
    'nothing suppressed'. Memoised on the file's mtime so a shelf
    build doesn't re-read it per row."""
    path = _avail_cache_path()
    if not path:
        return {}
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        return {}
    if _AVAIL_MEM[0] == mtime and isinstance(_AVAIL_MEM[1], dict):
        return _AVAIL_MEM[1]
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        titles = data.get("titles") if isinstance(data, dict) \
            else None
        verdicts = titles if isinstance(titles, dict) else {}
    except Exception:
        verdicts = {}
    _AVAIL_MEM[0] = mtime
    _AVAIL_MEM[1] = verdicts
    return verdicts


def _avail_key(tmdb_type, tmdb_id):
    return "%s:%s" % (tmdb_type or "", str(tmdb_id or ""))


def avail_is_zero(tmdb_type, tmdb_id):
    """True only on a proven zero verdict for this exact title.
    Anything else — no id, no entry, an ok entry, a corrupt or
    absent file — is False: the title stays on the shelf."""
    if not tmdb_id:
        return False
    entry = avail_verdicts().get(_avail_key(tmdb_type, tmdb_id))
    return bool(entry and entry.get("state") == "zero")


def _avail_filter_rows(rows):
    """Drop proven-zero titles from one shelf's rows. Rows
    without a TMDB id can't be keyed, so they are never dropped
    (unknown is not zero). Never raises."""
    try:
        verdicts = avail_verdicts()
        if not verdicts:
            return rows
        out = []
        for row in rows or []:
            entry = verdicts.get(_avail_key(row.get("tmdb_type"),
                                            row.get("tmdb_id")))
            if entry and entry.get("state") == "zero":
                continue
            out.append(row)
        return out
    except Exception:
        return rows


def _avail_queue_path():
    base = _master_data_dir()
    return os.path.join(base, AVAIL_QUEUE_FILE) if base else ""


def _avail_read_queue():
    path = _avail_queue_path()
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _avail_write_queue(data):
    path = _avail_queue_path()
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def _avail_note_rows(rows):
    """Note served shelf titles for background re-checking. Only
    titles without a fresh verdict are queued (fresh-ok and
    recently-zero titles are the tick's cache-due business, not
    the queue's). Merges, never replaces; never raises — a shelf
    build must not fail over bookkeeping."""
    try:
        now = time.time()
        verdicts = avail_verdicts()
        queue = _avail_read_queue()
        entries = queue.get("entries") or {}
        changed = False
        for row in rows or []:
            tmdb_id = row.get("tmdb_id")
            if not tmdb_id:
                continue
            key = _avail_key(row.get("tmdb_type"), tmdb_id)
            verdict = verdicts.get(key) or {}
            checked = float(verdict.get("checked") or 0)
            if verdict.get("state") == "ok" \
                    and now - checked < AVAIL_OK_REFRESH_S:
                continue
            if verdict.get("state") == "zero" \
                    and now - checked < AVAIL_ZERO_RECHECK_S:
                continue
            old = entries.get(key) or {}
            year = row.get("year") or old.get("year") or ""
            if not year and row.get("release_date"):
                year = str(row["release_date"])[:4]
            entries[key] = {
                "tmdb_id": str(tmdb_id),
                "tmdb_type": row.get("tmdb_type") or "",
                "title": row.get("label") or old.get("title") or "",
                "year": year,
                "noted": now,
                "fired": old.get("fired") or 0,
            }
            changed = True
        if changed:
            queue["entries"] = entries
            _avail_write_queue(queue)
    except Exception:
        pass


def avail_service_tick(now=None, playing_fn=None, fire_fn=None):
    """One background re-check step (the service calls this on
    its AVAIL_EVERY cadence). Fires RocPlay's avail_check for at
    most one due title, only while nothing is playing, at most
    one fire per AVAIL_FIRE_GAP_S. Priority: (1) queued titles
    with no verdict at all — a shelf is showing them unchecked;
    (2) queued titles whose verdict is due (zero past its
    re-check age, ok past its refresh age); (3) cache-due titles
    no shelf has noted lately — a title that fell off every
    shelf while suppressed must still get its restore re-check.
    Returns the fired title's key, or None. playing_fn / fire_fn
    are injectable for the harness. Never raises."""
    try:
        now = time.time() if now is None else now
        if playing_fn is not None:
            playing = bool(playing_fn())
        elif xbmc is not None:
            try:
                playing = bool(xbmc.Player().isPlaying())
            except Exception:
                playing = False
        else:
            playing = False
        if playing:
            return None
        queue = _avail_read_queue()
        meta = queue.get("_meta") or {}
        if now - float(meta.get("last_fire") or 0) \
                < AVAIL_FIRE_GAP_S:
            return None
        verdicts = avail_verdicts()
        entries = queue.get("entries") or {}

        def _due(verdict):
            checked = float(verdict.get("checked") or 0)
            if verdict.get("state") == "zero":
                return now - checked >= AVAIL_ZERO_RECHECK_S
            if verdict.get("state") == "ok":
                return now - checked >= AVAIL_OK_REFRESH_S
            return False

        pick = None   # (priority, sort key, key, fire entry)

        def _consider(cand):
            nonlocal pick
            if pick is None or cand[:2] < pick[:2]:
                pick = cand

        for key, e in entries.items():
            verdict = verdicts.get(key)
            fired = float(e.get("fired") or 0)
            if now - fired < AVAIL_FIRED_RETRY_S:
                continue
            if verdict is None:
                _consider((0, float(e.get("noted") or 0), key, e))
            elif _due(verdict):
                _consider((1, float(verdict.get("checked") or 0),
                           key, e))
        if pick is None:
            for key, verdict in verdicts.items():
                if key in entries:
                    continue   # queue-owned: the pass above owns
                    # its retry timing; never double-fire it here
                if not _due(verdict):
                    continue
                parts = key.split(":", 1)
                if len(parts) != 2 or not parts[1].isdigit():
                    # Title-fallback verdicts (no TMDB id) can
                    # never suppress a shelf row; nothing to fire.
                    continue
                _consider((2, float(verdict.get("checked") or 0),
                           key, {
                               "tmdb_id": parts[1],
                               "tmdb_type": parts[0],
                               "title": verdict.get("title") or "",
                               "year": verdict.get("year") or "",
                           }))
        if pick is None:
            return None
        _prio, _sort, key, e = pick
        tmdb_id = str(e.get("tmdb_id") or "")
        tmdb_type = e.get("tmdb_type") or ""
        if not tmdb_id.isdigit() \
                or tmdb_type not in ("movie", "tv"):
            return None
        from urllib.parse import quote_plus
        url = ("plugin://plugin.video.rocplay/?action=avail_check"
               "&tmdb=%s&tmdb_type=%s&title=%s"
               % (tmdb_id, tmdb_type,
                  quote_plus(e.get("title") or "")))
        if e.get("year"):
            url += "&year=%s" % quote_plus(str(e["year"])[:4])
        if fire_fn is not None:
            fire_fn(url)
        elif xbmc is not None:
            xbmc.executebuiltin("RunPlugin(%s)" % url)
        else:
            return None
        meta["last_fire"] = now
        queue["_meta"] = meta
        ent = entries.get(key)
        if ent is None:
            # A cache-due fire enrols the title in the queue, so
            # its next retry obeys the same 1 h rule as any
            # shelf-noted title instead of re-firing every gap.
            ent = {"tmdb_id": tmdb_id, "tmdb_type": tmdb_type,
                   "title": e.get("title") or "",
                   "year": e.get("year") or "", "noted": now}
            entries[key] = ent
        ent["fired"] = now
        queue["entries"] = entries
        _avail_write_queue(queue)
        log("avail_service_tick: check fired for %s" % key)
        return key
    except Exception as exc:
        log("avail_service_tick failed: %s" % exc)
        return None


# --------------------------------------------------------------------------
# Roc Log (G7, v3.3.0) — persistent, timestamped, on-device log at
# special://profile/addon_data/script.rocui/roc-log.txt (capped at
# ~500 lines, kept until cleared). Key rocui events + install/update/
# success/failure lines land here via roc_log(); the skin's Roc Log
# window (1126) reads it back through the roc_log action in default.py.
# --------------------------------------------------------------------------
ROC_LOG_FILE = "roc-log.txt"
ROC_LOG_MAX_LINES = 500
ROC_LOG_WINDOW_ID = 1126


def _roc_log_path():
    base = _data_dir()
    return os.path.join(base, ROC_LOG_FILE) if base else ""


def roc_log(message, event="event"):
    """Append one timestamped line to the persistent Roc Log and mirror
    it to the Kodi log. Never raises."""
    line = "[%s] [%s] %s" % (
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        event, str(message))
    log(line)
    path = _roc_log_path()
    if not path:
        return False
    try:
        lines = []
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.read().splitlines()
        lines.append(line)
        if len(lines) > ROC_LOG_MAX_LINES:
            lines = lines[-ROC_LOG_MAX_LINES:]
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log("roc_log append failed: %s" % exc)
        return False


def roc_log_text():
    """Full Roc Log contents (newest last), '' when there is none."""
    path = _roc_log_path()
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except Exception as exc:
        log("roc_log read failed: %s" % exc)
        return ""


def roc_log_clear():
    path = _roc_log_path()
    if path and os.path.isfile(path):
        try:
            os.remove(path)
        except Exception:
            pass


def show_roc_log():
    """action=roc_log: publish the log to Window(10000) property
    RocLog.Text (newest last) and open the skin's Roc Log window."""
    text = roc_log_text()
    if not text:
        text = "Roc log is empty - nothing has been recorded yet."
    if xbmcgui is not None:
        try:
            xbmcgui.Window(HOME_WINDOW_ID).setProperty("RocLog.Text", text)
        except Exception as exc:
            log("roc log publish failed: %s" % exc)
    if xbmc is not None:
        xbmc.executebuiltin("ActivateWindow(%d)" % ROC_LOG_WINDOW_ID)
    return True


# --------------------------------------------------------------------------
# skin strings (the skin's own settings store — same place Skin.SetString
# writes, so XML conditions and this helper always agree)
# --------------------------------------------------------------------------
def get_skin_string(name):
    if xbmc is not None:
        try:
            value = xbmc.getInfoLabel("Skin.String(%s)" % name)
            if value:
                return value
        except Exception:
            pass
    if xbmcaddon is not None:
        try:
            return xbmcaddon.Addon(SKIN_ID).getSetting(name) or ""
        except Exception:
            pass
    return ""


def set_skin_string(name, value):
    if xbmc is None:
        return
    try:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (name, value))
    except Exception as exc:
        log("Skin.SetString %s failed: %s" % (name, exc))


# --------------------------------------------------------------------------
# Day / Midday / Night
# --------------------------------------------------------------------------
def daypart_for(moment):
    """moment: datetime.datetime -> 'Day' | 'Midday' | 'Night'."""
    hour = moment.hour
    if 7 <= hour < 16:
        return "Day"
    if 16 <= hour < 20:
        return "Midday"
    return "Night"


def next_boundary(moment):
    """Epoch seconds of the next daypart change strictly after `moment`."""
    candidates = []
    for day_offset in (0, 1):
        day = (moment + datetime.timedelta(days=day_offset)).date()
        for hour, _name in DAYPART_BOUNDARIES:
            cand = datetime.datetime.combine(
                day, datetime.time(hour=hour), tzinfo=moment.tzinfo)
            if cand > moment:
                candidates.append(cand)
    return int(min(candidates).timestamp())


def _state():
    return _read_json("rocui-state.json")


def _save_state(state):
    return _write_json("rocui-state.json", state)


def manual_override(now=None):
    """Active manual mode dict {'mode':..., 'until': epoch} or None."""
    now = time.time() if now is None else now
    manual = _state().get("manual") or {}
    try:
        if manual.get("mode") and float(manual.get("until", 0)) > now:
            return manual
    except Exception:
        pass
    return None


# Mode -> skin background slot (G7 modes, v3.3.0). This matches the
# mapping Home.xml already renders: Day -> roc-day.jpg (bright daylight
# grade), Midday -> roc-midday.jpg (brightest midday grade), Night ->
# roc-hero.jpg (night/default hero). Verified against Home.xml lines
# 20-35 on 2026-10-25 — the skin mapping was already correct, so
# mode_set only has to drive RocOS.Mode honestly and publish the slot.
MODE_BACKGROUNDS = {"Day": "roc-day.jpg",
                    "Midday": "roc-midday.jpg",
                    "Night": "roc-hero.jpg"}
MODE_BACKGROUND_STRING = "RocOS.Background"


def publish_mode_background(mode):
    """Publish the background slot for `mode` as skin string
    RocOS.Background + Home window property RocOS.Background, so any
    surface can read the slot without re-deriving the mapping."""
    bg = MODE_BACKGROUNDS.get(mode, "roc-hero.jpg")
    if get_skin_string(MODE_BACKGROUND_STRING) != bg:
        set_skin_string(MODE_BACKGROUND_STRING, bg)
    if xbmcgui is not None:
        try:
            xbmcgui.Window(HOME_WINDOW_ID).setProperty(
                "RocOS.Background", bg)
        except Exception:
            pass
    return bg


def mode_set(mode):
    """action=mode_set,mode=Day|Midday|Night (v3.3.0): set RocOS.Mode
    directly as a manual override (same hold semantics as mode_cycle —
    it lasts until the next automatic light change) and publish the
    matching background slot. ModeSource=Auto clock behavior is
    untouched: sync_daypart still owns Auto when no override is alive.
    """
    mode = (mode or "").strip().capitalize()
    if mode not in MODE_BACKGROUNDS:
        log("mode_set refused unknown mode: %r" % mode)
        notify("Unknown light mode", "That mode is not Day Midday or Night",
               ok=False)
        return ""
    now_dt = datetime.datetime.now().astimezone()
    state = _state()
    state["manual"] = {"mode": mode, "until": next_boundary(now_dt)}
    _save_state(state)
    set_skin_string(MODE_SKIN_STRING, mode)
    set_skin_string(MODE_SOURCE_STRING, "Manual")
    bg = publish_mode_background(mode)
    roc_log("Light set to %s (manual, background %s)" % (mode, bg),
            event="mode")
    notify("Light set to %s - manual until the next light change" % mode,
           3000)
    return mode


def sync_daypart(now_dt=None):
    """Apply the automatic daypart unless a manual override is alive.

    Returns the effective mode. Safe to call often (service loop + Home
    onload); only writes skin strings when something actually changes.
    """
    now_dt = now_dt or datetime.datetime.now().astimezone()
    manual = manual_override(now_dt.timestamp())
    if manual:
        if get_skin_string(MODE_SOURCE_STRING) != "Manual":
            set_skin_string(MODE_SOURCE_STRING, "Manual")
        if get_skin_string(MODE_SKIN_STRING) != manual["mode"]:
            set_skin_string(MODE_SKIN_STRING, manual["mode"])
        publish_mode_background(manual["mode"])
        return manual["mode"]
    # override expired (or never existed): clear it and go automatic
    state = _state()
    if state.get("manual"):
        state.pop("manual", None)
        _save_state(state)
    auto = daypart_for(now_dt)
    if get_skin_string(MODE_SOURCE_STRING) != "Auto":
        set_skin_string(MODE_SOURCE_STRING, "Auto")
    if get_skin_string(MODE_SKIN_STRING) != auto:
        set_skin_string(MODE_SKIN_STRING, auto)
    publish_mode_background(auto)
    return auto


def mode_cycle():
    """Dock light button: advance the mode and hold it as a manual
    override until the next automatic light change."""
    order = {"Night": "Midday", "Midday": "Day", "Day": "Night"}
    now_dt = datetime.datetime.now().astimezone()
    current = get_skin_string(MODE_SKIN_STRING) or daypart_for(now_dt)
    new_mode = order.get(current, "Night")
    state = _state()
    state["manual"] = {"mode": new_mode, "until": next_boundary(now_dt)}
    _save_state(state)
    set_skin_string(MODE_SKIN_STRING, new_mode)
    set_skin_string(MODE_SOURCE_STRING, "Manual")
    publish_mode_background(new_mode)
    roc_log("Light cycled to %s (manual)" % new_mode, event="mode")
    notify("Light set to %s - manual until the next light change" % new_mode,
           3000)
    return new_mode


# --------------------------------------------------------------------------
# Adult PIN gate — the PIN is Eric's, set on-device at first use.
# Only a salted PBKDF2-HMAC-SHA256 hash is stored (addon profile data).
# --------------------------------------------------------------------------
def derive_pin(pin, salt, iterations=PIN_ITERATIONS):
    return hashlib.pbkdf2_hmac(
        "sha256", pin.encode("utf-8"), salt, int(iterations), dklen=32)


def _read_json_from(dirpath, name):
    if not dirpath:
        return {}
    path = os.path.join(dirpath, name)
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        log("read %s failed: %s" % (name, exc))
        return {}


def _pin_record():
    """v3.2.0 (Eric flag, 2026-10-24: 'wouldn't take my PIN numbers —
    more than once, both of them'). The record used to live ONLY in
    the current profile's addon_data: set it under one profile context
    and the gate running under another saw no PIN, ran the set flow
    again (a SECOND PIN), and from then on each PIN verified only in
    its own context. The canonical store now lives in the MASTER
    profile (same from everywhere); the per-profile file stays as a
    legacy fallback read so a PIN set by an older build still works."""
    rec = _read_json_from(_master_data_dir(), "pin.json")
    if rec.get("hash") and rec.get("salt"):
        return rec
    return _read_json("pin.json")


def pin_is_set():
    rec = _pin_record()
    return bool(rec.get("hash") and rec.get("salt"))


def _save_pin(pin):
    salt = os.urandom(16)
    rec = {
        "version": 1,
        "kdf": "pbkdf2_sha256",
        "iterations": PIN_ITERATIONS,
        "salt": base64.b64encode(salt).decode("ascii"),
        "hash": base64.b64encode(
            derive_pin(pin, salt, PIN_ITERATIONS)).decode("ascii"),
        "created": int(time.time()),
    }
    # Write the canonical (master profile) store AND the per-profile
    # copy, so no profile context can ever drift onto a different PIN.
    ok = False
    master = _master_data_dir()
    if master:
        try:
            path = os.path.join(master, "pin.json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(rec, fh)
            os.replace(tmp, path)
            ok = True
        except Exception as exc:
            log("write master pin.json failed: %s" % exc)
    if _write_json("pin.json", rec):
        ok = True
    return ok


def verify_pin(pin, rec=None):
    rec = rec if rec is not None else _pin_record()
    if not rec.get("hash"):
        return False
    try:
        salt = base64.b64decode(rec["salt"])
        expected = base64.b64decode(rec["hash"])
        actual = derive_pin(pin, salt, rec.get("iterations", PIN_ITERATIONS))
        return hmac.compare_digest(actual, expected)
    except Exception as exc:
        log("verify_pin failed: %s" % exc)
        return False


def _prompt_pin(heading):
    """PIN prompt. Returns the entered string, or None on cancel.

    The NUMERIC pad is the primary prompt (v3.4.1): a PIN is
    digits, and the pad is the remote-native surface — big digit
    buttons, digits only. The full QWERTY password keyboard this
    used before (Dialog.input INPUT_PASSWORD) is the wrong tool
    for a D-pad: it opens with its Done button focused over a
    40-key grid, and an OK press submits an EMPTY field, which
    the flows then aborted in silence — from the couch that
    reads as "it wouldn't take my PIN" (Eric's standing
    complaint, first flagged 2026-10-24, reproduced live on the
    Dell 2026-10-26). The password keyboard remains as fallback
    if the pad ever fails to open."""
    if xbmcgui is None:
        return None
    dialog = xbmcgui.Dialog()
    value = None
    try:
        value = dialog.numeric(0, heading)
    except Exception as exc:
        log("pin numeric prompt failed: %s" % exc)
        value = None
    if value is None:
        try:
            input_type = getattr(xbmcgui, "INPUT_PASSWORD", None)
            if input_type is not None:
                value = dialog.input(heading, type=input_type)
            else:
                value = dialog.numeric(0, heading)
        except Exception as exc:
            log("pin prompt failed: %s" % exc)
            return None
    if value is None or value == "":
        return None
    return value.strip()


def _valid_new_pin(pin):
    return bool(pin) and pin.isdigit() and PIN_MIN_LEN <= len(pin) <= PIN_MAX_LEN


def _set_pin_flow():
    """First use: Eric sets his own PIN (entered twice)."""
    notify("First use - set your own PIN for the adult door", 5000)
    first = _prompt_pin("Set your PIN (4-8 digits)")
    if first is None:
        notify("No PIN entered - nothing was set", 5000, ok=False)
        return False
    if not _valid_new_pin(first):
        notify("PIN must be 4 to 8 digits - nothing was set", 5000, ok=False)
        return False
    second = _prompt_pin("Enter that PIN again to confirm")
    if second is None:
        notify("No PIN entered - nothing was set", 5000, ok=False)
        return False
    if second != first:
        notify("Those PINs did not match - nothing was set", 5000, ok=False)
        return False
    if not _save_pin(first):
        notify("Could not save the PIN on this device", 5000, ok=False)
        return False
    roc_log("Adult PIN set on this device", event="success")
    notify("PIN set - the adult door is yours now", 4000)
    return True


def _verify_pin_flow():
    pin = _prompt_pin("Enter your PIN")
    if pin is None:
        notify("No PIN entered - the door stays shut", 4000, ok=False)
        return False
    if verify_pin(pin):
        return True
    notify("Wrong PIN - the door stays shut", 4000, ok=False)
    return False


_ADDON_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


def adult_gate(target="plugin.video.cumination"):
    """Route the Home adult tile/dock stop through the PIN gate.

    First use sets the PIN, later uses verify it; only then does the
    adult addon open. `target` is an addon id, never a path.
    """
    target = (target or "").strip()
    if not _ADDON_ID_RE.match(target):
        log("adult_gate refused malformed target: %r" % target)
        notify("That adult door is not wired right - nothing opened", 5000, ok=False)
        return False
    if not pin_is_set():
        if not _set_pin_flow():
            return False
    elif not _verify_pin_flow():
        return False
    if xbmc is not None:
        if target == "plugin.video.cumination":
            # v3.2.0: the gate lands on the Adult HUB (window 1123) —
            # the browse-style room that mixes the sources — and
            # stamps the session the hub's guard re-checks.
            adult_session_open()
            xbmc.executebuiltin("ActivateWindow(%d)" % ADULT_WINDOW_ID)
        else:
            xbmc.executebuiltin(
                "ActivateWindow(Videos,plugin://%s/,return)" % target)
    return True


def reset_pin():
    """Change the PIN: current PIN first, then the set flow."""
    if pin_is_set() and not _verify_pin_flow():
        return False
    return _set_pin_flow()


# --------------------------------------------------------------------------
# Focus memory — last focused control per window, restored on return.
# Stored in the addon profile data; the service owns reads/writes.
# --------------------------------------------------------------------------
def load_focus_memory():
    data = _read_json("focus-memory.json")
    return data if isinstance(data, dict) else {}


def save_focus_memory(memory):
    return _write_json("focus-memory.json", memory)


def current_window_and_focus():
    """(window_id, focus_id) or (None, None) when the API is unavailable."""
    if xbmcgui is None:
        return None, None
    try:
        win_id = xbmcgui.getCurrentWindowId()
        if not win_id:
            return None, None
        focus_id = xbmcgui.Window(win_id).getFocusId()
        return int(win_id), int(focus_id or 0)
    except Exception:
        return None, None


def restore_focus(win_id, focus_id):
    if xbmcgui is None or not focus_id:
        return False
    try:
        xbmcgui.Window(int(win_id)).setFocusId(int(focus_id))
        return True
    except Exception as exc:
        log("restore_focus %s/%s failed: %s" % (win_id, focus_id, exc))
        return False


# ==========================================================================
# VPN STATUS HOOK — Phase 2 preparation ONLY.
#
# detect_vpn_state() is the single, clearly-marked place that decides what
# the dock shield shows. Contract: it returns ("on" | "off" | "unknown",
# source-string). It may only say "on" when a tunnel interface is actually
# present (and up, where the platform exposes state). When the platform
# exposes nothing readable it returns "unknown" — and the skin renders
# "unknown" with the OFF shield, never the lit one. No fake ON, ever.
#
# Signals, in order:
#   1. /sys/class/net (Linux + Android): tun*/tap*/wg*/ppp* interfaces,
#      with operstate/carrier checked where readable.
#   2. /proc/net/dev (Linux + Android fallback): tunnel interface present.
#   3. Anything else (incl. Windows): "unknown" — adapter enumeration is
#      deliberately NOT faked here; it lands with the on-device phase,
#      where the R26 both-states hardware gate also lives.
# ==========================================================================
_TUN_PREFIXES = ("tun", "tap", "wg", "ppp")

# MERGE RUN (2026-11-06) — non-VPN kernel bookkeeping interfaces.
# These exist on stock Linux/Android kernels whether or not any
# VPN has ever run, so their mere presence must NEVER read as a
# tunnel: the tunnel bookkeeping devices tunl0 / ip6tnl0 plus the
# exact names sit0 (IPv6-in-IPv4 sit device), ip_vti0 and ip6_vti0
# (VTI bookkeeping). Spelling note: the two kernel names do NOT
# share one suffix — "ip6tnl0" ends in "tnl0" but "tunl0" ends in
# "tunl0" (t-u-n-l-0), so the predicate tests BOTH suffixes; a
# lone endswith("tnl0") would miss tunl0 itself, the very device
# in the proven defect. Proven live on the .159 stick: with the
# Proton tunnel verifiably DOWN (pid dead, no tun0 in
# /proc/net/dev), tunl0 + ip6tnl0 were still listed with zero
# counters and the old startswith("tun") matcher read vpn=on.
_VPN_BOOKKEEPING_EXACT = frozenset(["sit0", "ip_vti0", "ip6_vti0"])

# COORDINATOR PATCH (merge run, 2026-11-07) — WALL-MAP Wall 6 recipe:
# the candidate test is an ANCHORED full match, ^(tun|tap|wg|ppp)\d+$
# — after the prefix must come a digit, and then the name must END.
# Hand A's startswith form also credited names like "tunfake0"
# (tunnel prefix + trailing letters) whenever they carried counters;
# the recipe does not. The bookkeeping exclusion above and the
# evidence-of-life rule (rx > 0 / operstate, in detect_vpn_state)
# are unchanged — tunl0 dies on BOTH tests: it fails the anchored
# match (after "tun" comes "l", not a digit) and it is bookkeeping.
_TUN_ANCHORED = re.compile(r"(?:tun|tap|wg|ppp)\d+\Z")


def _is_tunnel_candidate(name):
    """Anchored Wall-6 candidate test for one interface name."""
    return bool(_TUN_ANCHORED.match((name or "").strip()))


def _is_vpn_bookkeeping(name):
    """True for non-VPN kernel bookkeeping interfaces (see above):
    any name ending in "tnl0" or "tunl0", plus sit0 / ip_vti0 /
    ip6_vti0."""
    name = (name or "").strip()
    return (name.endswith("tnl0") or name.endswith("tunl0")
            or name in _VPN_BOOKKEEPING_EXACT)


def _tun_names_from_listing(names):
    """Candidate tunnel interfaces from a name listing: tunnel
    prefix (tun/tap/wg/ppp), bookkeeping names excluded. Presence
    alone is NOT proof of a live VPN — callers must also see live
    traffic (or, sysfs-only, a not-down operstate when statistics
    are unreadable); see detect_vpn_state."""
    return [n for n in names
            if _is_tunnel_candidate(n)
            and not _is_vpn_bookkeeping(n)]


def _vpn_state_from_proc_text(text):
    """Pure /proc/net/dev verdict: (state, source) or None when
    the text carries no parseable interface lines at all (the
    caller then falls through to "unknown"). A candidate tunnel
    interface counts ONLY with live traffic — its rx-bytes field
    (the first number after the colon) must be > 0. Bookkeeping
    interfaces never count, even with counters. A world whose
    only tunnels sit at zero counters reads "off" with the honest
    source "proc-net-dev:no-live-tunnel-interface". Offline-
    testable: no I/O, no Kodi."""
    saw_interface = False
    for line in (text or "").splitlines():
        if ":" not in line:
            continue
        name, _colon, rest = line.partition(":")
        name = name.strip()
        if not name:
            continue
        saw_interface = True
        if (not _is_tunnel_candidate(name)
                or _is_vpn_bookkeeping(name)):
            continue
        fields = rest.split()
        try:
            rx_bytes = int(fields[0]) if fields else 0
        except Exception:
            rx_bytes = 0
        if rx_bytes > 0:
            return "on", "proc-net-dev:%s" % name
    if saw_interface:
        return "off", "proc-net-dev:no-live-tunnel-interface"
    return None


# FIX BATCH 2026-11-10: the VPN checks below run every service tick
# (~2-5 s). On Fire OS 8 both kernel reads are SELinux-denied to Kodi,
# so the failure lines repeated forever and drowned the log (measured
# on the bedroom stick: the same two lines every few seconds for
# hours). Identical failures now log at most once per window per key.
_LOG_THROTTLE = {}
_LOG_THROTTLE_WINDOW = 300.0


def _log_throttled(key, msg):
    now = time.time()
    last = _LOG_THROTTLE.get(key) or 0.0
    if now - last >= _LOG_THROTTLE_WINDOW:
        _LOG_THROTTLE[key] = now
        log(msg)


def detect_vpn_state():
    if os.name == "nt":
        return "unknown", "windows-adapter-enumeration-not-implemented"
    sysfs = "/sys/class/net"
    try:
        if os.path.isdir(sysfs):
            names = os.listdir(sysfs)
            tuns = _tun_names_from_listing(names)
            if not tuns:
                return "off", "sysfs:no-tunnel-interface"
            saw_zero_traffic = False
            for name in tuns:
                # A candidate counts only with live traffic where
                # statistics are readable (rx_bytes > 0). If the
                # statistics are unreadable, fall back to the
                # operstate logic for that interface (the
                # bookkeeping exclusion above still applies).
                rx_bytes = None
                try:
                    with open(os.path.join(sysfs, name, "statistics",
                                           "rx_bytes"),
                              "r", encoding="utf-8") as fh:
                        rx_bytes = int(fh.read().strip() or 0)
                except Exception:
                    rx_bytes = None
                if rx_bytes is not None:
                    if rx_bytes > 0:
                        return "on", "sysfs:%s(rx=%d)" % (name, rx_bytes)
                    saw_zero_traffic = True
                    continue
                state = ""
                try:
                    with open(os.path.join(sysfs, name, "operstate"),
                              "r", encoding="utf-8") as fh:
                        state = fh.read().strip().lower()
                except Exception:
                    state = ""
                if state in ("", "up", "unknown"):
                    # Android often reports operstate 'unknown' for a live
                    # tun; presence + not-down is the honest positive here.
                    if state != "down":
                        return "on", "sysfs:%s(%s)" % (name, state or "?")
            if saw_zero_traffic:
                return "off", "sysfs:no-live-tunnel-interface"
            return "off", "sysfs:tunnel-interface-down"
    except Exception as exc:
        _log_throttled("sysfs", "vpn sysfs check failed: %s" % exc)
    try:
        with open("/proc/net/dev", "r", encoding="utf-8") as fh:
            verdict = _vpn_state_from_proc_text(fh.read())
        if verdict is not None:
            return verdict
    except Exception as exc:
        _log_throttled("proc", "vpn /proc check failed: %s" % exc)
    # FIX BATCH 2026-11-10: both kernel reads were denied (Fire OS 8
    # SELinux: Kodi is untrusted_app and may read neither sysfs_net
    # nor proc_net — avc denials measured in the bedroom stick's
    # logcat). "No signal" here means WE are blind, not that the
    # tunnel is down, so before answering "unknown" (which closes
    # the gate and raises the "Can't confirm the VPN" modal over a
    # tunnel that is verifiably up), corroborate with the one tunnel
    # witness Kodi CAN read: the egress country lookup through the
    # tunnel itself, via the region cache detect_vpn_region keeps.
    corroborated = _egress_corroboration()
    if corroborated is not None:
        return corroborated
    return "unknown", "no-readable-network-signal"


def publish_vpn_state():
    """Write the VPN surface properties onto the Home window (10000).

    Skin reads Window(10000).Property(RocVPN.State) etc. 'unknown' is a
    real published state — the skin maps it to the OFF shield + 'VPN ?'.

    0.6.8: also publishes the REGION + PHASE surface (Eric, 2026-11-10
    — "VPN on and then Netherlands or whatnot", plus his transition
    states and his abbreviation call: codes, not whole words):
    RocVPN.Region (full name) / RocVPN.RegionCode (the tunnel's real
    exit country, from detect_vpn_region's egress-IP lookup — never
    guessed), RocVPN.Phase (connected | connecting | settled, from
    detect_vpn_phase), RocVPN.Target (the connecting target when it
    is honestly known), RocVPN.TargetOK ('true' only when the tunnel
    is on AND exiting in the Netherlands) and RocVPN.Display, the
    exact string Home renders:
        connected NL       -> 'VPN ● NL'
        connected elsewhere-> 'VPN ● US'   (plain, on purpose)
        connected, unverified region -> 'VPN on'
        connecting, target known     -> 'VPN connecting… NL'
        connecting, target unknown   -> 'VPN connecting…'
        off                -> 'VPN off'
        unknown            -> 'VPN ?'
    """
    state, source = detect_vpn_state()
    region = detect_vpn_region(state)
    code, name = region if region else ("", "")
    phase = detect_vpn_phase(state)
    target = ""
    if phase == "connecting":
        cache = _read_json(_REGION_CACHE_FILE)
        fix_target = str(cache.get("fix_target") or "")
        try:
            fix_ts = float(cache.get("fix_ts") or 0)
        except Exception:
            fix_ts = 0.0
        if fix_target and (time.time() - fix_ts) < _FIX_TARGET_TTL_SECONDS:
            target = fix_target
    display = vpn_display_for(state, phase, code, target)
    if xbmcgui is not None:
        try:
            home = xbmcgui.Window(HOME_WINDOW_ID)
            home.setProperty("RocVPN.State", state)
            home.setProperty("RocVPN.On", "true" if state == "on" else "false")
            home.setProperty("RocVPN.Source", source)
            home.setProperty(
                "RocVPN.Label",
                {"on": "VPN ON", "off": "VPN OFF"}.get(state, "VPN ?"))
            home.setProperty("RocVPN.Region", name)
            home.setProperty("RocVPN.RegionCode", code)
            home.setProperty("RocVPN.Phase", phase)
            home.setProperty("RocVPN.Target", target)
            home.setProperty(
                "RocVPN.TargetOK",
                "true" if (state == "on" and code == VPN_TARGET_CODE)
                else "false")
            home.setProperty("RocVPN.Display", display)
            home.setProperty("RocVPN.Checked", str(int(time.time())))
        except Exception as exc:
            log("publish_vpn_state failed: %s" % exc)
    return state, source


# ---------------------------------------------------------------------------
# Trakt state surface (SKIN PASS 2026-11-11 — Eric's order 2026-11-11
# 18:38: the Grin/Power TRAKT - CONNECT row must SHOW whether Trakt is
# connected; a stateless connect button leaves him guessing whether it
# dropped). Publishes Window(10000).Property(RocTrakt.State):
#   connected    — Trakt's own API answered 200 to THIS profile's stored
#                  token (GET /users/me) inside the throttle window.
#   disconnected — no token stored for this profile, or the live check
#                  answered 401/403 (token dead/revoked).
#   off          — this profile carries the rocprofiles no_trakt flag
#                  (August): Trakt is not part of that profile at all.
#   unknown      — no live verdict yet and none could be taken (offline,
#                  helper missing, Trakt 5xx). The menus render unknown
#                  exactly like disconnected — the plain CONNECT row —
#                  so CONNECTED can never appear without a real 200.
# RocTrakt.User carries the account username from that same 200.
# The live call is throttled to TRAKT_LIVE_EVERY seconds; between live
# checks the last verified verdict stands. Token presence alone NEVER
# publishes 'connected'.
# ---------------------------------------------------------------------------
_TRAKT_LIVE = {"ts": 0.0, "state": "", "user": ""}
TRAKT_LIVE_EVERY = 300.0


def _trakt_client_id():
    """The public Trakt client id the helper stack sends as the
    trakt-api-key header, read from its own source on disk. '' if
    unreadable (live check then refuses to run and no verdict is
    published).

    The keys followed the credentials into the sync module: current
    installs carry them at script.module.tmdbhelper.sync.trakt/
    resources/lib/tmdbhelper_sync_trakt/api/keys.py, and the
    helper's own resources/tmdbhelper/lib/api/api_keys/trakt.py no
    longer exists there (measured 2026-11-15 — reading only the
    legacy path failed with ENOENT on every publish, so no live
    verdict could ever be taken). Try the sync module first, the
    legacy helper path second (unmigrated installs)."""
    if xbmc is None:
        return ""
    for rel in (
            "addons/script.module.tmdbhelper.sync.trakt/resources/"
            "lib/tmdbhelper_sync_trakt/api/keys.py",
            "addons/plugin.video.themoviedb.helper/resources/"
            "tmdbhelper/lib/api/api_keys/trakt.py"):
        try:
            path = xbmcvfs.translatePath("special://home/" + rel)
            with open(path, "r") as fh:
                text = fh.read()
            m = re.search(r"CLIENT_ID\s*=\s*'([0-9a-f]{64})'", text)
            if m:
                return m.group(1)
        except Exception as exc:
            log("trakt client id read failed (%s): %s" % (rel, exc))
    return ""


def _trakt_token_from_blob(raw):
    """Extract the access token from a stored Trakt credential blob:
    the JSON shape ({'access_token': ...}) the credential stores use,
    or a bare token string. '' when the blob is empty or carries no
    access token."""
    if not raw or not str(raw).strip():
        return ""
    raw = str(raw).strip()
    try:
        data = json.loads(raw)
    except Exception:
        return raw
    if isinstance(data, dict):
        return str(data.get("access_token") or "")
    return raw


def _trakt_stored_token():
    """The LOADED profile's stored Trakt access token, or ''.

    The helper migrated its Trakt credentials OUT of its own
    'trakt_token' setting into the sync module
    (script.module.tmdbhelper.sync.trakt, setting 'token'; the sync
    settings carry 'credentials_migrated'). On a migrated install
    the legacy setting reads empty forever, so reading only it made
    this publisher report 'disconnected' while the account was in
    fact connected and syncing (measured 2026-11-15: legacy value
    length 0, sync token present, sync fetches succeeding, zero
    401s — yet Home showed 'Sign in to Trakt'). Read the sync
    module FIRST; fall back to the legacy helper setting for
    unmigrated installs (.159's generation, whose helper setting is
    still populated). Addon settings are per-profile, so this is
    always the current profile's token — never another profile's.
    Token values are never logged."""
    if xbmcaddon is None:
        return ""
    for addon_id, setting in (
            ("script.module.tmdbhelper.sync.trakt", "token"),
            ("plugin.video.themoviedb.helper", "trakt_token")):
        try:
            raw = xbmcaddon.Addon(addon_id).getSetting(setting)
        except Exception as exc:
            log("trakt token read failed (%s): %s" % (addon_id, exc))
            continue
        token = _trakt_token_from_blob(raw)
        if token:
            return token
    return ""


def _trakt_live_check(token):
    """One small authenticated call against Trakt (GET /users/me).
    Returns (state, user): ('connected', username) on a 200,
    ('disconnected', '') on 401, ('', '') when no verdict could be
    taken (network down, Trakt 5xx, no client id) — callers keep the
    last verified verdict in that case."""
    import urllib.request
    import urllib.error
    client_id = _trakt_client_id()
    if not client_id or not token:
        return "", ""
    req = urllib.request.Request(
        "https://api.trakt.tv/users/me",
        headers={
            "Content-Type": "application/json",
            "trakt-api-version": "2",
            "trakt-api-key": client_id,
            "Authorization": "Bearer " + token,
            # Trakt's edge 403s urllib's default user-agent before
            # auth (proven 2026-11-11: same key + no token gives 403
            # as Python-urllib, 401 as any ordinary UA) — send one.
            "User-Agent": "Mozilla/5.0 (Linux; Android 11) "
                          "AppleWebKit/537.36",
        })
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            if getattr(resp, "status", 200) != 200:
                return "", ""
            data = json.loads(resp.read().decode("utf-8", "replace"))
            return "connected", str(data.get("username") or "")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return "disconnected", ""
        log("trakt live check http %s (no verdict)" % exc.code)
        return "", ""
    except Exception as exc:
        log("trakt live check failed (no verdict): %s" % exc)
        return "", ""


def publish_trakt_state():
    """Write the Trakt surface properties onto the Home window
    (10000), in the same shape as publish_vpn_state. Best-effort and
    guarded: any failure leaves the last published state standing and
    never raises into the service loop."""
    state = "unknown"
    user = ""
    try:
        if xbmcgui is not None and xbmcgui.Window(
                HOME_WINDOW_ID).getProperty(
                "RocProfiles.NoTrakt") == "true":
            state = "off"
        else:
            token = _trakt_stored_token()
            if not token:
                state = "disconnected"
                _TRAKT_LIVE.update({"ts": 0.0, "state": "",
                                    "user": ""})
            else:
                now = time.time()
                if (_TRAKT_LIVE["state"]
                        and (now - _TRAKT_LIVE["ts"]) < TRAKT_LIVE_EVERY):
                    state = _TRAKT_LIVE["state"]
                    user = _TRAKT_LIVE["user"]
                else:
                    live, live_user = _trakt_live_check(token)
                    if live:
                        _TRAKT_LIVE.update(
                            {"ts": now, "state": live, "user": live_user})
                        state, user = live, live_user
                    elif _TRAKT_LIVE["state"]:
                        state = _TRAKT_LIVE["state"]
                        user = _TRAKT_LIVE["user"]
    except Exception as exc:
        log("trakt state read failed: %s" % exc)
    if xbmcgui is not None:
        try:
            home = xbmcgui.Window(HOME_WINDOW_ID)
            home.setProperty("RocTrakt.State", state)
            home.setProperty("RocTrakt.User", user)
            home.setProperty("RocTrakt.Checked", str(int(time.time())))
        except Exception as exc:
            log("publish_trakt_state failed: %s" % exc)
    return state


# ==========================================================================
# VPN REGION + PHASE — the honest exit-country / transition surface
# behind RocVPN.Display.
#
# REGION. detect_vpn_state() can only see the tunnel interface; it
# cannot know where the tunnel EXITS. The region therefore comes from
# the one witness that cannot lie about it: the device's own egress
# IP, asked of a geolocation service THROUGH the tunnel (the lookup
# traffic itself rides the VPN, so the answer describes the exit, not
# the house). Signals, in order:
#   1. https://ipapi.co/json/   (country_code + country_name)
#   2. https://ipwho.is/        (country_code + country)
# Both keyless HTTPS. No answer (or a malformed one) = region UNKNOWN,
# and the surface renders plain 'VPN on' — a region is never guessed,
# and a bare country code is never shown in place of its name on the
# RocVPN.Region property (the Display string uses the code itself,
# which IS the code, per Eric's abbreviation call).
#
# PHASE. The egress witness can only prove the SETTLED state, so the
# transition word comes from the interface evidence itself, read by
# detect_vpn_phase() — a display-only refinement that NEVER feeds
# back into detect_vpn_state (the playback gate depends on that
# function's strict 'on', and it is byte-untouched):
#   * 'connected'  — detect_vpn_state said on.
#   * 'connecting' — a real tunnel interface EXISTS but has carried
#     no traffic yet, and has been in that shape less than
#     _CONNECTING_MAX_SECONDS. Older than that it is a stalled
#     tunnel, and the surface falls back to the settled word.
#   * 'settled'    — everything else.
# 'disconnecting' is deliberately NOT rendered: teardown removes the
# interface outright, and interface-down is indistinguishable from a
# dead tunnel — the poll source cannot prove it, so it is not faked.
# If a future source (a Proton broadcast/intent) exposes these
# states directly, it binds inside detect_vpn_phase.
#
# CONNECTING TARGET. Shown only when honestly known: a fix-button
# request records fix_target=NL in the cache (vpn_fix), and the
# connecting display may name it for _FIX_TARGET_TTL_SECONDS. A
# connect started inside Proton names NO target — Proton's chosen
# country is not readable from here, so it is not invented.
#
# Cache law (vpn_region_cache.json in the addon data dir):
#   * a verified region is trusted for _REGION_TTL_SECONDS;
#   * the moment a publish sees the tunnel NOT on, the cached region
#     verdict is destroyed — a new tunnel owes a fresh lookup (the
#     phase/fix bookkeeping keys survive the wipe; they are not a
#     region verdict);
#   * vpn_fix() marks the cache 'pending': the surface then shows
#     plain 'VPN on' (honest unknown) and lookups retry on the
#     pending cadence until one verifies the new exit. A failed
#     switch can therefore never render as success: the display only
#     ever changes when a lookup through the live tunnel says so.
# ==========================================================================
VPN_TARGET_CODE = "NL"
VPN_TARGET_NAME = "Netherlands"
_REGION_CACHE_FILE = "vpn_region_cache.json"
_REGION_TTL_SECONDS = 300
_REGION_RETRY_SECONDS = 60
_REGION_PENDING_RETRY_SECONDS = 15
_REGION_LOOKUP_TIMEOUT = 8
_CONNECTING_MAX_SECONDS = 120
_FIX_TARGET_TTL_SECONDS = 600
_REGION_ENDPOINTS = (
    ("https://ipapi.co/json/", "country_code", "country_name"),
    ("https://ipwho.is/", "country_code", "country"),
    ("https://api.myip.com", "cc", "country"),
    ("https://freeipapi.com/api/json", "countryCode", "countryName"),
)

# ROC-GATEFIX 2026-11-11 (bedroom .155 only): hysteresis for the
# egress witness. A verified NL verdict stays trusted for
# _REGION_GRACE_SECONDS when later lookups merely FAIL (timeout /
# no answer): the gate holds "on" instead of flapping closed and
# raising the "Can't confirm the VPN" modal over a healthy tunnel.
# A SUCCESSFUL lookup always decides instantly — a verified
# non-NL exit closes the gate the tick it is seen (fresh-cache and
# live-lookup paths above are untouched). Grace never applies to
# a non-NL verdict and never resurrects one past the window.
_REGION_GRACE_SECONDS = 1800


def _grace_verdict(code, ok_ts, now):
    """('on', source) when the last verified verdict was the NL
    target inside the grace window; None otherwise."""
    if code == VPN_TARGET_CODE and ok_ts and \
            (now - ok_ts) < _REGION_GRACE_SECONDS:
        return "on", "egress:%s(grace)" % code
    return None


def _fetch_egress_country():
    """(code, name) for the current egress IP, or None. Live network
    I/O — callers own the throttling (see detect_vpn_region)."""
    try:
        import urllib.request
    except Exception:
        return None
    for url, code_key, name_key in _REGION_ENDPOINTS:
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "RocOS/2.0 (script.rocui)"})
            with urllib.request.urlopen(
                    req, timeout=_REGION_LOOKUP_TIMEOUT) as resp:
                data = json.loads(resp.read().decode("utf-8", "replace"))
            code = str(data.get(code_key) or "").strip().upper()
            name = str(data.get(name_key) or "").strip()
            if len(code) == 2 and code.isalpha() and name:
                return code, name
        except Exception as exc:
            log("vpn region lookup failed (%s): %s" % (url, exc))
    return None


def detect_vpn_region(state):
    """(code, name) of the tunnel's exit country, or None when that
    is not honestly known. Only defined while state == 'on'."""
    if state != "on":
        cache = _read_json(_REGION_CACHE_FILE)
        if cache:
            keep = {}
            # FIX BATCH 2026-11-10: the egress fact keys are kept too
            # (this function still returns None while not "on" — the
            # surface is unchanged). _egress_corroboration reads them
            # on kernel-blind sticks (Fire OS 8); wiping them every
            # tick made its verdict flap between the true egress
            # country and "unknown" once a minute.
            for key in ("idle_since", "fix_target", "fix_ts",
                        "code", "name", "ok_ts", "try_ts"):
                if cache.get(key):
                    keep[key] = cache[key]
            if keep != cache:
                _write_json(_REGION_CACHE_FILE, keep)
        return None
    now = time.time()
    cache = _read_json(_REGION_CACHE_FILE)
    code = str(cache.get("code") or "")
    name = str(cache.get("name") or "")
    try:
        ok_ts = float(cache.get("ok_ts") or 0)
    except Exception:
        ok_ts = 0.0
    try:
        try_ts = float(cache.get("try_ts") or 0)
    except Exception:
        try_ts = 0.0
    pending = bool(cache.get("pending"))
    if not pending and code and name and (now - ok_ts) < _REGION_TTL_SECONDS:
        return code, name
    wait = (_REGION_PENDING_RETRY_SECONDS if pending
            else _REGION_RETRY_SECONDS)
    if (now - try_ts) < wait:
        return None
    fetched = _fetch_egress_country()
    if fetched:
        _write_json(_REGION_CACHE_FILE, {
            "code": fetched[0], "name": fetched[1],
            "ok_ts": now, "try_ts": now, "pending": False,
            "fix_target": "", "fix_ts": 0})
        return fetched
    cache["try_ts"] = now
    _write_json(_REGION_CACHE_FILE, cache)
    if code and name and ok_ts and \
            (now - ok_ts) < _REGION_GRACE_SECONDS:
        return code, name
    return None


def _egress_corroboration():
    """FIX BATCH 2026-11-10: tunnel verdict from the egress witness,
    for worlds where Kodi may read neither sysfs nor /proc (Fire OS 8
    SELinux). Returns (state, source) or None when the witness cannot
    honestly speak:

      * cache marked pending (a fix/switch is mid-flight) -> None;
        a lookup in that window would race the switch.
      * fresh verified egress (inside the region TTL) -> "on" when
        the exit is the NL target, "off" when it verifiably exits
        somewhere else (the drift shape — the gate must still close,
        now with true evidence instead of blindness).
      * stale cache -> one throttled live lookup (same retry cadence
        as detect_vpn_region); a successful lookup refreshes the
        region cache in detect_vpn_region's own shape and decides
        the same way. Lookup failure -> None (stay "unknown" this
        tick; the retry window keeps this cheap).

    The fast kernel paths keep precedence: this runs only when both
    of them produced no verdict at all."""
    now = time.time()
    cache = _read_json(_REGION_CACHE_FILE)
    if cache.get("pending"):
        return None
    code = str(cache.get("code") or "").strip().upper()
    try:
        ok_ts = float(cache.get("ok_ts") or 0)
    except Exception:
        ok_ts = 0.0
    try:
        try_ts = float(cache.get("try_ts") or 0)
    except Exception:
        try_ts = 0.0
    if code and (now - ok_ts) < _REGION_TTL_SECONDS:
        if code == VPN_TARGET_CODE:
            return "on", "egress:%s" % code
        return "off", "egress:%s" % code
    if (now - try_ts) < _REGION_RETRY_SECONDS:
        return _grace_verdict(code, ok_ts, now)
    fetched = _fetch_egress_country()
    if fetched:
        cache.update({"code": fetched[0], "name": fetched[1],
                      "ok_ts": now, "try_ts": now, "pending": False})
        _write_json(_REGION_CACHE_FILE, cache)
        if fetched[0] == VPN_TARGET_CODE:
            return "on", "egress:%s" % fetched[0]
        return "off", "egress:%s" % fetched[0]
    cache["try_ts"] = now
    _write_json(_REGION_CACHE_FILE, cache)
    return _grace_verdict(code, ok_ts, now)


def _tunnel_present_idle():
    """True when a real tunnel interface exists but has carried no
    traffic yet (the connecting shape); False when no candidate is in
    that shape; None when nothing is readable. Mirrors
    detect_vpn_state's evidence order and bookkeeping exclusions;
    display-only (see detect_vpn_phase). An interface that is DOWN
    is not the connecting shape — it is the dead/disconnecting shape,
    which this surface deliberately does not name."""
    if os.name == "nt":
        return None
    sysfs = "/sys/class/net"
    try:
        if os.path.isdir(sysfs):
            names = os.listdir(sysfs)
            tuns = _tun_names_from_listing(names)
            if not tuns:
                return False
            for name in tuns:
                rx_bytes = None
                try:
                    with open(os.path.join(sysfs, name, "statistics",
                                           "rx_bytes"),
                              "r", encoding="utf-8") as fh:
                        rx_bytes = int(fh.read().strip() or 0)
                except Exception:
                    rx_bytes = None
                if rx_bytes is not None:
                    if rx_bytes == 0:
                        return True
                    continue
                state = ""
                try:
                    with open(os.path.join(sysfs, name, "operstate"),
                              "r", encoding="utf-8") as fh:
                        state = fh.read().strip().lower()
                except Exception:
                    state = ""
                if state == "down":
                    continue
                # Unreadable statistics + not down: detect_vpn_state
                # reads this as on; it is not the idle shape.
            return False
    except Exception as exc:
        _log_throttled("idle-sysfs",
                       "vpn idle sysfs check failed: %s" % exc)
    try:
        with open("/proc/net/dev", "r", encoding="utf-8") as fh:
            text = fh.read()
        for line in text.splitlines():
            if ":" not in line:
                continue
            name, _colon, rest = line.partition(":")
            name = name.strip()
            if (not _is_tunnel_candidate(name)
                    or _is_vpn_bookkeeping(name)):
                continue
            fields = rest.split()
            try:
                rx_bytes = int(fields[0]) if fields else 0
            except Exception:
                rx_bytes = 0
            if rx_bytes == 0:
                return True
        return False
    except Exception as exc:
        _log_throttled("idle-proc",
                       "vpn idle /proc check failed: %s" % exc)
    return None


def detect_vpn_phase(state):
    """Display-only phase for the readout: 'connected' |
    'connecting' | 'settled'. See the section header for the honesty
    contract — this function never influences detect_vpn_state or
    the gate; it only decides whether Home may say 'connecting'."""
    cache = _read_json(_REGION_CACHE_FILE)
    if state == "on":
        if cache.get("idle_since"):
            cache.pop("idle_since", None)
            _write_json(_REGION_CACHE_FILE, cache)
        return "connected"
    if _tunnel_present_idle():
        now = time.time()
        try:
            since = float(cache.get("idle_since") or 0)
        except Exception:
            since = 0.0
        if not since:
            cache["idle_since"] = now
            _write_json(_REGION_CACHE_FILE, cache)
            since = now
        if (now - since) < _CONNECTING_MAX_SECONDS:
            return "connecting"
        return "settled"
    if cache.get("idle_since"):
        cache.pop("idle_since", None)
        _write_json(_REGION_CACHE_FILE, cache)
    return "settled"


def vpn_display_for(state, phase, region_code, target_code):
    """The exact Home readout string. Pure — the state table lives
    here and nowhere else:
        connected + verified code -> 'VPN ● <CODE>'
        connected, no verdict     -> 'VPN on'
        connecting + known target -> 'VPN connecting… <CODE>'
        connecting, no target     -> 'VPN connecting…'
        off                       -> 'VPN off'
        unknown                   -> 'VPN ?'
    'disconnecting' does not exist here on purpose (see header)."""
    if state == "on":
        if region_code:
            return "VPN ● %s" % region_code
        return "VPN on"
    if phase == "connecting":
        if target_code:
            return "VPN connecting… %s" % target_code
        return "VPN connecting…"
    if state == "off":
        return "VPN off"
    return "VPN ?"


def vpn_switch_hook():
    """THE SWITCH — the one place the 'switch to Netherlands'
    mechanism binds. OPEN JOINT (2026-11-10): the VPN fix lane's
    on-device record (workspace/kodi-build/PATIO-VPN-DRIFT-20261110.md)
    has not landed yet, so no direct silent switch is bound. What
    binds TODAY is the strongest honest mechanism a Kodi add-on has
    on Fire OS: open Proton VPN itself (proton_vpn()), where the
    house Netherlands connection is the pinned/default one — the
    user lands on Proton's own reconnect surface. A silent in-place
    switch is NOT claimed: Android reserves VPN control to the VPN
    app itself, and Proton's Fire TV app exposes no verified
    connect-to-country intent to other apps. When the fix lane
    proves a direct mechanism, it lands INSIDE this function and
    nowhere else; vpn_fix and the skin do not change."""
    return proton_vpn()


def vpn_fix():
    """action=vpn_fix — Eric's Home fix button for a wrong/off VPN
    state (2026-11-10: 'click it like a fix button where it switches
    to Netherlands from there'). Fires the switch hook, marks the
    region cache pending (the cached country is about to stop being
    true, so it must not be trusted), records the honest connecting
    target (NL — the country this button exists to reach), and
    republishes — the readout re-verifies through the live tunnel
    and renders the NEW truth. If the switch was not taken or
    failed, the display keeps showing the real state: success is
    never rendered on the click's say-so.
    """
    state, _source = detect_vpn_state()
    region = detect_vpn_region(state)
    roc_log("VPN fix requested from Home (state=%s, region=%s)"
            % (state, region[1] if region else "unknown"),
            event="vpn")
    cache = _read_json(_REGION_CACHE_FILE)
    cache["pending"] = True
    cache["try_ts"] = time.time()
    cache["fix_target"] = VPN_TARGET_CODE
    cache["fix_ts"] = time.time()
    _write_json(_REGION_CACHE_FILE, cache)
    ok = False
    try:
        ok = bool(vpn_switch_hook())
    except Exception as exc:
        log("vpn_fix switch hook failed: %s" % exc)
    publish_vpn_state()
    return ok


# ==========================================================================
# v3.2.0 — Detail Window, View More, timeline click, adult session,
# weather + notification publish, 3D select. (Eric's fix pass,
# 2026-10-24: stick flags 1/2/8/13/19/30/33 + Dell flags 2/3.)
# ==========================================================================
DETAIL_WINDOW_ID = 1124
ADULT_WINDOW_ID = 1123
ADULT_SESSION_SECONDS = 1800

_STAGE_FIELDS = [
    # (property, infolabel template on the source container)
    ("Title", "Title"), ("Plot", "Plot"), ("Year", "Year"),
    ("Genre", "Genre"), ("Duration", "Duration"), ("MPAA", "MPAA"),
    ("Director", "Director"), ("Studio", "Studio"),
    ("Country", "Country"), ("Trailer", "Trailer"),
    ("Path", "FileNameAndPath"), ("DBType", "DBType"),
    ("TVShowTitle", "TVShowTitle"), ("Season", "Season"),
    ("Episode", "Episode"), ("Cast", "Cast"),
]


def _info(fmt, *args):
    if xbmc is None:
        return ""
    try:
        return xbmc.getInfoLabel(fmt % args) or ""
    except Exception:
        return ""


def _format_duration(value):
    """One Duration format for the detail page (Loop 299, MOVIES FEEL
    fix from Loop 298's scope): TMDB runtimes arrive as bare minutes
    (135) and Kodi's ListItem.Duration as a timecode (2:15:00) — the
    detail window's info line rendered whichever it got, so the same
    page showed "2024  -  135  -  ..." on a TMDB load and a different
    format on a failed one. Both stage_open() and
    open_collection_title() publish through here, so the line always
    reads "2h 15m" / "45m" / "1h". Unknown shapes pass through
    unchanged — never blank a value we do not understand."""
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        minutes = int(value)
    else:
        text = str(value).strip()
        if not text:
            return ""
        if "h" in text or "m" in text:
            return text
        if text.isdigit():
            minutes = int(text)
        elif ":" in text:
            parts = text.split(":")
            try:
                nums = [int(p) for p in parts]
            except ValueError:
                return text
            if len(nums) == 3:
                minutes = nums[0] * 60 + nums[1]
            elif len(nums) == 2:
                minutes = nums[0]
            else:
                return text
        else:
            try:
                minutes = int(float(text))
            except ValueError:
                return text
    if minutes <= 0:
        return ""
    if minutes < 60:
        return "%dm" % minutes
    hours, rem = divmod(minutes, 60)
    if rem == 0:
        return "%dh" % hours
    return "%dh %dm" % (hours, rem)


def stage_open(cid):
    """Poster click -> Roc Detail Window (1124). Reads the clicked
    item out of its container on the current window and republishes
    it as Window(1124) properties the window renders. This route is
    fully Roc-owned: it cannot die the silent way the v3.1.0
    Action(Info) -> DialogVideoInfo route did on Eric's hardware."""
    if xbmc is None or xbmcgui is None:
        return False
    try:
        cid = int(cid)
    except Exception:
        return False
    # FIX-BATCH2 (HAND SRC, IA folder route): a FOLDER item from a
    # non-TMDb source (Internet Archive album/collection rows in the
    # Music/Sports/Wrestling hubs, Toonime catalog folders) is a
    # directory route, not a playable leaf. Sending it to the Detail
    # window made RocStage.Path a folder plugin URL, and the detail
    # PLAY button's PlayMedia(Path) on a folder silently no-ops
    # (.159 full-run 2026-11-05, music item 5). Folders NAVIGATE via
    # the house's existing stage_folder dispatch instead; playable
    # leaves and every TMDb item keep the Detail route below.
    try:
        _is_folder = _info("Container(%d).ListItem.IsFolder", cid)
        _tmdb_probe = _info("Container(%d).ListItem.Property(tmdb_id)",
                            cid)
    except Exception:
        _is_folder, _tmdb_probe = "", ""
    # L4-D2 / C-1 (audit leftovers fix, 2026-11-08): the TMDb
    # Helper's pagination pseudo-item ("Next page") must never
    # stage a detail page. In a hub list it is the Helper
    # container's 21st item (20 real posters + this slot): it
    # carries no tmdb_id, no poster and no metadata, its icon is
    # the Helper's nextpage.png and it is stamped
    # Property(specialsort)=bottom (Helper listitem.py _NextPage).
    # On the audited build it was focusable and ENTER staged a
    # bare detail page titled "Next page" (CHECKER-LEG4 C-1) --
    # it slipped past the folder gate below, so this guard runs
    # FIRST and keys on the item's own stamps, not on IsFolder.
    # What a next-page item is supposed to do is NAVIGATE to the
    # next page: hand it to stage_folder, which opens its
    # FolderPath (the same plugin URL with page=N+1) as a wall
    # via view_more. If it has no plugin path, refuse -- never
    # stage it. The skin half of C-1 (nextpage=false on the
    # Helper-fed hub/Home shelf URLs) stops the item being
    # served to hub lists at all; this guard covers any list
    # that still serves one.
    try:
        _np_special = _info(
            "Container(%d).ListItem.Property(specialsort)", cid)
        _np_icon = _info("Container(%d).ListItem.Art(icon)", cid)
        _np_poster = _info("Container(%d).ListItem.Art(poster)", cid)
        _np_label = _info("Container(%d).ListItem.Label", cid)
    except Exception:
        _np_special = _np_icon = _np_poster = _np_label = ""
    _is_next_page = (not _tmdb_probe and not _np_poster
                     and (_np_special == "bottom"
                          and "nextpage" in _np_icon
                          or _np_label == "Next page"
                          and "nextpage" in _np_icon))
    if _is_next_page:
        log("stage_open: next-page pseudo-item intercepted in "
            "container %d (label %r); navigating instead of "
            "staging a detail" % (cid, _np_label))
        return stage_folder(cid)
    if _is_folder == "true" and not _tmdb_probe:
        return stage_folder(cid)
    # MUSIC FIX 2026-11-08 (Hand C, L4-D5): the IsFolder read above
    # does not return "true" for IA Theater album items surfaced
    # through hub 1121's skin <content> container (LEG4 census row
    # 34: the ASIN9NE album staged as a leaf, Detail PLAY ran
    # PlayMedia on the expand_item folder URL and silently no-oped).
    # IA's search level marks those items IsPlayable=false and gives
    # them a FolderPath; playable leaves (incl. the working
    # Wrestling/Sports IA leaves) are IsPlayable=true, and TMDb
    # items are excluded by the same tmdb guard as the primary
    # diversion. Same dispatch, wider net: folders NAVIGATE.
    #
    # FIX PASS 2026-11-09 (L4-D5 residual): on-stick, this fallback
    # STILL never fired (publish-train Leg 2 closing proof: detail
    # staged, zero stage_folder log lines -- the diversion logs to
    # roc-log.txt while stage_open's other lines land in kodi.log,
    # and roc-log carried the session's gate/service lines but NO
    # stage_open line of any kind). File-side adjudication of the
    # three candidate breaks: (1) hub 1121's list 602 declares NO
    # <content> of its own -- it rides the window-level container
    # that PROOF-159 caught serving window 1121's items under
    # container id 600 (the row-600 "empty and unfocusable" note),
    # so a Container(602)-addressed read can legitimately see a
    # different (or empty) container than the one clicked; (2) the
    # item's property is stamped 'IsPlayable' (Kodi's getProperty is
    # case-sensitive on the key) and the infolabel read depends on
    # the plugin having stamped the FOCUSED item of the container
    # actually read; (3) FolderPath on a focused directory item is
    # the PARENT listing's path, never the item's own URL, so the
    # plugin:// requirement could only ever pass via FileNameAndPath.
    # The three are indistinguishable from files, so the guard is
    # rebuilt to fail LOUD and wide instead of silent and narrow:
    # every read is logged to roc-log (this function's home log),
    # the diversion no longer requires a plugin:// path (the
    # IsPlayable=="false" + no-tmdb conjunction is the folder
    # signature -- a playable leaf is IsPlayable "true" or carries
    # a playable media type), and stage_folder keeps its own
    # plugin:// requirement as the final safety. Anything this
    # still cannot divert now leaves a full read dump in roc-log
    # instead of staging silently, and the Detail-side belt
    # (Custom_Detail.xml 8001) covers the folder-shaped residue.
    if not _tmdb_probe:
        try:
            _is_playable = _info(
                "Container(%d).ListItem.IsPlayable", cid)
            _folder_path = _info(
                "Container(%d).ListItem.FolderPath", cid)
            _file_path = _info(
                "Container(%d).ListItem.FileNameAndPath", cid)
            _dbtype = _info(
                "Container(%d).ListItem.DBType", cid)
        except Exception:
            _is_playable = _folder_path = _file_path = _dbtype = ""
        log("stage_open: folder-diversion probe cid=%d "
            "IsFolder=%r IsPlayable=%r DBType=%r FolderPath=%r "
            "FileNameAndPath=%r"
            % (cid, _is_folder, _is_playable, _dbtype,
               _folder_path, _file_path))
        if _is_playable == "false":
            log("stage_open: non-playable item in container %d "
                "diverted to stage_folder (L4-D5)" % cid)
            return stage_folder(cid)
    # L4-D2 (audit leftovers fix, 2026-11-08): a rocui-served
    # TITLE folder -- a movierow row (timeline.py build_movie_row)
    # or a collection title row (build_collection) -- is a folder
    # into this plugin's own ?mode=detail route, and its ListItem
    # carries ONLY title + poster + tmdb_id/tmdb_type
    # (setInfo {"title": label}). In the Videos wall (10025) a
    # click is Kodi's built-in folder activation, which dispatches
    # that route to open_collection_title() -- the function that
    # fetches the title's TMDB record and publishes a FULL
    # RocStage set. In a hub list the stage_open onclick pre-empts
    # the folder activation, so these items used to fall through
    # to the infolabel harvest below with nothing to harvest:
    # the detail page opened title+poster-only and never
    # backfilled (LEG4 L4-D2: Ramayana via list 601 bare vs the
    # same title via the wall fully dressed). Delegate to the
    # wall route's own function so both paths publish the exact
    # same metadata set. handle=None: stage_open is a RunScript,
    # not a directory call, so there is no directory to end --
    # open_collection_title only ends one when a handle is given.
    if _is_folder == "true" and _tmdb_probe:
        try:
            _folder_path = _info(
                "Container(%d).ListItem.FolderPath", cid)
            if not _folder_path:
                _folder_path = _info(
                    "Container(%d).ListItem.FileNameAndPath", cid)
        except Exception:
            _folder_path = ""
        if (_folder_path.startswith("plugin://script.rocui")
                and "mode=detail" in _folder_path):
            try:
                from urllib.parse import parse_qsl, urlparse
                _detail_params = dict(parse_qsl(
                    urlparse(_folder_path).query))
            except Exception as exc:
                log("stage_open: detail-folder param parse failed: "
                    "%s" % exc)
                _detail_params = {}
            if _detail_params.get("tmdb_id"):
                log("stage_open: rocui detail-folder item in "
                    "container %d delegated to "
                    "open_collection_title (coll=%r tmdb_id=%r)"
                    % (cid, _detail_params.get("coll", ""),
                       _detail_params.get("tmdb_id", "")))
                return open_collection_title(_detail_params, None)
    prefix = "Container(%d).ListItem" % cid
    values = {}
    for prop, field in _STAGE_FIELDS:
        values[prop] = _info("%s.%s", prefix, field)
    # MOVIES FEEL (Loop 299): one Duration format on the detail
    # page — Kodi's ListItem.Duration arrives as a timecode;
    # publish "2h 15m" instead of the raw value.
    values["Duration"] = _format_duration(values.get("Duration"))
    if not values.get("Title"):
        values["Title"] = _info("%s.Label", prefix)
    if not values.get("Title"):
        notify("That title has no details to show yet", 3500)
        return False
    values["TmdbId"] = _info("%s.Property(tmdb_id)", prefix)
    values["TmdbType"] = _info("%s.Property(tmdb_type)", prefix)
    values["Poster"] = _info("%s.Art(poster)", prefix) or _info(
        "%s.Art(thumb)", prefix)
    values["Thumb"] = _info("%s.Art(thumb)", prefix)
    values["Fanart"] = _info("%s.Art(fanart)", prefix) or values["Thumb"]
    for prop, names in (("RatingIMDb", ("imdb", "imdb_rating")),
                        ("RatingRT", ("rottentomatoes",
                                      "rottentomatoes_rating")),
                        ("RatingMC", ("metacritic", "metacritic_rating")),
                        ("RatingTMDB", ("themoviedb", None))):
        val = _info("%s.Rating(%s)", prefix, names[0])
        if not val and names[1]:
            val = _info("%s.Property(%s)", prefix, names[1])
        values[prop] = val
    # L4-D8 backfill: hub list items are Helper plugin items, and
    # the Helper enriches ONLY its info=details route with OMDb
    # ratings -- a list item therefore carries an IMDb/RT/MC
    # property only if some other route already fetched it, which
    # in this build is never (no OMDb key is configured; even with
    # one, the Helper's list containers do not call OMDb per item).
    # When the staged values are missing AND an OMDb key is
    # configured in the Helper's settings, resolve them here from
    # the title's own TMDB record (its imdb_id) + OMDb. With no
    # key this block costs one cached settings read and changes
    # nothing; a failed lookup leaves the chips honestly absent.
    if not (values.get("RatingIMDb") and values.get("RatingRT")):
        try:
            if omdb_key():
                _imdb = _info("%s.Property(imdb_id)", prefix)
                if not _imdb.startswith("tt"):
                    _imdb = ""
                if not _imdb and values.get("TmdbId") and \
                        values.get("TmdbType") in ("movie", "tv"):
                    _det = tmdb_get(
                        "%s/%s?append_to_response=external_ids"
                        % (values["TmdbType"], values["TmdbId"])) or {}
                    _imdb = _detail_imdb_id(_det)
                if _imdb:
                    for _prop, _val in omdb_ratings(_imdb).items():
                        if _val and not values.get(_prop):
                            values[_prop] = _val
        except Exception as exc:
            log("stage_open: ratings backfill failed: %s" % exc)
    resumable = _info("%s.IsResumable", prefix)
    values["Resumable"] = "true" if resumable == "true" else ""
    pct = _info("%s.PercentPlayed", prefix)
    try:
        _pct_f = float(pct) if pct else 0.0
    except Exception:
        _pct_f = 0.0
    # FLEET CATCH-UP 2026-11-16: a literal 0 from the infolabel is
    # NO percent (the title may still hold a real Roc Sync
    # position - layer 4b below fills from the store). Rendering
    # "- 0% watched" was the resume-label bug.
    pct = ("%d%%" % int(_pct_f)) if _pct_f > 0 else ""
    values["PercentPlayed"] = ("- " + pct + " watched") if pct else ""
    # L4-D2 BACKFILL (audit leftovers fix, 2026-11-08): any
    # remaining tmdb-carrying item (movie/tv) whose infolabel
    # harvest came up metadata-bare -- no Plot AND no Cast --
    # gets the same TMDB enrichment open_collection_title()
    # performs for the wall route: one tmdb_get of the title's
    # own record with credits appended, filling ONLY fields the
    # item did not carry (an item that arrived dressed keeps its
    # own values). This is the backfill stage_open never had:
    # Custom_Detail.xml renders the published RocStage set
    # statically, so a bare publish stayed bare forever (LEG4:
    # unchanged after >=18 s). Best-effort, exactly like the wall
    # route's enrichment: an offline or partial record still
    # opens the page with whatever the item carried. Episode
    # items are excluded -- their TMDB record is the episode
    # endpoint, which this house's enrichment has never read.
    if (values.get("TmdbType") in ("movie", "tv")
            and values.get("TmdbId")
            and not values.get("Plot") and not values.get("Cast")):
        try:
            # FIX PASS 2026-11-09: release_dates / content_ratings
            # join the append set so the fill below can publish the
            # US MPAA rating on this route too -- the collection
            # route has carried it since L4-D8 (via _detail_mpaa),
            # but the hub route's backfill never requested the data,
            # so its detail pages rendered the trailing "- " gap
            # PROOF-159 §C8 caught on Ramayana.
            _detail = tmdb_get(
                "%s/%s?append_to_response=credits,release_dates,"
                "content_ratings"
                % (values["TmdbType"], values["TmdbId"])) or {}
        except Exception as exc:
            log("stage_open: TMDB backfill fetch failed: %s" % exc)
            _detail = {}
        if _detail:
            _filled = []

            def _fill(prop, val):
                if val and not values.get(prop):
                    values[prop] = val
                    _filled.append(prop)

            _fill("Plot", _detail.get("overview") or "")
            _date = (_detail.get("release_date")
                     or _detail.get("first_air_date") or "")
            _fill("Year", _date[:4])
            _fill("Genre", ", ".join(
                g.get("name", "")
                for g in _detail.get("genres") or []
                if g.get("name")))
            _runtime = _detail.get("runtime")
            if not _runtime:
                _runs = _detail.get("episode_run_time") or []
                _runtime = _runs[0] if _runs else ""
            _fill("Duration", _format_duration(_runtime))
            _companies = _detail.get("production_companies") or []
            if _companies:
                _fill("Studio", _companies[0].get("name") or "")
            _countries = _detail.get("production_countries") or []
            if _countries:
                _fill("Country", _countries[0].get("name") or "")
            elif _detail.get("origin_country"):
                _fill("Country", _detail["origin_country"][0])
            if _detail.get("vote_average"):
                _fill("RatingTMDB",
                      "%.1f" % _detail["vote_average"])
            _credits = _detail.get("credits") or {}
            for _member in _credits.get("crew") or []:
                if _member.get("job") == "Director":
                    _fill("Director", _member.get("name") or "")
                    break
            _cast = [c.get("name", "")
                     for c in _credits.get("cast") or []
                     if c.get("name")]
            if _cast:
                _fill("Cast", ", ".join(_cast[:6]))
            _fill("MPAA", _detail_mpaa(_detail,
                                       values.get("TmdbType")))
            if not values.get("Fanart") \
                    and _detail.get("backdrop_path"):
                values["Fanart"] = (_TMDB_IMG_W500
                                    + _detail["backdrop_path"])
                _filled.append("Fanart")
            log("stage_open: TMDB backfill for %r (%s/%s) filled "
                "%s" % (values.get("Title") or "",
                        values.get("TmdbType"),
                        values.get("TmdbId"),
                        ",".join(_filled) or "nothing"))
    # MERGE RUN (2026-11-06) — RESUME populate, LAYERED. The detail
    # window's RESUME button (8002) renders only when BOTH
    # RocStage.Resumable and RocStage.Path are non-empty
    # (Custom_Detail.xml). Layer 1 (above, unchanged): Resumable
    # from the ListItem.IsResumable infolabel, PercentPlayed from
    # its infolabel, Path from FileNameAndPath. On Helper-fed
    # EPISODE pages IsResumable reads empty even for an
    # in-progress episode, so the button never rendered (proven
    # live: CW WWE Raw S33E18 in-progress, no RESUME) — hence:
    #   Layer 2 — the ITEM's own carried progress. The Helper
    #     publishes every infoproperty as a ListItem property
    #     (tmdbhelper listitem.py: set_resume_point(infoproperties)
    #     + setProperties), and Trakt in-progress items carry a
    #     'progress' percent (Trakt filters in-progress to 5-95%).
    #     The coordinator's pull of the stick's history.json (44
    #     entries) holds ZERO WWE Raw entries — that episode is
    #     in-progress via Trakt only — so this layer, not local
    #     history, is what can light RESUME on the proof page.
    #   Layer 2.5 — Path fallback: ListItem.Path, where Helper
    #     items carry their encoded play URL.
    #   Layer 3 — rocui's own local history (house precedent:
    #     open_collection_title()'s movie block in this file —
    #     merged _history_entries_all() scan, the build's own
    #     thresholds; rocui_playback.detail_resume_play consumes
    #     the same history per title via show_progress_target /
    #     _movie_resume_position).
    # Each layer logs when it fires. Scope for layers 2/2.5/3:
    # EPISODE items (TmdbType "tv" OR "episode" AND the item itself
    # carried Season+Episode, read above before any later mirroring)
    # and
    # MOVIE items (TmdbType "movie"). Pure SHOW pages (tv without
    # a staged episode) are EXCLUDED — their main button already
    # carries resume semantics via show_progress_target below.
    # Never raises.
    # MERGE RUN LEG 2 LIVE FIX (2026-11-07, coordinator): the
    # Helper stamps an EPISODE item's tmdb_type property as
    # "episode", not "tv" (proven live on .159 by diagnostic log:
    # CW WWE Raw S33E18 reads tmdb_type='episode', season='33',
    # episode='18', dbtype='episode'). The original "tv"-only gate
    # therefore classified NO Helper episode item as an episode
    # item and every layer below was dead on real hardware. The
    # gate now accepts both stamps; the Season+Episode requirement
    # still excludes pure show pages either way.
    _item_season = (values.get("Season") or "").strip()
    _item_episode = (values.get("Episode") or "").strip()
    _is_episode_item = (values.get("TmdbType") in ("tv", "episode")
                        and bool(_item_season) and bool(_item_episode))
    _is_movie_item = values.get("TmdbType") == "movie"
    if not values.get("Resumable") and (_is_episode_item
                                        or _is_movie_item):
        # Layer 2: item-carried progress signals, read through the
        # same _info helper as every other field above. Floors are
        # the build's own: pct in [SHOW_PROGRESS_FLOOR_PCT,
        # SHOW_FINISHED_PCT) — the constants' literal values
        # (2 <= pct < 97) — or a resume_point past
        # SHOW_PROGRESS_FLOOR_POS seconds (the constants' 45).
        try:
            _pp_raw = _info("%s.PercentPlayed", prefix)
            try:
                _pp_pct = float(_pp_raw) if _pp_raw else None
            except Exception:
                _pp_pct = None
            if (_pp_pct is not None
                    and SHOW_PROGRESS_FLOOR_PCT <= _pp_pct
                    < SHOW_FINISHED_PCT):
                values["Resumable"] = "true"
                log("stage_open: resume populated layer 2 "
                    "(PercentPlayed %.1f%%) for %r"
                    % (_pp_pct, values.get("Title") or ""))
            else:
                _rp_raw = _info("%s.Property(resume_point)", prefix)
                try:
                    _rp_secs = float(_rp_raw) if _rp_raw else None
                except Exception:
                    _rp_secs = None
                if (_rp_secs is not None
                        and _rp_secs > SHOW_PROGRESS_FLOOR_POS):
                    values["Resumable"] = "true"
                    if not values.get("PercentPlayed"):
                        _pg_raw = _info("%s.Property(progress)",
                                        prefix)
                        try:
                            _pg_pct = (float(_pg_raw)
                                       if _pg_raw else None)
                        except Exception:
                            _pg_pct = None
                        if (_pg_pct is not None
                                and SHOW_PROGRESS_FLOOR_PCT <= _pg_pct
                                < SHOW_FINISHED_PCT):
                            values["PercentPlayed"] = (
                                "- %d%% watched" % int(_pg_pct))
                    log("stage_open: resume populated layer 2 "
                        "(resume_point %.0fs) for %r"
                        % (_rp_secs, values.get("Title") or ""))
        except Exception as exc:
            log("stage_open: resume item-progress layer failed: %s"
                % exc)
    if (_is_episode_item or _is_movie_item) \
            and not values.get("Path"):
        # Layer 2.5: Path fallback — Helper items carry their play
        # URL as ListItem.Path (their infolabels['path']). Runs
        # regardless of which layer set Resumable: button 8002
        # needs BOTH properties. Only if this is also empty may
        # layer 3's history snap path fill Path.
        try:
            _li_path = _info("%s.Path", prefix)
            if _li_path:
                values["Path"] = _li_path
                log("stage_open: Path populated layer 2.5 "
                    "(ListItem.Path) for %r"
                    % (values.get("Title") or ""))
        except Exception as exc:
            log("stage_open: ListItem.Path fallback failed: %s"
                % exc)
    # Layer 3: local-history fallback (full floor set below).
    if not values.get("Resumable") and (_is_episode_item
                                        or _is_movie_item):
        try:
            _want_show = _norm_show_title(
                values.get("TVShowTitle") or values.get("Title")
                or "")
            _want_title = _norm_show_title(values.get("Title") or "")
            _want_tmdb = str(values.get("TmdbId") or "")
            try:
                _want_season = int(_item_season)
                _want_episode = int(_item_episode)
            except Exception:
                _want_season = _want_episode = None
            _entries = sorted(
                _history_entries_all(),
                key=lambda e: float(e.get("ts") or 0)
                if isinstance(e, dict) else 0.0,
                reverse=True)
            for _e in _entries:
                if not isinstance(_e, dict):
                    continue
                _snap = _e.get("snap") or {}
                if _is_episode_item:
                    if (_snap.get("type") or "") != "episode":
                        continue
                    if (_norm_show_title(_snap.get("showtitle") or "")
                            != _want_show or not _want_show):
                        continue
                    _snap_tmdb = str(_snap.get("tmdb") or "")
                    if (_want_tmdb and _snap_tmdb
                            and _snap_tmdb != _want_tmdb):
                        continue
                    try:
                        if (int(_snap.get("season", -1)) != _want_season
                                or int(_snap.get("episode", -1))
                                != _want_episode):
                            continue
                    except Exception:
                        continue
                else:
                    # Movie match mirrors open_collection_title:
                    # type "movie" + tmdb or title (title compared
                    # normalised, as _movie_resume_position does).
                    if (_snap.get("type") or "") != "movie":
                        continue
                    _snap_tmdb = str(_snap.get("tmdb") or "")
                    _tmdb_hit = bool(_want_tmdb and _snap_tmdb
                                     and _snap_tmdb == _want_tmdb)
                    _title_hit = bool(
                        _want_title
                        and _norm_show_title(_snap.get("title") or "")
                        == _want_title)
                    if not (_tmdb_hit or _title_hit):
                        continue
                try:
                    _pos = float(_e.get("position") or 0)
                    _dur = float(_e.get("duration") or 0)
                    _pct = float(_e.get("pct") or 0)
                except Exception:
                    continue
                if _dur <= 0:
                    # Precedent guard (show_progress_target /
                    # _movie_resume_position): no duration, no
                    # trustworthy pct — the entry cannot qualify.
                    _pct = 0.0
                _remain = (_dur - _pos) if _dur > 0 else 999999.0
                if (_pos <= SHOW_PROGRESS_FLOOR_POS
                        or _pct < SHOW_PROGRESS_FLOOR_PCT
                        or _remain <= SHOW_FINISHED_REMAIN
                        or _pct >= SHOW_FINISHED_PCT):
                    continue
                values["Resumable"] = "true"
                if not values.get("PercentPlayed"):
                    values["PercentPlayed"] = (
                        "- %d%% watched" % int(_pct))
                if not values.get("Path") and _snap.get("path"):
                    values["Path"] = _snap.get("path")
                log("stage_open: resume populated layer 3 "
                    "(history) for %r (pos %.0fs, %.1f%%)"
                    % (values.get("Title") or "", _pos, _pct))
                break
        except Exception as exc:
            log("stage_open: resume history fallback failed: %s"
                % exc)
    # Layer 4 - the Roc Sync store (2026-11-16, Eric 19:45): the
    # house progress store since Roc Sync went live. A saved
    # position here lights RESUME even when layers 1-3 all missed,
    # and fills Path with the Helper play path when nothing else
    # did (detail_resume_play's fallback PlayMedia()s it, with
    # the seek armed to the same store's position).
    if not values.get("Resumable") and (_is_episode_item
                                        or _is_movie_item):
        try:
            if _is_movie_item:
                _rs = rocsync_resume("movie", values.get("TmdbId"))
            else:
                try:
                    _s4 = int(_item_season)
                    _e4 = int(_item_episode)
                except Exception:
                    _s4 = _e4 = None
                _rs = (rocsync_resume("episode",
                                      values.get("TmdbId"), _s4, _e4)
                       if _s4 is not None else None)
            if _rs:
                _pos, _dur = _rs
                values["Resumable"] = "true"
                if not values.get("PercentPlayed") and _dur > 0:
                    values["PercentPlayed"] = (
                        "- %d%% watched" % int(100.0 * _pos / _dur))
                if not values.get("Path"):
                    if _is_movie_item:
                        values["Path"] = (
                            "plugin://plugin.video.themoviedb.helper/"
                            "?info=play&tmdb_type=movie&tmdb_id=%s"
                            % values.get("TmdbId"))
                    else:
                        values["Path"] = (
                            "plugin://plugin.video.themoviedb.helper/"
                            "?info=play&tmdb_type=tv&tmdb_id=%s"
                            "&season=%s&episode=%s"
                            % (values.get("TmdbId"), _s4, _e4))
                log("stage_open: resume populated layer 4 "
                    "(rocsync) for %r (pos %.0fs)"
                    % (values.get("Title") or "", _pos))
        except Exception as exc:
            log("stage_open: resume rocsync layer failed: %s" % exc)
    if _is_episode_item and not values.get("Resumable"):
        log("stage_open: anomaly: episode item %r S%sE%s publishes "
            "with Resumable empty (all layers missed: no "
            "infolabel, no item progress, no history hit, no rocsync hit)"
            % (values.get("Title") or "", _item_season,
               _item_episode))
    # xbmcgui.Window(1124) raises "Window id does not exist" until the
    # window has been activated once (proven on hardware .159,
    # 2026-10-30: every poster click died at this line and the detail
    # window never opened). Activate FIRST, wait until the window is
    # current, THEN publish the RocStage properties onto it; the
    # window's $INFO bindings repaint as the properties land, and its
    # buttons read the properties at click time, so the brief
    # publish-after-open is harmless.
    xbmc.executebuiltin("ActivateWindow(%d)" % DETAIL_WINDOW_ID)
    # ID NAMESPACES (proven on .159, 2026-10-30): the skin declares
    # this window as 1124 and ActivateWindow(1124) opens it — but the
    # Python side lives in the runtime id space, where the same
    # window is 1124 + 10000 = 11124 (the rocui service's own focus
    # memory records the hubs the same way: XML 1111 -> runtime
    # 11111). xbmcgui.Window(1124) throws "Window id does not exist"
    # forever, even while the window is on screen; Window(11124) is
    # the publish target. Poll until it constructs (activation is
    # not instant on this hardware), then publish + read back.
    runtime_id = DETAIL_WINDOW_ID + 10000
    win = None
    monitor = xbmc.Monitor()
    for _ in range(200):
        try:
            win = xbmcgui.Window(runtime_id)
            break
        except Exception:
            win = None
        if monitor.waitForAbort(0.05):
            break
    # Layer 4b (fleet catch-up 2026-11-16): percent truth. The
    # layers above only fill PercentPlayed when it is empty, so a
    # lit RESUME could still carry no percent (or a stale one)
    # while Roc Sync holds this title's real position - the seek
    # (detail_resume_play) reads the store, the label did not.
    # When the button is lit and the percent is missing or zero,
    # the store's own numbers win.
    if values.get("Resumable") and (_is_episode_item
                                    or _is_movie_item):
        _pp_now = (values.get("PercentPlayed") or "").strip()
        _pp_zero = not _pp_now
        if _pp_now:
            try:
                _pp_zero = float(_pp_now.replace("- ", "")
                                 .replace("% watched", "")
                                 .strip()) <= 0
            except Exception:
                _pp_zero = False
        # F3 (refapp FUSE-NOW): when the store holds the position,
        # the label states the stop point in words - so 4b also
        # fires over a percent-only label that lacks it.
        if _pp_zero or "stopped at" not in _pp_now:
            try:
                if _is_movie_item:
                    _rs4b = rocsync_resume("movie",
                                           values.get("TmdbId"))
                else:
                    _rs4b = rocsync_resume(
                        "episode", values.get("TmdbId"),
                        int(_item_season), int(_item_episode))
                if _rs4b and _rs4b[1] > 0 and _rs4b[0] > 0:
                    _pos_i = int(_rs4b[0])
                    _hh = _pos_i // 3600
                    _mm = (_pos_i % 3600) // 60
                    _ss = _pos_i % 60
                    _at = (("%d:%02d:%02d" % (_hh, _mm, _ss))
                           if _hh else ("%d:%02d" % (_mm, _ss)))
                    values["PercentPlayed"] = (
                        "- stopped at %s - %d%% watched"
                        % (_at, int(100.0 * _rs4b[0] / _rs4b[1])))
                    log("stage_open: resume percent corrected "
                        "layer 4b (rocsync) for %r"
                        % (values.get("Title") or ""))
            except Exception as exc:
                log("stage_open: resume percent 4b failed: %s" % exc)
    if win is None:
        log("stage_open: detail window %d (runtime %d) never came "
            "into existence; RocStage properties not published"
            % (DETAIL_WINDOW_ID, runtime_id))
        return False
    for prop, val in values.items():
        try:
            win.setProperty("RocStage." + prop, val or "")
        except Exception:
            pass
    try:
        if win.getProperty("RocStage.Title") != (values.get("Title") or ""):
            log("stage_open: RocStage.Title readback mismatch "
                "(published %r, read %r)"
                % (values.get("Title"), win.getProperty("RocStage.Title")))
            return False
    except Exception:
        pass
    # Resume-PLAY (0.5.8): TV titles only. The label computation
    # reads local history only for fresh/mid cases; the TMDB season
    # lookup fires only when the newest entry is finished, so a
    # normal detail open pays no network cost.
    if values.get("TmdbType") == "tv":
        try:
            target = show_progress_target(values.get("Title") or "",
                                          values.get("TmdbId") or "")
            win.setProperty("RocStage.MainLabel", target["label"])
            win.setProperty("RocStage.MainTargetKind", target["kind"])
            win.setProperty("RocStage.MainTargetSeason",
                            str(target["season"]))
            win.setProperty("RocStage.MainTargetEpisode",
                            str(target["episode"]))
            win.setProperty("RocStage.MainTargetPosition",
                            str(target["position"]))
            win.setProperty("RocStage.MainTargetTag", target["tag"])
        except Exception as exc:
            log("stage_open: resume target failed: %s" % exc)
            win.setProperty("RocStage.MainLabel", "PLAY")
            win.setProperty("RocStage.MainTargetKind", "fresh")
            win.setProperty("RocStage.MainTargetSeason", "1")
            win.setProperty("RocStage.MainTargetEpisode", "1")
            win.setProperty("RocStage.MainTargetPosition", "0")
            win.setProperty("RocStage.MainTargetTag", "S01E01")
    else:
        # 0.5.17 (Stage 2 skin wiring): movies publish the same
        # Main* props (fresh PLAY) so the detail PLAY button's
        # label wire — $INFO[RocStage.MainLabel] with a PLAY
        # fallback — never shows a STALE TV label left over from
        # the previous title on the window. Window properties
        # persist between detail opens; only TV titles set these
        # above, so without this a movie opened after a show would
        # read CONTINUE WATCHING. Season/Episode/Position are
        # meaningless for a movie and the skin never reads them
        # there; they ride along only so the prop set stays whole.
        win.setProperty("RocStage.MainLabel", "PLAY")
        win.setProperty("RocStage.MainTargetKind", "fresh")
        win.setProperty("RocStage.MainTargetSeason", "1")
        win.setProperty("RocStage.MainTargetEpisode", "1")
        win.setProperty("RocStage.MainTargetPosition", "0")
        win.setProperty("RocStage.MainTargetTag", "S01E01")
    if values.get("TmdbType") == "tv":
        # 0.5.15 (Player Fix Lane, Hand A): mirror the computed
        # target into RocStage.Season/Episode when the staged item
        # carried none. A show-level item (a series poster on a hub
        # row) has no ListItem.Season/Episode, so 0.5.14 published
        # both EMPTY -- and the shipped detail window's PLAY button
        # gates its TV branch on RocStage.Episode being non-empty
        # (its movie branch has no such gate), so a show's detail
        # page rendered with NO PLAY button at all: only SOURCES,
        # whose Helper route carries no season/episode and dies in
        # the Helper's player assert (play_episode requires
        # showname+season+episode). Eric on .155, 2026-11-05: a
        # movie detail shows PLAY and plays; a show detail "just
        # says sources, can't scroll over to nothing". Filling
        # Season/Episode from the SAME target MainTarget* already
        # carries (fresh S1E1 / resume spot / next episode) makes
        # the TV PLAY branch render and fire with a real
        # season/episode, exactly like the movie branch. An item
        # that DID carry Season/Episode (an episode row) is never
        # overwritten.
        try:
            if not values.get("Season"):
                win.setProperty(
                    "RocStage.Season",
                    win.getProperty("RocStage.MainTargetSeason")
                    or "1")
            if not values.get("Episode"):
                win.setProperty(
                    "RocStage.Episode",
                    win.getProperty("RocStage.MainTargetEpisode")
                    or "1")
        except Exception:
            pass
    return True


def view_more(path):
    """VIEW MORE: open a plugin path as a full Videos page and put it
    in the poster WALL view (view 55, View_55_Wall — a panel — in
    this skin; view 54 is View_54_Banner, a Banner fixedlist).

    MERGE RUN live patch (2026-11-06, on top of the burst's
    10006->10025 window fix): the burst's 10x0.25 s poll gave up
    before cold Trakt loads landed, so SetViewMode never fired
    (full run 2026-11-05 + batch 2). Poll on the house Monitor
    pattern for a ~20 s budget: until the current window is 10025
    AND Container.NumItems parses > 0, then fire
    Container.SetViewMode(55) once. If the window arrives but the
    content never does within budget, fire SetViewMode(55) anyway
    (the wall still applies when the items land) and log it. If
    the window never arrives, log and return True — the open
    itself succeeded, which is this function's contract.

    SKIN PASS PUSH (2026-11-12): phase 2, the container-swap
    guard. Some flows replace the container AFTER the first
    SetViewMode lands — the Helper's info=search opens a keyboard
    first, then container-updates to the results path, and the
    fresh container comes up in its remembered LIST view, so
    search results rendered as a list, not the wall (skin-pass
    candidate shortfall, 2026-11-11). After the phase-1 fire,
    keep watching (total budget ~120 s, which also covers slow
    typing on the search keyboard): whenever Container.FolderPath
    changes, wait for items on the new path and fire
    SetViewMode(55) again. The guard exits when the path has been
    stable with the view set for ~2 s, when the user settles back
    on Home (10000) for ~4 s, or on abort. Non-redirecting paths
    see no behavior change: their path never changes, the guard
    just confirms stability and returns."""
    if xbmc is None:
        return False
    path = (path or "").strip()
    if not path.startswith("plugin://"):
        log("view_more refused non-plugin path: %r" % path)
        return False
    xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % path)
    if xbmcgui is not None:
        monitor = xbmc.Monitor()
        on_window = False
        fired = False
        for _ in range(80):
            if monitor.waitForAbort(0.25):
                break
            try:
                # Videos window is 10025 (ActivateWindow(Videos,...)
                # opens it); 10006 is the Video Files window and can
                # never fire here, which left SetViewMode dead on
                # this path before the burst fix.
                if xbmcgui.getCurrentWindowId() != 10025:
                    continue
                on_window = True
                try:
                    num_items = int(str(
                        _info("Container.NumItems") or "").strip()
                        or 0)
                except Exception:
                    num_items = 0
                if num_items > 0:
                    xbmc.executebuiltin("Container.SetViewMode(55)")
                    fired = True
                    break
            except Exception:
                break
        if on_window and not fired:
            log("view_more: window 10025 open but Container.NumItems "
                "never rose within budget; SetViewMode(55) fired "
                "anyway for %r" % path)
            try:
                xbmc.executebuiltin("Container.SetViewMode(55)")
                fired = True
            except Exception:
                pass
        if not on_window:
            log("view_more: window 10025 never arrived for %r" % path)
            return True
        if not fired:
            return True
        # Phase 2: container-swap guard (~100 s more of polling).
        try:
            last_path = str(_info("Container.FolderPath") or "")
        except Exception:
            last_path = ""
        stable = 0
        home_polls = 0
        for _ in range(400):
            if monitor.waitForAbort(0.25):
                break
            try:
                win = xbmcgui.getCurrentWindowId()
            except Exception:
                break
            if win == 10000:
                # Home: the user backed out for good after ~4 s.
                home_polls += 1
                if home_polls >= 16:
                    break
                continue
            home_polls = 0
            if win != 10025:
                # A dialog (e.g. the search keyboard) is up over
                # the Videos window — wait it out.
                stable = 0
                continue
            try:
                cur_path = str(_info("Container.FolderPath") or "")
                num_items = int(str(
                    _info("Container.NumItems") or "").strip()
                    or 0)
            except Exception:
                cur_path = last_path
                num_items = 0
            if cur_path != last_path:
                # The container was swapped (search results, a
                # plugin redirect): the wall must be re-fired on
                # the new path once its items land.
                last_path = cur_path
                stable = 0
                if num_items > 0:
                    try:
                        xbmc.executebuiltin(
                            "Container.SetViewMode(55)")
                        log("view_more: container swapped to %r; "
                            "SetViewMode(55) re-fired" % cur_path)
                    except Exception:
                        pass
                continue
            if num_items > 0:
                stable += 1
                if stable >= 8:
                    break
            else:
                stable = 0
    return True


def adult_session_open():
    """Stamp the adult session on the Home window (the hub window
    re-checks it via adult_guard)."""
    if xbmcgui is None:
        return
    try:
        xbmcgui.Window(HOME_WINDOW_ID).setProperty(
            "RocAdult.Until", str(int(time.time()) + ADULT_SESSION_SECONDS))
    except Exception as exc:
        log("adult session stamp failed: %s" % exc)


def adult_guard():
    """Adult hub onload: without a live gate session, bounce home.
    The PIN gate is the door; this keeps the hub from being a
    walk-in via a stale window reference."""
    if xbmc is None or xbmcgui is None:
        return True
    try:
        until = xbmcgui.Window(HOME_WINDOW_ID).getProperty("RocAdult.Until")
        if until and float(until) > time.time():
            return True
    except Exception:
        pass
    notify("Locked - open Adult from the dock and enter your PIN", 4500, ok=False)
    xbmc.executebuiltin("ActivateWindow(home)")
    return False


def stereo_select():
    """Dedicated 3D button: Kodi's own stereoscopic-mode picker."""
    if xbmc is None:
        return
    try:
        xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"GUI.SetStereoscopicMode",'
            '"params":{"mode":"select"},"id":1}')
    except Exception as exc:
        log("stereo_select failed: %s" % exc)


# --------------------------------------------------------------------------
# Weather (dock right-end): Open-Meteo, Mesa AZ — keyless, the same
# source the BAR uses. Published to Home window properties; offline
# or failed fetches leave the properties empty and the dock slot
# hides (honest absence).
# --------------------------------------------------------------------------
_WEATHER_CODES = [
    (0, "Clear"), (1, "Mostly clear"), (2, "Partly cloudy"),
    (3, "Cloudy"), (45, "Fog"), (48, "Fog"), (51, "Drizzle"),
    (53, "Drizzle"), (55, "Drizzle"), (56, "Drizzle"), (57, "Drizzle"),
    (61, "Rain"), (63, "Rain"), (65, "Heavy rain"), (66, "Rain"),
    (67, "Rain"), (71, "Snow"), (73, "Snow"), (75, "Snow"),
    (77, "Snow"), (80, "Showers"), (81, "Showers"), (82, "Showers"),
    (85, "Snow"), (86, "Snow"), (95, "Thunderstorm"),
    (96, "Thunderstorm"), (99, "Thunderstorm"),
]
WEATHER_URL = (
    "https://api.open-meteo.com/v1/forecast?latitude=33.4152"
    "&longitude=-111.8315&current=temperature_2m,weather_code"
    "&daily=temperature_2m_max,temperature_2m_min"
    "&temperature_unit=fahrenheit&timezone=America%2FPhoenix"
    "&forecast_days=1")


def _weather_label(code):
    try:
        code = int(code)
    except Exception:
        return ""
    best = ""
    for known, label in _WEATHER_CODES:
        if code == known:
            return label
        if code > known:
            best = label
    return best


def publish_weather():
    if xbmcgui is None:
        return False
    try:
        import urllib.request
        req = urllib.request.Request(
            WEATHER_URL, headers={"User-Agent": "RocOS/3.2"})
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        cur = data.get("current") or {}
        daily = data.get("daily") or {}
        temp = cur.get("temperature_2m")
        if temp is None:
            return False
        cond = _weather_label(cur.get("weather_code"))
        hi = (daily.get("temperature_2m_max") or [None])[0]
        lo = (daily.get("temperature_2m_min") or [None])[0]
        home = xbmcgui.Window(HOME_WINDOW_ID)
        home.setProperty("RocWeather.Temp", "%d°" % int(round(temp)))
        home.setProperty("RocWeather.Cond", cond)
        if hi is not None and lo is not None:
            home.setProperty("RocWeather.HiLo",
                             "H %d  L %d" % (int(round(hi)), int(round(lo))))
        home.setProperty("RocWeather.Checked", str(int(time.time())))
        return True
    except Exception as exc:
        log("weather fetch failed: %s" % exc)
        return False


def publish_notification(title, text):
    """Dock notification flip: the service's monitor calls this for
    real Kodi notifications; the service clears them when stale."""
    if xbmcgui is None:
        return
    try:
        home = xbmcgui.Window(HOME_WINDOW_ID)
        home.setProperty("RocNotify.Title", title or "")
        home.setProperty("RocNotify.Text", text or "")
    except Exception as exc:
        log("notify publish failed: %s" % exc)


def clear_notification():
    if xbmcgui is None:
        return
    try:
        home = xbmcgui.Window(HOME_WINDOW_ID)
        home.setProperty("RocNotify.Title", "")
        home.setProperty("RocNotify.Text", "")
    except Exception:
        pass


# --------------------------------------------------------------------------
# playback snapshot / resume keeper / source re-pick support (v3.2.0,
# Eric 2026-10-24 16:36-16:39: resume on any launch after a sudden
# shutdown, an OSD source re-pick, and an Episodes/Collection panel).
# The resume checkpoint is PER-PROFILE on purpose (special://profile):
# each household profile keeps its own last spot. It carries title +
# IMDb/TMDb/TVDb IDs + season/episode so another device running the
# build can re-resolve the same title; the cross-device progress leg
# itself rides Trakt (his sign-in, never baked in here).
# --------------------------------------------------------------------------
import re as _re
import time as _time

try:
    import urllib.request as _urlreq
except Exception:  # pragma: no cover
    _urlreq = None

RESUME_FILE = "resume.json"
SEEK_FILE = "pending_seek.json"


def _rpc(method, params):
    if xbmc is None:
        return {}
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        out = xbmc.executeJSONRPC(json.dumps(req))
        return (json.loads(out) or {}).get("result") or {}
    except Exception as exc:
        log("rpc %s failed: %s" % (method, exc))
        return {}


def now_playing_snapshot():
    """Identity of the playing item, or None. JSON-RPC Player.GetItem
    is the reliable source (unique IDs included); the info tag is the
    fallback. Never raises."""
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            return None
        snap = {"title": "", "showtitle": "", "season": -1, "episode": -1,
                "year": 0, "type": "", "path": "", "imdb": "", "tmdb": "",
                "tvdb": "", "dbid": -1}
        try:
            snap["path"] = player.getPlayingFile() or ""
        except Exception:
            pass
        players = _rpc("Player.GetActivePlayers", {})
        pid = None
        for p in players if isinstance(players, list) else []:
            if p.get("type") == "video":
                pid = p.get("playerid")
                break
        item = {}
        if pid is not None:
            res = _rpc("Player.GetItem", {
                "playerid": pid,
                "properties": ["title", "showtitle", "season", "episode",
                               "year", "file", "uniqueid", "type", "id",
                               "thumbnail", "fanart"]})
            item = res.get("item") or {}
        if item:
            snap["title"] = item.get("title") or ""
            snap["showtitle"] = item.get("showtitle") or ""
            snap["season"] = item.get("season", -1) or -1
            snap["episode"] = item.get("episode", -1) or -1
            snap["year"] = item.get("year", 0) or 0
            snap["type"] = item.get("type") or ""
            snap["dbid"] = item.get("id", -1) or -1
            # v3.4.0: art for the history shelves (resume ignores it)
            snap["thumb"] = item.get("thumbnail") or ""
            snap["fanart"] = item.get("fanart") or ""
            if item.get("file"):
                snap["path"] = item["file"]
            uid = item.get("uniqueid") or {}
            snap["imdb"] = str(uid.get("imdb") or "")
            snap["tmdb"] = str(uid.get("tmdb") or "")
            snap["tvdb"] = str(uid.get("tvdb") or "")
        if not snap["title"]:
            tag = player.getVideoInfoTag()
            snap["title"] = tag.getTitle() or ""
            snap["showtitle"] = tag.getTVShowTitle() or ""
            snap["season"] = tag.getSeason()
            snap["episode"] = tag.getEpisode()
            snap["year"] = tag.getYear()
            snap["imdb"] = str(tag.getIMDBNumber() or "")
        if snap["showtitle"] and snap["type"] in ("", "unknown"):
            snap["type"] = "episode"
        return snap
    except Exception as exc:
        log("snapshot failed: %s" % exc)
        return None


def snapshot_display(snap):
    if not snap:
        return ""
    if snap.get("showtitle"):
        label = snap["showtitle"]
        if snap.get("season", -1) >= 0 and snap.get("episode", -1) >= 0:
            label += " S%02dE%02d" % (snap["season"], snap["episode"])
        if snap.get("title") and snap["title"] != snap["showtitle"]:
            label += " - " + snap["title"]
        return label
    label = snap.get("title") or ""
    if snap.get("year"):
        label += " (%d)" % snap["year"]
    return label


def fmt_clock(seconds):
    try:
        seconds = int(max(0, seconds))
    except Exception:
        seconds = 0
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


# ---- resume checkpoint (per-profile store) ----

def resume_save(snap, position, duration):
    if not snap:
        return False
    data = {"snap": snap, "position": float(position),
            "duration": float(duration), "saved_at": _time.time()}
    return _write_json(RESUME_FILE, data)


def resume_load():
    return _read_json(RESUME_FILE)


def resume_delete():
    try:
        path = os.path.join(_data_dir(), RESUME_FILE)
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass
    publish_resume_props()


def publish_resume_props():
    """Mirror the checkpoint into Home window properties the skin's
    RESUME strip reads. Called on service start (a checkpoint left by
    a crashed/killed session is offered on the next launch), after
    every checkpoint write, and on clear."""
    if xbmcgui is None:
        return
    try:
        win = xbmcgui.Window(HOME_WINDOW_ID)
        data = resume_load()
        snap = data.get("snap") or {}
        if snap and data.get("position"):
            win.setProperty("RocResume.Ready", "1")
            win.setProperty("RocResume.Title", snapshot_display(snap))
            win.setProperty(
                "RocResume.Detail",
                "Left off at %s of %s" % (fmt_clock(data["position"]),
                                          fmt_clock(data.get("duration", 0))))
        else:
            win.setProperty("RocResume.Ready", "")
            win.setProperty("RocResume.Title", "")
            win.setProperty("RocResume.Detail", "")
    except Exception as exc:
        log("publish resume props failed: %s" % exc)


# ---- pending seek (armed by one-shot actions, applied by the service) ----

def seek_arm(seconds, title_hint=""):
    return _write_json(SEEK_FILE, {"time": float(seconds),
                                   "title": title_hint,
                                   "ts": _time.time()})


def seek_peek():
    data = _read_json(SEEK_FILE)
    return data if data.get("time") else None


def seek_clear():
    try:
        path = os.path.join(_data_dir(), SEEK_FILE)
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass


# ---- per-title SOURCE MEMORY (0.5.15, Hand B player-fix 2026-11-05) ----
# Item 2b root cause: the Resume Keeper checkpoint (resume.json) and
# the history store record only snap["path"], and for a RocPlay play
# that path is the RESOLVED stream URL (RocPlay's _listitem carries
# no path; the player plays the well's direct CDN URL, so
# Player.getPlayingFile() / Player.GetItem's file are that http(s)
# URL). resume_play() explicitly refuses http(s) paths, so every
# return fell through to the TMDb Helper play path and re-ran the
# FULL source hunt — the chosen source was never remembered anywhere.
# This store remembers, per title/episode identity: the resolved URL
# that actually played, the plugin path that ORIGINATED the play
# when there was one, and the position/duration at the last
# checkpoint. resume_play / detail_main_play consult it FIRST and go
# straight back to that source at that position; the old routes stay
# as the fallback when no memory exists or the remembered source
# will not start. Per-profile, like the checkpoint it companions.
SOURCE_MEMORY_FILE = "source_memory.json"
SOURCE_MEMORY_CAP = 60


def source_key(snap):
    """Stable identity for one playable: TMDb id when known, else
    the normalised show/title text; season/episode appended for TV.
    Deliberately NOT the path — resolved URLs carry per-session
    rendition/signature suffixes (the Loop 74 dedup lesson)."""
    if not snap:
        return ""
    is_tv = bool(snap.get("showtitle")) or snap.get("type") == "episode"
    base = ""
    if snap.get("tmdb"):
        base = "tmdb:%s" % snap["tmdb"]
    elif snap.get("imdb"):
        base = "imdb:%s" % snap["imdb"]
    else:
        base = "title:%s" % _norm_show_title(
            snap.get("showtitle") or snap.get("title") or "")
    if not base or base.endswith(":"):
        return ""
    if is_tv:
        try:
            return "%s|s%de%d" % (base, int(snap.get("season", -1)),
                                  int(snap.get("episode", -1)))
        except Exception:
            return base
    return base


def source_save(snap, url, position, duration, origin_path=""):
    """Remember the source that is actually playing for this title.
    `url` is the playing file at checkpoint time (the resolved
    stream); `origin_path` is the plugin:// path that launched the
    play when the snapshot carries one (library/strm/plugin plays).
    Newest first, de-duplicated by source_key, capped. Never raises."""
    if not snap:
        return False
    key = source_key(snap)
    if not key:
        return False
    try:
        position = float(position)
        duration = float(duration)
    except Exception:
        return False
    entry = {"key": key, "snap": snap, "url": url or "",
             "origin_path": origin_path or "",
             "position": position, "duration": duration,
             "ts": _time.time()}
    data = _read_json(SOURCE_MEMORY_FILE)
    entries = [e for e in (data.get("entries") or [])
               if isinstance(e, dict) and e.get("key") != key]
    entries.insert(0, entry)
    return _write_json(SOURCE_MEMORY_FILE,
                       {"entries": entries[:SOURCE_MEMORY_CAP]})


def source_load_for(snap):
    """The remembered source entry for this title/episode, or None.
    Matches on source_key; a TMDb-less snapshot also gets a title-key
    second chance so a checkpoint written before the id resolved
    still finds its entry."""
    if not snap:
        return None
    key = source_key(snap)
    data = _read_json(SOURCE_MEMORY_FILE)
    entries = [e for e in (data.get("entries") or [])
               if isinstance(e, dict)]
    if key:
        for e in entries:
            if e.get("key") == key:
                return e
    is_tv = bool(snap.get("showtitle")) or snap.get("type") == "episode"
    alt = {"showtitle": snap.get("showtitle") or "",
           "title": snap.get("title") or "",
           "type": snap.get("type") or "",
           "season": snap.get("season", -1),
           "episode": snap.get("episode", -1),
           "tmdb": "", "imdb": ""}
    alt_key = source_key(alt)
    if alt_key and alt_key != key:
        for e in entries:
            if e.get("key") == alt_key:
                return e
    return None


def source_for_episode(title, tmdb_id, season, episode):
    """Source-memory lookup by bare fields (the detail_main_play
    route, which knows title/id/S/E but holds no snapshot)."""
    snap = {"showtitle": title or "", "title": "",
            "type": "episode", "season": season, "episode": episode,
            "tmdb": str(tmdb_id or ""), "imdb": ""}
    return source_load_for(snap)


# ---- TMDB mini-client (collection / season data for the panel) ----
# The API key is TMDb Helper's own bundled key, read from its files at
# runtime — nothing of Eric's is stored or baked into rocui.

_TMDB_KEY_CACHE = [None]


def tmdb_key():
    if _TMDB_KEY_CACHE[0] is not None:
        return _TMDB_KEY_CACHE[0]
    key = ""
    try:
        path = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.themoviedb.helper/"
            "resources/tmdbhelper/lib/api/api_keys/tmdb.py")
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            m = _re.search(r"API_KEY\s*=\s*['\"]([^'\"]+)['\"]", fh.read())
        if m:
            key = m.group(1)
    except Exception as exc:
        log("tmdb key read failed: %s" % exc)
    _TMDB_KEY_CACHE[0] = key
    return key


def tmdb_get(path):
    key = tmdb_key()
    if not key or _urlreq is None:
        return None
    try:
        url = "https://api.themoviedb.org/3/%s%sapi_key=%s" % (
            path, "&" if "?" in path else "?", key)
        req = _urlreq.Request(url, headers={"User-Agent": "RocOS"})
        with _urlreq.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        log("tmdb get %s failed: %s" % (path, exc))
        return None


# ---- OMDb ratings client (L4-D8, Phase-2 audit 2026-11-08) ----
# IMDb / Rotten Tomatoes / Metacritic scores exist in NO feed this
# build already pulls: TMDB supplies only its own vote_average, and
# the TMDb Helper's OMDb module -- the one component that maps
# imdbRating / tomatoMeter / metascore onto the exact imdb_rating /
# rottentomatoes_rating / metacritic_rating properties the skin
# reads -- is inert until an OMDb API key sits in the Helper's own
# settings (omdb_apikey; every audited profile carries it EMPTY, so
# the Helper's omdb_api is None and those properties are never
# produced). This client follows the house precedent set by
# tmdb_key()/tmdb_get() above: it reads the Helper's key from the
# Helper's settings file at runtime (profile first, then master
# profile -- nothing of Eric's is baked into rocui), and it is a
# strict no-op while no key is configured: no request is made and
# every rating stays empty (honest absence -- the detail window's
# chips are visibility-gated on non-empty, so nothing renders).
# The moment a key is entered in TMDb Helper settings, both detail
# staging routes below light up IMDb/RT/MC with no further code
# change.
_OMDB_KEY_CACHE = [None]
_OMDB_SETTINGS_REL = ("addon_data/plugin.video.themoviedb.helper/"
                      "settings.xml")


def omdb_key():
    """The OMDb API key from TMDb Helper's settings, or ''."""
    if _OMDB_KEY_CACHE[0] is not None:
        return _OMDB_KEY_CACHE[0]
    key = ""
    if xbmcvfs is not None:
        for root in ("special://profile/", "special://masterprofile/"):
            try:
                path = xbmcvfs.translatePath(root + _OMDB_SETTINGS_REL)
                with open(path, "r", encoding="utf-8",
                          errors="replace") as fh:
                    text = fh.read()
            except Exception:
                continue
            m = _re.search(
                r'<setting id="omdb_apikey"[^>]*>([^<]+)</setting>',
                text)
            if m and m.group(1).strip():
                key = m.group(1).strip()
                break
    _OMDB_KEY_CACHE[0] = key
    return key


def omdb_ratings(imdb_id):
    """{RatingIMDb, RatingRT, RatingMC} for one IMDb id, via OMDb.

    Real data only: a field OMDb returns as missing / "N/A" is
    simply absent from the result -- never substituted, never
    derived from another score. {} when no key is configured, the
    id is not an IMDb id, or the lookup fails for any reason.
    Rotten Tomatoes is OMDb's critics Tomatometer (the Ratings
    entry sourced "Rotten Tomatoes", e.g. "87%") -- the same value
    the Helper's OMDb mapper publishes as rottentomatoes_rating
    (from tomatoMeter).
    """
    imdb_id = (imdb_id or "").strip()
    if not imdb_id.startswith("tt") or _urlreq is None:
        return {}
    key = omdb_key()
    if not key:
        return {}
    try:
        url = ("https://www.omdbapi.com/?i=%s&apikey=%s"
               % (_urlparse.quote_plus(imdb_id),
                  _urlparse.quote_plus(key)))
        req = _urlreq.Request(url, headers={"User-Agent": "RocOS"})
        with _urlreq.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        log("omdb get %s failed: %s" % (imdb_id, exc))
        return {}
    if not isinstance(data, dict) or data.get("Response") != "True":
        return {}
    out = {}

    def _clean(val):
        val = val.strip() if isinstance(val, str) else ""
        return "" if val in ("", "N/A") else val

    imdb = _clean(data.get("imdbRating"))
    if imdb:
        out["RatingIMDb"] = imdb
    for entry in data.get("Ratings") or []:
        if not isinstance(entry, dict):
            continue
        if entry.get("Source") == "Rotten Tomatoes":
            rt = _clean(entry.get("Value"))
            if rt:
                out["RatingRT"] = rt
        elif entry.get("Source") == "Metacritic":
            mc_full = _clean(entry.get("Value"))  # "74/100"
            if mc_full:
                out["RatingMC"] = mc_full.split("/")[0]
    if "RatingMC" not in out:
        mc = _clean(data.get("Metascore"))
        if mc:
            out["RatingMC"] = mc
    return out


def _detail_imdb_id(detail):
    """IMDb id out of a TMDB detail record ('' when absent).

    Movie records carry imdb_id at top level; TV records carry it
    only under external_ids (callers append external_ids)."""
    if not isinstance(detail, dict):
        return ""
    imdb = detail.get("imdb_id") or ""
    if not imdb:
        imdb = (detail.get("external_ids") or {}).get("imdb_id") or ""
    return imdb if isinstance(imdb, str) else ""


def _detail_mpaa(detail, tmdb_type):
    """US content rating out of a TMDB detail record.

    Mirrors the TMDb Helper's own mapper (api/tmdb/mapping.py
    get_mpaa_rating): US entry only, "Rated " prefix (the Helper's
    mpaa_prefix setting is "Rated" on every audited profile),
    movie certification chosen in release-type order, TV rating
    verbatim. Callers must append release_dates (movie) /
    content_ratings (TV) to the TMDB request. '' when TMDB lists
    no US rating -- honest absence, never a guess."""
    if not isinstance(detail, dict):
        return ""
    try:
        if tmdb_type == "tv":
            results = (detail.get("content_ratings") or {}).get(
                "results") or []
            for entry in results:
                if entry.get("iso_3166_1") == "US" and entry.get(
                        "rating"):
                    return "Rated %s" % entry["rating"]
        else:
            results = (detail.get("release_dates") or {}).get(
                "results") or []
            for entry in results:
                if entry.get("iso_3166_1") != "US":
                    continue
                dated = sorted(entry.get("release_dates") or [],
                               key=lambda k: k.get("type") or 0)
                for rd in dated:
                    if rd.get("certification"):
                        return "Rated %s" % rd["certification"]
    except Exception:
        return ""
    return ""


def tmdb_find_tmdb_id(snap):
    """Resolve a TMDb id from an IMDb id via TMDB's /find endpoint."""
    imdb = (snap or {}).get("imdb") or ""
    if not imdb:
        return ""
    is_tv = bool((snap or {}).get("showtitle")) or \
        (snap or {}).get("type") == "episode"
    data = tmdb_get("find/%s?external_source=imdb_id" % imdb)
    if not data:
        return ""
    bucket = "tv_results" if is_tv else "movie_results"
    rows = data.get(bucket) or []
    if rows and rows[0].get("id"):
        return str(rows[0]["id"])
    return ""


def snapshot_tmdb_id(snap):
    if not snap:
        return ""
    if snap.get("tmdb"):
        return str(snap["tmdb"])
    found = tmdb_find_tmdb_id(snap)
    if found:
        snap["tmdb"] = found
    return found


# ==========================================================================
# v3.3.0 — Discovery (G24), Proton VPN (G27), Install App (G26)
# ==========================================================================
import urllib.parse as _urlparse

# 0.5.5: tmdb_type=both is REQUIRED — TMDb Helper 5.4.16's search
# route (ListSearch.get_items) takes tmdb_type as a mandatory
# argument; the untyped 0.5.4 URL raised a TypeError inside the
# Helper on every title click (the .155 "TMDb Helper error" toast).
TMDBH_SEARCH = ("plugin://plugin.video.themoviedb.helper/"
                "?info=search&tmdb_type=both")


def _discover_seeds():
    """Real watched titles only — Roc's own data, never fabricated.

    Order: the Resume Keeper checkpoint (the single most recent title),
    then local-library movies by last played, then library episodes'
    show titles by last played. TMDb Helper trakt_ondeck data is NOT
    read here: no local helper for it exists in this addon (searched
    rocui_common/rocui_playback on 2026-10-25), so the honest core is
    Roc's own resume + library history.
    Returns a list of display titles (strings), de-duplicated.
    """
    seeds = []

    def _add(title):
        title = (title or "").strip()
        if title and title.lower() not in [s.lower() for s in seeds]:
            seeds.append(title)

    data = resume_load()
    snap = data.get("snap") or {}
    if snap:
        _add(snap.get("showtitle") or snapshot_display(snap))
    try:
        res = _rpc("VideoLibrary.GetMovies", {
            "properties": ["title", "lastplayed"],
            "sort": {"order": "descending", "method": "lastplayed"},
            "limits": {"start": 0, "end": 10}})
        for m in (res.get("movies") or []):
            _add(m.get("title"))
    except Exception as exc:
        log("discover movie seeds failed: %s" % exc)
    try:
        res = _rpc("VideoLibrary.GetEpisodes", {
            "properties": ["showtitle", "lastplayed"],
            "sort": {"order": "descending", "method": "lastplayed"},
            "limits": {"start": 0, "end": 25}})
        for e in (res.get("episodes") or []):
            _add(e.get("showtitle"))
    except Exception as exc:
        log("discover episode seeds failed: %s" % exc)
    return seeds[:5]


def discover():
    """action=discover (G24): publish up to 5 discovery rows as Home
    window properties RocDiscover.1..5. Each row's Title is a real
    watched title, its Label reads 'BECAUSE YOU WATCHED <title>', and
    its Path is a TMDb Helper search for that title — a candidate only
    surfaces when it resolves to that playable search path. With no
    stored history at all, sets RocDiscover.Empty=1 and nothing else.
    """
    if xbmcgui is None:
        return 0
    win = xbmcgui.Window(HOME_WINDOW_ID)
    seeds = _discover_seeds()
    for i in range(1, 6):
        prefix = "RocDiscover.%d" % i
        if i <= len(seeds):
            title = seeds[i - 1]
            win.setProperty(prefix + ".Title", title)
            win.setProperty(prefix + ".Label",
                            "BECAUSE YOU WATCHED %s" % title.upper())
            win.setProperty(prefix + ".Path",
                            "%s&query=%s" % (
                                TMDBH_SEARCH,
                                _urlparse.quote_plus(title)))
        else:
            win.setProperty(prefix + ".Title", "")
            win.setProperty(prefix + ".Label", "")
            win.setProperty(prefix + ".Path", "")
    win.setProperty("RocDiscover.Empty", "" if seeds else "1")
    win.setProperty("RocDiscover.Count", str(len(seeds)))
    roc_log("Discovery published %d row(s) from watched history"
            % len(seeds), event="discover")
    if not seeds:
        notify("Nothing to discover yet",
               "Watch something first and discovery fills in from "
               "your own history", ok=False)
    return len(seeds)


PROTON_PACKAGE = "com.protonvpn.android"


def _android_apps():
    """Installed Android app packages via Kodi's androidapp VFS, or
    None when the listing is unavailable (not Android / restricted)."""
    if xbmcvfs is None:
        return None
    try:
        _dirs, files = xbmcvfs.listdir("androidapp://sources/apps/")
        names = list(files or []) + list(_dirs or [])
        return names if names else None
    except Exception:
        return None


def proton_vpn():
    """action=proton_vpn (G27): launch Proton VPN on Android/Fire TV.
    Never fakes a connection state — it only opens the app (or, when
    the app is not installed, says so and opens the Amazon Appstore
    search for it)."""
    if xbmc is None:
        return False
    is_android = False
    try:
        is_android = bool(xbmc.getCondVisibility("System.Platform.Android"))
    except Exception:
        is_android = False
    if not is_android:
        notify("Proton VPN", "Proton VPN launch only works on Android "
               "and Fire TV devices", ok=False)
        roc_log("Proton VPN launch refused: not an Android device",
                event="vpn")
        return False
    apps = _android_apps()
    installed = None
    if apps is not None:
        installed = any(PROTON_PACKAGE in str(a) for a in apps)
    if installed:
        try:
            xbmc.executebuiltin(
                "StartAndroidActivity(%s,android.intent.action.MAIN,,)"
                % PROTON_PACKAGE)
            roc_log("Proton VPN app launched", event="vpn")
            notify("Proton VPN", "Opening Proton VPN")
            return True
        except Exception as exc:
            log("proton launch failed: %s" % exc)
    if installed is False:
        notify("Proton VPN isn't installed on this device yet",
               "Opening the Appstore search so you can grab it",
               ok=False)
        roc_log("Proton VPN not installed; Appstore search opened",
                event="vpn")
        try:
            xbmc.executebuiltin(
                "StartAndroidActivity(android.intent.action.VIEW,"
                "android.intent.action.VIEW,,"
                "amzn://apps/android?p=%s)" % PROTON_PACKAGE)
        except Exception as exc:
            log("proton appstore fallback failed: %s" % exc)
        return False
    # Listing unavailable: attempt the launch honestly — Kodi/Android
    # will surface its own error if the package is truly absent.
    try:
        xbmc.executebuiltin(
            "StartAndroidActivity(%s,android.intent.action.MAIN,,)"
            % PROTON_PACKAGE)
        roc_log("Proton VPN launch attempted (install state unverified)",
                event="vpn")
        notify("Proton VPN", "Opening Proton VPN")
        return True
    except Exception as exc:
        log("proton launch failed: %s" % exc)
        notify("Proton VPN",
               "Proton VPN could not be opened on this device",
               ok=False)
        return False


FAMILY_PROFILES = ("E-Roc", "Nue", "Jama", "August")


def install_app(profile):
    """action=install_app,profile=<name> (G26): the standalone family
    apps are not published yet, so this is the honest route — a plain
    dialog saying so. No URLs are invented, nothing is downloaded."""
    profile = (profile or "").strip()
    if profile not in FAMILY_PROFILES:
        log("install_app refused unknown profile: %r" % profile)
        notify("Unknown profile", "That family profile is not one of "
               "E-Roc Nue Jama or August", ok=False)
        return False
    message = ("The %s app isn't published yet - it arrives with the "
               "family apps release. This profile inside Roc OS is "
               "ready now." % profile)
    roc_log("Install app requested for %s: not published yet" % profile,
            event="install")
    if xbmcgui is not None:
        try:
            xbmcgui.Dialog().ok("Roc OS", message)
            return True
        except Exception:
            pass
    notify("Roc OS", message, ok=False)
    return True


# ==========================================================================
# v3.4.0 — THE LOOK PASS: per-profile playback HISTORY store (Adult
# Continue Watching / History shelves + per-category stage CW), the
# COLLECTIONS engine for the stage's second row (Eric's pick,
# 2026-10-25 10:00: collections built ONLY from titles Eric personally
# named — his Trakt lists, the Classics catalog, the wrestling eras,
# horror, Herbie), and stage_folder (collection-tile click route).
# ==========================================================================
HISTORY_FILE = "history.json"
HISTORY_CAP = 80


def history_record(snap, position, duration):
    """Record one playback checkpoint into the per-profile history
    store (companion to resume_save's single checkpoint: history
    keeps every title, newest first, de-duplicated by path, capped).
    Called by the service on the same ~30s cadence as resume_save,
    and once more when a title finishes. Never raises."""
    if not snap or not snap.get("path"):
        return False
    try:
        position = float(position)
        duration = float(duration)
    except Exception:
        return False
    pct = (100.0 * position / duration) if duration > 0 else 0.0
    entry = {"snap": snap, "position": position, "duration": duration,
             "pct": round(pct, 1), "ts": _time.time()}
    data = _read_json(HISTORY_FILE)
    entries = [e for e in (data.get("entries") or [])
               if isinstance(e, dict)
               and (e.get("snap") or {}).get("path") != snap.get("path")]
    entries.insert(0, entry)
    return _write_json(HISTORY_FILE, {"entries": entries[:HISTORY_CAP]})


def history_entries():
    data = _read_json(HISTORY_FILE)
    return [e for e in (data.get("entries") or []) if isinstance(e, dict)]


def history_filtered(src="", continue_only=False):
    """History entries filtered for a shelf. `src` is a comma list of
    tokens matched as substrings of the stored plugin path (e.g.
    src=cumination for the Adult shelves, src=watchnixtoons2 for the
    Toonime stage). continue_only keeps started-but-unfinished
    entries (2%..97%) — the Continue Watching shelves."""
    tokens = [t.strip() for t in (src or "").split(",") if t.strip()]
    out = []
    for e in history_entries():
        snap = e.get("snap") or {}
        path = snap.get("path") or ""
        if tokens and not any(t in path for t in tokens):
            continue
        if continue_only and not (2.0 <= float(e.get("pct") or 0) < 97.0):
            continue
        out.append(e)
    return out



# --------------------------------------------------------------------------
# Resume-PLAY (Eric Nov 1 10:07, refined 10:32): the show-page main
# button's label follows progress — no progress -> PLAY (S1E1),
# progress -> CONTINUE WATCHING (resume his spot), credits reached ->
# CONTINUE WATCHING the NEXT episode. This block is the target
# computation only; the skin wiring (label $INFO + onclick) is a
# separate file change, and detail_main_play in rocui_playback.py
# is the click-time action. Movies are NOT touched by this build:
# stage_open publishes Main* props for TV titles only, and the
# proven movie path (Loop 54 Herbie) keeps its PLAY+RESUME pair.
# --------------------------------------------------------------------------
SHOW_PROGRESS_FLOOR_POS = 45.0
SHOW_PROGRESS_FLOOR_PCT = 2.0
SHOW_FINISHED_REMAIN = 90.0
SHOW_FINISHED_PCT = 97.0


def _norm_show_title(title):
    """Normalise a show title for history matching: lower-case,
    non-alphanumerics -> single spaces, stripped. History snaps
    carry tmdb EMPTY for streamed episodes (Loop 74 scope), so the
    match key is the show title, never the tmdb id."""
    return re.sub(r"[^a-z0-9]+", " ", (title or "").lower()).strip()


def _history_entries_all():
    """History entries from BOTH stores, merged. The service
    (start=login) writes under the master profile, while stage_open
    runs under the logged-in profile — Loop 74's build-blocking
    question. Reading both stores (same pattern as the PIN record's
    master-canonical + per-profile fallback) means the lookup sees
    the entry whichever store the service wrote, without needing to
    prove the write side first. Never raises."""
    seen = []
    try:
        seen.extend(history_entries())
    except Exception:
        pass
    try:
        data = _read_json_from(_master_data_dir(), HISTORY_FILE)
        for e in (data.get("entries") or []):
            if isinstance(e, dict):
                seen.append(e)
    except Exception:
        pass
    return seen


# ---- Roc Sync resume (2026-11-16, Eric 19:45) ------------------
# The detail page's RESUME button must light from the house's own
# progress store: service.rocsync's per-profile tracking JSON
# (pause->play is the log; 60 s safety saves underneath). Layers
# 1-3 in stage_open read infolabels, item-carried progress and
# rocui's legacy local history - none of them reads the Roc Sync
# store, so a title whose progress lives only there (the normal
# case since Roc Sync went live) showed no RESUME. This reader is
# Layer 4's source and detail_resume_play's position authority.
# Current profile only: special://profile mounts only the active
# profile's subtree (the Design A wall). Finished follows Roc
# Sync's own rule (<=90 s left or >=97% played = finished, never
# resumable). Never raises.
_ROCSYNC_SLUGS = {"E-Roc": "eric", "Nue": "nue", "Jama": "jama",
                  "August": "august"}


def _rocsync_store():
    try:
        name = xbmc.getInfoLabel("System.ProfileName") or ""
        slug = _ROCSYNC_SLUGS.get(name)
        if not slug:
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") \
                or "master"
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/service.rocsync/"
            "tracking/%s.json" % slug)
        with open(path, "r") as fh:
            return json.loads(fh.read())
    except Exception:
        return None


def rocsync_resume(tmdb_type, tmdb_id, season=None, episode=None):
    """(position_seconds, runtime_seconds) for this title in the
    current profile's Roc Sync store, or None. Episodes match on
    the show's tmdb id + season + episode number; movies on the
    tmdb id. A position qualifies when it is past the house floor
    (SHOW_PROGRESS_FLOOR_POS) and the title is not finished under
    Roc Sync's own rule. Never raises."""
    try:
        if not tmdb_id:
            return None
        store = _rocsync_store()
        if not store:
            return None
        want = str(tmdb_id)
        for row in store.get("progress") or []:
            if not isinstance(row, dict):
                continue
            ids = row.get("ids") or {}
            if str(ids.get("tmdb") or "") != want:
                continue
            rtype = row.get("type") or ""
            if tmdb_type == "movie":
                if rtype != "movie":
                    continue
            else:
                if rtype != "episode":
                    continue
                try:
                    r_season = int(row.get("season"))
                    r_ep = row.get("episode_number")
                    if r_ep is None and row.get("episode"):
                        _m = re.search(r"S(\d+)E(\d+)",
                                       str(row["episode"]), re.I)
                        if _m:
                            r_season = int(_m.group(1))
                            r_ep = int(_m.group(2))
                    if int(season) != r_season \
                            or int(episode) != int(r_ep):
                        continue
                except Exception:
                    continue
            try:
                pos = float(row.get("position_seconds") or 0)
                dur = float(row.get("runtime_seconds") or 0)
            except Exception:
                continue
            if pos <= SHOW_PROGRESS_FLOOR_POS:
                continue
            if dur > 0 and (dur - pos <= 90.0 or pos >= 0.97 * dur):
                continue
            return (pos, dur)
    except Exception as exc:
        log("rocsync_resume failed: %s" % exc)
    return None


def _fresh_or_store(fresh, title, tmdb_id, tmdb_get_fn):
    """History produced no qualifying target: give the Roc Sync
    store its say before PLAY S1E1 is declared (rocui 0.7.13)."""
    s = _show_target_from_store(title, tmdb_id, tmdb_get_fn)
    return s if s is not None else fresh


def _show_target_from_store(title, tmdb_id="", tmdb_get_fn=None):
    """Bundle fix (rocui 0.7.13): the Roc Sync store fallback for
    show_progress_target. A show whose episode progress lives ONLY
    in the Roc Sync store (the normal case since Roc Sync went
    live) used to show PLAY from every route, because the target
    reader only scanned legacy history. Mirrors the history path's
    exact rules (collapse by episode, newest wins, same floors,
    same finished rule, next-episode verified the same way) over
    the store's episode rows for this show's tmdb id. Returns a
    target dict or None. Never raises."""
    try:
        if not tmdb_id:
            return None
        store = _rocsync_store()
        if not store:
            return None
        want = str(tmdb_id)
        best = {}
        for row in store.get("progress") or []:
            if not isinstance(row, dict):
                continue
            if (row.get("type") or "") != "episode":
                continue
            ids = row.get("ids") or {}
            if str(ids.get("tmdb") or "") != want:
                continue
            try:
                season = row.get("season")
                ep = row.get("episode_number")
                if (season is None or ep is None) and row.get("episode"):
                    m = re.search(r"S(\d+)E(\d+)", str(row["episode"]), re.I)
                    if not m:
                        continue
                    season = int(m.group(1))
                    ep = int(m.group(2))
                season = int(season)
                episode = int(ep)
            except Exception:
                continue
            if season < 0 or episode < 0:
                continue
            try:
                ts = float(row.get("last_ts") or 0)
            except Exception:
                ts = 0.0
            key = (season, episode)
            cur = best.get(key)
            if cur is None or ts >= cur[0]:
                best[key] = (ts, row)
        if not best:
            return None
        _ts, row = max(best.values(), key=lambda kv: kv[0])
        try:
            position = float(row.get("position_seconds") or 0)
            duration = float(row.get("runtime_seconds") or 0)
        except Exception:
            return None
        pct = (100.0 * position / duration) if duration > 0 else 0.0
        season = row.get("season")
        ep = row.get("episode_number")
        if (season is None or ep is None) and row.get("episode"):
            m = re.search(r"S(\d+)E(\d+)", str(row["episode"]), re.I)
            season = int(m.group(1))
            ep = int(m.group(2))
        season = int(season)
        episode = int(ep)
        if position <= SHOW_PROGRESS_FLOOR_POS or pct < SHOW_PROGRESS_FLOOR_PCT:
            return None
        remaining = duration - position if duration > 0 else 999999.0
        if remaining <= SHOW_FINISHED_REMAIN or pct >= SHOW_FINISHED_PCT:
            nxt = _next_episode(tmdb_id, season, episode, tmdb_get_fn)
            if nxt is None:
                log("show_progress_target(store): no next episode for "
                    "%r S%dE%d, falling back to PLAY S1E1"
                    % (title, season, episode))
                return None
            ns, ne = nxt
            return {"label": "CONTINUE WATCHING", "kind": "next",
                    "season": ns, "episode": ne, "position": 0.0,
                    "tag": "S%02dE%02d" % (ns, ne)}
        return {"label": "CONTINUE WATCHING", "kind": "resume",
                "season": season, "episode": episode,
                "position": position,
                "tag": "S%02dE%02d" % (season, episode)}
    except Exception as exc:
        log("show_progress_target(store) failed: %s" % exc)
    return None


def show_progress_target(title, tmdb_id="", tmdb_get_fn=None):
    """Compute the show-page main-button target for one show title.
    Returns a dict: label ("PLAY" | "CONTINUE WATCHING"), kind
    ("fresh" | "resume" | "next"), season, episode, position
    (seconds, 0 for fresh/next), tag ("S01E01" style, for screenshot
    checkability). tmdb_get_fn defaults to tmdb_get; the harness
    injects a stub. Never raises: on any failure the target is
    fresh PLAY S1E1 (a working button, never a dead one)."""
    fresh = {"label": "PLAY", "kind": "fresh", "season": 1, "episode": 1,
             "position": 0.0, "tag": "S01E01"}
    if not title:
        return dict(fresh)
    want = _norm_show_title(title)
    if not want:
        return dict(fresh)
    # Collapse by (show, season, episode): newest ts wins. This is
    # the Loop 74 dedup fix — the same S1E1 appears 4x in the live
    # store under rendition-suffixed paths, so path-dedup (what
    # history_record does) cannot be the lookup key.
    best = {}
    for e in _history_entries_all():
        snap = e.get("snap") or {}
        show = snap.get("showtitle") or ""
        if _norm_show_title(show) != want:
            continue
        if snap.get("type") not in ("episode", "", None) and not show:
            continue
        try:
            season = int(snap.get("season", -1))
            episode = int(snap.get("episode", -1))
        except Exception:
            continue
        if season < 0 or episode < 0:
            continue
        key = (season, episode)
        try:
            ts = float(e.get("ts") or 0)
        except Exception:
            ts = 0.0
        cur = best.get(key)
        if cur is None or ts >= cur[0]:
            best[key] = (ts, e)
    if not best:
        return _fresh_or_store(dict(fresh), title, tmdb_id, tmdb_get_fn)
    # Newest collapsed entry overall is the show's latest activity.
    _ts, entry = max(best.values(), key=lambda kv: kv[0])
    try:
        position = float(entry.get("position") or 0)
        duration = float(entry.get("duration") or 0)
        pct = float(entry.get("pct") or 0)
    except Exception:
        return dict(fresh)
    if duration <= 0:
        pct = 0.0
    season = int((entry.get("snap") or {}).get("season", -1))
    episode = int((entry.get("snap") or {}).get("episode", -1))
    # Progress floor (both house floors): a sub-45s or sub-2% blip
    # does not flip PLAY to CONTINUE WATCHING.
    if position <= SHOW_PROGRESS_FLOOR_POS or pct < SHOW_PROGRESS_FLOOR_PCT:
        return _fresh_or_store(dict(fresh), title, tmdb_id, tmdb_get_fn)
    # Finished / credits proxy (union of the house rules): the
    # service deletes the resume checkpoint at remaining <= 90s,
    # history continue_only ends at pct >= 97%.
    remaining = duration - position if duration > 0 else 999999.0
    if remaining <= SHOW_FINISHED_REMAIN or pct >= SHOW_FINISHED_PCT:
        nxt = _next_episode(tmdb_id, season, episode, tmdb_get_fn)
        if nxt is None:
            # No verifiable next episode: a working PLAY S1E1 beats
            # a dead CONTINUE WATCHING button (scope's edge rule).
            log("show_progress_target: no next episode for %r "
                "S%dE%d, falling back to PLAY S1E1"
                % (title, season, episode))
            return _fresh_or_store(dict(fresh), title, tmdb_id, tmdb_get_fn)
        ns, ne = nxt
        return {"label": "CONTINUE WATCHING", "kind": "next",
                "season": ns, "episode": ne, "position": 0.0,
                "tag": "S%02dE%02d" % (ns, ne)}
    return {"label": "CONTINUE WATCHING", "kind": "resume",
            "season": season, "episode": episode, "position": position,
            "tag": "S%02dE%02d" % (season, episode)}


def _next_episode(tmdb_id, season, episode, tmdb_get_fn=None):
    """Next episode after (season, episode), verified against TMDB
    season data when an id is available: next in the same season,
    else S+1E1 if that season exists. Returns (season, episode) or
    None. Without a tmdb id there is nothing to verify against, so
    None (the caller falls back to PLAY S1E1, never a blind hop)."""
    if not tmdb_id:
        return None
    get = tmdb_get_fn or tmdb_get
    try:
        data = get("tv/%s/season/%d" % (tmdb_id, season)) or {}
        eps = [e.get("episode_number") for e in (data.get("episodes") or [])
               if isinstance(e, dict) and e.get("episode_number") is not None]
        if episode + 1 in eps:
            return (season, episode + 1)
        data2 = get("tv/%s/season/%d" % (tmdb_id, season + 1)) or {}
        eps2 = (data2.get("episodes") or [])
        if eps2:
            return (season + 1, 1)
    except Exception as exc:
        log("show_progress_target: next-episode lookup failed: %s" % exc)
    return None


# ---- collections (stage row 2) -------------------------------------------
_TMDBH = "plugin://plugin.video.themoviedb.helper/"
_TRAKT_SLUG_MEM = [None]


def _trakt_user_slug():
    """The Trakt user slug from this addon's own setting
    `trakt_user_slug` (resources/settings.xml, default EMPTY). No
    account identity ships in the code: on Eric's fleet the deploy
    drops a settings seed into this addon's profile data
    (58-fleet-settings-seed) so his sticks keep their Trakt lists;
    anywhere else the setting stays empty and the Trakt collections
    are absent (see _trakt_list_path / collections_for). Memoized
    like _TITLE_ID_MEM / _ART_CACHE_MEM. Never raises."""
    if _TRAKT_SLUG_MEM[0] is None:
        slug = ""
        if xbmcaddon is not None:
            try:
                slug = xbmcaddon.Addon(ADDON_ID).getSetting(
                    "trakt_user_slug") or ""
            except Exception:
                slug = ""
        _TRAKT_SLUG_MEM[0] = slug.strip()
    return _TRAKT_SLUG_MEM[0]


def _trakt_list_path(name, slug):
    """A Trakt list as a TMDb Helper directory (the params are TMDb
    Helper's own trakt_userlist contract, incl. owner=true for the
    list owner's lists), for the user named by the `trakt_user_slug`
    setting. List slugs are Trakt's canonical slugification of the
    exact list names harvested 2026-10-24. No user configured -> ''
    (nothing user-identifying, never raises): _coll drops the empty
    path and collections_for leaves the shelf off the stage."""
    user = _trakt_user_slug()
    if not user:
        return ""
    q = _urlparse.quote
    return ("%s?info=trakt_userlist&list_name=%s&list_slug=%s"
            "&user_slug=%s&owner=true&plugin_category=%s"
            % (_TMDBH, q(name), slug, user, q(name)))


def _coll_tmdb_type(c):
    """TMDb media type for a titles-based collection. Herbie is the
    one movie shelf Eric named; every other titles shelf is TV.
    Derived from the shelf's own cats so a future movie shelf that
    declares ("movies",) alone types itself correctly."""
    cats = c.get("cats") or ()
    if "movies" in cats and "tv" not in cats and "toonime" not in cats:
        return "movie"
    return "tv"


TITLE_ID_FILE = "title_ids.json"
_TITLE_ID_MEM = [None]


def _title_tmdb_id(title, tmdb_type):
    """TMDB id for one named title, resolved through the TMDB
    mini-client and cached in the addon profile data (the
    collection_art pattern: hits cached, a miss retries next build).
    '' when unresolved — the caller falls back to a typed search.
    Only the FIRST search hit is taken: these are titles Eric
    named personally, and the kind-specific endpoint (search/tv
    or search/movie) ranks the canonical entry first."""
    if not title or tmdb_type not in ("movie", "tv"):
        return ""
    if _TITLE_ID_MEM[0] is None:
        _TITLE_ID_MEM[0] = _read_json(TITLE_ID_FILE)
    cache = _TITLE_ID_MEM[0]
    key = "%s|%s" % (tmdb_type, title.lower())
    if cache.get(key):
        return str(cache[key])
    data = tmdb_get("search/%s?query=%s"
                    % (tmdb_type, _urlparse.quote_plus(title)))
    for row in (data or {}).get("results") or []:
        if row.get("id"):
            cache[key] = row["id"]
            _write_json(TITLE_ID_FILE, cache)
            return str(row["id"])
    return ""


def _search_path(title, tmdb_type="both"):
    """TMDb Helper route for one named collection title (0.5.5).

    Eric's law: click a picture -> THAT title's page. So when the
    title resolves to a TMDB id, the path goes straight to the
    Helper's page for that title (info=details, whose route
    requires tmdb_type + tmdb_id) — no search detour. When it
    cannot resolve (offline, no key, no hit), the fallback is a
    TYPED search: Helper 5.4.16's search route requires tmdb_type
    as a mandatory argument, and the untyped 0.5.4 URL raised a
    TypeError inside the Helper on every title click — the
    "TMDb Helper error" toast Eric hit on the room stick."""
    tmdb_id = _title_tmdb_id(title, tmdb_type)
    if tmdb_id:
        return ("%s?info=details&tmdb_type=%s&tmdb_id=%s"
                % (_TMDBH, tmdb_type, tmdb_id))
    return ("%s?info=search&tmdb_type=%s&query=%s"
            % (_TMDBH, tmdb_type, _urlparse.quote_plus(title)))



TITLE_INFO_FILE = "title_info.json"
_TITLE_INFO_MEM = [None]


def _title_tmdb_info(title, tmdb_type):
    """{id, poster, fanart} for one named title, from ONE TMDB
    search, cached together in the addon profile data
    (title_info.json). _title_tmdb_id caches the id alone; this
    caches the art with it, so minting a title poster costs no
    second lookup. A legacy title_ids.json hit is adopted when
    the search itself cannot run (offline): the id alone still
    mints the title's details route, just without fresh art.
    All-empty when nothing resolves — the caller decides what
    an unresolved title means (collection_detail omits the row:
    a title poster never points at a search)."""
    empty = {"id": "", "poster": "", "fanart": ""}
    if not title or tmdb_type not in ("movie", "tv"):
        return dict(empty)
    if _TITLE_INFO_MEM[0] is None:
        _TITLE_INFO_MEM[0] = _read_json(TITLE_INFO_FILE)
    cache = _TITLE_INFO_MEM[0]
    key = "%s|%s" % (tmdb_type, title.lower())
    hit = cache.get(key)
    if hit:
        return {"id": str(hit.get("id") or ""),
                "poster": hit.get("poster") or "",
                "fanart": hit.get("fanart") or ""}
    data = tmdb_get("search/%s?query=%s"
                    % (tmdb_type, _urlparse.quote_plus(title)))
    for row in (data or {}).get("results") or []:
        if row.get("id"):
            info = {"id": str(row["id"]),
                    "poster": (_TMDB_IMG_W500 + row["poster_path"])
                    if row.get("poster_path") else "",
                    "fanart": (_TMDB_IMG_W500 + row["backdrop_path"])
                    if row.get("backdrop_path") else ""}
            cache[key] = {"id": row["id"], "poster": info["poster"],
                          "fanart": info["fanart"]}
            _write_json(TITLE_INFO_FILE, cache)
            return info
    legacy = _title_tmdb_id(title, tmdb_type)
    if legacy:
        return {"id": legacy, "poster": "", "fanart": ""}
    return dict(empty)


def _title_details_path(title, tmdb_type, info=None):
    """The ONLY route a title poster may carry (0.5.7): the
    title's own TMDb Helper details route, with the concrete
    TMDB id. '' when the title does not resolve — NEVER a
    search URL. 0.5.5's _search_path fell back to a typed search
    when a title could not resolve; as a poster target that
    still broke Eric's click law (a search page is a list to
    hunt through, not the title's page), so the poster route
    does not fall back at all."""
    if info is None:
        info = _title_tmdb_info(title, tmdb_type)
    if not info.get("id"):
        return ""
    return ("%s?info=details&tmdb_type=%s&tmdb_id=%s"
            % (_TMDBH, tmdb_type, info["id"]))

def _member_tmdb_info(m):
    """{id, poster, fanart} for one explicit collection member
    (MCU lane 2026-11-17). The member already carries its verified
    TMDB id, so the art comes from the record itself (movie/<id>
    or tv/<id>) — no search, no first-hit guessing. Cached in the
    same title_info.json the named-title shelves use, under an
    'id:' key that cannot collide with a title key. All-empty
    when the record cannot be fetched — the caller omits the row
    for this build and retries on the next."""
    empty = {"id": "", "poster": "", "fanart": ""}
    tmdb_type = m.get("tmdb_type") or ""
    tmdb_id = str(m.get("tmdb_id") or "")
    if tmdb_type not in ("movie", "tv") or not tmdb_id:
        return dict(empty)
    if _TITLE_INFO_MEM[0] is None:
        _TITLE_INFO_MEM[0] = _read_json(TITLE_INFO_FILE)
    cache = _TITLE_INFO_MEM[0]
    key = "%s|id:%s" % (tmdb_type, tmdb_id)
    hit = cache.get(key)
    if hit:
        return {"id": str(hit.get("id") or tmdb_id),
                "poster": hit.get("poster") or "",
                "fanart": hit.get("fanart") or ""}
    data = tmdb_get("%s/%s" % (tmdb_type, tmdb_id)) or {}
    if not data.get("id"):
        return dict(empty)
    info = {"id": str(data["id"]),
            "poster": (_TMDB_IMG_W500 + data["poster_path"])
            if data.get("poster_path") else "",
            "fanart": (_TMDB_IMG_W500 + data["backdrop_path"])
            if data.get("backdrop_path") else ""}
    cache[key] = {"id": data["id"], "poster": info["poster"],
                  "fanart": info["fanart"]}
    _write_json(TITLE_INFO_FILE, cache)
    return info


# ---- TMDb Helper Roc Play player seeding (0.5.5) ------------------
# The Helper routes its play hop through player files living in its
# OWN addon_data/players/ — a folder Install-from-zip can never
# write into. The working builds carry roc_rocplay.json there
# because it was placed by hand; a fresh install (the room stick)
# has no Roc Play player at all, so even a fixed click would dead-
# end at the play step. rocui therefore ships the identical file
# as a resource (resources/data/roc_rocplay.json, byte-for-byte the
# seeded file from the working builds) and the service lands it at
# login — ONLY if absent. An existing file is never overwritten:
# it may be Eric's own edited player config.
ROCPLAY_PLAYER_FILE = "roc_rocplay.json"
TMDBH_PLAYERS_SUBPATH = ("addon_data/plugin.video.themoviedb.helper"
                         "/players")


def _rocplay_player_resource():
    """Path to the shipped player definition (module-relative:
    readable in Kodi and in offline tests)."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "resources", "data", ROCPLAY_PLAYER_FILE)


def seed_tmdbh_player():
    """Land the Roc Play player file in TMDb Helper's players
    folder, and REPAIR it whenever the on-disk copy has drifted
    from the shipped template. Returns True when this call wrote
    the file. Never raises.

    SKIN PASS PUSH (2026-11-12): the original seed-if-absent rule
    never overwrote an existing file, so a stale template variant
    (the pre-auto one, without &auto=1 in its play URLs) lived
    forever once landed — Roc Play then showed its manual source
    picker on titles Eric expected to just play (his 2026-11-12
    walkthrough: "I thought we had auto play on or something").
    The file is rocui's own seeded artifact and the resource in
    this addon is its source of truth, so a content mismatch is
    drift, not a user edit: replace it and log the repair."""
    if xbmcvfs is None:
        return False
    try:
        dst_dir = xbmcvfs.translatePath(
            "special://profile/%s/" % TMDBH_PLAYERS_SUBPATH)
        if not dst_dir:
            return False
        dst = os.path.join(dst_dir, ROCPLAY_PLAYER_FILE)
        src = _rocplay_player_resource()
        if not os.path.isfile(src):
            log("rocplay player resource missing: %s" % src)
            return False
        with open(src, "rb") as fh:
            data = fh.read()
        if os.path.isfile(dst):
            try:
                with open(dst, "rb") as fh:
                    existing = fh.read()
            except Exception:
                existing = None
            if existing == data:
                return False
            tmp = dst + ".tmp"
            with open(tmp, "wb") as fh:
                fh.write(data)
            os.replace(tmp, dst)
            roc_log("Repaired drifted TMDb Helper player file: %s"
                    % ROCPLAY_PLAYER_FILE, event="install")
            return True
        if not os.path.isdir(dst_dir):
            os.makedirs(dst_dir)
        tmp = dst + ".tmp"
        with open(tmp, "wb") as fh:
            fh.write(data)
        os.replace(tmp, dst)
        roc_log("Seeded TMDb Helper player file: %s"
                % ROCPLAY_PLAYER_FILE, event="install")
        return True
    except Exception as exc:
        log("tmdbh player seed failed: %s" % exc)
        return False


def _coll(cid, label, sub, cats, path=None, titles=None, years=None,
          members=None, profiles=None):
    d = {"id": cid, "label": label, "sub": sub, "cats": tuple(cats)}
    if path:
        d["path"] = path
    if titles:
        d["titles"] = list(titles)
    if years:
        d["years"] = tuple(years)
    if members:
        d["members"] = list(members)
    if profiles:
        d["profiles"] = tuple(profiles)
    return d


def _m(label, tmdb_id, tmdb_type, year, season=None, note=None):
    """One explicit member of a members-based collection (MCU lane
    2026-11-17): the entry carries its own verified TMDB id and
    kind, so one ordered list can mix movies and shows and split
    a show by season — neither is expressible with a titles list,
    whose members all share the shelf's single derived kind and
    resolve by name search. `note` is an optional marker appended
    to the row's sub (the MCU shelf uses it for Eric's place)."""
    d = {"label": label, "tmdb_id": str(tmdb_id),
         "tmdb_type": tmdb_type, "year": year}
    if season:
        d["season"] = season
    if note:
        d["note"] = note
    return d


# Every entry below is built from something Eric personally named:
# his seven Trakt lists (harvested 2026-10-24, counts are the
# harvest's), the Classics catalog he dictated 2026-10-24
# (rocos-dev/TOONIME-CLASSICS-CATALOG.md, same groupings), the
# TMDB's Horror genre (his
# named horror lane), and the Herbie films from his openers.
COLLECTIONS = [
    _coll("power-universe", "Power Universe", "YOUR TRAKT LIST - 4 SHOWS",
          ("tv", "home"), path=_trakt_list_path("Power Universe",
                                                "power-universe")),
    _coll("that-70s-universe", "That '70s Show Universe",
          "YOUR TRAKT LIST - 2 SHOWS", ("tv",),
          path=_trakt_list_path("That '70s Show Universe",
                                "that-70s-show-universe")),
    _coll("pokemon-universe", "Pokémon Universe",
          "YOUR TRAKT LIST - 4 SHOWS + 25 MOVIES", ("tv", "toonime",
                                                    "movies", "home"),
          path=_trakt_list_path("Pokémon Universe", "pokemon-universe")),
    _coll("digimon-universe", "Digimon Universe",
          "YOUR TRAKT LIST - 11 SHOWS + 7 MOVIES", ("tv", "toonime",
                                                    "movies"),
          path=_trakt_list_path("Digimon Universe", "digimon-universe")),
    _coll("dragon-ball-universe", "Dragon Ball Universe",
          "YOUR TRAKT LIST - 7 SHOWS + 21 MOVIES", ("tv", "toonime",
                                                    "movies"),
          path=_trakt_list_path("Dragon Ball Universe",
                                "dragon-ball-universe")),
    _coll("harry-potter", "Harry Potter", "YOUR TRAKT LIST - 8 MOVIES",
          ("movies", "home"),
          path=_trakt_list_path("Harry Potter", "harry-potter")),
    _coll("lord-of-the-rings", "Lord of the Rings",
          "YOUR TRAKT LIST - 3 MOVIES", ("movies",),
          path=_trakt_list_path("Lord of the Rings", "lord-of-the-rings")),
    _coll("horror", "Horror", "TOP HORROR MOVIES ON TMDB",
          ("movies", "home"),
          path="%s?info=discover&tmdb_type=movie&with_genres=27" % _TMDBH),
    _coll("herbie", "Herbie the Love Bug", "ERIC'S CLASSICS - THE FILMS",
          ("movies",),
          titles=["The Love Bug", "Herbie Rides Again",
                  "Herbie Goes to Monte Carlo", "Herbie Goes Bananas",
                  "Herbie: Fully Loaded"]),
    _coll("classics-openers", "The Classics - His Openers",
          "THE SHELF HE NAMED FIRST", ("toonime", "home"),
          titles=["Animaniacs", "Tiny Toon Adventures", "Little Bear",
                  "Franklin", "Blue's Clues", "The Berenstain Bears",
                  "Pippi Longstocking", "Freakazoid!"]),
    _coll("classics-wb", "Classics - WB", "ERIC'S CLASSICS SHELF",
          ("toonime",),
          titles=["Freakazoid!", "Pinky and the Brain", "Histeria!",
                  "Taz-Mania", "The Sylvester & Tweety Mysteries",
                  "Baby Looney Tunes", "Looney Tunes", "Animaniacs",
                  "Tiny Toon Adventures"]),
    _coll("classics-nick", "Classics - Nickelodeon",
          "ERIC'S CLASSICS SHELF", ("toonime",),
          titles=["Rugrats", "Doug", "Hey Arnold!", "The Wild Thornberrys",
                  "As Told by Ginger", "Rocket Power",
                  "Rocko's Modern Life", "Blue's Clues"]),
    _coll("classics-gentle", "Classics - Gentle & PBS",
          "ERIC'S CLASSICS SHELF", ("toonime",),
          titles=["Little Bear", "Franklin", "Oswald", "Maisy",
                  "Max & Ruby", "Dragon Tales",
                  "Clifford the Big Red Dog", "Arthur", "Zoboomafoo",
                  "Madeline", "Thomas the Tank Engine", "Little Bill",
                  "Maggie and the Ferocious Beast",
                  "The Busy World of Richard Scarry",
                  "Sagwa the Chinese Siamese Cat", "Caillou",
                  "Between the Lions", "Timothy Goes to School",
                  "Corduroy", "George Shrinks", "Seven Little Monsters",
                  "Miss Spider's Sunny Patch Friends",
                  "Gullah Gullah Island", "Eureeka's Castle"]),
    _coll("classics-playhouse", "Classics - Playhouse Disney",
          "ERIC'S CLASSICS SHELF", ("toonime",),
          titles=["Bear in the Big Blue House", "PB&J Otter",
                  "Rolie Polie Olie", "Out of the Box", "The Book of Pooh",
                  "Stanley", "JoJo's Circus", "The Big Comfy Couch",
                  "It's a Big Big World"]),
    _coll("classics-disney", "Classics - Disney Afternoon",
          "ERIC'S CLASSICS SHELF", ("toonime",),
          titles=["DuckTales", "Chip 'n Dale Rescue Rangers",
                  "Darkwing Duck", "TaleSpin",
                  "The Wacky Adventures of Ronald McDonald"]),
    # Spread ruling (Eric, 2026-10-31 14:38 — Loop 30): the spooky
    # pair stays IN this shelf, but never adjacent — Goosebumps was
    # swapped with Hey Dude so Are You Afraid of the Dark? and
    # Goosebumps sit 3 non-spooky titles apart, not back-to-back.
    _coll("classics-liveaction", "Classics - Live Action",
          "ERIC'S CLASSICS SHELF", ("toonime", "tv"),
          titles=["Power Rangers", "Big Bad Beetleborgs", "Animorphs",
                  "The Secret World of Alex Mack", "Land of the Lost",
                  "Are You Afraid of the Dark?", "Hey Dude",
                  "The Adventures of Pete & Pete", "Salute Your Shorts",
                  "Goosebumps", "Fraggle Rock", "The Muppet Show",
                  "Reading Rainbow"]),
    # classics-faith REMOVED 2026-11-09 (Toonime fix, Eric's
    # category cut: anything Christian or religious based is out,
    # and Donut Man / McGee and Me! / Colby's Clubhouse were ruled
    # not-his the same morning). The collection, its
    # COLLECTION_ORDER entry and its KidsWall allowlist entry are
    # all gone; those titles appear nowhere in COLLECTIONS.
    _coll("classics-christmas", "Classics - Christmas Canon",
          "ERIC'S CLASSICS SHELF", ("toonime", "tv", "home"),
          titles=["Rudolph the Red-Nosed Reindeer", "Frosty the Snowman",
                  "The Little Drummer Boy", "Santa Claus Is Comin' to Town",
                  "The Year Without a Santa Claus",
                  "A Charlie Brown Christmas",
                  "It's the Great Pumpkin, Charlie Brown"]),
    _coll("classics-anchors", "Saturday-Morning Anchors",
          "POKÉMON - DIGIMON - YU-GI-OH!", ("toonime",),
          titles=["Pokémon", "Digimon", "Yu-Gi-Oh!"]),
    # MCU: Story Order (Eric, 2026-11-17): the whole saga in
    # in-universe story order — every movie, plus the series that
    # are load-bearing for the films (his named class: WandaVision,
    # Loki, The Falcon and the Winter Soldier, Hawkeye, Ms. Marvel,
    # Daredevil). Sequence follows Marvel's official Disney+
    # timeline row; every member's TMDB id was verified against
    # its own record workspace-side (lane record:
    # kodi-build/mcu-story-order-20261117/ORDER.md). E-Roc's
    # profile ONLY — the profiles gate below keeps the tile and
    # the route off Nue, Jama and August entirely.
    _coll("mcu-story-order", "MCU: Story Order",
          "THE WHOLE SAGA IN STORY ORDER - 38 MOVIES + 16 SHOWS",
          ("movies",), profiles=("E-Roc",),
          members=[
              _m("Captain America: The First Avenger", 1771, "movie", 2011),
              _m("Captain Marvel", 299537, "movie", 2019),
              _m("Iron Man", 1726, "movie", 2008),
              _m("Iron Man 2", 10138, "movie", 2010),
              _m("The Incredible Hulk", 1724, "movie", 2008),
              _m("Thor", 10195, "movie", 2011),
              _m("The Avengers", 24428, "movie", 2012),
              _m("Thor: The Dark World", 76338, "movie", 2013),
              _m("Iron Man 3", 68721, "movie", 2013),
              _m("Captain America: The Winter Soldier", 100402, "movie", 2014),
              _m("Guardians of the Galaxy", 118340, "movie", 2014),
              _m("Guardians of the Galaxy Vol. 2", 283995, "movie", 2017),
              _m("Daredevil: Season 1", 61889, "tv", 2015, season=1),
              _m("Avengers: Age of Ultron", 99861, "movie", 2015),
              _m("Ant-Man", 102899, "movie", 2015),
              _m("Daredevil: Season 2", 61889, "tv", 2015, season=2),
              _m("The Defenders", 62285, "tv", 2017),
              _m("Captain America: Civil War", 271110, "movie", 2016),
              _m("Black Widow", 497698, "movie", 2021),
              _m("Black Panther", 284054, "movie", 2018),
              _m("Spider-Man: Homecoming", 315635, "movie", 2017),
              _m("Doctor Strange", 284052, "movie", 2016),
              _m("Daredevil: Season 3", 61889, "tv", 2015, season=3),
              _m("Thor: Ragnarok", 284053, "movie", 2017),
              _m("Ant-Man and the Wasp", 363088, "movie", 2018),
              _m("Avengers: Infinity War", 299536, "movie", 2018),
              _m("Avengers: Endgame", 299534, "movie", 2019),
              _m("Loki: Season 1", 84958, "tv", 2021, season=1),
              _m("What If...?: Season 1", 91363, "tv", 2021, season=1),
              _m("WandaVision", 85271, "tv", 2021),
              _m("Shang-Chi and the Legend of the Ten Rings", 566525, "movie", 2021),
              _m("The Falcon and the Winter Soldier", 88396, "tv", 2021),
              _m("Spider-Man: Far From Home", 429617, "movie", 2019),
              _m("Eternals", 524434, "movie", 2021),
              _m("Spider-Man: No Way Home", 634649, "movie", 2021),
              _m("Doctor Strange in the Multiverse of Madness", 453395, "movie", 2022),
              _m("Hawkeye", 88329, "tv", 2021),
              _m("Black Panther: Wakanda Forever", 505642, "movie", 2022),
              _m("Ms. Marvel", 92782, "tv", 2022),
              _m("Thor: Love and Thunder", 616037, "movie", 2022),
              _m("Ant-Man and the Wasp: Quantumania", 640146, "movie", 2023),
              _m("Guardians of the Galaxy Vol. 3", 447365, "movie", 2023),
              _m("The Marvels", 609681, "movie", 2023),
              _m("Loki: Season 2", 84958, "tv", 2021, season=2),
              _m("What If...?: Season 2", 91363, "tv", 2021, season=2),
              _m("Deadpool & Wolverine", 533535, "movie", 2024),
              _m("Agatha All Along", 138501, "tv", 2024),
              _m("What If...?: Season 3", 91363, "tv", 2021, season=3),
              _m("Daredevil: Born Again: Season 1", 202555, "tv", 2025, season=1),
              _m("Captain America: Brave New World", 822119, "movie", 2025, note="Eric's place: 73% watched on Disney+ (Nov 17)"),
              _m("Thunderbolts*", 986056, "movie", 2025),
              _m("The Fantastic Four: First Steps", 617126, "movie", 2025),
              _m("Daredevil: Born Again: Season 2", 202555, "tv", 2025, season=2),
              _m("Spider-Man: Brand New Day", 969681, "movie", 2026),
          ]),
]

# The home stage shows a bit of everything he named; categories show
# their own fits in this order. Sports and Music have no collection
# he named, so their stage keeps the home set (the zone still swaps
# its Continue Watching row per category).
COLLECTION_ORDER = {
    "home": ["power-universe", "pokemon-universe",
             "classics-openers", "harry-potter", "horror",
             "that-70s-universe", "dragon-ball-universe",
             "lord-of-the-rings", "classics-wb", "digimon-universe",
             "classics-christmas"],
    "movies": ["mcu-story-order", "harry-potter", "lord-of-the-rings",
               "horror", "herbie",
               "pokemon-universe", "dragon-ball-universe",
               "digimon-universe"],
    "tv": ["power-universe", "that-70s-universe", "pokemon-universe",
           "digimon-universe", "dragon-ball-universe",
           "classics-liveaction", "classics-christmas"],
    "toonime": ["classics-openers", "classics-wb", "classics-nick",
                "classics-gentle", "classics-playhouse",
                "classics-disney", "classics-liveaction",
                "classics-christmas",
                "classics-anchors", "pokemon-universe",
                "digimon-universe", "dragon-ball-universe"],
}

# Eric's kid-wall law (2026-10-31, the allowlist flip — Loop 23):
# under KidsWall the stage rows are an ALLOWLIST, not a blocklist.
# Only the collections below may surface on a kid-walled profile, on
# any stage category: the parent-named keeps (Lord of the Rings,
# Dragon Ball — Eric ruled both STAY; Harry Potter — kept OUT by the
# morning flip, ruled back IN by Eric 2026-10-31 14:37: "you can
# leave Harry Potter in there that's fine" — Loop 29), the kids' own
# universe shelves (Pokémon, Digimon), the Herbie films, and the
# Classics shelves he dictated. Everything else — Power Universe,
# That '70s Show, Horror, and every wrestling era — never reaches
# the row.
# This subsumes Loop 16's wrestling-cats gate: the eras are out
# because they are not on this list, not because of their cats.
KID_COLLECTION_ALLOWLIST = frozenset([
    "pokemon-universe", "digimon-universe", "dragon-ball-universe",
    "lord-of-the-rings", "harry-potter", "herbie",
    "classics-openers", "classics-wb", "classics-nick",
    "classics-gentle", "classics-playhouse", "classics-disney",
    "classics-liveaction", "classics-christmas",
    "classics-anchors",
])

# G1 explicit banned-id guard (2026-11-04, profile-apps Hand D;
# AUGUST-GATES-AUDIT.md §2 GAP G1 + §5 item 1): Eric's out-list for
# August's rows — horror / Power Universe / That '70s Show OUT,
# Harry Potter IN (his explicit calls, MEMORY.md). These 3 ids are
# dropped BY ID under KidsWall, in addition to the allowlist above.
# By id, never by category: horror's cats are ("movies", "home"),
# the same as the harry-potter keeper's, so a category drop would
# kill a keeper. The explicit banned check runs FIRST in
# collections_for(), so it still wins if a future edit ever
# re-admits one of these ids to KID_COLLECTION_ALLOWLIST.
KIDSWALL_BANNED_COLLECTIONS = frozenset([
    "power-universe", "horror", "that-70s-universe",
])

_COLLECTIONS_BY_ID = {c["id"]: c for c in COLLECTIONS}


def _kidswall_active():
    """True when rocprofiles has published the KidsWall property on
    the home window (closed_allowlist profile, e.g. August). This is
    the same property the skin's dock/stage gates already read
    (Window(10000).Property(RocProfiles.KidsWall)). Outside Kodi
    (xbmcgui absent) it reads False, so unit tests see the ungated
    list — the gate only ever engages on a real kid-walled login."""
    if xbmcgui is None:
        return False
    try:
        return (xbmcgui.Window(HOME_WINDOW_ID).getProperty(
            "RocProfiles.KidsWall") == "true")
    except Exception:
        return False


def _animeonly_active():
    """True when rocprofiles has published the AnimeOnly property
    on the home window (anime_only profile, Jama). The exact
    mirror of _kidswall_active: same window property channel the
    skin's gates read (Window(10000).Property(
    RocProfiles.AnimeOnly)). Outside Kodi it reads False, so
    unit tests see the open feed."""
    if xbmcgui is None:
        return False
    try:
        return (xbmcgui.Window(HOME_WINDOW_ID).getProperty(
            "RocProfiles.AnimeOnly") == "true")
    except Exception:
        return False


def _current_profile_name():
    """Active Kodi profile name ('' when unreadable). Same seam
    _rocsync_store uses — System.ProfileName, whose house values
    are E-Roc / Nue / Jama / August."""
    if xbmc is None:
        return ""
    try:
        return xbmc.getInfoLabel("System.ProfileName") or ""
    except Exception:
        return ""


def _collection_profile_ok(c):
    """Profile gate for collections that declare `profiles`
    (MCU lane 2026-11-17: MCU: Story Order is E-Roc's alone).
    A collection with no `profiles` is ungated, exactly as
    before. When a gate IS declared, an unreadable profile name
    closes it — the shelf is his, so a name that cannot be read
    cannot be his. Mirrors the KidsWall seams in collections_for
    and collection_detail: the tile never renders and the direct
    route returns the unknown-id behaviour ([])."""
    profs = c.get("profiles")
    if not profs:
        return True
    return _current_profile_name() in profs


def collections_for(cat):
    """Ordered collection tiles for one stage category. Each tile is
    {label, sub, plot, path, art}: direct-path tiles point at the real
    destination (his Trakt list / TMDB discover); detail tiles point
    back into script.rocui at ?mode=collection&id=<id>. art carries
    the tile's poster/thumb (see collection_art).

    Category gate (2026-10-31, Loop 15's named leak; allowlist flip
    Loop 23): the home stage row rode COLLECTION_ORDER["home"]
    straight through, so August's whitelist-only wall showed the
    wrestling "Attitude Era" tile (WrestleMania X-Seven poster) even
    though KidsWall hides the wrestling/sports dock stops and stage
    groups. Loop 16 dropped wrestling-catted collections under
    KidsWall; Eric's standing law is stricter — kid-walled rows are
    kid collections ONLY. So under KidsWall this is now an ALLOWLIST
    (KID_COLLECTION_ALLOWLIST): a collection surfaces only if Eric
    named it for kids or as a parent-named keep. Horror, Power
    Universe and That '70s Show are out by his name; Lord of the
    Rings and Dragon Ball stay by his name, and Harry Potter is a
    parent-named keep since his 2026-10-31 14:37 ruling (Loop 29).

    G1 addendum (2026-11-04, AUGUST-GATES-AUDIT GAP G1): the 3 ids
    in KIDSWALL_BANNED_COLLECTIONS (power-universe, horror,
    that-70s-universe) are dropped by explicit id ahead of the
    allowlist check, so Eric's named out-list holds even if the
    allowlist is edited later. Wall-down behaviour is unchanged:
    both KidsWall checks are skipped entirely when the wall is off."""
    ids = COLLECTION_ORDER.get(cat) or COLLECTION_ORDER["home"]
    kidswall = _kidswall_active()
    out = []
    for cid in ids:
        c = _COLLECTIONS_BY_ID.get(cid)
        if not c:
            continue
        if kidswall and cid in KIDSWALL_BANNED_COLLECTIONS:
            # G1 (2026-11-04): Eric's named out-list, dropped by id
            # regardless of allowlist membership — see the constant.
            continue
        if kidswall and cid not in KID_COLLECTION_ALLOWLIST:
            continue
        if not _collection_profile_ok(c):
            # Profile gate (MCU lane 2026-11-17): a profile-scoped
            # collection's tile never renders off its profile.
            continue
        if not (c.get("path") or c.get("titles") or c.get("years")
                or c.get("members")):
            # No content source at all: a Trakt collection on a build
            # with no Trakt user configured. The shelf is absent, not
            # a dead tile (collection_detail returns [] for it if a
            # stale route reaches it directly).
            continue
        if c.get("path"):
            path = c["path"]
            plot = c["sub"].title()
        elif c.get("titles"):
            path = "plugin://script.rocui/?mode=collection&id=%s" % cid
            plot = ", ".join(c["titles"])
        elif c.get("members"):
            path = "plugin://script.rocui/?mode=collection&id=%s" % cid
            plot = ", ".join(m["label"] for m in c["members"])
        else:
            path = "plugin://script.rocui/?mode=collection&id=%s" % cid
            plot = "Every %s pay-per-view in date order." % c["label"]
        out.append({"label": c["label"], "sub": c["sub"], "plot": plot,
                    "path": path, "art": collection_art(cid)})
    return out


# ---- collection tile art -------------------------------------------------
# The stage rows render ListItem.Art(poster) and ListItem.Art(thumb);
# a tile carrying only the badge as its icon paints nothing (the 0.5.0
# defect, found in the code 2026-10-30). Each collection is fronted by
# the TMDB poster of a representative title, resolved through the same
# TMDB mini-client the panel uses (tmdb_get, key read from TMDb
# Helper's files — nothing baked in) and cached in the addon profile
# data, so the lookup runs once per collection rather than once per
# directory build. Only hits are cached: a miss retries next build.

_TMDB_IMG_W500 = "https://image.tmdb.org/t/p/w500"
_TMDB_IMG_W1280 = "https://image.tmdb.org/t/p/w1280"
COLLECTION_ART_FILE = "collection_art.json"
_ART_CACHE_MEM = [None]

# Representative title (+ TMDB kind) for the collections that name no
# titles of their own: the franchise head for the Trakt-list
# universes, the 1978 original for the horror lane.
_COLLECTION_REPS = {
    "power-universe": ("Power", "tv"),
    "that-70s-universe": ("That '70s Show", "tv"),
    "pokemon-universe": ("Pokémon", "tv"),
    "digimon-universe": ("Digimon", "tv"),
    "dragon-ball-universe": ("Dragon Ball Z", "tv"),
    "harry-potter": ("Harry Potter and the Philosopher's Stone",
                     "movie"),
    "lord-of-the-rings": ("The Lord of the Rings: "
                          "The Fellowship of the Ring", "movie"),
    "horror": ("Halloween", "movie"),
    "mcu-story-order": ("Captain America: The First Avenger",
                        "movie"),
}


def _collection_rep(cid):
    """(title, kind-or-None) whose poster fronts this collection."""
    if cid in _COLLECTION_REPS:
        return _COLLECTION_REPS[cid]
    c = _COLLECTIONS_BY_ID.get(cid or "")
    if c and c.get("titles"):
        return (c["titles"][0], None)
    return None


def _tmdb_poster_url(title, kind):
    """First TMDB poster for a title, as a full image URL ('' if
    none). Tries the kind-specific search first, then search/multi."""
    if not title:
        return ""
    query = _urlparse.quote_plus(title)
    endpoints = []
    if kind in ("movie", "tv"):
        endpoints.append("search/%s?query=%s" % (kind, query))
    endpoints.append("search/multi?query=%s" % query)
    for path in endpoints:
        data = tmdb_get(path)
        for row in (data or {}).get("results") or []:
            if row.get("media_type") == "person":
                continue
            if row.get("poster_path"):
                return _TMDB_IMG_W500 + row["poster_path"]
    return ""


def collection_art(cid):
    """{'poster': url, 'thumb': url} for one collection tile — the
    representative title's TMDB poster under both keys (the stage
    layouts read poster and thumb at poster aspect). {} when nothing
    resolves: the tile then keeps only its badge icon, exactly the
    0.5.0 behaviour, and the lookup retries on the next build."""
    if _ART_CACHE_MEM[0] is None:
        _ART_CACHE_MEM[0] = _read_json(COLLECTION_ART_FILE)
    cache = _ART_CACHE_MEM[0]
    if cache.get(cid):
        return dict(cache[cid])
    rep = _collection_rep(cid)
    if not rep:
        return {}
    url = _tmdb_poster_url(rep[0], rep[1])
    if not url:
        return {}
    art = {"poster": url, "thumb": url}
    cache[cid] = art
    _write_json(COLLECTION_ART_FILE, cache)
    return dict(art)


def collection_detail(cid, events=None):
    """Members of one detail collection as row dicts: named titles
    become title posters — {label, sub, path, tmdb_id, tmdb_type,
    art} with path the title's own TMDb Helper details route
    (0.5.7: no search fallback; a title that cannot resolve to a
    TMDB id is OMITTED and retries on the next build, so a poster
    never points at a list). Unknown id -> []."""
    c = _COLLECTIONS_BY_ID.get(cid or "")
    if not c:
        return []
    if _kidswall_active() and cid in KIDSWALL_BANNED_COLLECTIONS:
        # collection_detail seam (2026-11-04, CHECKER-VERDICT item 11):
        # this route had NO KidsWall check at all, so a hand-typed or
        # stale direct route ?mode=collection&id=<banned> under a
        # kid-walled profile returned the banned collection's folder
        # row even though its tile is absent from every row. Same
        # banned-id set as collections_for()'s G1 guard, same fail
        # direction (property unreadable -> wall reads False ->
        # ungated, unchanged). Returning [] is the unknown-id
        # behaviour, so the route renders empty, never the banned
        # collection. Scope is deliberately the banned-id set ONLY:
        # an allowlist-wide closure of this route (e.g. era-attitude
        # direct routes) is a separate decision, NOT taken here.
        return []
    if not _collection_profile_ok(c):
        # Profile gate seam (MCU lane 2026-11-17), same reasoning
        # as the KidsWall banned-id seam above: a stale or
        # hand-typed route to a profile-scoped collection on the
        # wrong profile renders empty, never the shelf.
        return []
    if c.get("path"):
        # Direct-path collections (his Trakt lists, TMDB discover):
        # the stage tile links straight at the destination, but this
        # route must never render an empty directory when reached
        # directly — return one folder row to the real destination.
        # (Round 5, 2026-10-27: this branch missing was the
        # "collections return 0 items x7" defect — every Trakt
        # collection is path-based, so all seven rendered empty.)
        return [{"label": c["label"], "sub": c["sub"], "path": c["path"]}]
    if c.get("members"):
        rows = []
        for m in c["members"]:
            info = _member_tmdb_info(m)
            if not info.get("id"):
                # Same click law as the titles branch: an
                # unresolved member is omitted for this build and
                # retries on the next; a poster never points at a
                # search page.
                continue
            path = ("%s?info=details&tmdb_type=%s&tmdb_id=%s"
                    % (_TMDBH, m["tmdb_type"], info["id"]))
            art = {}
            if info.get("poster"):
                art = {"poster": info["poster"],
                       "thumb": info["poster"]}
                if info.get("fanart"):
                    art["fanart"] = info["fanart"]
            sub = c["label"]
            if m.get("season"):
                sub = "%s - Season %s" % (c["label"], m["season"])
            if m.get("note"):
                sub = "%s - %s" % (sub, m["note"])
            row = {"label": m["label"], "sub": sub, "path": path,
                   "tmdb_id": info["id"],
                   "tmdb_type": m["tmdb_type"], "art": art}
            if m.get("season"):
                row["season"] = m["season"]
            rows.append(row)
        # ZERO-SOURCE SHELF: proven-zero titles come off the
        # shelf; the rest are noted for background re-checking.
        rows = _avail_filter_rows(rows)
        _avail_note_rows(rows)
        return rows
    if c.get("titles"):
        tmdb_type = _coll_tmdb_type(c)
        rows = []
        for t in c["titles"]:
            info = _title_tmdb_info(t, tmdb_type)
            path = _title_details_path(t, tmdb_type, info)
            if not path:
                # 0.5.7 click law: a title poster never points at
                # a search page. An unresolved title is left off
                # the shelf for this build; resolution retries on
                # the next directory build (hits are cached, a
                # miss is not).
                continue
            art = {}
            if info.get("poster"):
                art = {"poster": info["poster"],
                       "thumb": info["poster"]}
                if info.get("fanart"):
                    art["fanart"] = info["fanart"]
            rows.append({"label": t, "sub": c["label"], "path": path,
                         "tmdb_id": info["id"],
                         "tmdb_type": tmdb_type, "art": art})
        # ZERO-SOURCE SHELF: as the members branch above.
        rows = _avail_filter_rows(rows)
        _avail_note_rows(rows)
        return rows
    return []


# ---- movie hub rows, date-gated (0.5.15, Player Fix Lane Hand A) ----
# The Movies hub's COMING SOON / IN THEATERS NOW rows are fed by
# TMDb Helper's basic lists (skin content paths
# plugin://plugin.video.themoviedb.helper/?info=upcoming /
# ?info=now_playing&tmdb_type=movie), which are a verbatim pass-
# through of TMDB's /movie/upcoming and /movie/now_playing
# endpoints (Helper consts TMDB_BASIC_LISTS: path
# '{tmdb_type}/upcoming' / '{tmdb_type}/now_playing', key
# 'results', no filtering; 'upcoming' is even exempted from the
# Helper's unaired-item handling via NO_UNAIRED_CHECK). Those
# TMDB endpoints key on REGIONAL RELEASE EVENTS, not the title's
# primary release date: a classic with a future anniversary /
# Halloween re-release carries a future regional date, so it
# sails into "upcoming" -- and a 1993 title with a current
# re-release window lands in "now_playing" -- even though its
# primary release_date is decades past. Eric's .155 photo,
# 2026-11-05: COMING SOON held Dune: Part Two (2024), Dune
# (2021) and A Beautiful Mind (2001); IN THEATERS NOW held The
# Nightmare Before Christmas (1993). Nothing in the chain ever
# compares the item's own release_date to today.
#
# movie_row_items() is the gate: it pulls the SAME two TMDB
# endpoints through rocui's own TMDB mini-client and keeps only
# titles whose PRIMARY release_date (the release_date field on
# the list item itself) satisfies the row's promise:
#   upcoming    (COMING SOON):      release_date > today
#   now_playing (IN THEATERS NOW):  today-45d <= release_date
#                                   <= today
# Rows come back in collection_detail's row-dict shape so
# timeline.py can serve them with the proven folder-into-detail
# dispatch (build_movie_row). The equivalent pure-feed fix, if
# the skin keeps pointing at the Helper, is a discover route --
# Helper's discover supports primary_release_date.gte/.lte,
# with_release_type and region (its api/tmdb/discover.py param
# lists): COMING SOON =
# discover/movie?region=US&with_release_type=3&
# primary_release_date.gte=<tomorrow>&sort_by=
# primary_release_date.asc ; IN THEATERS NOW = the same with
# primary_release_date.gte=<today-45d>&primary_release_date.lte=
# <today>&sort_by=primary_release_date.desc.
import datetime as _dt

MOVIE_ROW_FEEDS = {"upcoming": "movie/upcoming",
                   "now_playing": "movie/now_playing"}
NOW_PLAYING_WINDOW_DAYS = 45


def _parse_iso_date(text):
    """'YYYY-MM-DD' -> datetime.date, or None. Never raises."""
    try:
        parts = (text or "")[:10].split("-")
        return _dt.date(int(parts[0]), int(parts[1]), int(parts[2]))
    except Exception:
        return None


def movie_row_items(list_name, tmdb_get_fn=None, today=None,
                    kidswall_fn=None):
    """Date-gated rows for one Movies-hub row. list_name is
    'upcoming' (COMING SOON) or 'now_playing' (IN THEATERS NOW);
    anything else -> []. tmdb_get_fn / today are injectable for
    the harness; they default to tmdb_get and the device's local
    date. Undated titles are dropped (an unverifiable date cannot
    satisfy either row's promise). Never raises.

    PM-1 (merge run 2026-11-07, Eric's ruled call): under KidsWall
    (August), titles whose TMDb genre_ids carry Horror (27) are
    dropped at browse level -- batch 2 proved his playback gate
    stops horror at PLAY, but the row itself still surfaced the
    IT / "A Story of Derry" poster in his IN THEATERS NOW row.
    kidswall_fn is injectable for the harness, same pattern as
    tmdb_get_fn; it defaults to _kidswall_active, which reads
    False outside Kodi, so file-side suites see the ungated row.

    Browse cap (2026-11-09, Eric's 21:24 ruling -- "Cap them. He
    doesn't need any wrestling."): the launch sweep proved the
    date gate alone still surfaced adult titles on August's
    Movies hub (Verity, La Bola Negra in IN THEATERS NOW), so
    under KidsWall each candidate must ALSO clear the Job 3 wall
    before a row exists: (1) the wrestling title exclusion
    (_is_wrestling_title -- rating cannot identify wrestling;
    WWE Raw can carry TV-PG), and (2) the Job 3 certification
    join -- _search_certification("movie", id, get) must land in
    SEARCH_ALLOWED_RATINGS, the SAME constant the search route
    uses, never a copy; over-line, unrated ('') and unverifiable
    (None) are all hidden, default-deny. PM-1's horror drop
    above stays as-is (Eric's 2026-11-07 ruling; the cert wall
    only adds). The NEW wall's gate read fails WALLED on error
    (Job 3 semantics -- wall_cert below), while PM-1's legacy
    read keeps its ungated-on-error direction; date gating,
    sorting and row shape are untouched either way, and with
    the wall off no certification call is ever made."""
    feed = MOVIE_ROW_FEEDS.get(list_name or "")
    if not feed:
        return []
    get = tmdb_get_fn or tmdb_get
    if today is None:
        today = _dt.date.today()
    kw = _kidswall_active if kidswall_fn is None else kidswall_fn
    try:
        wall_on = bool(kw())
        _gate_err = False
    except Exception:
        wall_on = False
        _gate_err = True
    # The browse-cap wall (certification + wrestling) reads
    # WALLED when the gate itself errors -- Job 3 semantics.
    # PM-1's horror drop keeps wall_on's legacy direction above.
    wall_cert = True if _gate_err else wall_on
    # PAGINATION (2026-11-16, Eric's In Theaters / Coming Soon
    # exclusivity ruling): the date gate drops most of page 1 of
    # TMDB's regional lists (re-release events whose PRIMARY date
    # fails the row's promise) - page-1-only fetching is what
    # rendered COMING SOON empty in the 2026-11-12 walkthrough and
    # got the row repointed at trending_week. Fetch up to 5 pages
    # (deduped by id) so the gate has enough candidates; the gate
    # itself - upcoming strictly future, now_playing inside the
    # 45-day window - is unchanged, so the two rows stay mutually
    # exclusive by construction.
    results_all = []
    _seen_ids = set()
    for _page in range(1, 6):
        try:
            _data = get(feed if _page == 1 else
                        "%s?page=%d" % (feed, _page)) or {}
        except Exception as exc:
            log("movie_row_items: %s fetch failed: %s" % (feed, exc))
            return []
        _batch = _data.get("results") or []
        for _it in _batch:
            _iid = _it.get("id") if isinstance(_it, dict) else None
            if _iid is not None and _iid in _seen_ids:
                continue
            if _iid is not None:
                _seen_ids.add(_iid)
            results_all.append(_it)
        if not _batch:
            break
        try:
            if _page >= int(_data.get("total_pages") or 1):
                break
        except Exception:
            break
    rows = []
    for item in results_all:
        if not isinstance(item, dict) or not item.get("id"):
            continue
        rel = _parse_iso_date(item.get("release_date") or "")
        if rel is None:
            continue
        if list_name == "upcoming":
            if rel <= today:
                continue
        else:  # now_playing
            if rel > today or (today - rel).days > \
                    NOW_PLAYING_WINDOW_DAYS:
                continue
        if wall_on:
            # PM-1: TMDb genre 27 is Horror. Kid-walled profiles
            # never see a horror poster at browse level. The
            # isinstance guard is checker #4's hardening: a
            # malformed genre_ids (bare string/int) must fail open
            # on that one title, never raise out of the row build.
            gids = item.get("genre_ids")
            if isinstance(gids, (list, tuple)) and 27 in gids:
                continue
        if wall_cert:
            # Browse cap (see the docstring): wrestling out by
            # title, then the Job 3 certification join -- keep
            # only the allowed set. Both drops happen here,
            # after the date gate and before the row is built,
            # so a capped title never becomes a row at all.
            _btitle = item.get("title") or item.get("name") or ""
            if _is_wrestling_title(_btitle):
                continue
            if _search_certification(
                    "movie", str(item["id"]), get) \
                    not in SEARCH_ALLOWED_RATINGS:
                continue
        title = item.get("title") or item.get("name") or ""
        if not title:
            continue
        art = {}
        if item.get("poster_path"):
            art = {"poster": _TMDB_IMG_W500 + item["poster_path"],
                   "thumb": _TMDB_IMG_W500 + item["poster_path"]}
            if item.get("backdrop_path"):
                art["fanart"] = (_TMDB_IMG_W500
                                 + item["backdrop_path"])
        rows.append({"label": title,
                     "sub": "%s - %s" % (
                         "COMING SOON" if list_name == "upcoming"
                         else "IN THEATERS NOW",
                         item.get("release_date") or ""),
                     "path": _title_details_path(
                         title, "movie",
                         {"id": str(item["id"]),
                          "poster": art.get("poster", ""),
                          "fanart": art.get("fanart", "")}),
                     "tmdb_id": str(item["id"]),
                     "tmdb_type": "movie",
                     "release_date": item.get("release_date") or "",
                     "art": art})
    if list_name == "upcoming":
        rows.sort(key=lambda r: r["release_date"])
    else:
        rows.sort(key=lambda r: r["release_date"], reverse=True)
    # ZERO-SOURCE SHELF: proven-zero titles come off the row;
    # the rest are noted for background re-checking.
    rows = _avail_filter_rows(rows)
    _avail_note_rows(rows)
    return rows


# ---- Toonime shelves (2026-11-09, the Toonime fix) ------------
# Hub 1122's rows are served by OUR code over a sealed catalog:
# resources/data/toonime_shelves.json, generated workspace-side
# from AUDIT-MASTER.json ONLY (270 of 287 in play; every
# removed_by_eric title held out -- the Christian/religious
# category cut, the 5 unrated titles, Waynehead, and the not-his
# Donut Man / McGee and Me! / Colby's Clubhouse / Shnookums &
# Meat). The JSON carries NAMED PER-STATION LISTS (Nickelodeon,
# Disney, Cartoon Network, Kids' WB, WB, PBS/Gentle, Playhouse
# Disney, Live-action, Christmas, Anchors, Anime-US, Anime, and
# the era's Fox Kids & Syndication block -- each station its own
# list, never bundled) and the 3 shelves as ordered unions:
# toons (western TV), anime (Anchors + Anime-US first, then the
# broader Anime canon -- Eric's 2026-11-09 merge ruling), and
# anime-movies (the seed's 9 movie-type titles; AUDIT-MASTER
# holds zero anime films, so no title is invented to fill it).
# plugin.video.watchnixtoons2 is no longer load-bearing anywhere
# in this room.
#
# Kid flag rule (mechanical, baked at generation): kid=true iff
# applied_rating in {TV-Y, TV-Y7, TV-Y7-FV, TV-G, G}; the 5 TV-PG
# titles are kid=false. Under KidsWall only kid-flagged titles
# surface. Fail-safe direction: an unknown shelf id returns [],
# and a KidsWall gate that errors reads as walled (kid-only),
# never as the unfiltered set.

TOONIME_SHELVES_FILE = "toonime_shelves.json"
TOONIME_ART_FILE = "toonime_art.json"
_TOONIME_DATA_MEM = [None]
_TOONIME_ART_MEM = [None]


def _toonime_shelves_data():
    """The shipped shelf data (module-relative resource, like the
    Roc Play player file). {} when the file is missing or
    unparseable -- every shelf then reads empty, never stale."""
    if _TOONIME_DATA_MEM[0] is not None:
        return _TOONIME_DATA_MEM[0]
    data = {}
    try:
        path = os.path.join(os.path.dirname(
            os.path.abspath(__file__)), "resources", "data",
            TOONIME_SHELVES_FILE)
        with open(path, "r", encoding="utf-8") as fh:
            loaded = json.load(fh)
        if isinstance(loaded, dict):
            data = loaded
    except Exception as exc:
        log("toonime shelves load failed: %s" % exc)
    _TOONIME_DATA_MEM[0] = data
    return data


def _toonime_art(tmdb_type, tmdb_id, get):
    """{'poster','thumb','fanart'} for one shelved title from its
    OWN TMDB record (receipted id -- no search), cached in the
    addon profile data. A record with no poster of its own
    (Phantom Investigators) caches {} and renders the badge
    fallback -- honest absence, never a placeholder or an
    unrelated image. A failed fetch (get -> None) is NOT cached,
    so it retries on the next build."""
    key = "%s|%s" % (tmdb_type, tmdb_id)
    if _TOONIME_ART_MEM[0] is None:
        _TOONIME_ART_MEM[0] = _read_json(TOONIME_ART_FILE)
    cache = _TOONIME_ART_MEM[0]
    if key in cache:
        return dict(cache[key])
    try:
        rec = get("%s/%s" % (tmdb_type, tmdb_id)) or None
    except Exception:
        rec = None
    if rec is None:
        return {}
    art = {}
    if rec.get("poster_path"):
        art = {"poster": _TMDB_IMG_W500 + rec["poster_path"],
               "thumb": _TMDB_IMG_W500 + rec["poster_path"]}
        if rec.get("backdrop_path"):
            art["fanart"] = _TMDB_IMG_W500 + rec["backdrop_path"]
    cache[key] = art
    try:
        _write_json(TOONIME_ART_FILE, cache)
    except Exception:
        pass
    return dict(art)


def toonime_shelf_items(shelf_id, kidswall_fn=None, tmdb_get_fn=None):
    """Rows for one Toonime shelf ('toons' | 'anime' |
    'anime-movies') in collection_detail's row shape: {label,
    sub (station name), path, tmdb_id, tmdb_type, year, kid,
    station, art}. Unknown shelf -> []. Under KidsWall only
    kid-flagged rows return. kidswall_fn / tmdb_get_fn are
    injectable for the offline harness; they default to
    _kidswall_active and tmdb_get. Never raises."""
    shelves = (_toonime_shelves_data().get("shelves") or {})
    entries = shelves.get(shelf_id or "")
    if entries is None:
        return []
    kw = _kidswall_active if kidswall_fn is None else kidswall_fn
    try:
        wall_on = bool(kw())
    except Exception:
        # Fail-safe: an unreadable gate filters to kid titles,
        # never the unfiltered set.
        wall_on = True
    get = tmdb_get_fn or tmdb_get
    rows = []
    for e in entries:
        if not isinstance(e, dict) or not e.get("tmdb_id"):
            continue
        if wall_on and not e.get("kid"):
            continue
        tmdb_id = str(e["tmdb_id"])
        tmdb_type = e.get("tmdb_type") or ""
        art = _toonime_art(tmdb_type, tmdb_id, get)
        rows.append({
            "label": e.get("title") or "",
            "sub": e.get("station_label") or "",
            "path": _title_details_path(
                e.get("title") or "", tmdb_type,
                {"id": tmdb_id}),
            "tmdb_id": tmdb_id,
            "tmdb_type": tmdb_type,
            "year": e.get("year"),
            "kid": bool(e.get("kid")),
            "station": e.get("station") or "",
            "art": art})
    # ZERO-SOURCE SHELF: proven-zero titles come off the shelf;
    # the rest are noted for background re-checking.
    rows = _avail_filter_rows(rows)
    _avail_note_rows(rows)
    return rows


# ---- Wrestling title exclusion (2026-11-09, browse cap) ---------
# Eric's ruling (2026-11-09 21:24): no wrestling on August's
# profile anywhere -- and wrestling must NOT rely on rating,
# because WWE Raw can carry TV-PG, inside the allowed set. TMDB
# genre cannot identify wrestling either (WWE Raw is
# Talk/Reality-shaped data), so the exclusion is title-based: a
# whole-word token set plus a phrase set, matched
# case-insensitively over the title normalized to alphanumeric
# words. Whole-word matching is the safety property: "Rawhide"
# tokenizes to the single word "rawhide", never to "raw", so
# legit titles survive. Applied under the wall in BOTH browse
# row builders (movie_row_items and tv_row_items below) and,
# since 2026-11-10 (Eric's 03:18 ruling), in search_items too.

WRESTLING_TITLE_TOKENS = frozenset([
    "wwe", "raw", "smackdown", "nxt", "aew", "tna", "njpw",
    "roh",
])
WRESTLING_TITLE_PHRASES = (
    "wrestlemania", "wrestling", "royal rumble", "summerslam",
    "survivor series", "money in the bank",
    "all elite wrestling", "aew dynamite", "aew collision",
    "aew rampage",
)


def _is_wrestling_title(title):
    """True when a title reads as wrestling under the token /
    phrase sets above. Tokens match as whole words; phrases
    match on the normalized title (non-alphanumerics folded to
    single spaces, word-boundary padded). Never raises: any
    surprise reads as not-wrestling, so one malformed title can
    never take a whole row build down with it."""
    try:
        text = (title or "").lower()
        if not text.strip():
            return False
        words = re.sub(r"[^a-z0-9]+", " ", text).split()
        if not words:
            return False
        wordset = set(words)
        for tok in WRESTLING_TITLE_TOKENS:
            if tok in wordset:
                return True
        joined = " " + " ".join(words) + " "
        for phrase in WRESTLING_TITLE_PHRASES:
            pnorm = " " + " ".join(
                re.sub(r"[^a-z0-9]+", " ",
                       phrase.lower()).split()) + " "
            if pnorm in joined:
                return True
        return False
    except Exception:
        return False


# ---- August search filter (2026-11-09, Job 3) ---------------------
# Eric's ruling (2026-11-09 11:14 + 11:52): on August's profile
# ONLY, search never SHOWS an over-line title -- not in results,
# not as a typing suggestion. The line follows the shelf, ceiling
# TV-PG: SEARCH_ALLOWED_RATINGS below; anything above it (PG-13,
# TV-14, TV-MA, R, NC-17) never renders, and UNRATED or
# unverifiable = HIDDEN (default-deny: on any error the fail
# direction is the walled one). Jama has NO cap (her profile never
# sets KidsWall, so her doors never route here) and grown-ups are
# untouched (their doors keep the TMDb Helper dir_search path,
# byte-identical in the skin).
#
# The intercept is a conditional path swap in the skin (Home 940,
# hub 1111 751, hub 1112 751): under KidsWall the door opens
# ?mode=search here instead of the Helper. The Helper's rendered
# items cannot be filtered -- a TMDB search payload carries NO
# certification field, and the Helper's mapper fills MPAA only
# from detail fields a search payload never contains -- so the
# rating is joined per result id through this build's own TMDB
# mini-client: tmdb_get("{movie|tv}/{id}?append_to_response=
# release_dates,content_ratings") -> _detail_mpaa() -> the US
# certification, cached in the addon profile data exactly like
# title_info.json (hits AND confirmed-unrated results cache; a
# failed fetch does NOT cache, so the title retries next search
# -- and stays hidden while unfetched). AUDIT-MASTER.json is NOT
# the join: it covers only the 287 cartoon-shelf titles, so
# joining it would hide nearly the whole movie/TV catalog.
#
# Wrestling extension (2026-11-10, Eric's 03:18 ruling -- "Go
# ahead on the trending row and wrestling block."): the browse
# cap dropped wrestling by title, but this route capped by
# rating only, so a TV-PG wrestling title (WWE Raw) could still
# surface here. search_items now applies the SAME
# _is_wrestling_title() matcher the browse rows use, per
# candidate and BEFORE the certification fetch -- a wrestling
# candidate's cert is never even fetched, and the candidate
# counts as filtered exactly like a cert drop (it consumes
# fetch pages, never quota).
#
# Filtering happens BEFORE any item becomes a ListItem: an
# over-line or unrated candidate never enters the returned rows,
# so it can never render. This directory IS the kid search by
# construction -- it is only ever routed to under KidsWall, and
# the filter applies whenever it is invoked (a hand-typed
# ?mode=search URL on any profile serves the same filtered
# directory; the gate read below exists so a gate ERROR is
# treated as walled, the toonime wrapper semantics, never as a
# reason to serve anything unfiltered). Never raises.

SEARCH_ALLOWED_RATINGS = frozenset([
    "TV-Y", "TV-Y7", "TV-Y7-FV", "TV-G", "TV-PG", "G", "PG",
])
SEARCH_CERT_FILE = "search_certs.json"
_SEARCH_CERT_MEM = [None]
SEARCH_PAGE_QUOTA = 20
SEARCH_MAX_PAGES = 3


def _search_certification(tmdb_type, tmdb_id, get):
    """US certification for one TMDB id, via the detail join
    (release_dates / content_ratings -> _detail_mpaa, prefix
    stripped). Returns the cert string ('' = the detail record
    came back but carries no US certification: confirmed
    unrated), or None when the fetch itself failed (no record at
    all: unverifiable). Confirmed answers -- hits and
    confirmed-unrated alike -- are cached in search_certs.json
    (the title_info.json pattern); a failed fetch is NOT cached,
    so it retries on the next search. Never raises."""
    if _SEARCH_CERT_MEM[0] is None:
        _SEARCH_CERT_MEM[0] = _read_json(SEARCH_CERT_FILE)
    cache = _SEARCH_CERT_MEM[0]
    key = "%s|%s" % (tmdb_type, tmdb_id)
    if key in cache:
        return cache[key] or ""
    try:
        detail = get("%s/%s?append_to_response=release_dates,"
                     "content_ratings" % (tmdb_type, tmdb_id))
    except Exception:
        detail = None
    if not isinstance(detail, dict):
        return None
    cert = _detail_mpaa(detail, tmdb_type)
    if cert.startswith("Rated "):
        cert = cert[len("Rated "):]
    cache[key] = cert
    try:
        _write_json(SEARCH_CERT_FILE, cache)
    except Exception:
        pass
    return cert


def search_items(query, tmdb_type, page=1, kidswall_fn=None,
                 tmdb_get_fn=None):
    """Filtered TMDB search rows for the August search route, in
    collection_detail's row shape ({label, sub, path, tmdb_id,
    tmdb_type, art} plus rating/year). Returns (rows, has_more,
    next_page): rows are ONLY the candidates whose US
    certification is in SEARCH_ALLOWED_RATINGS and whose title
    is not wrestling (_is_wrestling_title -- rating cannot
    identify wrestling; WWE Raw can carry TV-PG), in original
    search order; wrestling, over-line, unrated and
    cert-fetch-failed candidates are dropped before any row
    exists. Person rows
    are dropped defensively. Pagination is filter-then-paginate:
    TMDB pages are fetched (at most SEARCH_MAX_PAGES per call)
    until SEARCH_PAGE_QUOTA visible rows are filled or the pages
    run out; has_more/next_page then point at the first unfetched
    page, so the next-page row resumes honestly. kidswall_fn /
    tmdb_get_fn are injectable for the offline harness; they
    default to _kidswall_active and tmdb_get. A gate that errors
    reads as WALLED (toonime wrapper semantics). Never raises:
    an empty query, an unknown tmdb_type or a dead API all read
    as ([], False, 0)."""
    if tmdb_type not in ("movie", "tv"):
        return [], False, 0
    query = (query or "").strip()
    if not query:
        return [], False, 0
    try:
        page = int(page)
    except Exception:
        page = 1
    if page < 1:
        page = 1
    kw = _kidswall_active if kidswall_fn is None else kidswall_fn
    try:
        wall_on = bool(kw())
    except Exception:
        # Fail-safe: an unreadable gate reads as walled, never as
        # a licence to serve unfiltered (toonime semantics). The
        # filter below applies on this route regardless -- the
        # route exists only as the walled search -- so a gate
        # error can only ever keep the wall up.
        wall_on = True
    get = tmdb_get_fn or tmdb_get
    rows = []
    resume_page = 0
    try:
        fetched = 0
        cur = page
        total_pages = 1
        while fetched < SEARCH_MAX_PAGES:
            try:
                data = get("search/%s?query=%s&page=%d" % (
                    tmdb_type, _urlparse.quote_plus(query), cur))
            except Exception as exc:
                log("search_items: search fetch failed: %s" % exc)
                data = None
            if not isinstance(data, dict):
                break
            fetched += 1
            try:
                total_pages = int(data.get("total_pages") or 1)
            except Exception:
                total_pages = 1
            if total_pages < 1:
                total_pages = 1
            for item in data.get("results") or []:
                if not isinstance(item, dict):
                    continue
                if item.get("media_type") == "person":
                    continue
                if not item.get("id"):
                    continue
                tmdb_id = str(item["id"])
                _stitle = item.get("title") or item.get("name") \
                    or ""
                if _is_wrestling_title(_stitle):
                    # Wrestling block (2026-11-10, Eric's 03:18
                    # ruling): dropped by title BEFORE the
                    # certification fetch, mirroring the
                    # browse-row builders -- a wrestling
                    # candidate's cert is never even fetched and
                    # it never becomes a row. It counts as a
                    # filtered candidate exactly like a cert drop
                    # below: it consumes fetch pages, not quota.
                    continue
                cert = _search_certification(tmdb_type, tmdb_id,
                                             get)
                if cert not in SEARCH_ALLOWED_RATINGS:
                    # Over the line, unrated (''), or unverifiable
                    # (None): hidden -- default-deny, and the drop
                    # happens here, before the title can become a
                    # ListItem anywhere.
                    continue
                title = item.get("title") or item.get("name") or ""
                if not title:
                    continue
                date = (item.get("release_date")
                        or item.get("first_air_date") or "")
                art = {}
                if item.get("poster_path"):
                    art = {"poster": _TMDB_IMG_W500
                           + item["poster_path"],
                           "thumb": _TMDB_IMG_W500
                           + item["poster_path"]}
                    if item.get("backdrop_path"):
                        art["fanart"] = (_TMDB_IMG_W500
                                         + item["backdrop_path"])
                rows.append({
                    "label": title,
                    "sub": "Rated %s" % cert,
                    "path": _title_details_path(
                        title, tmdb_type, {"id": tmdb_id}),
                    "tmdb_id": tmdb_id,
                    "tmdb_type": tmdb_type,
                    "rating": cert,
                    "year": date[:4],
                    "art": art})
            if len(rows) >= SEARCH_PAGE_QUOTA:
                if cur < total_pages:
                    resume_page = cur + 1
                break
            if cur >= total_pages:
                break
            cur += 1
            if fetched >= SEARCH_MAX_PAGES:
                # Page cap reached with pages still unfetched:
                # the next-page row resumes at the first one.
                resume_page = cur
                break
    except Exception as exc:
        log("search_items failed: %s" % exc)
        return [], False, 0
    return rows, bool(resume_page), resume_page


def spotlight_items(tmdb_get_fn=None, kidswall_fn=None,
                    animeonly_fn=None):
    """Home SPOTLIGHT feed (CW-IN-CATEGORIES lane, 2026-11-17;
    Eric's front-door design, 08:59): up to 10 featured titles
    for the Home hero — TMDB trending/all/day, movies and TV
    only, in TMDB's own order. A candidate MUST carry a
    backdrop: the spotlight is one big piece of art, and a
    title without one cannot be the hero (it may still live in
    the NEW rows below). Row shape is the house row shape
    ({label, sub, path, tmdb_id, tmdb_type, art}), so
    timeline.build_spotlight serves rows exactly like
    build_movie_row, and the sub carries the house badge
    (_usearch_badge: MOVIE / TV SHOW / ANIME) + year.

    Per-profile law, in the route (the F4 pattern — the skin
    binds one content path for every profile):
      * AnimeOnly (Jama): only ANIME-badged candidates; if
        trending yields fewer than 3, the sealed Toonime
        anime shelf backfills so her hero never runs dry.
      * KidsWall: PM-1's horror drop (genre 27) plus the Job 3
        browse-cap wall — wrestling out by title, then the
        certification join against SEARCH_ALLOWED_RATINGS,
        default-deny — the same constants movie_row_items
        uses, never copies. A gate read that errors reads
        WALLED for the cert wall (Job 3 semantics).
    Never raises: a dead feed is an empty spotlight, and Home
    still renders its rows and dock."""
    get = tmdb_get_fn or tmdb_get
    kw = _kidswall_active if kidswall_fn is None else kidswall_fn
    ao = _animeonly_active if animeonly_fn is None else animeonly_fn
    try:
        wall_on = bool(kw())
        _gate_err = False
    except Exception:
        wall_on = False
        _gate_err = True
    wall_cert = True if _gate_err else wall_on
    try:
        anime_only = bool(ao())
    except Exception:
        anime_only = False
    rows = []
    seen = set()
    pages = 3 if (wall_cert or anime_only) else 2
    for page in range(1, pages + 1):
        if len(rows) >= 10:
            break
        try:
            data = get("trending/all/day" if page == 1 else
                       "trending/all/day?page=%d" % page) or {}
        except Exception as exc:
            log("spotlight_items: trending fetch failed: %s" % exc)
            break
        batch = data.get("results") or []
        if not batch:
            break
        for item in batch:
            if len(rows) >= 10:
                break
            if not isinstance(item, dict) or not item.get("id"):
                continue
            media = item.get("media_type") or ""
            if media not in ("movie", "tv"):
                continue
            iid = str(item["id"])
            if (media, iid) in seen:
                continue
            seen.add((media, iid))
            title = item.get("title") or item.get("name") or ""
            if not title:
                continue
            if not item.get("backdrop_path"):
                continue
            if anime_only and _usearch_badge(item) != "ANIME":
                continue
            if wall_on:
                gids = item.get("genre_ids")
                if isinstance(gids, (list, tuple)) and 27 in gids:
                    continue
            if wall_cert:
                if _is_wrestling_title(title):
                    continue
                if _search_certification(media, iid, get) \
                        not in SEARCH_ALLOWED_RATINGS:
                    continue
            if avail_is_zero(media, iid):
                # ZERO-SOURCE SHELF: a proven zero-working title
                # never becomes the hero. Inline (not at return)
                # so the cap still fills from later candidates
                # instead of the spotlight running short.
                continue
            art = {"fanart": _TMDB_IMG_W1280
                   + item["backdrop_path"]}
            if item.get("poster_path"):
                art["poster"] = _TMDB_IMG_W500 + item["poster_path"]
                art["thumb"] = art["poster"]
            date = (item.get("release_date")
                    or item.get("first_air_date") or "")
            rows.append({
                "label": title,
                "sub": "%s%s" % (_usearch_badge(item),
                                 (" - " + date[:4]) if date else ""),
                "path": _title_details_path(
                    title, media,
                    {"id": iid, "poster": art.get("poster", ""),
                     "fanart": art.get("fanart", "")}),
                "tmdb_id": iid,
                "tmdb_type": media,
                "art": art})
    if anime_only and len(rows) < 3:
        try:
            shelf = toonime_shelf_items("anime")
        except Exception:
            shelf = []
        for row in shelf:
            if len(rows) >= 10:
                break
            key = (row.get("tmdb_type") or "",
                   str(row.get("tmdb_id") or ""))
            if not row.get("tmdb_id") or key in seen:
                continue
            seen.add(key)
            rows.append(row)
    # ZERO-SOURCE SHELF: note the served hero titles for
    # background re-checking (the backfill rows were already
    # filtered + noted inside toonime_shelf_items).
    _avail_note_rows(rows[:10])
    return rows[:10]


def _usearch_badge(item):
    """F4 type badge (v1.1 FUSE pack, 2026-11-17): OUR OWN badge
    text for one search/multi row - MOVIE / TV SHOW / ANIME.
    ANIME is our own derivation, not a copied taxonomy: a TV or
    movie row whose TMDB genres include Animation (16) and whose
    original language is Japanese. Anything else keeps its plain
    type badge."""
    media = item.get("media_type") or ""
    genres = item.get("genre_ids") or []
    try:
        anime = 16 in [int(g) for g in genres] \
            and (item.get("original_language") or "") == "ja"
    except Exception:
        anime = False
    if anime:
        return "ANIME"
    return "MOVIE" if media == "movie" else "TV SHOW"


def unified_search_items(query, page=1, kidswall_fn=None,
                         tmdb_get_fn=None):
    """F4 unified search (v1.1 FUSE pack, 2026-11-17): ONE search
    across the catalogs - TMDB search/multi fans out over movies
    and TV in a single call and the rows come back as ONE list in
    TMDB's own relevance order, each row carrying its type badge
    (_usearch_badge: MOVIE / TV SHOW / ANIME, our text) in `badge`
    and in the row's `sub`.

    Per-profile law, intact by construction:
      * KidsWall up (August): the search_items wall applies per
        candidate BEFORE any row exists - US certification must be
        in SEARCH_ALLOWED_RATINGS (unrated and unverifiable are
        hidden, default-deny) and wrestling titles drop by name.
        His ceiling is TV-PG: nothing over the line ever renders.
      * Wall down (Eric / Nue / Jama): open search, no cert gate -
        Jama's search stays open per Eric's 2026-11-16 correction.
        Person rows still drop (they are not playable titles).
    Pagination mirrors search_items: TMDB pages are fetched (at
    most SEARCH_MAX_PAGES per call) until SEARCH_PAGE_QUOTA
    visible rows fill or the pages run out; has_more/next_page
    resume at the first unfetched page. Row shape is
    collection_detail's ({label, sub, path, tmdb_id, tmdb_type,
    art} plus badge/rating/year), so timeline.build_usearch serves
    rows exactly like build_search. kidswall_fn / tmdb_get_fn are
    injectable for the offline harness. A gate that errors reads
    as WALLED (the search_items rule). Never raises."""
    query = (query or "").strip()
    if not query:
        return [], False, 0
    try:
        page = int(page)
    except Exception:
        page = 1
    if page < 1:
        page = 1
    kw = _kidswall_active if kidswall_fn is None else kidswall_fn
    try:
        wall_on = bool(kw())
    except Exception:
        wall_on = True
    get = tmdb_get_fn or tmdb_get
    rows = []
    resume_page = 0
    try:
        fetched = 0
        cur = page
        total_pages = 1
        while fetched < SEARCH_MAX_PAGES:
            try:
                data = get("search/multi?query=%s&page=%d" % (
                    _urlparse.quote_plus(query), cur))
            except Exception as exc:
                log("unified_search_items: fetch failed: %s" % exc)
                data = None
            if not isinstance(data, dict):
                break
            fetched += 1
            try:
                total_pages = int(data.get("total_pages") or 1)
            except Exception:
                total_pages = 1
            if total_pages < 1:
                total_pages = 1
            for item in data.get("results") or []:
                if not isinstance(item, dict):
                    continue
                media = item.get("media_type") or ""
                if media not in ("movie", "tv"):
                    continue  # person rows are not playable titles
                if not item.get("id"):
                    continue
                tmdb_id = str(item["id"])
                title = item.get("title") or item.get("name") or ""
                if not title:
                    continue
                cert = ""
                if wall_on:
                    if _is_wrestling_title(title):
                        continue
                    cert = _search_certification(media, tmdb_id,
                                                 get)
                    if cert not in SEARCH_ALLOWED_RATINGS:
                        continue
                badge = _usearch_badge(item)
                date = (item.get("release_date")
                        or item.get("first_air_date") or "")
                year = date[:4]
                sub = badge
                if year:
                    sub += " \u2022 " + year
                if cert:
                    sub += " \u2022 Rated " + cert
                art = {}
                if item.get("poster_path"):
                    art = {"poster": _TMDB_IMG_W500
                           + item["poster_path"],
                           "thumb": _TMDB_IMG_W500
                           + item["poster_path"]}
                    if item.get("backdrop_path"):
                        art["fanart"] = (_TMDB_IMG_W500
                                         + item["backdrop_path"])
                rows.append({
                    "label": title,
                    "sub": sub,
                    "badge": badge,
                    "path": _title_details_path(
                        title, media, {"id": tmdb_id}),
                    "tmdb_id": tmdb_id,
                    "tmdb_type": media,
                    "rating": cert,
                    "year": year,
                    "art": art})
            if len(rows) >= SEARCH_PAGE_QUOTA:
                if cur < total_pages:
                    resume_page = cur + 1
                break
            if cur >= total_pages:
                break
            cur += 1
            if fetched >= SEARCH_MAX_PAGES:
                resume_page = cur
                break
    except Exception as exc:
        log("unified_search_items failed: %s" % exc)
        return [], False, 0
    return rows, bool(resume_page), resume_page


# ---- TV hub browse rows, capped (2026-11-09, browse cap) ---------
# The TV hub's AIRING TODAY / TRENDING SHOWS rows are served by
# TMDb Helper content paths today, and the Helper path cannot be
# capped: a TMDB list payload carries no certification and the
# Helper's rendered items carry nothing to compare (Job 3
# pre-pass section 5.1, proven). So under KidsWall the skin
# swaps those 2 rows to this route instead (Includes.xml
# variables RocTvRowAiringToday / RocTvRowTrendingDay, the
# RocTraktOnDeck pattern; the unwalled value is today's Helper
# path byte-identical, so grown-ups and Jama never change).
# tv_row_items pulls the SAME TMDB feeds the Helper lists wrap
# (tv/airing_today, tv/trending/day) through rocui's own
# mini-client and applies the SAME wall as the Movies rows:
# the wrestling title exclusion plus the Job 3 certification
# join -- _search_certification("tv", id, get) must land in
# SEARCH_ALLOWED_RATINGS (the shared constant, not a copy);
# over-line, unrated ('') and unverifiable (None) are hidden,
# default-deny. Like search_items, this directory IS the kid
# route by construction -- it is only ever routed to under
# KidsWall, and the filter applies whenever it is invoked; the
# kidswall_fn parameter rides along for harness symmetry and
# gate-error parity with search_items (a gate error reads as
# walled; it can never licence an unfiltered serving, because
# there is no unfiltered serving on this route). Rows keep
# feed order and collection_detail's row shape, so
# timeline.build_tv_row serves them with the proven
# folder-into-detail dispatch. Never raises: an unknown list
# or a dead API reads as [].

TV_ROW_FEEDS = {"airing_today": "tv/airing_today",
                "trending_day": "trending/tv/day"}


def tv_row_items(list_name, tmdb_get_fn=None, kidswall_fn=None):
    """Capped rows for one TV-hub browse row. list_name is
    'airing_today' (AIRING TODAY) or 'trending_day' (TRENDING
    SHOWS); anything else -> []. tmdb_get_fn / kidswall_fn are
    injectable for the harness; they default to tmdb_get and
    _kidswall_active. Never raises."""
    feed = TV_ROW_FEEDS.get(list_name or "")
    if not feed:
        return []
    kw = _kidswall_active if kidswall_fn is None else kidswall_fn
    try:
        wall_on = bool(kw())
    except Exception:
        # Gate-error parity with search_items: an unreadable
        # gate reads as walled. The filter below applies on
        # this route regardless (see the section comment).
        wall_on = True
    get = tmdb_get_fn or tmdb_get
    try:
        data = get(feed) or {}
    except Exception as exc:
        log("tv_row_items: %s fetch failed: %s" % (feed, exc))
        return []
    if not isinstance(data, dict):
        return []
    rows = []
    for item in data.get("results") or []:
        if not isinstance(item, dict) or not item.get("id"):
            continue
        title = item.get("name") or item.get("title") or ""
        if not title:
            continue
        if _is_wrestling_title(title):
            continue
        if _search_certification(
                "tv", str(item["id"]), get) \
                not in SEARCH_ALLOWED_RATINGS:
            continue
        art = {}
        if item.get("poster_path"):
            art = {"poster": _TMDB_IMG_W500 + item["poster_path"],
                   "thumb": _TMDB_IMG_W500 + item["poster_path"]}
            if item.get("backdrop_path"):
                art["fanart"] = (_TMDB_IMG_W500
                                 + item["backdrop_path"])
        rows.append({"label": title,
                     "sub": "%s - %s" % (
                         "AIRING TODAY"
                         if list_name == "airing_today"
                         else "TRENDING",
                         item.get("first_air_date") or ""),
                     "path": _title_details_path(
                         title, "tv", {"id": str(item["id"])}),
                     "tmdb_id": str(item["id"]),
                     "tmdb_type": "tv",
                     "art": art})
    # ZERO-SOURCE SHELF: proven-zero titles come off the row;
    # the rest are noted for background re-checking.
    rows = _avail_filter_rows(rows)
    _avail_note_rows(rows)
    return rows


def stage_folder(cid):
    """Collection-tile click on the stage: open the clicked folder
    item as a full Videos page (Roc's grid via view_more). The stage
    click law sends title posters to the Detail window; collection
    tiles are folders, so their click NAVIGATES — that is the whole
    point of a collection."""
    if xbmc is None:
        return False
    try:
        cid = int(cid)
    except Exception:
        return False
    path = _info("Container(%d).ListItem.FolderPath", cid)
    if not path or not path.startswith("plugin://"):
        path = _info("Container(%d).ListItem.FileNameAndPath", cid)
    if not path or not path.startswith("plugin://"):
        notify("That collection has no page to open yet", 3500, ok=False)
        return False
    return view_more(path)
def open_collection_title(params, handle=None):
    """Collection-page title click (0.5.12, Loop 122): the detail
    open for a title row on a collection page (Videos window 10025).

    Why this exists: a collection page's items live in the stock
    Videos window, whose views carry no stage_open onclick —
    Kodi's built-in activation is all a click gets there, and it
    dispatches exactly two item shapes: folders (GetDirectory) and
    playable leaves (PlayMedia). The 0.5.7 construction (leaf
    item, Helper info=details path, no IsPlayable) was neither, so
    the click was inert; and the details route itself only ever
    returns Helper's basedir listing (its Router sends only
    info=play to the player), so no flag on that path could open
    the title's page either. The rows therefore arrive here as
    folders into this plugin (?mode=detail, coll/tmdb_id/
    tmdb_type params — folder clicks are the dispatch every other
    rocui page already relies on), and this function performs the
    same open stage_open performs for stage rows:
    ActivateWindow(1124), publish the full RocStage value set,
    read the Title back. The caller ends the directory with
    succeeded=False, so the collection page stays underneath.
    Never raises: any failure notifies and returns False, leaving
    the user on the shelf — never on a dead page.

    0.5.13 (Loop 131): the directory MUST be ended before the
    activation. 0.5.12 activated window 1124 from inside the plugin
    directory call, while Kodi still held its busy dialog for that
    call — a modal dialog — so activation was refused ("Activate of
    window '11124' refused because there are active modal
    dialogs", 10x cross-session for TV titles on the Classics-WB
    page, Loops 128/130, while the faster movie call opened in the
    same run). Ending the directory first (succeeded=False, page
    stays underneath) releases the busy dialog; the activation that
    follows is no longer refused. Every return path ends the
    directory exactly once when a handle is given; when handle is
    None the caller owns the directory end (timeline.main passes
    its handle, so the normal path always ends it here).

    0.5.14 (Loop 133): the retry's success criterion is the CURRENT
    window id, not the Window object. Loop 132 proved 0.5.13's poll
    blind: Pinky and the Brain was refused at +2 ms after the
    directory end (inside DialogBusy's fade-out tail) while the
    other 3 clicks that session landed at +431/+521/+532 ms and
    opened -- and the retry could not see it, because
    xbmcgui.Window(11124) constructs instantly once 1124 has been
    activated once in the session, even while the collection page
    is still current. So attempt 1 "succeeded", properties
    published onto the inactive window, readback passed, True
    returned, user still on the shelf, no failure line. Now every
    poll reads xbmcgui.getCurrentWindowId() and only skin id 1124
    or runtime id 11124 counts as open; the Window object is built
    only after that check passes. A budget exhausted without the
    detail becoming current logs the last current window id and
    returns False -- a logged failure, never a silent True."""
    if xbmc is None or xbmcgui is None:
        if handle is not None:
            try:
                import xbmcplugin as _xp
                _xp.endOfDirectory(handle, succeeded=False)
            except Exception:
                pass
        return False
    # End-directory helper: exactly once, succeeded=False so the
    # collection page stays underneath for BACK from the detail.
    _dir_state = {"ended": False}

    def _end_dir():
        if handle is None or _dir_state["ended"]:
            return
        _dir_state["ended"] = True
        try:
            import xbmcplugin as _xp
            _xp.endOfDirectory(handle, succeeded=False)
        except Exception:
            pass

    params = params or {}
    cid = params.get("coll", "")
    tmdb_id = str(params.get("tmdb_id", "") or "")
    tmdb_type = params.get("tmdb_type", "") or ""
    row = None
    try:
        # Toonime fix (2026-11-09): a toonime- coll resolves ONLY
        # from the sealed shelf data -- it must NOT call
        # collection_detail / load_timeline (the shelf JSON is the
        # whole universe for this room; the collection engine
        # would resolve a different, unsealed set).
        _candidates = (toonime_shelf_items(cid[len("toonime-"):])
                       if cid.startswith("toonime-")
                       else collection_detail(cid))
        for r in _candidates:
            if not tmdb_id or str(r.get("tmdb_id") or "") != tmdb_id:
                continue
            if (tmdb_type and r.get("tmdb_type")
                    and r["tmdb_type"] != tmdb_type):
                continue
            row = r
            break
    except Exception as exc:
        log("open_collection_title: row resolve failed: %s" % exc)
    if row is None and (cid.startswith("movierow")
                        or cid.startswith("tvrow")
                        or cid == "search"
                        or cid == "spotlight") and tmdb_id \
            and tmdb_type in ("movie", "tv"):
        # 0.5.15 (Player Fix Lane, Hand A): a movie-row title
        # (timeline.py ?mode=movierow, the date-gated COMING SOON /
        # IN THEATERS NOW feed) is not a collection member, so
        # collection_detail cannot resolve it. Synthesize the row
        # from the title's own TMDB record; the enrichment block
        # below fills the rest from the same record. Gated on the
        # movierow coll prefix: a stale COLLECTION detail route
        # keeps its 0.5.12 behaviour (notify, stay on the shelf).
        # Job 3 (2026-11-09): coll=search rows (the August search
        # route, timeline.py ?mode=search) are siblings of the
        # movierow branch -- not collection members either, so
        # they resolve from the title's own TMDB record exactly
        # the same way, off the item's own tmdb_id/tmdb_type
        # stamps. The Helper's search is never called here.
        # Browse cap (2026-11-09): coll=tvrow-<list> rows (the
        # capped TV-hub browse route, timeline.py ?mode=tvrow)
        # are the same sibling shape -- not collection members,
        # resolved from the title's own TMDB record off its own
        # stamps.
        try:
            _rec = tmdb_get("%s/%s" % (tmdb_type, tmdb_id)) or {}
        except Exception:
            _rec = {}
        _label = _rec.get("title") or _rec.get("name") or ""
        if _label:
            _art = {}
            if _rec.get("poster_path"):
                _art = {"poster": _TMDB_IMG_W500 + _rec["poster_path"],
                        "thumb": _TMDB_IMG_W500 + _rec["poster_path"]}
                if _rec.get("backdrop_path"):
                    _art["fanart"] = (_TMDB_IMG_W500
                                      + _rec["backdrop_path"])
            row = {"label": _label, "sub": "", "tmdb_id": tmdb_id,
                   "tmdb_type": tmdb_type, "art": _art}
    if row is None or not row.get("label"):
        _end_dir()
        notify("That title has no details to show yet", 3500)
        return False
    title = row["label"]
    tmdb_type = row.get("tmdb_type") or tmdb_type
    info = _title_tmdb_info(title, tmdb_type)
    if not tmdb_id:
        tmdb_id = str(info.get("id") or "")
    art = row.get("art") or {}
    values = {}
    for prop, _field in _STAGE_FIELDS:
        values[prop] = ""
    values["Title"] = title
    values["TmdbId"] = tmdb_id
    values["TmdbType"] = tmdb_type
    values["Poster"] = art.get("poster") or info.get("poster") or ""
    values["Thumb"] = art.get("thumb") or values["Poster"]
    values["Fanart"] = (art.get("fanart") or info.get("fanart")
                        or values["Thumb"])
    values["Path"] = _title_details_path(title, tmdb_type, info)
    values["DBType"] = "movie" if tmdb_type == "movie" else "tvshow"
    for prop in ("RatingIMDb", "RatingRT", "RatingMC", "RatingTMDB",
                 "Resumable", "PercentPlayed"):
        values[prop] = ""
    # Enrichment: rocui's own TMDB client fills the fields a
    # Helper-fed stage item would have carried as infolabels.
    # Best-effort — an offline or partial record still opens the
    # page; the detail window enriches itself off TmdbId.
    try:
        detail = tmdb_get(
            "%s/%s?append_to_response=credits,external_ids,"
            "release_dates,content_ratings"
            % (tmdb_type, tmdb_id)) or {}
    except Exception:
        detail = {}
    if detail:
        values["Plot"] = detail.get("overview") or ""
        date = (detail.get("release_date")
                or detail.get("first_air_date") or "")
        values["Year"] = date[:4]
        values["Genre"] = ", ".join(
            g.get("name", "") for g in detail.get("genres") or []
            if g.get("name"))
        runtime = detail.get("runtime")
        if not runtime:
            runs = detail.get("episode_run_time") or []
            runtime = runs[0] if runs else ""
        # MOVIES FEEL (Loop 299): TMDB runtime is bare minutes;
        # publish "2h 15m", the same format stage_open() uses.
        values["Duration"] = _format_duration(runtime)
        companies = detail.get("production_companies") or []
        if companies:
            values["Studio"] = companies[0].get("name") or ""
        countries = detail.get("production_countries") or []
        if countries:
            values["Country"] = countries[0].get("name") or ""
        elif detail.get("origin_country"):
            values["Country"] = detail["origin_country"][0]
        if detail.get("vote_average"):
            values["RatingTMDB"] = "%.1f" % detail["vote_average"]
        # L4-D8: this TMDB record also carries the title's US
        # content rating (release_dates / content_ratings) -- the
        # collection route previously published MPAA empty on
        # every title (the movie-sample MPAA gap in LEG4 S3).
        if not values.get("MPAA"):
            values["MPAA"] = _detail_mpaa(detail, tmdb_type)
        # L4-D8: IMDb / Rotten Tomatoes / Metacritic via OMDb,
        # from the imdb_id on this same TMDB record. No-op while
        # no OMDb key sits in the Helper's settings (omdb_ratings
        # gates on the key itself).
        try:
            for _prop, _val in omdb_ratings(
                    _detail_imdb_id(detail)).items():
                if _val and not values.get(_prop):
                    values[_prop] = _val
        except Exception as exc:
            log("open_collection_title: ratings fetch failed: %s"
                % exc)
        credits = detail.get("credits") or {}
        for member in credits.get("crew") or []:
            if member.get("job") == "Director":
                values["Director"] = member.get("name") or ""
                break
        cast = [c.get("name", "") for c in credits.get("cast") or []
                if c.get("name")]
        if cast:
            values["Cast"] = ", ".join(cast[:6])
    # Movie resume state for the detail window's RESUME button
    # (8002 shows only when Resumable AND Path are set; its click
    # PlayMedias Path, so Path becomes the entry's real play path,
    # not the details route above). Sourced from the same merged
    # history reader show_progress_target uses; thresholds are the
    # build's own (0.5.8: finished = remaining <= 90 s or >= 97%;
    # progress counts only above 45 s and 2%).
    if tmdb_type == "movie":
        try:
            best = None
            for e in _history_entries_all():
                snap = e.get("snap") or {}
                if (snap.get("type") or "") != "movie":
                    continue
                if (str(snap.get("tmdb") or "") != tmdb_id
                        and (snap.get("title") or "") != title):
                    continue
                if (best is None
                        or (e.get("ts") or 0) > (best.get("ts") or 0)):
                    best = e
            if best is not None:
                pos = float(best.get("position") or 0)
                dur = float(best.get("duration") or 0)
                pct = float(best.get("pct") or 0)
                if (dur > 0 and (dur - pos) > 90 and pct < 97.0
                        and pos > 45 and pct >= 2.0):
                    values["Resumable"] = "true"
                    values["PercentPlayed"] = "- %d%% watched" % int(pct)
                    play_path = ((best.get("snap") or {}).get("path")
                                 or "")
                    if play_path:
                        values["Path"] = play_path
        except Exception as exc:
            log("open_collection_title: resume lookup failed: %s"
                % exc)
    # Layer 4 — the Roc Sync store (collection-resume lane,
    # 2026-11-17): the movie block above is stage_open's layer 3
    # only (legacy local history). Layers 4/4b never ran on this
    # route, so a movie whose checkpoint lives only in the Roc
    # Sync store — the house progress store since 2026-11-16,
    # i.e. the normal case — published Resumable empty and its
    # detail page showed no RESUME, while the same movie staged
    # from a hub CW row lit it via stage_open's layer 4 (the
    # resume-fix lane's adjacent finding). Mirror stage_open
    # here: the store lights the button; Path becomes the Helper
    # play path (on this route Path still holds the details route
    # whenever the history block did not substitute a real play
    # path — the same replacement the history block itself makes,
    # and detail_resume_play's fallback PlayMedia()s Path); 4b
    # then gives the label the store's own stop point. Movies
    # only: TV titles on this route carry resume semantics on the
    # main button via show_progress_target, exactly as they do on
    # the hub route — unchanged.
    if tmdb_type == "movie" and not values.get("Resumable"):
        try:
            _rs = rocsync_resume("movie", tmdb_id)
            if _rs:
                _pos, _dur = _rs
                values["Resumable"] = "true"
                if not values.get("PercentPlayed") and _dur > 0:
                    values["PercentPlayed"] = (
                        "- %d%% watched" % int(100.0 * _pos / _dur))
                values["Path"] = (
                    "plugin://plugin.video.themoviedb.helper/"
                    "?info=play&tmdb_type=movie&tmdb_id=%s" % tmdb_id)
                log("open_collection_title: resume populated "
                    "layer 4 (rocsync) for %r (pos %.0fs)"
                    % (title, _pos))
        except Exception as exc:
            log("open_collection_title: resume rocsync layer "
                "failed: %s" % exc)
    if tmdb_type == "movie" and values.get("Resumable"):
        # Layer 4b (mirror of stage_open's 4b): when the store
        # holds the position, the label states the stop point in
        # words — a lit RESUME never carries a percent-only or
        # stale label while the store knows the real spot.
        try:
            _pp_now = (values.get("PercentPlayed") or "").strip()
            _pp_zero = not _pp_now
            if _pp_now:
                try:
                    _pp_zero = float(_pp_now.replace("- ", "")
                                     .replace("% watched", "")
                                     .strip()) <= 0
                except Exception:
                    _pp_zero = False
            if _pp_zero or "stopped at" not in _pp_now:
                _rs4b = rocsync_resume("movie", tmdb_id)
                if _rs4b and _rs4b[1] > 0 and _rs4b[0] > 0:
                    _pos_i = int(_rs4b[0])
                    _hh = _pos_i // 3600
                    _mm = (_pos_i % 3600) // 60
                    _ss = _pos_i % 60
                    _at = (("%d:%02d:%02d" % (_hh, _mm, _ss))
                           if _hh else ("%d:%02d" % (_mm, _ss)))
                    values["PercentPlayed"] = (
                        "- stopped at %s - %d%% watched"
                        % (_at, int(100.0 * _rs4b[0] / _rs4b[1])))
                    log("open_collection_title: resume percent "
                        "corrected layer 4b (rocsync) for %r" % title)
        except Exception as exc:
            log("open_collection_title: resume percent 4b "
                "failed: %s" % exc)
    # 0.5.13: END THE DIRECTORY BEFORE ACTIVATING. 0.5.12
    # activated from inside the plugin directory call, while Kodi
    # held its busy dialog for that call, and the activation was
    # refused as long as that modal dialog was up (Loops 128/130).
    # Ending first releases it; the collection page stays
    # underneath because succeeded=False. Publish order after
    # this is stage_open's order (proven on hardware .159,
    # 2026-10-30: xbmcgui.Window(1124) raises until the window
    # has been activated once; the runtime id is 1124 + 10000).
    _end_dir()
    runtime_id = DETAIL_WINDOW_ID + 10000
    win = None
    monitor = xbmc.Monitor()
    _attempts = 0
    _last_current = None
    for _attempts in range(1, 21):
        try:
            xbmc.executebuiltin(
                "ActivateWindow(%d)" % DETAIL_WINDOW_ID)
        except Exception:
            pass
        for _ in range(10):
            if monitor.waitForAbort(0.05):
                break
            # 0.5.14: the Window object is NOT the proof. It
            # constructs the moment 1124 has been activated once
            # in the session, even while the collection page is
            # still current (Loop 132 Pinky). Only the CURRENT
            # window id proves the open: skin id 1124, or its
            # runtime id 11124.
            try:
                _last_current = xbmcgui.getCurrentWindowId()
            except Exception:
                _last_current = None
            if _last_current in (DETAIL_WINDOW_ID, runtime_id):
                break
        if _last_current in (DETAIL_WINDOW_ID, runtime_id):
            try:
                win = xbmcgui.Window(runtime_id)
            except Exception:
                win = None
                log("open_collection_title: detail window current "
                    "but Window(%d) would not construct; retrying"
                    % runtime_id)
        if win is not None:
            break
        log("open_collection_title: attempt %d did not open the "
            "detail (current window %r); re-firing"
            % (_attempts, _last_current))
        if monitor.waitForAbort(0.1):
            break
    if win is None:
        log("open_collection_title: detail window %d (runtime %d) "
            "never became current after %d attempts (last current "
            "window %r); RocStage properties not published"
            % (DETAIL_WINDOW_ID, runtime_id, _attempts, _last_current))
        return False
    if _attempts > 1:
        log("open_collection_title: detail window opened on "
            "attempt %d" % _attempts)
    for prop, val in values.items():
        try:
            win.setProperty("RocStage." + prop, val or "")
        except Exception:
            pass
    try:
        if win.getProperty("RocStage.Title") != (values.get("Title")
                                                or ""):
            log("open_collection_title: RocStage.Title readback "
                "mismatch (published %r, read %r)"
                % (values.get("Title"),
                   win.getProperty("RocStage.Title")))
            return False
    except Exception:
        pass
    # Resume-PLAY label for TV titles — the same computation
    # stage_open publishes (detail_main_play recomputes it fresh
    # at click time regardless).
    if values.get("TmdbType") == "tv":
        try:
            target = show_progress_target(values.get("Title") or "",
                                          values.get("TmdbId") or "")
            win.setProperty("RocStage.MainLabel", target["label"])
            win.setProperty("RocStage.MainTargetKind",
                            target["kind"])
            win.setProperty("RocStage.MainTargetSeason",
                            str(target["season"]))
            win.setProperty("RocStage.MainTargetEpisode",
                            str(target["episode"]))
            win.setProperty("RocStage.MainTargetPosition",
                            str(target["position"]))
            win.setProperty("RocStage.MainTargetTag", target["tag"])
        except Exception as exc:
            log("open_collection_title: resume target failed: %s"
                % exc)
            win.setProperty("RocStage.MainLabel", "PLAY")
            win.setProperty("RocStage.MainTargetKind", "fresh")
            win.setProperty("RocStage.MainTargetSeason", "1")
            win.setProperty("RocStage.MainTargetEpisode", "1")
            win.setProperty("RocStage.MainTargetPosition", "0")
            win.setProperty("RocStage.MainTargetTag", "S01E01")
    else:
        # 0.5.17 (Stage 2 skin wiring): same fresh-PLAY Main* publish
        # as stage_open's else branch — a movie opened after a show
        # must never inherit the show's CONTINUE WATCHING label.
        win.setProperty("RocStage.MainLabel", "PLAY")
        win.setProperty("RocStage.MainTargetKind", "fresh")
        win.setProperty("RocStage.MainTargetSeason", "1")
        win.setProperty("RocStage.MainTargetEpisode", "1")
        win.setProperty("RocStage.MainTargetPosition", "0")
        win.setProperty("RocStage.MainTargetTag", "S01E01")
    if values.get("TmdbType") == "tv":
        # 0.5.15 (Player Fix Lane, Hand A): same Season/Episode
        # mirror as stage_open (see its note). This route zeroes
        # every _STAGE_FIELDS value by construction, so a TV title
        # opened from a collection page hit the identical dead
        # detail page -- no PLAY, SOURCES only. Fill from the
        # computed target; never overwrite a carried value.
        try:
            if not values.get("Season"):
                win.setProperty(
                    "RocStage.Season",
                    win.getProperty("RocStage.MainTargetSeason")
                    or "1")
            if not values.get("Episode"):
                win.setProperty(
                    "RocStage.Episode",
                    win.getProperty("RocStage.MainTargetEpisode")
                    or "1")
        except Exception:
            pass
    return True


# ======================================================================
# FIX PASS 2026-11-09 — AUGUST MUSIC SEEDER (August 1133/1134 render
# defect + 1132 Quick picks). Root cause, proven from the shipped
# bytes: 1133/1134's panel 610 and 1132's Quick-picks panel 610 are
# fed by <content>special://profile/playlists/music/*.xspf</content>,
# but a skin container content path to a playlist FILE is not a
# directory source in Kodi -- the loader in this path only knows
# .xsp smart playlists (which resolve through the music library; the
# old design died exactly that way) and plugin:// / library directory
# paths. The XSPF file sitting correctly in August's profile (the
# publish train deployed it; Checker D md5-verified all 3) can
# therefore never populate the panel: 0 items, and defaultcontrol
# 610 in 1133/1134 became the "asked to focus, but it can't" error
# PROOF-159 recorded. The seeder replaces the file-as-content
# mechanism with the one the house already proves everywhere else:
# a PLUGIN DIRECTORY. service.py calls august_music_seed() at
# startup; it parses August's XSPF playlists and republishes every
# track as a Window-property count + a cached JSON the directory
# mode (default.py ?mode=augustmusic&list=...) serves as ordinary
# ListItems. The skin panels then read
# plugin://script.rocui/?mode=augustmusic&list=kpop|spiderverse|liked
# and render like every other rocui-fed row. Items are display-only
# (IsPlayable=false): August's playback is the Spotify app door, by
# Eric's ruling -- nothing here pretends a track plays in Kodi.
# Titles/artists come from the XSPF files themselves; nothing is
# invented, and the liked-songs slot renders empty until Tanisha's
# list fills the XSPF (the seed then republishes automatically).
# ======================================================================

AUGUST_MUSIC_LISTS = (
    ("kpop", "august_kpop_demon_hunters.xspf"),
    ("spiderverse", "august_spiderverse.xspf"),
    ("liked", "august_liked_songs.xspf"),
)
AUGUST_MUSIC_CACHE = "august_music_items.json"


def _august_music_profile_dirs():
    """Candidate profile roots that can hold August's playlists: the
    loaded profile (August's own, when his profile is active) and
    every named profile dir under the master profile's profiles/
    tree (the fleet layout: userdata/profiles/August/...)."""
    roots = []
    try:
        prof = xbmcvfs.translatePath("special://profile/")
        if prof:
            roots.append(prof)
    except Exception:
        pass
    try:
        master = xbmcvfs.translatePath("special://masterprofile/")
        if master:
            base = os.path.join(master, "profiles")
            if os.path.isdir(base):
                for name in sorted(os.listdir(base)):
                    roots.append(os.path.join(base, name) + os.sep)
    except Exception:
        pass
    return roots


def _parse_xspf_tracks(path):
    """(title, creator) pairs from an XSPF file, file order. Never
    raises; a missing/unparseable file yields []."""
    try:
        import xml.etree.ElementTree as _ET
        tree = _ET.parse(path)
    except Exception:
        return []
    ns = {"x": "http://xspf.org/ns/0/"}
    out = []
    for tr in tree.getroot().iter():
        if not tr.tag.endswith("}track") and tr.tag != "track":
            continue
        title = creator = album = image = ""
        duration = 0
        for child in tr:
            tag = child.tag.rsplit("}", 1)[-1]
            if tag == "title":
                title = (child.text or "").strip()
            elif tag == "creator":
                creator = (child.text or "").strip()
            elif tag == "album":
                album = (child.text or "").strip()
            elif tag == "image":
                image = (child.text or "").strip()
            elif tag == "duration":
                try:
                    duration = int((child.text or "0").strip() or 0)
                except Exception:
                    duration = 0
        if title:
            out.append({"title": title, "artist": creator,
                        "album": album, "image": image,
                        "duration": duration})
    return out


def august_music_seed():
    """Republish August's XSPF track lists for the skin: per-list
    item counts as Window(10000) properties RocAugust.KpopCount /
    .SpiderverseCount / .LikedCount (1133/1134 gate their
    defaultcontrol on these, so an empty list can never again become
    an unfocusable default), plus the cached JSON the augustmusic
    directory mode serves. Best-effort by design: any failure leaves
    counts at 0 and the windows fall back to the SPOTIFY chip.
    Returns the counts dict. Never raises."""
    counts = {}
    items = {}
    try:
        roots = _august_music_profile_dirs()
        for key, fname in AUGUST_MUSIC_LISTS:
            tracks = []
            for root in roots:
                cand = os.path.join(
                    root, "playlists", "music", fname)
                if os.path.isfile(cand):
                    tracks = _parse_xspf_tracks(cand)
                    if tracks:
                        break
                    # file exists but empty (the liked slot): the
                    # authoritative answer for this list is 0
                    break
            items[key] = tracks
            counts[key] = len(tracks)
        try:
            win = xbmcgui.Window(10000)
            _prop_names = {"kpop": "RocAugust.KpopCount",
                           "spiderverse": "RocAugust.SpiderverseCount",
                           "liked": "RocAugust.LikedCount"}
            for key, _fname in AUGUST_MUSIC_LISTS:
                win.setProperty(_prop_names[key],
                                str(counts.get(key, 0)))
        except Exception:
            pass
        try:
            _write_json(AUGUST_MUSIC_CACHE, {"items": items})
        except Exception:
            pass
        log("august_music_seed: counts %r" % (counts,))
    except Exception as exc:
        log("august_music_seed failed: %s" % exc)
    return counts


# ---------------------------------------------------------------------------
# FLEET CATCH-UP 2026-11-16: YouTube readiness gate (wave 3.3).
# The Music hub's YouTube rows may only carry content when the
# CURRENT profile's YouTube add-on is actually ready - its own
# readiness test: an api_keys.json in the profile's YouTube
# addon_data with api_key + client_id + client_secret all present.
# Anything else (no file, empty values, unreadable) reads NOT
# ready and the rows stay empty: the API-keys nag can never fire
# unprompted. Only booleans are ever logged - never key material.
# ---------------------------------------------------------------------------
def publish_youtube_ready():
    ready = False
    try:
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.youtube/"
            "api_keys.json")
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            try:
                raw = f.read()
            finally:
                f.close()
            data = json.loads(raw)
            keys = data.get("keys") if isinstance(data, dict) else None
            if not isinstance(keys, dict):
                keys = data if isinstance(data, dict) else {}
            ready = all(str(keys.get(k) or "").strip()
                        for k in ("api_key", "client_id",
                                  "client_secret"))
    except Exception as exc:
        log("youtube ready check failed: %s" % exc)
        ready = False
    try:
        win = xbmcgui.Window(10000)
        cur = win.getProperty("RocOS.YouTubeReady")
        if ready and cur != "true":
            win.setProperty("RocOS.YouTubeReady", "true")
            log("youtube ready: TRUE for this profile")
        elif not ready and cur:
            win.clearProperty("RocOS.YouTubeReady")
            log("youtube ready: false for this profile")
    except Exception:
        pass
    return ready


# ---------------------------------------------------------------------------
# FLEET CATCH-UP 2026-11-16: OSD source label fallback (Eric 20:11).
# RocPlay stamps RocOS.SourceLabel/SourcePath itself at play time.
# This tick covers every OTHER play route (WatchNixtoons, YouTube,
# direct streams): when the playing file is not the file the stamp
# belongs to, derive the label from the path. Cleared when nothing
# plays. The label only ever renders inside the OSD.
# ---------------------------------------------------------------------------
_SOURCE_LABEL_MAP = {
    "plugin.video.watchnixtoons2": "WatchNixtoons",
    "plugin.video.youtube": "YouTube",
    "plugin.video.themoviedb.helper": "Roc Play",
    "plugin.video.rocplay": "Roc Play",
    "script.rocui": "Archive.org",
    "plugin.video.madtitansports": "Mad Titan Sports",
}
_SOURCE_HOST_MAP = {
    "movy.sx": "Movy", "www.movy.sx": "Movy",
    "archive.org": "Archive.org",
    "vixsrc.co": "VixSrc", "vixsrc.to": "VixSrc",
}


def _derive_source_label(path):
    import urllib.parse
    try:
        if path.startswith("plugin://"):
            seg = path[len("plugin://"):].split("/")[0]
            return _SOURCE_LABEL_MAP.get(seg, seg)
        host = urllib.parse.urlparse(path).hostname or ""
        if host in _SOURCE_HOST_MAP:
            return _SOURCE_HOST_MAP[host]
        if host.endswith("googlevideo.com"):
            return "YouTube"
        if "vidzee" in host:
            return "VidZee"
        return host or "Stream"
    except Exception:
        return "Stream"


def source_label_tick():
    try:
        win = xbmcgui.Window(10000)
        player = xbmc.Player()
        if not player.isPlayingVideo():
            if win.getProperty("RocOS.SourceLabel"):
                win.clearProperty("RocOS.SourceLabel")
            if win.getProperty("RocOS.SourcePath"):
                win.clearProperty("RocOS.SourcePath")
            return
        path = player.getPlayingFile() or ""
        if path and win.getProperty("RocOS.SourcePath") != path:
            win.setProperty("RocOS.SourcePath", path)
            win.setProperty("RocOS.SourceLabel",
                            _derive_source_label(path))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# FLEET CATCH-UP 2026-11-16: SEARCH INPUT (Eric 20:52, mandate
# 23:22) - microphone + QR phone typing + predictive suggestions
# on every RocOS search bar.
#
# Shape: tapping MIC or PHONE beside any search button opens a
# session (this profile's script.rocui/input/session.json) bound
# to that search button's own path template. PHONE shows window
# 1141 with the stick's QR code; the phone page is served by the
# service's tiny HTTP server on port 9898 (this module, started by
# service.py). MIC launches the RocOS Voice helper app
# (com.rocos.voicetype), which posts the recognized text back to
# the same server on localhost. A submission lands in result.json;
# the service's input_tick consumes it exactly once and runs the
# search with the text injected into the template - the same
# results wall the keyboard path lands on. Predictive: the phone
# page suggests live from the house catalog (toonime shelves +
# search history titles) as he types.
# ---------------------------------------------------------------------------
INPUT_PORT = 9898
_INPUT_SESSION_S = 180
_input_server = {"started": False, "shelves": None}


def _input_dir():
    d = xbmcvfs.translatePath(
        "special://profile/addon_data/script.rocui/input/")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _json_file_write(path, obj):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f)
        return True
    except Exception as exc:
        log("input file write failed: %s" % exc)
        return False


def _json_file_read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def input_session_open(mode, path):
    d = _input_dir()
    try:
        os.remove(os.path.join(d, "result.json"))
    except Exception:
        pass
    sess = {"mode": mode, "path": path or "",
            "opened": time.time(),
            "expires": time.time() + _INPUT_SESSION_S}
    if not _json_file_write(os.path.join(d, "session.json"), sess):
        notify("Search input is not available right now", ok=False)
        return
    try:
        xbmcgui.Window(10000).setProperty("RocInput.Active", "1")
    except Exception:
        pass
    log("input session opened (%s) for %s" % (mode, (path or "")[:80]))
    if mode == "phone":
        xbmc.executebuiltin("ActivateWindow(1141)")
    else:
        xbmc.executebuiltin(
            "StartAndroidActivity(com.rocos.voicetype)")
        notify("Speak now - RocOS is listening")


def input_session_cancel():
    d = _input_dir()
    for name in ("session.json", "result.json"):
        try:
            os.remove(os.path.join(d, name))
        except Exception:
            pass
    try:
        xbmcgui.Window(10000).clearProperty("RocInput.Active")
    except Exception:
        pass
    log("input session cancelled")


def run_search_with_text(path, text):
    """Inject a typed/spoken query into a search path template and
    open the results wall - the exact landing the keyboard path
    produces (view_more). Returns True when a search ran."""
    import urllib.parse
    q = (text or "").strip()
    if not q:
        return False
    enc = urllib.parse.quote_plus(q)
    p = path or ""
    if "kodion/search/query" in p:
        final = p + "?q=" + enc
    elif "info=search" in p:
        final = p + "&query=" + enc
    elif "mode=search" in p or "mode=ia_search" in p \
            or "mode=usearch" in p:
        final = p + "&q=" + enc
    elif "actionSearch" in p:
        # A carrier's own search menu (WatchNixtoons) takes no
        # injected query - open it as-is rather than fake a result.
        final = p
    elif p:
        final = p + ("&q=" if "?" in p else "?q=") + enc
    else:
        return False
    log("input search: %r -> %s" % (q, final[:120]))
    return view_more(final)


def input_suggest(q):
    """Predictive suggestions from the house catalog: toonime
    shelf titles + this profile's playback-history titles.
    Prefix matches rank first, then substring; max 8."""
    q = (q or "").strip().lower()
    if len(q) < 2:
        return []
    titles = []
    try:
        if _input_server["shelves"] is None:
            spath = xbmcvfs.translatePath(
                "special://home/addons/script.rocui/resources/data/"
                "toonime_shelves.json")
            data = _json_file_read(spath) or {}
            seen = set()
            for shelf in (data.get("shelves") or {}).values():
                for row in shelf or []:
                    t = (row or {}).get("title") or ""
                    if t and t.lower() not in seen:
                        seen.add(t.lower())
                        titles.append(t)
            _input_server["shelves"] = titles
        titles = list(_input_server["shelves"])
    except Exception:
        titles = []
    try:
        for entry in _history_entries_all():
            t = entry.get("title") or entry.get("showtitle") or ""
            if t and t.lower() not in [x.lower() for x in titles]:
                titles.append(t)
    except Exception:
        pass
    pre = [t for t in titles if t.lower().startswith(q)]
    sub = [t for t in titles
           if q in t.lower() and t not in pre]
    return (pre + sub)[:8]


_INPUT_PAGE = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RocOS Search</title>
<style>
body{background:#0b0b0e;color:#f2f2f2;font-family:sans-serif;
margin:0;padding:24px}
h1{font-size:20px;color:#d9a05b;margin:0 0 6px}
p{color:#9a9aa2;font-size:14px;margin:0 0 18px}
input{width:100%;box-sizing:border-box;font-size:22px;padding:14px;
border-radius:10px;border:1px solid #333;background:#17171c;
color:#fff}
button{width:100%;margin-top:14px;font-size:20px;padding:14px;
border:0;border-radius:10px;background:#d9a05b;color:#111;
font-weight:bold}
#sug{margin-top:10px}
.chip{display:block;width:100%;text-align:left;margin-top:8px;
padding:12px;font-size:17px;border-radius:10px;border:1px solid #333;
background:#17171c;color:#f2f2f2;font-weight:normal}
#msg{margin-top:14px;color:#8fd18b;font-size:15px;min-height:20px}
</style></head><body>
<h1>RocOS Search</h1>
<p>Type here - it lands on your TV.</p>
<input id="q" type="text" autocomplete="off"
placeholder="Movie, show, artist...">
<div id="sug"></div>
<button id="send">SEARCH ON TV</button>
<div id="msg"></div>
<script>
var q=document.getElementById('q'),sug=document.getElementById('sug'),
msg=document.getElementById('msg'),timer=null;
q.focus();
function send(text){
  fetch('/submit',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:text})})
  .then(function(r){return r.json()})
  .then(function(j){
    if(j.ok){msg.textContent='Sent - look at your TV.';
      q.value='';sug.innerHTML='';}
    else{msg.textContent='The TV is not waiting for input - '+
      'tap PHONE on the search bar first.';}
  })
  .catch(function(){msg.textContent='Could not reach the TV.';});
}
document.getElementById('send').onclick=function(){
  if(q.value.trim())send(q.value.trim());};
q.addEventListener('keydown',function(e){
  if(e.key==='Enter'&&q.value.trim())send(q.value.trim());});
q.addEventListener('input',function(){
  clearTimeout(timer);
  timer=setTimeout(function(){
    var v=q.value.trim();
    if(v.length<2){sug.innerHTML='';return;}
    fetch('/suggest?q='+encodeURIComponent(v))
    .then(function(r){return r.json()})
    .then(function(j){
      sug.innerHTML='';
      (j.items||[]).forEach(function(t){
        var b=document.createElement('button');
        b.className='chip';b.textContent=t;
        b.onclick=function(){send(t);};
        sug.appendChild(b);});
    }).catch(function(){});
  },150);});
</script></body></html>"""


def input_server_ensure():
    """Start the phone-typing HTTP server (service process only).
    Idempotent; a bind failure logs and leaves the flag clear so a
    later tick can retry."""
    if _input_server["started"]:
        return True
    try:
        import threading
        from http.server import BaseHTTPRequestHandler, \
            ThreadingHTTPServer
    except Exception as exc:
        log("input server unavailable: %s" % exc)
        return False
    idir = _input_dir()

    class _H(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _send(self, code, body, ctype="application/json"):
            data = body.encode("utf-8") \
                if isinstance(body, str) else body
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            import urllib.parse
            try:
                u = urllib.parse.urlparse(self.path)
                if u.path in ("/", "/index.html"):
                    self._send(200, _INPUT_PAGE, "text/html")
                elif u.path == "/suggest":
                    qs = urllib.parse.parse_qs(u.query)
                    items = input_suggest(
                        (qs.get("q") or [""])[0])
                    self._send(200, json.dumps(
                        {"items": items}))
                else:
                    self._send(404, json.dumps({"ok": False}))
            except Exception:
                pass

        def do_POST(self):
            import urllib.parse
            try:
                if self.path not in ("/submit", "/voice"):
                    self._send(404, json.dumps({"ok": False}))
                    return
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n).decode("utf-8", "replace")
                try:
                    text = (json.loads(raw) or {}).get("text") or ""
                except Exception:
                    form = urllib.parse.parse_qs(raw)
                    text = (form.get("text") or [""])[0]
                sess = _json_file_read(
                    os.path.join(idir, "session.json"))
                if not sess or time.time() > sess.get("expires", 0):
                    self._send(409, json.dumps(
                        {"ok": False, "error": "no open session"}))
                    return
                if not (text or "").strip():
                    self._send(400, json.dumps({"ok": False}))
                    return
                _json_file_write(
                    os.path.join(idir, "result.json"),
                    {"text": text.strip(), "ts": time.time()})
                self._send(200, json.dumps({"ok": True}))
            except Exception:
                try:
                    self._send(500, json.dumps({"ok": False}))
                except Exception:
                    pass

    try:
        srv = ThreadingHTTPServer(("0.0.0.0", INPUT_PORT), _H)
    except Exception as exc:
        log("input server bind failed: %s" % exc)
        return False
    t = threading.Thread(target=srv.serve_forever)
    t.daemon = True
    t.start()
    _input_server["started"] = True
    log("input server listening on port %d" % INPUT_PORT)
    return True


def input_tick():
    """Service tick (~2 s): consume one submitted text for the
    open session and run its search. Also expires stale sessions
    and retries the server start if the bind failed earlier."""
    if not _input_server["started"]:
        input_server_ensure()
    d = _input_dir()
    rpath = os.path.join(d, "result.json")
    spath = os.path.join(d, "session.json")
    res = _json_file_read(rpath)
    sess = _json_file_read(spath)
    if sess and time.time() > sess.get("expires", 0):
        log("input session expired (%s)" % sess.get("mode"))
        sess = None
        try:
            os.remove(spath)
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).clearProperty("RocInput.Active")
        except Exception:
            pass
    if not res:
        return
    try:
        os.remove(rpath)
    except Exception:
        pass
    if not sess:
        log("input submission arrived with no open session")
        return
    try:
        os.remove(spath)
    except Exception:
        pass
    try:
        xbmcgui.Window(10000).clearProperty("RocInput.Active")
    except Exception:
        pass
    if xbmc.getCondVisibility("Window.IsVisible(1141)"):
        xbmc.executebuiltin("Dialog.Close(1141)")
    run_search_with_text(sess.get("path") or "",
                         res.get("text") or "")


def input_keyboard():
    """Dialog fallback (fleet catch-up 2026-11-16): from the phone
    dialog's USE KEYBOARD button - drop the input session, close
    the dialog, and run the session's own search path the normal
    way (which opens the on-screen keyboard)."""
    d = _input_dir()
    sess = _json_file_read(os.path.join(d, "session.json"))
    input_session_cancel()
    if xbmc.getCondVisibility("Window.IsVisible(1141)"):
        xbmc.executebuiltin("Dialog.Close(1141)")
    if sess and sess.get("path"):
        view_more(sess["path"])
