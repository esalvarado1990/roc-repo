# -*- coding: utf-8 -*-
"""
script.rocui — service entry point (starts at login).

Loop duties:
  * Daypart clock: keep Skin.String(RocOS.Mode) on the automatic
    Day/Midday/Night band unless Eric's manual override is alive.
  * Focus memory: remember the last focused control per window and
    restore it once when he returns to that window (design bible §2.2 /
    §5.2 — focus is never lost on screen transitions).
  * VPN surface: re-check the tunnel state and publish it to the Home
    window properties the dock shield reads (Phase 2 preparation — the
    hardware both-states gate is a later on-device phase).

Everything is best-effort and guarded: a helper that cannot read a
signal stays silent instead of breaking the shell.
"""
import time

import xbmc
import xbmcgui

import rocui_common as rc
import rocui_gate as gate

POLL_SECONDS = 0.3
SEEK_REAPPLY_GRACE_S = 30.0   # 0.7.17: minimum spacing between
                              # pending-seek applies to the SAME
                              # file — a seek reopens the stream
                              # and the playhead reads behind the
                              # target for the whole reopen (~15 s
                              # on the house HLS), so re-applying
                              # inside the grace only restarts it
SEEK_MAX_APPLIES = 3          # 0.7.17: applies per (arm, file),
                              # grace-spaced; a file change (a
                              # real failover) re-keys and re-arms
FOREIGN_SLACK = 5.0    # layer 3 (2026-11-16): a playhead may predate this
                       # service by at most this many seconds before an
                       # unstamped file reads as foreign (see _playback_owner)
DAYPART_EVERY = 20.0   # seconds between daypart syncs
VPN_EVERY = 10.0       # seconds between VPN re-checks
TRAKT_EVERY = 60.0     # seconds between Trakt state publishes (the live API check inside is throttled to 300 s)
GATE_EVERY = 5.0       # seconds between gate verdict ticks (v0.6.0)
FOCUS_STABLE = 1.2     # focus must rest this long before it is remembered
RESTORE_WINDOW = 1.5   # restore only within this long after a window opens
WEATHER_EVERY = 1800.0  # dock weather refresh (Open-Meteo via rocui_common)
AVAIL_EVERY = 60.0      # zero-source shelf re-check tick (rocui_common
                        # .avail_service_tick gates itself further:
                        # idle-only, one fire per 120 s — see there)
NOTIFY_HOLD = 8.0       # seconds a notification stays flipped in the dock
PREVIEW_DWELL = 1.5     # rest this long on a poster before a preview starts
PREVIEW_WINDOWS_DECLARED = {10000, 1111, 1112, 1113, 1114, 1121,
                           1122, 1123}
# FIX PASS 2026-11-09 (preview id-space defect, flagged by
# CHECKER-L4-D1 as the fleet-wide sibling of the wrestling-timeline
# namespace bug): _preview_tick tests the id returned by
# xbmcgui.getCurrentWindowId() -- the RUNTIME id space, where a
# custom window declared 1111 is observed as 11111 -- against the
# DECLARED ids above, so the membership test could only ever match
# Home (10000, identical in both spaces) and hub previews never
# started on any hub. The gate-dialog set below already carries
# both spaces for its own test; the preview test now uses the same
# dual-space set. The declared set stays the single source: both
# runtime sets derive from it.
PREVIEW_WINDOWS = PREVIEW_WINDOWS_DECLARED | {
    win + 10000 for win in PREVIEW_WINDOWS_DECLARED if win < 10000}
# WEDGE FIX (2026-11-08): the gate dialog may be dispatched ONLY while
# a hub-class window is foreground — the same hub set the preview pass
# trusts, in BOTH id spaces the service observes: the skin ids in
# PREVIEW_WINDOWS_DECLARED and their runtime forms (skin id + 10000,
# e.g. hub 1111 is observed as 11111; Home is 10000 in both spaces).
# The detail window (1124 skin / 11124 runtime — the 2026-11-07 wedge
# foreground) is not a member and is never added; fullscreen video
# (12005) is not a member either, and _gate_dialog_tick also refuses
# while the player is fullscreen or any modal below is already
# visible. (PREVIEW_WINDOWS itself is already the dual-space union
# since the 2026-11-09 fix pass; the re-derivation below is a no-op
# kept so this set's construction stays explicit.)
GATE_DIALOG_WINDOWS = PREVIEW_WINDOWS | {
    win + 10000 for win in PREVIEW_WINDOWS_DECLARED if win < 10000}
GATE_DIALOG_MODALS = ("DialogSelect.xml", "DialogProgress.xml",
                      "DialogContextMenu.xml", "DialogConfirm.xml",
                      "DialogBusy.xml")
HOME_FLYOUT_IDS = {941, 942, 943, 944, 945, 946}  # remembered as the chip (921)


def _seek_title_matches(hint, snap):
    """0.5.15: does a pending seek's title hint belong to the title
    playing now? seek_arm hints are snapshot_display() strings
    ("Show S01E02 - Episode Name") or detail_main_play's
    "Title S01E02" — both are prefix-forms of the snapshot display,
    so normalised containment either way is the match. An empty
    hint matches everything (legacy arms carry no title)."""
    if not hint:
        return True
    if not snap:
        return False
    try:
        h = rc._norm_show_title(hint)
        d = rc._norm_show_title(rc.snapshot_display(snap))
        if not h or not d:
            return True
        return h in d or d in h
    except Exception:
        return True


class RocMonitor(xbmc.Monitor):
    """Feeds real Kodi notifications to the service (dock flip)."""

    def __init__(self, service):
        super().__init__()
        self._service = service

    def onNotification(self, sender, method, data):
        try:
            self._service.handle_notification(sender, method, data)
        except Exception as exc:
            rc.log("notification hook failed: %s" % exc)


class RocUIService(object):
    def __init__(self):
        self.monitor = RocMonitor(self)
        self.focus_memory = rc.load_focus_memory()
        self.current_window = None
        self.window_opened_at = 0.0
        self.restored_for = None        # (window_id, opened_at) already done
        self.pending_focus = None       # (window_id, focus_id, since)
        self.last_daypart = 0.0
        self.last_vpn = 0.0
        self.last_trakt = 0.0
        self.last_gate = 0.0
        self.last_input = 0.0
        self.last_ytready = 0.0
        self.last_avail = 0.0
        self.last_gate_dialog = None  # last gate-dialog dispatch (mono); None = none yet, first dispatch is not gap-blocked (C1)
        self.gate = gate.GateKeeper()
        self.last_weather = -WEATHER_EVERY + 5.0  # first fetch ~5s in
        self.notify_until = 0.0
        # dwell-preview state
        self.pv_key = None              # (win, focus, item-key) resting on
        self.pv_since = 0.0
        self.pv_active = False
        self.pv_started_at = 0.0
        self.pv_url = ""
        self.pv_saved_volume = None
        self.pv_dead = set()            # item keys that refused to play
        # resume keeper state (v3.2.0): current item + checkpointing
        self.pb_file = ""
        self.pb_since = 0.0
        self.pb_snap = None
        self.pb_tick = 0
        self.pb_coll_done_for = ""
        # 0.5.15 (Hand B player-fix): last known playhead, refreshed
        # every poll while playing — when playback stops the player
        # can no longer be asked, so the stop-transition checkpoint
        # is written from these, never from a post-stop read.
        self.pb_last_pos = 0.0
        self.pb_last_dur = 0.0
        # 0.5.15: the file the fullscreen enforcer already fired for
        # (once per file, see _playback_tick).
        self.pb_fs_for = ""
        # 0.7.17 (resume seek-storm fix): per-(arm, file) seek
        # application state for the pending-seek applier below.
        self.pb_seek_key = None       # (arm ts, target, file)
        self.pb_seek_at = 0.0         # monotonic time of last apply
        self.pb_seek_count = 0        # applies for pb_seek_key
        # 2026-11-16 (back-keeps-audio fix, layer 3): playback
        # ownership - see _playback_owner. The enforcer must never
        # adopt a video another profile started.
        self.pb_owner = ""           # profile that owns pb_file
        self.pb_boot = None          # monotonic time of first tick
        self.pb_foreign = ""         # foreign file already stopped
        self.pb_profile = ""         # this instance's profile (lazy)
        # F1 autoplay-next (v1.1 FUSE pack, 2026-11-17): next-up
        # state for pb_file - the resolved next episode, the file
        # it belongs to, and the once-only guards. See
        # _nextup_tick / rocui_nextup.
        self.nu_file = ""            # file nu_next was resolved for
        self.nu_next = None          # resolved next-episode dict
        self.nu_pending = False      # a resolve thread is running
        self.nu_fired = False        # autoplay already fired (file)
        self.nu_shown = False        # the card is published

    # ------------------------------------------------------------- focus
    def _flush_pending(self):
        if not self.pending_focus:
            return
        win_id, focus_id, _since = self.pending_focus
        # v3.2.0: never remember a Home flyout item as the restore
        # target — returning to Home with the flyout already open was
        # the "Extras won't go away" trap. Remember the chip instead.
        if win_id == rc.HOME_WINDOW_ID and focus_id in HOME_FLYOUT_IDS:
            focus_id = 921
        key = str(win_id)
        if self.focus_memory.get(key, {}).get("focus") != focus_id:
            self.focus_memory[key] = {
                "focus": focus_id, "updated": int(time.time())}
            rc.save_focus_memory(self.focus_memory)
        self.pending_focus = None

    # ------------------------------------------------------- notifications
    def handle_notification(self, sender, method, data):
        if method != "GUI.OnNotification":
            return
        payload = data
        if isinstance(payload, str):
            try:
                import json as _json
                payload = _json.loads(payload)
            except Exception:
                payload = {}
        if not isinstance(payload, dict):
            return
        text = payload.get("message") or payload.get("title") or ""
        title = payload.get("title") or "Kodi"
        if not text:
            return
        rc.publish_notification(title, text)
        self.notify_until = time.monotonic() + NOTIFY_HOLD

    # ------------------------------------------------------------ preview
    def _preview_item(self, win_id):
        """(key, url, title) for the focused container item, or None.
        Trailer wins; otherwise the item's own path. Buttons have no
        ListItem, so they never qualify — a natural focus guard."""
        try:
            title = xbmc.getInfoLabel("ListItem.Title") or ""
            if not title:
                return None
            trailer = xbmc.getInfoLabel("ListItem.Trailer") or ""
            path = xbmc.getInfoLabel("ListItem.FileNameAndPath") or ""
            url = trailer or path
            if not url or url.startswith("plugin://plugin.video."
                                         "themoviedb.helper/?info=details"):
                return None
            key = "%s|%s" % (win_id, url)
            return key, url, title
        except Exception:
            return None

    def _preview_stop(self):
        if not self.pv_active:
            return
        try:
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
        except Exception:
            pass
        try:
            if self.pv_saved_volume is not None:
                xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","method":"Application.SetVolume",'
                    '"params":{"volume":%d},"id":1}' % self.pv_saved_volume)
        except Exception:
            pass
        try:
            win = xbmcgui.Window(self.current_window or 10000)
            win.setProperty("RocPreview.Active", "")
        except Exception:
            pass
        self.pv_active = False
        self.pv_url = ""
        self.pv_saved_volume = None

    def _preview_tick(self, now):
        if rc.get_skin_string("RocOS.PreviewClips") == "off":
            if self.pv_active:
                self._preview_stop()
            return
        if not self.gate.is_open():
            # v0.6.0 gate: previews are playback too — never start one
            # while the gate is closed (the watchdog would stop it
            # anyway; not starting is cleaner).
            if self.pv_active:
                self._preview_stop()
            self.pv_key = None
            return
        win_id, _focus = rc.current_window_and_focus()
        item = None
        if win_id in PREVIEW_WINDOWS and not xbmc.getCondVisibility(
                "VideoPlayer.IsFullscreen"):
            item = self._preview_item(win_id)
        if item is None:
            if self.pv_active:
                self._preview_stop()
            self.pv_key = None
            return
        key, url, _title = item
        if key in self.pv_dead:
            return
        if self.pv_active:
            if key != self.pv_key:
                self._preview_stop()
                self.pv_key = key
                self.pv_since = now
            elif not xbmc.Player().isPlaying() and \
                    now - self.pv_started_at > 3.0:
                # the preview ended on its own (short trailer)
                self._preview_stop()
                self.pv_key = None
            return
        if key != self.pv_key:
            self.pv_key = key
            self.pv_since = now
            return
        if now - self.pv_since < PREVIEW_DWELL:
            return
        # start the preview, windowed + muted, volume restored on stop
        try:
            vol = xbmc.getInfoLabel("Application.Volume")
            self.pv_saved_volume = int(float(vol)) if vol else None
            if self.pv_saved_volume is not None:
                xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","method":"Application.SetVolume",'
                    '"params":{"volume":0},"id":1}')
            xbmc.Player().play(url, windowed=True)
            win = xbmcgui.Window(win_id)
            win.setProperty("RocPreview.Active", "1")
            self.pv_active = True
            self.pv_url = url
            self.pv_started_at = now
        except Exception as exc:
            rc.log("preview start failed: %s" % exc)
            self.pv_dead.add(key)
            self._preview_stop()

    def _focus_tick(self, now):
        win_id, focus_id = rc.current_window_and_focus()
        if win_id is None:
            return
        if win_id != self.current_window:
            # window changed: remember where we left the old one, then
            # restore where he left this one (once, promptly).
            self._flush_pending()
            self.current_window = win_id
            self.window_opened_at = now
            self.restored_for = None
        if win_id in rc.FOCUS_SKIP_WINDOWS:
            self.pending_focus = None
            return
        # restore pass — once per window entry, inside the entry window
        stored = self.focus_memory.get(str(win_id), {}).get("focus")
        if stored:
            # v3.2.1: never restore focus into a container that is
            # currently empty (e.g. the Trakt on-deck shelf before
            # sign-in) \u2014 the focused frame has nothing to land on
            # and focus reads as lost. The window's defaultcontrol
            # (a shelf that always has content) wins instead.
            try:
                n = xbmc.getInfoLabel("Container(%d).NumItems" % int(stored))
                if n == "0":
                    stored = None
            except Exception:
                pass
        if (stored and focus_id and stored != focus_id
                and self.restored_for != (win_id, self.window_opened_at)
                and now - self.window_opened_at <= RESTORE_WINDOW):
            if rc.restore_focus(win_id, stored):
                self.restored_for = (win_id, self.window_opened_at)
                focus_id = stored
        # remember pass — only focus that rests counts (skim = travel)
        if focus_id:
            if (not self.pending_focus
                    or self.pending_focus[0] != win_id
                    or self.pending_focus[1] != focus_id):
                self.pending_focus = (win_id, focus_id, now)
            elif now - self.pending_focus[2] >= FOCUS_STABLE:
                self._flush_pending()

    # -------------------------------------------------------------- main
    # ------------------------------------------------- resume keeper
    def _collection_probe(self, snap):
        """Movie playing: does it belong to a TMDB collection? Sets
        the fullscreen window property the OSD COLLECTION button
        reads. Runs in a thread — a slow network must never stall
        the service loop."""
        try:
            tmdb_id = rc.snapshot_tmdb_id(snap)
            has = ""
            if tmdb_id:
                detail = rc.tmdb_get("movie/%s" % tmdb_id)
                if detail and (detail.get("belongs_to_collection") or {}).get("id"):
                    has = "1"
            xbmcgui.Window(12005).setProperty("RocPlayer.HasCollection", has)
            self.pb_coll_done_for = self.pb_file
        except Exception as exc:
            rc.log("collection probe failed: %s" % exc)

    def _final_checkpoint(self):
        """0.5.15 (Hand B player-fix, item 2b): write the checkpoint
        at the moment playback STOPS, from the last known playhead.
        Before this, backing out of an episode saved nothing — the
        newest saved position was up to a full 30s cadence stale,
        and a title watched for under one cadence past the 45s
        floor left no trace at all, so the return read as a fresh
        play. Same end-of-title rules as the cadence checkpoint."""
        snap, pos, dur = self.pb_snap, self.pb_last_pos, self.pb_last_dur
        if not snap or pos <= 0:
            return
        try:
            if dur > 0 and dur - pos <= 90:
                rc.history_record(snap, pos, dur)
                if rc.resume_load().get("snap"):
                    rc.resume_delete()
                return
            if pos > 45:
                if rc.resume_save(snap, pos, dur):
                    rc.publish_resume_props()
                rc.history_record(snap, pos, dur)
                origin = snap.get("path") or ""
                rc.source_save(snap, self.pb_file, pos, dur,
                               origin_path=origin
                               if origin.startswith("plugin://")
                               else "")
        except Exception as exc:
            rc.log("final checkpoint failed: %s" % exc)

    # ------------------------------------------------- F1 next-up
    def _nextup_reset(self):
        self.nu_file = ""
        self.nu_next = None
        self.nu_pending = False
        self.nu_fired = False
        if self.nu_shown:
            self.nu_shown = False
            try:
                import rocui_nextup
                rocui_nextup.clear_card()
            except Exception:
                pass

    def _nextup_resolve(self, snap, file):
        """Resolve thread: TMDB fetches must never stall the poll
        loop. Lands the result only if the file is still the one
        playing when it arrives."""
        try:
            import rocui_nextup
            nxt = rocui_nextup.resolve_next(snap)
        except Exception as exc:
            rc.log("nextup resolve failed: %s" % exc)
            nxt = None
        if self.pb_file == file and self.nu_file == file:
            self.nu_next = nxt
        self.nu_pending = False

    def _nextup_tick(self):
        """F1 (v1.1 FUSE pack, Eric's 2026-10-28 spec): while an
        owned episode plays, resolve its next episode inside the
        resolve window, publish the card inside the last 30 s
        (RocNextUp.* on the fullscreen window - VideoFullScreen
        renders it, the OSD NEXT UP button jumps), and fire
        autoplay when the playhead reaches the end. A stop inside
        the end zone takes _nextup_on_stop instead. Movies and
        foreign files never reach here (pb_snap/pb_file are owned
        state only)."""
        import rocui_nextup as nu
        snap = self.pb_snap
        if not nu.is_episode_snap(snap):
            if self.nu_shown or self.nu_file:
                self._nextup_reset()
            return
        dur, pos = self.pb_last_dur, self.pb_last_pos
        if dur <= 0:
            return
        remaining = dur - pos
        if self.nu_file != self.pb_file:
            self.nu_file = self.pb_file
            self.nu_next = None
            self.nu_fired = False
        if remaining > nu.RESOLVE_WINDOW_S:
            if self.nu_shown:
                self.nu_shown = False
                nu.clear_card()
            return
        if self.nu_next is None and not self.nu_pending:
            self.nu_pending = True
            import threading
            threading.Thread(target=self._nextup_resolve,
                             args=(snap, self.pb_file),
                             daemon=True).start()
            return
        if not self.nu_next:
            return
        if remaining <= nu.CARD_WINDOW_S:
            self.nu_shown = True
            nu.publish_card(self.nu_next, remaining)
        elif self.nu_shown:
            self.nu_shown = False
            nu.clear_card()
        if remaining <= 0.6 and not self.nu_fired:
            self.nu_fired = True
            self.nu_shown = False
            nu.clear_card()
            nu.play_next(snap, self.nu_next)

    def _nextup_on_stop(self):
        """Playback stopped: if the last playhead sat inside the
        end zone (<=10 s from the end - the house 'finished'
        reading is 90 s for resume purposes; autoplay is stricter,
        so a mid-episode back-out never chains) and a next episode
        was resolved, the episode ENDED: play it. Fires once."""
        if self.nu_fired or not self.nu_next or not self.pb_snap:
            return
        dur, pos = self.pb_last_dur, self.pb_last_pos
        if dur <= 0 or dur - pos > 10.0:
            return
        self.nu_fired = True
        try:
            import rocui_nextup
            rocui_nextup.play_next(self.pb_snap, self.nu_next)
        except Exception as exc:
            rc.log("nextup on-stop failed: %s" % exc)

    # ------------------------------------------------- play owner
    def _profile_name(self):
        if not self.pb_profile:
            try:
                self.pb_profile = xbmc.getInfoLabel(
                    "System.ProfileName") or ""
            except Exception:
                self.pb_profile = ""
        return self.pb_profile

    def _owner_stamp_path(self):
        # The stamp lives in the MASTER profile's addon data - the
        # one store every profile context resolves identically (the
        # PIN-store pattern in rocui_common) - so it survives the
        # profile switch the stamp exists for.
        try:
            import xbmcvfs
            return xbmcvfs.translatePath(
                "special://masterprofile/addon_data/script.rocui/"
                "play_owner.json")
        except Exception:
            return ""

    def _owner_stamp_read(self):
        """{file, profile} stamped when the current file STARTED,
        or {} when no stamp covers it."""
        try:
            import json as _json
            import xbmcvfs
            path = self._owner_stamp_path()
            if not path or not xbmcvfs.exists(path):
                return {}
            fh = xbmcvfs.File(path)
            raw = fh.read()
            fh.close()
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            data = _json.loads(raw) if raw else {}
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _owner_stamp_write(self, file, profile):
        try:
            import json as _json
            import xbmcvfs
            path = self._owner_stamp_path()
            if not path:
                return
            fh = xbmcvfs.File(path, "wb")
            fh.write(_json.dumps({"file": file, "profile": profile,
                                  "ts": int(time.time())}))
            fh.close()
        except Exception as exc:
            rc.log("play owner stamp write failed: %s" % exc)

    def _owner_stamp_clear(self, file):
        """Drop the stamp when playback ends - only the stamp for
        THIS file; a newer file's stamp is not ours to clear."""
        try:
            import xbmcvfs
            stamp = self._owner_stamp_read()
            if file and stamp.get("file") and \
                    stamp.get("file") != file:
                return
            path = self._owner_stamp_path()
            if path and xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except Exception:
            pass

    def _playback_owner(self, player, cur_file, now):
        """'owned' when the video now playing belongs to THIS
        profile, 'foreign' when another profile started it.

        Owned: the stamp names this profile for this file; or no
        stamp covers the file and its playhead cannot predate this
        service's birth (a fresh start this instance simply had not
        ticked for yet) - a fresh owned file is stamped here.
        Foreign: the stamp names a different profile; or the stamp
        is missing AND the playhead predates this service by more
        than FOREIGN_SLACK - the file was already rolling when this
        profile loaded, so an earlier profile started it. That was
        the Rudolph haunting: Jama's stream adopted by this
        service's enforcer on Nue and again on E-Roc (2026-11-16
        19:33-19:34)."""
        me = self._profile_name()
        stamp = self._owner_stamp_read()
        if stamp.get("file") == cur_file and stamp.get("profile"):
            return "owned" if stamp.get("profile") == me else "foreign"
        try:
            pos = float(player.getTime())
        except Exception:
            pos = 0.0
        boot = self.pb_boot if self.pb_boot is not None else now
        if pos > (now - boot) + FOREIGN_SLACK:
            return "foreign"
        self._owner_stamp_write(cur_file, me)
        return "owned"

    def _playback_tick(self, now):
        """Resume Keeper + pending-seek applier (v3.2.0). Cheap on
        every poll; the checkpoint write itself runs ~every 30s."""
        player = xbmc.Player()
        if self.pb_boot is None:
            self.pb_boot = now
        if not player.isPlayingVideo():
            if self.pb_file:
                # 0.5.15: capture the leave position BEFORE the
                # state is cleared (see _final_checkpoint).
                self._final_checkpoint()
                # F1: a stop inside the end zone with a resolved
                # next episode IS the episode ending (the card's
                # timer reaching zero takes this same door).
                self._nextup_on_stop()
                self._owner_stamp_clear(self.pb_file)
                self.pb_owner = ""
                self.pb_file = ""
                self.pb_snap = None
                self.pb_last_pos = 0.0
                self.pb_last_dur = 0.0
                self._nextup_reset()
                try:
                    xbmcgui.Window(12005).setProperty(
                        "RocPlayer.HasCollection", "")
                except Exception:
                    pass
            self.pb_foreign = ""
            return
        try:
            cur_file = player.getPlayingFile() or ""
        except Exception:
            cur_file = ""
        if cur_file != self.pb_file:
            if cur_file == self.pb_foreign:
                # Foreign file already told to stop; never adopt it
                # while the stop lands.
                return
            if self._playback_owner(player, cur_file,
                                    now) == "foreign":
                # Layer 3 (2026-11-16): a video another profile
                # started is stopped, never adopted - the fullscreen
                # enforcer below keys on pb_file, and a foreign file
                # never becomes pb_file.
                rc.log("foreign playback stopped (started under "
                       "another profile): %s" % cur_file[:100])
                try:
                    player.stop()
                except Exception as exc:
                    rc.log("foreign stop failed: %s" % exc)
                self.pb_foreign = cur_file
                self._owner_stamp_clear(cur_file)
                return
            self.pb_owner = self._profile_name()
            self.pb_file = cur_file
            self.pb_since = now
            self._nextup_reset()
            self.pb_snap = rc.now_playing_snapshot()
            self.pb_coll_done_for = ""
            if self.pb_snap and not self.pb_snap.get("showtitle") \
                    and self.pb_snap.get("type") != "episode":
                import threading
                threading.Thread(target=self._collection_probe,
                                 args=(self.pb_snap,), daemon=True).start()
        # 0.5.15: track the playhead every poll (the stop-transition
        # checkpoint reads these; getTime after stop is gone).
        try:
            self.pb_last_pos = float(player.getTime())
            self.pb_last_dur = float(player.getTotalTime())
        except Exception:
            pass
        # F1 autoplay-next (v1.1 FUSE pack): card + end-of-episode
        # autoplay for the owned file now playing.
        try:
            self._nextup_tick()
        except Exception as exc:
            rc.log("nextup tick failed: %s" % exc)
        # 0.5.15 (item 2c): fullscreen enforcement. A play started
        # from a plugin/modal context (the RocPlay chain: picker
        # dialog -> Player().play() -> endOfDirectory) can leave the
        # video rolling WITHOUT the fullscreen window ever becoming
        # active — transport keys still hit the core player, but
        # Select belongs to whatever window is on top (no OSD), and
        # the skin's DialogSeekBar is gated on
        # VideoPlayer.IsFullscreen + Window.IsActive(fullscreenvideo),
        # so FF/RW/paused show no bar and no time. If a video has
        # been playing >4s, no preview owns the windowed surface, no
        # picker/progress dialog is up, and it still isn't
        # fullscreen, activate the fullscreen window — once per file.
        if self.pb_file and self.pb_file != self.pb_fs_for \
                and not self.pv_active and now - self.pb_since > 4.0:
            try:
                if not xbmc.getCondVisibility("VideoPlayer.IsFullscreen") \
                        and not xbmc.getCondVisibility(
                            "Window.IsVisible(DialogSelect.xml)") \
                        and not xbmc.getCondVisibility(
                            "Window.IsVisible(DialogProgress.xml)") \
                        and not xbmc.getCondVisibility(
                            "Window.IsVisible(DialogContextMenu.xml)"):
                    xbmc.executebuiltin(
                        "ActivateWindow(fullscreenvideo)")
                    rc.log("fullscreen enforced for %s"
                           % self.pb_file[:100])
                self.pb_fs_for = self.pb_file
            except Exception as exc:
                rc.log("fullscreen enforce failed: %s" % exc)
        # pending seek: armed by source_select / resume_play in a
        # one-shot script process; applied here once the new stream
        # is actually rolling.
        # 0.5.15 rework (item 2b): the seek is NO LONGER cleared on
        # application. RocPlay's failover ladder changes the playing
        # file per attempt, and the old code cleared the seek after
        # applying it to whichever attempt happened to be 3s old —
        # a source that then died took the resume position with it.
        # Now: apply whenever the current file is >3s in and behind
        # the target (a fresh failover file re-receives it), and
        # clear only when the playhead is CONFIRMED at/past the
        # target, when it expires (1200s — a full fan-out + ladder
        # can eat most of the old 600s), or when its title hint
        # plainly belongs to a different title than the one playing.
        pending = rc.seek_peek()
        if pending:
            age = time.time() - float(pending.get("ts") or 0)
            if age > 1200:
                rc.seek_clear()
            elif not _seek_title_matches(pending.get("title"),
                                         self.pb_snap):
                if age > 120:
                    rc.seek_clear()
            else:
                try:
                    target = float(pending["time"])
                    pos = self.pb_last_pos
                    if pos >= target - 10:
                        rc.seek_clear()
                        self.pb_seek_key = None
                        self.pb_seek_count = 0
                    elif now - self.pb_since > 3.0:
                        # 0.7.17: ONE seek per reopen. Before this
                        # fix the branch re-applied on every poll
                        # while the playhead read behind target —
                        # but a seek makes the stream REOPEN, and
                        # the playhead reads behind target for the
                        # entire reopen (~15 s on the house HLS),
                        # so each re-apply restarted the reopen:
                        # a seek storm (measured on .155,
                        # 2026-11-18: 5 applies in 18 s; the
                        # player EOF'd a second after the landing
                        # the storm finally allowed, and RocPlay's
                        # hold loop had no living player to hold).
                        # Applies are now keyed to (arm, file),
                        # spaced by SEEK_REAPPLY_GRACE_S and
                        # capped at SEEK_MAX_APPLIES; a file
                        # change (a real failover) re-keys, so
                        # the 0.5.15 failover re-apply survives.
                        key = (pending.get("ts"), target,
                               self.pb_file)
                        if key != self.pb_seek_key:
                            self.pb_seek_key = key
                            self.pb_seek_at = \
                                now - SEEK_REAPPLY_GRACE_S
                            self.pb_seek_count = 0
                        if self.pb_seek_count < SEEK_MAX_APPLIES \
                                and now - self.pb_seek_at \
                                >= SEEK_REAPPLY_GRACE_S:
                            player.seekTime(target)
                            self.pb_seek_at = now
                            self.pb_seek_count += 1
                            rc.log("pending seek applied: %s "
                                   "(apply %d of %d, grace %.0fs)"
                                   % (target, self.pb_seek_count,
                                      SEEK_MAX_APPLIES,
                                      SEEK_REAPPLY_GRACE_S))
                except Exception as exc:
                    rc.log("pending seek failed: %s" % exc)
        # checkpoint ~every 30s of playback
        self.pb_tick += 1
        if self.pb_tick < 100:
            return
        self.pb_tick = 0
        if not self.pb_snap:
            self.pb_snap = rc.now_playing_snapshot()
            if not self.pb_snap:
                return
        pos, dur = self.pb_last_pos, self.pb_last_dur
        if dur <= 0 and pos <= 0:
            return
        if dur > 0 and dur - pos <= 90:
            # finished (or close enough): no resume offer for it,
            # but it DOES land in the history store (v3.4.0)
            if self.pb_snap:
                rc.history_record(self.pb_snap, pos, dur)
            if rc.resume_load().get("snap"):
                rc.resume_delete()
            return
        if pos > 45:
            if rc.resume_save(self.pb_snap, pos, dur):
                rc.publish_resume_props()
            # v3.4.0: same checkpoint feeds the history store
            rc.history_record(self.pb_snap, pos, dur)
            # 0.5.15: same checkpoint feeds the source memory — the
            # playing file IS the source that won (item 2b).
            origin = self.pb_snap.get("path") or ""
            rc.source_save(self.pb_snap, self.pb_file, pos, dur,
                           origin_path=origin
                           if origin.startswith("plugin://") else "")

    def _enforce_tmdbh_defaults(self):
        """v3.2.1: TMDb Helper's player defaults are enforced HERE, via
        the settings API, instead of a baked settings.xml \u2014 a baked
        file made every build swap wipe his Trakt token and OMDb key
        (they live in the same settings.xml). setSetting touches only
        these keys; his sign-in and key survive swaps from now on."""
        try:
            import xbmcaddon
            ad = xbmcaddon.Addon("plugin.video.themoviedb.helper")
            want = {"default_player_movies": "roc_rocplay.json play_movie",
                    "default_player_episodes": "roc_rocplay.json play_episode",
                    "bundled_players": "false",
                    "combined_players": "false",
                    "default_player_kodi": "0",
                    "force_xbmcplayer": "false"}
            for k, v in want.items():
                if ad.getSetting(k) != v:
                    ad.setSetting(k, v)
        except Exception as exc:
            rc.log("tmdbh defaults enforce failed: %s" % exc)

    def _apply_layout(self):
        # v3.3.0 distinct layouts (G30): the package bakes exactly one
        # RocOS.Layout* bool into the skin settings; map it onto the
        # Skin.String(RocOS.Layout) the Home geometry reads. Absent =
        # posterwall default (Home onload also defaults it).
        try:
            import xbmcvfs
            import xml.etree.ElementTree as ET
            path = xbmcvfs.translatePath(
                "special://profile/addon_data/skin.rocos/settings.xml")
            if not xbmcvfs.exists(path):
                return
            f = xbmcvfs.File(path)
            data = f.read()
            f.close()
            root = ET.fromstring(data)
            for sid, val in (("RocOS.LayoutCinema", "cinema"),
                             ("RocOS.LayoutRail", "rail"),
                             ("RocOS.LayoutStageleft", "stageleft"),
                             ("RocOS.LayoutLounge", "lounge"),
                             ("RocOS.LayoutPosterwall", "posterwall")):
                for el in root.iter("setting"):
                    if el.get("id") == sid and (el.text or "").strip() == "true":
                        xbmc.executebuiltin(
                            "Skin.SetString(RocOS.Layout,%s)" % val)
                        rc.roc_log("Layout applied: %s" % val, event="layout")
                        return
        except Exception as exc:  # never take the shell down with us
            rc.log("layout apply failed: %s" % exc)

    # ------------------------------------------------------- gate dialog
    def _gate_dialog_tick(self, now):
        """WEDGE FIX (2026-11-08): dispatch a pending gate dialog —
        fire-and-forget, and only from a hub-class foreground.

        The GateKeeper never raises its modal itself anymore (its
        synchronous modal OK-dialog call on this loop thread is what
        wedged Kodi on 2026-11-07, gate closing over detail 1124).
        When gate.dialog_pending is set, the gate cadence permits
        (NOTICE_DIALOG_GAP), the foreground window is hub-class
        (GATE_DIALOG_WINDOWS — 1124/11124 and fullscreen 12005 are
        excluded by construction), the player is not fullscreen, and
        no modal is already visible, the dialog is handed to a
        disposable one-shot script process via
        RunScript(script.rocui,action=gate_dialog) ->
        rocui_gate.route_gate_refuse(). executebuiltin queues and
        returns: this thread never waits on the dialog, so the loop
        (and its log lines) keep running while the modal is up.
        Returns True when a dispatch fired."""
        keeper = self.gate
        if not getattr(keeper, "dialog_pending", False):
            return False
        if keeper.is_open():
            # restored since the notice: nothing left to deliver.
            keeper.dialog_pending = False
            return False
        if self.last_gate_dialog is not None and \
                now - self.last_gate_dialog < gate.NOTICE_DIALOG_GAP:
            return False
        win_id, _focus_id = rc.current_window_and_focus()
        if win_id not in GATE_DIALOG_WINDOWS:
            return False
        try:
            if xbmc.getCondVisibility("VideoPlayer.IsFullscreen"):
                return False
            for modal in GATE_DIALOG_MODALS:
                if xbmc.getCondVisibility(
                        "Window.IsVisible(%s)" % modal):
                    return False
        except Exception as exc:
            rc.log("gate dialog guard failed: %s" % exc)
            return False
        try:
            xbmc.executebuiltin(
                "RunScript(script.rocui,action=gate_dialog)")
        except Exception as exc:
            rc.log("gate dialog dispatch failed: %s" % exc)
            return False
        keeper.dialog_pending = False
        self.last_gate_dialog = now
        try:
            keeper._publish()
        except Exception:
            pass
        rc.log("gate dialog dispatched (window %s)" % win_id)
        return True

    def run(self):
        rc.log("service starting")
        rc.roc_log("Roc UI service starting", event="service")
        self._apply_layout()
        rc.sync_daypart()
        rc.publish_vpn_state()
        rc.publish_trakt_state()
        rc.publish_resume_props()  # crash-leftover checkpoint -> offer
        try:
            # 0.5.5: land the Roc Play player file in TMDb Helper's
            # players folder (only if absent) so the play hop the
            # defaults below point at actually has its player on
            # fresh installs.
            rc.seed_tmdbh_player()
        except Exception as exc:  # never take the shell down with us
            rc.log("tmdbh player seed failed: %s" % exc)
        self._enforce_tmdbh_defaults()
        try:
            # FIX PASS 2026-11-09: republish August's music lists
            # (counts for his windows' defaultcontrol gating + the
            # directory cache his panels read). Best-effort; failure
            # leaves his windows on their SPOTIFY-chip fallback.
            rc.august_music_seed()
        except Exception as exc:  # never take the shell down with us
            rc.log("august music seed failed: %s" % exc)
        try:
            # FLEET CATCH-UP 2026-11-16: phone-typing server for
            # the search bars (QR page + voice endpoint).
            rc.input_server_ensure()
        except Exception as exc:  # never take the shell down
            rc.log("input server start failed: %s" % exc)
        try:
            self.gate.begin()
        except Exception as exc:  # the gate must never block startup
            rc.log("gate begin failed: %s" % exc)
        self.last_daypart = time.monotonic()
        self.last_vpn = time.monotonic()
        self.last_trakt = time.monotonic()
        self.last_gate = time.monotonic()
        while not self.monitor.abortRequested():
            now = time.monotonic()
            try:
                self.gate.watchdog()
            except Exception as exc:  # gate must never break the loop
                rc.log("gate watchdog failed: %s" % exc)
            try:
                self._focus_tick(now)
            except Exception as exc:  # never take the shell down with us
                rc.log("focus tick failed: %s" % exc)
            if now - self.last_gate >= GATE_EVERY:
                self.last_gate = now
                try:
                    self.gate.tick(now)
                except Exception as exc:
                    rc.log("gate tick failed: %s" % exc)
                try:
                    self._gate_dialog_tick(now)
                except Exception as exc:
                    rc.log("gate dialog tick failed: %s" % exc)
            if now - self.last_daypart >= DAYPART_EVERY:
                self.last_daypart = now
                try:
                    rc.sync_daypart()
                except Exception as exc:
                    rc.log("daypart sync failed: %s" % exc)
            if now - self.last_vpn >= VPN_EVERY:
                self.last_vpn = now
                try:
                    rc.publish_vpn_state()
                except Exception as exc:
                    rc.log("vpn publish failed: %s" % exc)
            if now - self.last_trakt >= TRAKT_EVERY:
                self.last_trakt = now
                try:
                    rc.publish_trakt_state()
                except Exception as exc:
                    rc.log("trakt publish failed: %s" % exc)
            if now - self.last_weather >= WEATHER_EVERY:
                self.last_weather = now
                try:
                    rc.publish_weather()
                except Exception as exc:
                    rc.log("weather publish failed: %s" % exc)
            if self.notify_until and now > self.notify_until:
                self.notify_until = 0.0
                try:
                    rc.clear_notification()
                except Exception as exc:
                    rc.log("notify clear failed: %s" % exc)
            try:
                self._preview_tick(now)
            except Exception as exc:  # previews must never break the loop
                rc.log("preview tick failed: %s" % exc)
            try:
                self._playback_tick(now)
            except Exception as exc:  # keeper must never break the loop
                rc.log("playback tick failed: %s" % exc)
            if now - self.last_input >= 2:
                self.last_input = now
                try:
                    rc.input_tick()
                except Exception as exc:
                    rc.log("input tick failed: %s" % exc)
                try:
                    rc.source_label_tick()
                except Exception as exc:
                    rc.log("source label tick failed: %s" % exc)
            if now - self.last_ytready >= 30:
                self.last_ytready = now
                try:
                    rc.publish_youtube_ready()
                except Exception as exc:
                    rc.log("youtube ready failed: %s" % exc)
            if now - self.last_avail >= AVAIL_EVERY:
                self.last_avail = now
                try:
                    # ZERO-SOURCE SHELF (2026-11-17): one due
                    # availability re-check per tick, idle only —
                    # the logic (queue, cadence, priorities) lives
                    # in rocui_common.avail_service_tick.
                    rc.avail_service_tick()
                except Exception as exc:
                    rc.log("avail tick failed: %s" % exc)
            if self.monitor.waitForAbort(POLL_SECONDS):
                break
        self._flush_pending()
        rc.log("service stopped")
        rc.roc_log("Roc UI service stopped", event="service")


if __name__ == "__main__":
    RocUIService().run()
