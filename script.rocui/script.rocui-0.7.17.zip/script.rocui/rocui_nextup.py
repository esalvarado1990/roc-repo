# -*- coding: utf-8 -*-
"""
script.rocui autoplay-next (F1, v1.1 FUSE pack, 2026-11-17).

Eric's spec (2026-10-28, AUTOPLAY-NEXT-SPEC): when an episode ends,
the next episode plays automatically - no trip back to a menu.
During the last 30 seconds a card carries the next episode's name
and description; clicking it (the OSD NEXT UP button, the house
button pattern) jumps now, letting it run out autoplays at zero.

Fused shape, our code only:
  * The rocui SERVICE watches the playhead (service._nextup_tick);
    inside the card window it resolves the next episode from the
    show's own TMDB episode list (this module's resolve_next) and
    publishes RocNextUp.* properties on the fullscreen window
    (12005) - the skin's VideoFullScreen card and the OSD NEXT UP
    button read them.
  * Playing the next episode goes through RocPlay directly with
    auto=1 (NEVER a picker - August included; a picker is the one
    thing autoplay must never become) and prefer_well=<the well
    that played the episode just finished>: SAME well first, SAME
    quality first, then down RocPlay's ordinary ladder (the
    partition lives in RocPlay 0.2.10's play()).
  * No RocPlay -> the TMDb Helper play path for the exact episode
    (its default player IS RocPlay on this house, so the chain is
    the same; the Helper hop just loses the prefer_well hint).

resolve_next is getter-injectable so the offline harness can drive
it with canned TMDB payloads; every public function never raises.
"""
try:
    import xbmc
    import xbmcgui
except Exception:  # pragma: no cover - importable outside Kodi
    xbmc = xbmcgui = None

from six.moves import urllib_parse

import rocui_common as rc

ROCPLAY = "plugin://plugin.video.rocplay/"
TMDBH = "plugin://plugin.video.themoviedb.helper/"
WELLS = ("movy", "vixsrc", "vidzee", "vidmario", "vidsrc", "mp4hydra")

CARD_WINDOW_S = 30.0     # the card's window before the end (spec)
RESOLVE_WINDOW_S = 45.0  # start resolving a little before the card


def _int(value, default=-1):
    try:
        return int(value)
    except Exception:
        return default


def is_episode_snap(snap):
    if not snap:
        return False
    if not (snap.get("showtitle") or snap.get("type") == "episode"):
        return False
    return _int(snap.get("season"), -1) >= 0 \
        and _int(snap.get("episode"), -1) >= 0


def resolve_next(snap, get=None):
    """The episode after the snapshot's, from the show's own TMDB
    episode list: the next episode number in the same season, else
    episode 1 of the next real season (season 0 specials never
    autoplay). Returns {season, episode, name, overview, still,
    air_date} or None when there is no next episode (or no data).
    Never raises."""
    if not is_episode_snap(snap):
        return None
    get = get or rc.tmdb_get
    tmdb_id = rc.snapshot_tmdb_id(snap)
    if not tmdb_id:
        return None
    season = _int(snap.get("season"))
    episode = _int(snap.get("episode"))
    try:
        data = get("tv/%s/season/%d" % (tmdb_id, season)) or {}
        eps = [e for e in (data.get("episodes") or [])
               if isinstance(e, dict)]
        for ep in eps:
            if _int(ep.get("episode_number")) == episode + 1:
                return _shape(season, ep)
        show = get("tv/%s" % tmdb_id) or {}
        seasons = [s for s in (show.get("seasons") or [])
                   if isinstance(s, dict)
                   and _int(s.get("season_number")) > season
                   and _int(s.get("episode_count")) > 0]
        seasons.sort(key=lambda s: _int(s.get("season_number")))
        if not seasons:
            return None
        nxt_season = _int(seasons[0].get("season_number"))
        data = get("tv/%s/season/%d" % (tmdb_id, nxt_season)) or {}
        eps = [e for e in (data.get("episodes") or [])
               if isinstance(e, dict)
               and _int(e.get("episode_number")) >= 0]
        if not eps:
            return None
        eps.sort(key=lambda e: _int(e.get("episode_number")))
        return _shape(nxt_season, eps[0])
    except Exception as exc:
        rc.log("nextup: resolve failed: %s" % exc)
        return None


def _shape(season, ep):
    still = ep.get("still_path") or ""
    return {"season": season,
            "episode": _int(ep.get("episode_number")),
            "name": ep.get("name") or "",
            "overview": ep.get("overview") or "",
            "still": ("https://image.tmdb.org/t/p/w300" + still)
                     if still else "",
            "air_date": ep.get("air_date") or ""}


def current_well():
    """The well playing right now: RocPlay 0.2.10 stamps the
    machine-readable RocPlay.Well window property at play success;
    older plays only carry the human RocOS.SourceLabel
    ("<well> - <label>"), whose head token is the fallback. '' when
    neither names a known well."""
    if xbmcgui is None:
        return ""
    try:
        win = xbmcgui.Window(10000)
        well = (win.getProperty("RocPlay.Well") or "").strip().lower()
        if well in WELLS:
            return well
        label = win.getProperty("RocOS.SourceLabel") or ""
        head = label.split(" - ", 1)[0].strip().lower()
        if head in WELLS:
            return head
    except Exception:
        pass
    return ""


def play_next(snap, nxt):
    """Fire the next episode through RocPlay (auto=1: no picker,
    ever) with the same-well preference. True when a route fired.
    Never raises."""
    if not snap or not nxt:
        return False
    showtitle = snap.get("showtitle") or snap.get("title") or ""
    if not showtitle:
        return False
    try:
        if xbmc is not None and xbmc.getCondVisibility(
                "System.HasAddon(plugin.video.rocplay)"):
            q = {"action": "play",
                 "title": nxt.get("name") or showtitle,
                 "tvshowtitle": showtitle,
                 "season": nxt["season"],
                 "episode": nxt["episode"],
                 "auto": "1"}
            tmdb_id = rc.snapshot_tmdb_id(snap)
            if tmdb_id:
                q["tmdb"] = tmdb_id
            if snap.get("imdb"):
                q["imdb"] = snap["imdb"]
            if nxt.get("air_date"):
                q["premiered"] = nxt["air_date"]
            well = current_well()
            if well:
                q["prefer_well"] = well
            url = ROCPLAY + "?" + urllib_parse.urlencode(
                {k: v for k, v in q.items() if v != ""})
            rc.log("nextup: autoplay %s S%02dE%02d via RocPlay "
                   "(prefer_well=%s)"
                   % (showtitle, nxt["season"], nxt["episode"],
                      well or "none"))
            xbmc.executebuiltin("PlayMedia(%s)" % url)
            return True
        tmdb_id = rc.snapshot_tmdb_id(snap)
        if tmdb_id:
            path = ("%s?info=play&tmdb_type=tv&tmdb_id=%s"
                    "&season=%d&episode=%d"
                    % (TMDBH, tmdb_id, nxt["season"], nxt["episode"]))
            rc.log("nextup: autoplay %s S%02dE%02d via Helper "
                   "(no RocPlay)" % (showtitle, nxt["season"],
                                     nxt["episode"]))
            xbmc.Player().play(path)
            return True
    except Exception as exc:
        rc.log("nextup: play_next failed: %s" % exc)
    return False


# ----------------------------------------------------------------------
# card properties (fullscreen window 12005 - the HasCollection pattern)
# ----------------------------------------------------------------------
def publish_card(nxt, countdown_s):
    if xbmcgui is None or not nxt:
        return
    try:
        win = xbmcgui.Window(12005)
        win.setProperty("RocNextUp.Show", "1")
        win.setProperty(
            "RocNextUp.Title",
            "S%02dE%02d%s" % (nxt["season"], nxt["episode"],
                              (" - " + nxt["name"]) if nxt.get("name")
                              else ""))
        win.setProperty("RocNextUp.Plot", nxt.get("overview") or "")
        win.setProperty("RocNextUp.Countdown",
                        str(max(0, int(countdown_s))))
        win.setProperty("RocNextUp.Season", str(nxt["season"]))
        win.setProperty("RocNextUp.Episode", str(nxt["episode"]))
    except Exception:
        pass


def clear_card():
    if xbmcgui is None:
        return
    try:
        win = xbmcgui.Window(12005)
        for key in ("Show", "Title", "Plot", "Countdown",
                    "Season", "Episode"):
            win.clearProperty("RocNextUp." + key)
    except Exception:
        pass


def play_next_now():
    """The OSD NEXT UP button (one-shot script process): play the
    episode the service's card is showing, NOW, instead of at zero.
    The identity comes from the live snapshot; the target S/E from
    the card's own published properties (what Eric sees is what
    plays); with no card up, resolve fresh from the snapshot."""
    snap = rc.now_playing_snapshot()
    if not is_episode_snap(snap):
        rc.notify("Next episode is for TV episodes", ok=False)
        return False
    nxt = None
    if xbmcgui is not None:
        try:
            win = xbmcgui.Window(12005)
            s = _int(win.getProperty("RocNextUp.Season"), -1)
            e = _int(win.getProperty("RocNextUp.Episode"), -1)
            if s >= 0 and e >= 0:
                nxt = {"season": s, "episode": e,
                       "name": "", "overview": "", "still": "",
                       "air_date": ""}
        except Exception:
            nxt = None
    if nxt is None:
        nxt = resolve_next(snap)
    if not nxt:
        rc.notify("No next episode for this one", ok=False)
        return False
    clear_card()
    return play_next(snap, nxt)
