# -*- coding: utf-8 -*-
"""
script.rocui — WWE Timeline plugin source (Phase 3).

Serves the 447-event WWF/WWE PPV/PLE index to the War Room scrubber
(skin window 1113) as container content:

  plugin://script.rocui/                      -> the years (scrubber rail)
  plugin://script.rocui/?mode=years           -> same
  plugin://script.rocui/?mode=year&year=1998  -> that year's events,
                                                 date order

Year items are real destinations (v3.1.0 Simple Line — Eric,
2026-10-24 02:29/02:47): each year item's path is this same source at
?mode=year&year=YYYY, so clicking a year opens that year's events by
plain plugin navigation. (The v3.0 design used EMPTY paths + a service
focus sync publishing a window property the events pane read; on real
hardware the clicks were dead and the pane froze on the default year.
That machinery is gone from the flow — no Latest-year landing anywhere.)

Event items point at Purely Wrestling's root (plugin.video
.purelywrestling) as folders: selecting one routes there, per the
Phase 3 spec. A per-event deep-link search inside the wrestling addons
is a later refinement and is NOT claimed here.

All data comes from rocui_common's timeline functions over the shipped
resources/data/ppv_events.json — this file is only the xbmc wrapper.
"""
import sys
from urllib.parse import parse_qsl

import xbmcgui
import xbmcplugin

import rocui_common as rc

PURELY_ROOT = "plugin://plugin.video.purelywrestling/"
BADGE_ART = "special://skin/media/rocos-badge-gold.png"


def _params(query):
    if query.startswith("?"):
        query = query[1:]
    return dict(parse_qsl(query))


def build_years(handle, events):
    """One item per year, ascending; each is a folder into that year's
    events (its own ?mode=year path). Label2 carries the era, labeled
    era-correct: WWF for the pre-rename years, WWE after (Eric,
    2026-10-24 02:49). Returns the item count."""
    count = 0
    for year, num in rc.timeline_years(events):
        item = xbmcgui.ListItem(label=str(year))
        item.setLabel2("%s - %d EVENTS" % (rc.timeline_year_era(year), num))
        item.setProperty("year", str(year))
        item.setProperty("era", rc.timeline_year_era(year))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(
            handle, "plugin://script.rocui/?mode=year&year=%s" % year,
            item, True)
        count += 1
    return count


def build_year(handle, events, year):
    """One year's events in date order. Returns the item count."""
    count = 0
    for event in rc.timeline_events_for_year(events, year):
        pretty = rc.format_event_date(event["date"])
        item = xbmcgui.ListItem(label=str(event["name"]))
        item.setLabel2("%s - %s" % (pretty, event.get("promotion", "")))
        item.setProperty("date", str(event["date"]))
        item.setProperty("promotion", str(event.get("promotion", "")))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, PURELY_ROOT, item, True)
        count += 1
    return count


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    handle = int(argv[1]) if len(argv) > 1 else -1
    params = _params(argv[2] if len(argv) > 2 else "")
    events = rc.load_timeline()
    xbmcplugin.setContent(handle, "videos")
    if params.get("mode") == "year":
        build_year(handle, events, params.get("year"))
    else:
        build_years(handle, events)
    xbmcplugin.endOfDirectory(handle)


if __name__ == "__main__":
    main()
