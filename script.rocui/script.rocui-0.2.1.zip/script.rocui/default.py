# -*- coding: utf-8 -*-
"""
script.rocui — script entry point (RunScript actions from the Roc OS skin).

Actions:
  action=adult_gate[,target=plugin.video.cumination]  PIN gate, then open
  action=reset_pin                                    change the PIN
  action=mode_cycle                                   dock light button:
                                                      manual override pick
  action=sync_daypart                                 apply clock daypart now
  action=vpn_refresh                                  re-check + publish VPN
"""
import sys

import rocui_common as rc


def _params(argv):
    params = {}
    for arg in argv:
        if "=" in arg:
            key, value = arg.split("=", 1)
            params[key.strip()] = value.strip()
    return params


def main():
    params = _params(sys.argv[1:])
    action = params.get("action", "")
    if action == "adult_gate":
        rc.adult_gate(params.get("target", "plugin.video.cumination"))
    elif action == "reset_pin":
        rc.reset_pin()
    elif action == "mode_cycle":
        rc.mode_cycle()
    elif action == "sync_daypart":
        rc.sync_daypart()
    elif action == "vpn_refresh":
        rc.publish_vpn_state()
    else:
        rc.log("default.py called with unknown action: %r" % action)


if __name__ == "__main__":
    main()
