# -*- coding: utf-8 -*-
"""
script.rocui — service entry point (starts at login).

Loop duties:
  * Daypart clock: keep Skin.String(RocOS.Mode) on the automatic
    Day/Midday/Night band unless Eric's manual override is alive.
  * Focus memory: remember the last focused control per window and
    restore it once when he returns to that window (design bible §2.2 /
    §5.2 — focus is never lost on screen transitions).
  * VPN surface: re-check the tunnel state and publish it to the Home
    window properties the dock shield reads (Phase 2 preparation — the
    hardware both-states gate is a later on-device phase).

Everything is best-effort and guarded: a helper that cannot read a
signal stays silent instead of breaking the shell.
"""
import time

import xbmc
import xbmcgui

import rocui_common as rc

POLL_SECONDS = 0.3
DAYPART_EVERY = 20.0   # seconds between daypart syncs
VPN_EVERY = 10.0       # seconds between VPN re-checks
FOCUS_STABLE = 1.2     # focus must rest this long before it is remembered
RESTORE_WINDOW = 1.5   # restore only within this long after a window opens
WEATHER_EVERY = 1800.0  # dock weather refresh (Open-Meteo via rocui_common)
NOTIFY_HOLD = 8.0       # seconds a notification stays flipped in the dock
PREVIEW_DWELL = 1.5     # rest this long on a poster before a preview starts
PREVIEW_WINDOWS = {10000, 1111, 1112, 1113, 1114, 1121, 1122, 1123}
HOME_FLYOUT_IDS = {941, 942, 943, 944, 945}  # remembered as the chip (921)


class RocMonitor(xbmc.Monitor):
    """Feeds real Kodi notifications to the service (dock flip)."""

    def __init__(self, service):
        super().__init__()
        self._service = service

    def onNotification(self, sender, method, data):
        try:
            self._service.handle_notification(sender, method, data)
        except Exception as exc:
            rc.log("notification hook failed: %s" % exc)


class RocUIService(object):
    def __init__(self):
        self.monitor = RocMonitor(self)
        self.focus_memory = rc.load_focus_memory()
        self.current_window = None
        self.window_opened_at = 0.0
        self.restored_for = None        # (window_id, opened_at) already done
        self.pending_focus = None       # (window_id, focus_id, since)
        self.last_daypart = 0.0
        self.last_vpn = 0.0
        self.last_weather = -WEATHER_EVERY + 5.0  # first fetch ~5s in
        self.notify_until = 0.0
        # dwell-preview state
        self.pv_key = None              # (win, focus, item-key) resting on
        self.pv_since = 0.0
        self.pv_active = False
        self.pv_started_at = 0.0
        self.pv_url = ""
        self.pv_saved_volume = None
        self.pv_dead = set()            # item keys that refused to play

    # ------------------------------------------------------------- focus
    def _flush_pending(self):
        if not self.pending_focus:
            return
        win_id, focus_id, _since = self.pending_focus
        # v3.2.0: never remember a Home flyout item as the restore
        # target — returning to Home with the flyout already open was
        # the "Extras won't go away" trap. Remember the chip instead.
        if win_id == rc.HOME_WINDOW_ID and focus_id in HOME_FLYOUT_IDS:
            focus_id = 921
        key = str(win_id)
        if self.focus_memory.get(key, {}).get("focus") != focus_id:
            self.focus_memory[key] = {
                "focus": focus_id, "updated": int(time.time())}
            rc.save_focus_memory(self.focus_memory)
        self.pending_focus = None

    # ------------------------------------------------------- notifications
    def handle_notification(self, sender, method, data):
        if method != "GUI.OnNotification":
            return
        payload = data
        if isinstance(payload, str):
            try:
                import json as _json
                payload = _json.loads(payload)
            except Exception:
                payload = {}
        if not isinstance(payload, dict):
            return
        text = payload.get("message") or payload.get("title") or ""
        title = payload.get("title") or "Kodi"
        if not text:
            return
        rc.publish_notification(title, text)
        self.notify_until = time.monotonic() + NOTIFY_HOLD

    # ------------------------------------------------------------ preview
    def _preview_item(self, win_id):
        """(key, url, title) for the focused container item, or None.
        Trailer wins; otherwise the item's own path. Buttons have no
        ListItem, so they never qualify — a natural focus guard."""
        try:
            title = xbmc.getInfoLabel("ListItem.Title") or ""
            if not title:
                return None
            trailer = xbmc.getInfoLabel("ListItem.Trailer") or ""
            path = xbmc.getInfoLabel("ListItem.FileNameAndPath") or ""
            url = trailer or path
            if not url or url.startswith("plugin://plugin.video."
                                         "themoviedb.helper/?info=details"):
                return None
            key = "%s|%s" % (win_id, url)
            return key, url, title
        except Exception:
            return None

    def _preview_stop(self):
        if not self.pv_active:
            return
        try:
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
        except Exception:
            pass
        try:
            if self.pv_saved_volume is not None:
                xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","method":"Application.SetVolume",'
                    '"params":{"volume":%d},"id":1}' % self.pv_saved_volume)
        except Exception:
            pass
        try:
            win = xbmcgui.Window(self.current_window or 10000)
            win.setProperty("RocPreview.Active", "")
        except Exception:
            pass
        self.pv_active = False
        self.pv_url = ""
        self.pv_saved_volume = None

    def _preview_tick(self, now):
        if rc.get_skin_string("RocOS.PreviewClips") == "off":
            if self.pv_active:
                self._preview_stop()
            return
        win_id, _focus = rc.current_window_and_focus()
        item = None
        if win_id in PREVIEW_WINDOWS and not xbmc.getCondVisibility(
                "VideoPlayer.IsFullscreen"):
            item = self._preview_item(win_id)
        if item is None:
            if self.pv_active:
                self._preview_stop()
            self.pv_key = None
            return
        key, url, _title = item
        if key in self.pv_dead:
            return
        if self.pv_active:
            if key != self.pv_key:
                self._preview_stop()
                self.pv_key = key
                self.pv_since = now
            elif not xbmc.Player().isPlaying() and \
                    now - self.pv_started_at > 3.0:
                # the preview ended on its own (short trailer)
                self._preview_stop()
                self.pv_key = None
            return
        if key != self.pv_key:
            self.pv_key = key
            self.pv_since = now
            return
        if now - self.pv_since < PREVIEW_DWELL:
            return
        # start the preview, windowed + muted, volume restored on stop
        try:
            vol = xbmc.getInfoLabel("Application.Volume")
            self.pv_saved_volume = int(float(vol)) if vol else None
            if self.pv_saved_volume is not None:
                xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","method":"Application.SetVolume",'
                    '"params":{"volume":0},"id":1}')
            xbmc.Player().play(url, windowed=True)
            win = xbmcgui.Window(win_id)
            win.setProperty("RocPreview.Active", "1")
            self.pv_active = True
            self.pv_url = url
            self.pv_started_at = now
        except Exception as exc:
            rc.log("preview start failed: %s" % exc)
            self.pv_dead.add(key)
            self._preview_stop()

    def _focus_tick(self, now):
        win_id, focus_id = rc.current_window_and_focus()
        if win_id is None:
            return
        try:
            rc.timeline_tick(win_id, focus_id)
        except Exception as exc:  # scrubber sync must never break the loop
            rc.log("timeline tick failed: %s" % exc)
        if win_id != self.current_window:
            # window changed: remember where we left the old one, then
            # restore where he left this one (once, promptly).
            self._flush_pending()
            self.current_window = win_id
            self.window_opened_at = now
            self.restored_for = None
        if win_id in rc.FOCUS_SKIP_WINDOWS:
            self.pending_focus = None
            return
        # restore pass — once per window entry, inside the entry window
        stored = self.focus_memory.get(str(win_id), {}).get("focus")
        if (stored and focus_id and stored != focus_id
                and self.restored_for != (win_id, self.window_opened_at)
                and now - self.window_opened_at <= RESTORE_WINDOW):
            if rc.restore_focus(win_id, stored):
                self.restored_for = (win_id, self.window_opened_at)
                focus_id = stored
        # remember pass — only focus that rests counts (skim = travel)
        if focus_id:
            if (not self.pending_focus
                    or self.pending_focus[0] != win_id
                    or self.pending_focus[1] != focus_id):
                self.pending_focus = (win_id, focus_id, now)
            elif now - self.pending_focus[2] >= FOCUS_STABLE:
                self._flush_pending()

    # -------------------------------------------------------------- main
    def run(self):
        rc.log("service starting")
        rc.sync_daypart()
        rc.publish_vpn_state()
        self.last_daypart = time.monotonic()
        self.last_vpn = time.monotonic()
        while not self.monitor.abortRequested():
            now = time.monotonic()
            try:
                self._focus_tick(now)
            except Exception as exc:  # never take the shell down with us
                rc.log("focus tick failed: %s" % exc)
            if now - self.last_daypart >= DAYPART_EVERY:
                self.last_daypart = now
                try:
                    rc.sync_daypart()
                except Exception as exc:
                    rc.log("daypart sync failed: %s" % exc)
            if now - self.last_vpn >= VPN_EVERY:
                self.last_vpn = now
                try:
                    rc.publish_vpn_state()
                except Exception as exc:
                    rc.log("vpn publish failed: %s" % exc)
            if now - self.last_weather >= WEATHER_EVERY:
                self.last_weather = now
                try:
                    rc.publish_weather()
                except Exception as exc:
                    rc.log("weather publish failed: %s" % exc)
            if self.notify_until and now > self.notify_until:
                self.notify_until = 0.0
                try:
                    rc.clear_notification()
                except Exception as exc:
                    rc.log("notify clear failed: %s" % exc)
            try:
                self._preview_tick(now)
            except Exception as exc:  # previews must never break the loop
                rc.log("preview tick failed: %s" % exc)
            if self.monitor.waitForAbort(POLL_SECONDS):
                break
        self._flush_pending()
        rc.log("service stopped")


if __name__ == "__main__":
    RocUIService().run()
