# -*- coding: utf-8 -*-
"""
script.rocui — WWE Timeline plugin source (Phase 3).

Serves the 447-event WWF/WWE PPV/PLE index to the War Room scrubber
(skin window 1113) as container content:

  plugin://script.rocui/                      -> the years (scrubber rail)
  plugin://script.rocui/?mode=years           -> same
  plugin://script.rocui/?mode=year&year=1998  -> that year's events,
                                                 date order

Year items carry Property(year) — the skin's focus sync
(rocui_common.timeline_tick) publishes the rested year as a window
property and the events pane reads it. Year items deliberately have an
EMPTY path: they are selectors, not destinations, and clicking one must
never try to "play" a year.

Event items point at Purely Wrestling's root (plugin.video
.purelywrestling) as folders: selecting one routes there, per the
Phase 3 spec. A per-event deep-link search inside the wrestling addons
is a later refinement and is NOT claimed here.

All data comes from rocui_common's timeline functions over the shipped
resources/data/ppv_events.json — this file is only the xbmc wrapper.
"""
import sys
from urllib.parse import parse_qsl

import xbmcgui
import xbmcplugin

import rocui_common as rc

PURELY_ROOT = "plugin://plugin.video.purelywrestling/"
BADGE_ART = "special://skin/media/rocos-badge-gold.png"


def _params(query):
    if query.startswith("?"):
        query = query[1:]
    return dict(parse_qsl(query))


def build_years(handle, events):
    """One selector item per year, ascending. Returns the item count."""
    count = 0
    for year, num in rc.timeline_years(events):
        item = xbmcgui.ListItem(label=str(year))
        item.setLabel2("%d EVENTS" % num)
        item.setProperty("year", str(year))
        item.setProperty("era", rc.timeline_year_era(year))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, "", item, False)
        count += 1
    return count


def build_year(handle, events, year):
    """One year's events in date order. Returns the item count."""
    count = 0
    for event in rc.timeline_events_for_year(events, year):
        pretty = rc.format_event_date(event["date"])
        item = xbmcgui.ListItem(label=str(event["name"]))
        item.setLabel2("%s - %s" % (pretty, event.get("promotion", "")))
        item.setProperty("date", str(event["date"]))
        item.setProperty("promotion", str(event.get("promotion", "")))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, PURELY_ROOT, item, True)
        count += 1
    return count


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    handle = int(argv[1]) if len(argv) > 1 else -1
    params = _params(argv[2] if len(argv) > 2 else "")
    events = rc.load_timeline()
    xbmcplugin.setContent(handle, "videos")
    if params.get("mode") == "year":
        build_year(handle, events, params.get("year"))
    else:
        build_years(handle, events)
    xbmcplugin.endOfDirectory(handle)


if __name__ == "__main__":
    main()
