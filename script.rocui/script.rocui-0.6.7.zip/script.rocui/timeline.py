# -*- coding: utf-8 -*-
"""
script.rocui -- plugin source (the addon's xbmc.python.pluginsource).

Serves this addon's own directories to the skin:

  plugin://script.rocui/?mode=collections&cat=<stage cat>
      -> Eric's named collections for that stage category
  plugin://script.rocui/?mode=collection&id=<id>
      -> one collection's members (named titles via TMDb Helper)
  plugin://script.rocui/?mode=movierow&list=upcoming|now_playing
      -> the Movies hub's date-gated rows
  plugin://script.rocui/?mode=history&src=<tokens>
  plugin://script.rocui/?mode=continue&src=<tokens>
      -> the per-profile playback history store (continue = unfinished)
  plugin://script.rocui/?mode=augustmusic&list=<key>
      -> August's playlist directory (FIX PASS 2026-11-09)
  plugin://script.rocui/?mode=toonime&shelf=<toons|anime|anime-movies>
      -> one Toonime hub shelf from the sealed catalog
         (rocui_common.toonime_shelf_items; TOONIME FIX 2026-11-09)
  plugin://script.rocui/?mode=search&tmdb_type=movie|tv[&q=...][&page=N]
      -> the August search route (SEARCH FILTER 2026-11-09): no q =
         keyboard prompt, then rocui's own TMDB search filtered to
         the allowed rating set BEFORE any item is served
         (rocui_common.search_items); rows are folders into
         ?mode=detail&coll=search. Only the KidsWall skin doors
         route here; every other profile keeps the Helper search.
  plugin://script.rocui/?mode=ia_search&q=...&media=video|audio
             [&collection=<slug>][&page=N]
      -> archive.org keyword search (rocui_ia, ARCHIVE FIX
         2026-11-09); no q = keyboard prompt, then results
  plugin://script.rocui/?mode=ia_item&id=<identifier>&media=...
      -> one Archive item's playable files as playable leaves
  plugin://script.rocui/?mode=ia_play&id=<identifier>&file=...
      -> resolves one file to its archive.org URL (setResolvedUrl)
  plugin://script.rocui/?mode=ia_lt
      -> the Classic Looney Tunes shelf (baked lt_shorts.json)
  plugin://script.rocui/?mode=ia_root
      -> the Fringe menu: search + ported collection doors
  plugin://script.rocui/?mode=detail&coll=...&tmdb_id=...
      -> a collection title's detail page (rocui_common)
  plugin://script.rocui/?mode=emptyrow
      -> an intentionally empty directory (kid profiles' Trakt rows)

The WWE timeline source that used to root here (the 447-event
PPV/PLE years rail) was removed 2026-11-09 with the Wrestling
section itself (Eric's decision: WWE lives under Sports and via
search). Bare and unknown modes now end as an empty directory.
The canonical event dataset stays in the workspace records
(~/workspace/kodi-build/timeline/ppv_events.json); it no longer
ships inside the addon.
"""
import sys
from urllib.parse import parse_qsl, quote_plus

import xbmcgui
import xbmcplugin

import rocui_common as rc
import rocui_ia as ia

BADGE_ART = "special://skin/media/rocos-badge-gold.png"


def _params(query):
    """Plugin query string ('?mode=...&...') -> dict. (This helper
    was called by main() but never defined in the shipped tree --
    every pluginsource invocation raised NameError before dispatch;
    defined now, ARCHIVE FIX 2026-11-09, on the parse_qsl import
    that was already here.)"""
    query = (query or "").lstrip("?")
    try:
        return dict(parse_qsl(query, keep_blank_values=True))
    except Exception:
        return {}

# ---------------------------------------------------------------------------
# v3.4.0 — THE LOOK PASS: stage Collections row + history shelves.
#
#   ?mode=collections&cat=home|movies|tv|toonime|sports|music
#       -> Eric's named collections for that stage category (rocui_common
#          COLLECTIONS: his Trakt lists, the Classics catalog,
#          horror, Herbie — nothing he didn't name).
#   ?mode=collection&id=<id>
#       -> one collection's members: named titles via TMDb Helper
#          search.
#   ?mode=movierow&list=upcoming|now_playing
#       -> the Movies hub's COMING SOON / IN THEATERS NOW rows,
#          date-gated on each title's primary release_date
#          (0.5.15; see rocui_common.movie_row_items).
#   ?mode=history&src=<tokens>   -> the per-profile playback history
#   ?mode=continue&src=<tokens>  -> the same store, unfinished only
#       (Adult shelves pass src=cumination; the stage's per-category
#       Continue Watching passes its addons' tokens.)
# ---------------------------------------------------------------------------
def build_collections(handle, cat):
    count = 0
    for tile in rc.collections_for(cat):
        item = xbmcgui.ListItem(label=tile["label"])
        item.setLabel2(tile["sub"])
        item.setInfo("video", {"plot": tile["plot"]})
        # The badge stays as the icon/fallback; the stage rows render
        # Art(poster)/Art(thumb), so the tile's real art must ride
        # along or the tile paints nothing (0.5.0 defect).
        art = {"icon": BADGE_ART}
        art.update(tile.get("art") or {})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(handle, tile["path"], item, True)
        count += 1
    return count


def build_collection(handle, cid):
    count = 0
    for row in rc.collection_detail(cid):
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        art = {"icon": BADGE_ART}
        art.update(row.get("art") or {})
        item.setArt(art)
        if row.get("tmdb_id"):
            # 0.5.12: a title poster whose click opens its title.
            # The row carries the title's TMDB identity as item
            # properties (the same properties the stage's
            # stage_open reads off Helper-fed rows) and is served
            # as a FOLDER into this plugin's own detail mode —
            # because in the Videos window (10025) a click is
            # Kodi's built-in activation, which dispatches folders
            # and playable leaves only. The 0.5.7 leaf carrying
            # the Helper details route was neither (no IsPlayable
            # property, and the details route only ever returns
            # Helper's basedir listing), so its clicks were inert
            # on hardware (Loops 110/118/119b). The folder lands
            # in rocui_common.open_collection_title, which performs
            # the stage_open-identical RocStage publish into the
            # detail window (1124). (0.5.6's folders pointed at
            # the Helper route itself: the click navigated into a
            # directory listing — the room-stick folder loop.
            # The dispatch was never the problem; the
            # destination was.)
            item.setProperty("tmdb_id", str(row["tmdb_id"]))
            item.setProperty("tmdb_type", row.get("tmdb_type") or "")
            item.setInfo("video", {"title": row["label"]})
            xbmcplugin.addDirectoryItem(
                handle,
                "plugin://script.rocui/?mode=detail&coll=%s"
                "&tmdb_id=%s&tmdb_type=%s"
                % (cid, row["tmdb_id"], row.get("tmdb_type") or ""),
                item, True)
        else:
            xbmcplugin.addDirectoryItem(handle, row["path"], item,
                                        True)
        count += 1
    return count


def build_movie_row(handle, list_name):
    """0.5.15 (Player Fix Lane, Hand A): one date-gated Movies-hub
    row (COMING SOON / IN THEATERS NOW) from rocui_common.
    movie_row_items -- the Helper's verbatim /movie/upcoming and
    /movie/now_playing pass-through carries decades-old titles on
    the strength of regional re-release dates, and nothing in the
    old chain ever gated on the title's primary release_date.
    Rows are served exactly like collection title rows: folders
    into this plugin's own detail mode (coll=movierow-<list>),
    which open_collection_title resolves from the title's TMDB
    record, so a click opens the title's detail page by the proven
    dispatch. Skin wiring (coordinator/other hand): hub content
    plugin://script.rocui/?mode=movierow&list=upcoming and
    ?mode=movierow&list=now_playing replace the Helper
    info=upcoming / info=now_playing content paths."""
    count = 0
    for row in rc.movie_row_items(list_name):
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        art = {"icon": BADGE_ART}
        art.update(row.get("art") or {})
        item.setArt(art)
        item.setProperty("tmdb_id", str(row["tmdb_id"]))
        item.setProperty("tmdb_type", row.get("tmdb_type") or "")
        item.setInfo("video", {"title": row["label"]})
        xbmcplugin.addDirectoryItem(
            handle,
            "plugin://script.rocui/?mode=detail&coll=movierow-%s"
            "&tmdb_id=%s&tmdb_type=%s"
            % (list_name, row["tmdb_id"],
               row.get("tmdb_type") or ""),
            item, True)
        count += 1
    return count


def build_toonime_shelf(handle, shelf_id):
    """TOONIME FIX 2026-11-09: one Toonime hub shelf (toons /
    anime / anime-movies) served from rocui's sealed catalog
    (rocui_common.toonime_shelf_items) -- the build_collection
    dispatch exactly: title rows are FOLDERS into this plugin's
    own detail mode (coll=toonime-<shelf>), carrying the title's
    tmdb_id/tmdb_type as item properties, so a tap lands in
    rocui_common.open_collection_title's toonime- branch and from
    there in the Detail window (1124), identical to a Movies/TV
    title. The badge is the icon/fallback; a title with no TMDB
    art of its own (Phantom Investigators) renders the badge --
    never a placeholder or an unrelated image."""
    count = 0
    for row in rc.toonime_shelf_items(shelf_id):
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        art = {"icon": BADGE_ART}
        art.update(row.get("art") or {})
        item.setArt(art)
        item.setProperty("tmdb_id", str(row["tmdb_id"]))
        item.setProperty("tmdb_type", row.get("tmdb_type") or "")
        info = {"title": row["label"]}
        if row.get("year"):
            info["year"] = int(row["year"])
        item.setInfo("video", info)
        xbmcplugin.addDirectoryItem(
            handle,
            "plugin://script.rocui/?mode=detail&coll=toonime-%s"
            "&tmdb_id=%s&tmdb_type=%s"
            % (shelf_id, row["tmdb_id"], row.get("tmdb_type") or ""),
            item, True)
        count += 1
    return count


def build_history(handle, src, continue_only):
    count = 0
    for entry in rc.history_filtered(src, continue_only):
        snap = entry.get("snap") or {}
        label = rc.snapshot_display(snap) or snap.get("title") or ""
        if not label:
            continue
        pct = float(entry.get("pct") or 0)
        when = ""
        try:
            import datetime as _dt
            when = _dt.datetime.fromtimestamp(
                float(entry.get("ts") or 0)).strftime("%b %d")
        except Exception:
            when = ""
        label2 = "LEFT OFF %s OF %s%s" % (
            rc.fmt_clock(entry.get("position") or 0),
            rc.fmt_clock(entry.get("duration") or 0),
            (" - " + when) if when else "")
        if pct >= 97.0:
            label2 = "WATCHED IN FULL%s" % ((" - " + when) if when else "")
        item = xbmcgui.ListItem(label=label)
        item.setLabel2(label2)
        item.setProperty("IsPlayable", "true")
        art = {}
        if snap.get("thumb"):
            art["thumb"] = snap["thumb"]
        if snap.get("fanart"):
            art["fanart"] = snap["fanart"]
        if art:
            item.setArt(art)
        xbmcplugin.addDirectoryItem(handle, snap.get("path") or "",
                                    item, False)
        count += 1
    return count


def _directory_content(mode, params):
    """Kodi content type for one plugin directory (Loop 117).

    Collection title pages MUST declare movies/tvshows, not "videos":
    skin.rocos panel 50 (the primary Videos list) is visible only for
    movies/tvshows/musicvideos/actors/sets/seasons content, and its
    files branch explicitly excludes plugin:// folder paths -- with
    "videos" panel 50 is invisible, the window's defaultcontrol 50
    fails ("Control 50 in window 10025 has been asked to focus, but
    it can't", Loop 110 log 05:26:13 at the collection open), and
    the fallback 550 view's items do not activate on ENTER or
    DPAD_CENTER (Loop 110 step 5 caveat A: screenshots 62/65 show
    focus moving over the Love Bug shelf while clicks stay dead
    with no log lines). Declaring the collection's own media type
    puts the page on panel 50, the skin's standard, proven list.
    Path-based collections (one folder row to a Trakt/discover
    destination) and all other modes keep "videos": their rows are
    folders, and no dead-click evidence exists for them.
    """
    if mode == "collection":
        c = rc._COLLECTIONS_BY_ID.get(params.get("id", ""))
        if c and c.get("titles"):
            return "movies" if rc._coll_tmdb_type(c) == "movie" else "tvshows"
        return "videos"
    if mode == "collections":
        if params.get("cat") == "movies":
            return "movies"
        if params.get("cat") == "tv":
            return "tvshows"
        return "videos"
    if mode == "movierow":
        return "movies"
    if mode == "toonime":
        # Loop 117 law, same as collections: the Videos window's
        # panel 50 renders only for movies/tvshows content.
        return "movies" if params.get("shelf") == "anime-movies" \
            else "tvshows"
    if mode == "search":
        # Loop 117 law, same as above: movies / tvshows by the
        # door's own type, never "videos".
        return "tvshows" if params.get("tmdb_type") == "tv" \
            else "movies"
    if mode == "ia_search":
        return "songs" if params.get("media") == "audio" else "videos"
    if mode == "ia_item":
        return "songs" if params.get("media") == "audio" else "videos"
    if mode == "ia_lt":
        # Loop 117 law (plan step 2): title rows declare movies,
        # never "videos".
        return "movies"
    return "videos"


def build_august_music(handle, list_key):
    """FIX PASS 2026-11-09: August's playlist directory. Serves the
    seeder cache (rocui_common.august_music_seed) as ordinary
    display-only ListItems for windows 1132/1133/1134's panels --
    the supported directory-source mechanism, replacing the dead
    XSPF-file <content> path. Items are IsPlayable=false by design:
    August's playback is the Spotify app door (Eric's ruling); a tap
    does nothing playable and nothing pretends otherwise."""
    count = 0
    try:
        data = rc._read_json(rc.AUGUST_MUSIC_CACHE)
        tracks = ((data.get("items") or {}).get(list_key)) or []
    except Exception:
        tracks = []
    for track in tracks:
        item = xbmcgui.ListItem(label=track.get("title") or "")
        if track.get("artist"):
            item.setInfo("music", {"artist": track["artist"],
                                   "title": track.get("title") or ""})
        item.setArt({"icon": BADGE_ART})
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle, "", item, False)
        count += 1
    return count


# ---------------------------------------------------------------------------
# SEARCH FILTER 2026-11-09 -- the August search route (mode=search).
# The skin's 3 movie/TV search doors swap to this route ONLY under
# KidsWall (the onclick pair on Home 940 / hub 1111 751 / hub 1112
# 751); every other profile keeps the TMDb Helper's dir_search,
# byte-identical. Results come from rocui's own TMDB mini-client
# through rocui_common.search_items, which joins each result's US
# certification and drops over-line / unrated titles BEFORE any
# item is added here -- an over-line title never becomes a
# ListItem. No search-history rows are served on this route (the
# Helper's history items are never reproduced). Every failure
# shape -- empty result set, everything filtered out, the API
# down -- ends the directory cleanly with a notification and no
# exception (main()'s shared endOfDirectory closes the listing).
# ---------------------------------------------------------------------------
def _search_notify(msg):
    try:
        rc.notify("Search", msg, ok=False)
    except Exception:
        pass


def _prompt_title_search(tmdb_type):
    """Keyboard prompt for the August search doors (mode=search
    with no q): the build_ia_search pattern -- prompt first,
    results in the same invocation. '' on cancel / unavailable."""
    try:
        dlg = xbmcgui.Dialog()
        heading = "Search TV Shows" if tmdb_type == "tv" \
            else "Search Movies"
        text = dlg.input(heading,
                         type=getattr(xbmcgui, "INPUT_ALPHANUM", 0))
        return (text or "").strip()
    except Exception:
        return ""


def build_search(handle, params):
    tmdb_type = "tv" if params.get("tmdb_type") == "tv" else "movie"
    q = (params.get("q") or "").strip()
    if not q:
        q = _prompt_title_search(tmdb_type)
        if not q:
            return 0
    try:
        page = int(params.get("page") or 1)
    except Exception:
        page = 1
    rows, has_more, next_page = rc.search_items(q, tmdb_type, page)
    if not rows:
        _search_notify("Nothing at or under the rating line came "
                       "back for that search.")
        return 0
    count = 0
    for row in rows:
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        art = {"icon": BADGE_ART}
        art.update(row.get("art") or {})
        item.setArt(art)
        item.setProperty("tmdb_id", str(row["tmdb_id"]))
        item.setProperty("tmdb_type", row.get("tmdb_type") or "")
        info = {"title": row["label"]}
        if row.get("year"):
            try:
                info["year"] = int(row["year"])
            except Exception:
                pass
        if row.get("rating"):
            info["mpaa"] = "Rated %s" % row["rating"]
        item.setInfo("video", info)
        xbmcplugin.addDirectoryItem(
            handle,
            "plugin://script.rocui/?mode=detail&coll=search"
            "&tmdb_id=%s&tmdb_type=%s"
            % (row["tmdb_id"], row.get("tmdb_type") or ""),
            item, True)
        count += 1
    if has_more:
        nxt = xbmcgui.ListItem(label="NEXT PAGE >")
        nxt.setProperty("IsPlayable", "false")
        nxt.setArt({"icon": BADGE_ART, "thumb": BADGE_ART})
        xbmcplugin.addDirectoryItem(
            handle,
            "plugin://script.rocui/?mode=search&q=%s&tmdb_type=%s"
            "&page=%d" % (quote_plus(q), tmdb_type, next_page),
            nxt, True)
        count += 1
    return count


# ---------------------------------------------------------------------------
# ARCHIVE FIX 2026-11-09 -- Internet Archive doors (rocui_ia).
# Every builder fails CLEAN: an API that does not answer, or a search
# with no results, ends the directory with a notification and no
# exception (the retired add-on's own end-of-directory shape).
# ---------------------------------------------------------------------------
def _ia_notify(msg):
    try:
        rc.notify("Internet Archive", msg, ok=False)
    except Exception:
        pass


def _prompt_search_text(media):
    """Keyboard prompt for the interactive ARCHIVE SEARCH chips
    (mode=ia_search with no q). '' on cancel / unavailable."""
    try:
        dlg = xbmcgui.Dialog()
        heading = "Search Internet Archive (%s)" % (
            "Audio" if media == "audio" else "Video")
        text = dlg.input(heading, type=xbmcgui.INPUT_ALPHANUM)
        return (text or "").strip()
    except Exception:
        return ""


def build_ia_search(handle, params):
    media = "audio" if params.get("media") == "audio" else "video"
    collection = params.get("collection") or ""
    q = (params.get("q") or "").strip()
    interactive = False
    if not q and not collection:
        # The chips: keyboard first, results in the same invocation
        # (the standard Kodi search-plugin pattern).
        interactive = True
        q = _prompt_search_text(media)
        if not q:
            return 0
    elif not q:
        # A collection door (ia_root): browse the collection itself.
        interactive = False
    else:
        # Baked panel / VIEW MORE doors carry q: pure keyword
        # semantics, no junk floors (plan step 1).
        interactive = False
    try:
        page = int(params.get("page") or 1)
    except Exception:
        page = 1
    result = ia.search_items(q, media, page, collection or None,
                             interactive=interactive)
    if result.get("error"):
        _ia_notify("Archive.org did not answer. Try again in a bit.")
        return 0
    items = result.get("items") or []
    if not items:
        _ia_notify("No results on the Archive for that search.")
        return 0
    count = 0
    for row in items:
        item = xbmcgui.ListItem(label=row["title"])
        if row.get("year"):
            item.setLabel2(str(row["year"]))
        info_type = "music" if media == "audio" else "video"
        info = {"title": row["title"], "plot": row.get("plot") or ""}
        if row.get("year"):
            info["year"] = row["year"]
        item.setInfo(info_type, info)
        item.setArt({"icon": row["thumb"], "thumb": row["thumb"]})
        # Folders, born IsPlayable=false: a tap expands the item
        # (mode=ia_item) -- the F1 bug class asserted dead.
        item.setProperty("IsPlayable", "false")
        url = ("plugin://script.rocui/?mode=ia_item&id=%s&media=%s"
               % (quote_plus(row["identifier"]), media))
        xbmcplugin.addDirectoryItem(handle, url, item, True)
        count += 1
    total = int(result.get("total") or 0)
    if page * 100 < total:
        nxt = xbmcgui.ListItem(label="NEXT PAGE >")
        nxt.setProperty("IsPlayable", "false")
        nxt.setArt({"icon": BADGE_ART, "thumb": BADGE_ART})
        url = ("plugin://script.rocui/?mode=ia_search&q=%s&media=%s"
               "&page=%d" % (quote_plus(q), media, page + 1))
        if collection:
            url += "&collection=%s" % quote_plus(collection)
        xbmcplugin.addDirectoryItem(handle, url, nxt, True)
        count += 1
    return count


def build_ia_item(handle, params):
    media = "audio" if params.get("media") == "audio" else "video"
    ident = params.get("id") or ""
    if not ident:
        _ia_notify("That Archive item has no identifier.")
        return 0
    files = ia.playable_files(ident, media)
    if not files:
        if ia.item_metadata(ident) is None:
            _ia_notify("Archive.org did not answer. Try again in a "
                       "bit.")
        else:
            _ia_notify("No playable files in that Archive item.")
        return 0
    thumb = ia.IMG_URL % quote_plus(ident)
    count = 0
    for f in files:
        item = xbmcgui.ListItem(label=ia.clean_file_label(f))
        item.setInfo("music" if media == "audio" else "video",
                     {"title": ia.clean_file_label(f)})
        item.setArt({"icon": thumb, "thumb": thumb})
        item.setProperty("IsPlayable", "true")
        url = ("plugin://script.rocui/?mode=ia_play&id=%s&file=%s"
               "&media=%s" % (quote_plus(ident),
                              quote_plus(f["name"]), media))
        xbmcplugin.addDirectoryItem(handle, url, item, False)
        count += 1
    return count


def ia_play_resolve(handle, params):
    """mode=ia_play: resolve from cached metadata to the file's
    https archive.org URL and setResolvedUrl. Never raises; a
    failure resolves False so Kodi shows its own could-not-play
    surface instead of hanging."""
    media = "audio" if params.get("media") == "audio" else "video"
    ident = params.get("id") or ""
    url = None
    try:
        url = ia.resolve_url(ident, params.get("file") or None, media)
    except Exception:
        url = None
    if not url:
        _ia_notify("That Archive file could not be resolved.")
        try:
            xbmcplugin.setResolvedUrl(handle, False,
                                      xbmcgui.ListItem())
        except Exception:
            pass
        return False
    item = xbmcgui.ListItem(path=url)
    item.setProperty("IsPlayable", "true")
    try:
        xbmcplugin.setResolvedUrl(handle, True, item)
    except Exception:
        return False
    return True


def build_ia_lt(handle):
    """The Classic Looney Tunes shelf: one playable row per baked
    short (label 'Title (Year)'), art = the short's own .thumbs/
    still, path = mode=ia_play against ltmm-publicdomain + the
    short's original encode (resolved at tap time)."""
    count = 0
    for row in ia.lt_shorts():
        label = row["title"]
        if row.get("year"):
            label = "%s (%s)" % (row["title"], row["year"])
        item = xbmcgui.ListItem(label=label)
        info = {"title": row["title"],
                "plot": row.get("note") or ""}
        if row.get("year"):
            info["year"] = int(row["year"])
        item.setInfo("video", info)
        art = {}
        if row.get("thumb_url"):
            art = {"icon": row["thumb_url"], "thumb": row["thumb_url"],
                   "poster": row["thumb_url"]}
        item.setArt(art)
        item.setProperty("IsPlayable", "true")
        url = ("plugin://script.rocui/?mode=ia_play&id=%s&file=%s"
               "&media=video" % (ia.LT_IDENTIFIER,
                                  quote_plus(row["file"])))
        xbmcplugin.addDirectoryItem(handle, url, item, False)
        count += 1
    return count


def build_ia_root(handle):
    """The Fringe menu (replaces the retired add-on's root menu +
    splash): Search Video / Search Audio / the ported collections
    as data. Collection doors are mode=ia_search&collection=<slug>
    with no q (browse, never a keyboard prompt)."""
    count = 0
    doors = [
        ("Search Video", "Search the Archive's video",
         "plugin://script.rocui/?mode=ia_search&media=video&page=1"),
        ("Search Audio", "Search the Archive's audio",
         "plugin://script.rocui/?mode=ia_search&media=audio&page=1"),
    ]
    for slug, label, sub, media in ia.COLLECTIONS:
        doors.append((label, sub,
                      "plugin://script.rocui/?mode=ia_search"
                      "&collection=%s&media=%s&page=1"
                      % (quote_plus(slug), media)))
    for label, sub, url in doors:
        item = xbmcgui.ListItem(label=label)
        item.setLabel2(sub)
        item.setInfo("video", {"title": label, "plot": sub})
        item.setArt({"icon": BADGE_ART, "thumb": BADGE_ART})
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle, url, item, True)
        count += 1
    return count


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    handle = int(argv[1]) if len(argv) > 1 else -1
    params = _params(argv[2] if len(argv) > 2 else "")
    mode = params.get("mode")
    if mode == "augustmusic":
        xbmcplugin.setContent(handle, "songs")
        build_august_music(handle, params.get("list", ""))
        xbmcplugin.endOfDirectory(handle)
        return
    if mode == "ia_play":
        # Playable-leaf resolution: setResolvedUrl ends the
        # invocation; no directory is served.
        ia_play_resolve(handle, params)
        return
    xbmcplugin.setContent(handle, _directory_content(mode, params))
    if mode == "ia_search":
        build_ia_search(handle, params)
    elif mode == "ia_item":
        build_ia_item(handle, params)
    elif mode == "ia_lt":
        build_ia_lt(handle)
    elif mode == "ia_root":
        build_ia_root(handle)
    elif mode == "collections":
        build_collections(handle, params.get("cat", "home"))
    elif mode == "collection":
        build_collection(handle, params.get("id", ""))
    elif mode == "movierow":
        build_movie_row(handle, params.get("list", ""))
    elif mode == "toonime":
        build_toonime_shelf(handle, params.get("shelf", ""))
    elif mode == "search":
        build_search(handle, params)
    elif mode == "detail":
        # 0.5.13: the handle goes in so open_collection_title can
        # end the directory BEFORE activating 1124 (see its
        # docstring); it ends it on every path, so main must not
        # end it again below.
        try:
            rc.open_collection_title(params, handle)
        except Exception:
            try:
                xbmcplugin.endOfDirectory(handle, succeeded=False)
            except Exception:
                pass
        return
    elif mode == "emptyrow":
        # PM-2 rotation B (merge run 2026-11-07): the skin's
        # Trakt-fed row contents resolve through Includes.xml
        # variables; in kid profiles (RocProfiles.NoTrakt) they
        # resolve HERE instead of to the Helper's Trakt routes.
        # An intentionally empty directory: no provider is
        # queried, so the Helper's 401 auth dialog can never
        # fire from a kid profile's rows. (The shared
        # endOfDirectory below closes the listing.)
        pass
    elif mode == "history":
        build_history(handle, params.get("src", ""), False)
    elif mode == "continue":
        build_history(handle, params.get("src", ""), True)
    else:
        # Bare / unknown mode: an empty directory. The wrestling
        # years rail that used to land here was removed with the
        # section (2026-11-09).
        pass
    xbmcplugin.endOfDirectory(handle, succeeded=(mode != "detail"))


if __name__ == "__main__":
    main()
