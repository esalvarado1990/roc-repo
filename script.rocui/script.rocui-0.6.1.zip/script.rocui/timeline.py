# -*- coding: utf-8 -*-
"""
script.rocui — WWE Timeline plugin source (Phase 3).

Serves the 447-event WWF/WWE PPV/PLE index to the War Room scrubber
(skin window 1113) as container content:

  plugin://script.rocui/                      -> the years (scrubber rail)
  plugin://script.rocui/?mode=years           -> same
  plugin://script.rocui/?mode=year&year=1998  -> that year's events,
                                                 date order

Year items are real destinations (v3.1.0 Simple Line — Eric,
2026-10-24 02:29/02:47): each year item's path is this same source at
?mode=year&year=YYYY, so clicking a year opens that year's events by
plain plugin navigation. (The v3.0 design used EMPTY paths + a service
focus sync publishing a window property the events pane read; on real
hardware the clicks were dead and the pane froze on the default year.
That machinery is gone from the flow — no Latest-year landing anywhere.)

Event items point at Purely Wrestling's root (plugin.video
.purelywrestling) as folders: selecting one routes there, per the
Phase 3 spec. A per-event deep-link search inside the wrestling addons
is a later refinement and is NOT claimed here.

All data comes from rocui_common's timeline functions over the shipped
resources/data/ppv_events.json — this file is only the xbmc wrapper.
"""
import sys
from urllib.parse import parse_qsl

import xbmcgui
import xbmcplugin

import rocui_common as rc

PURELY_ROOT = "plugin://plugin.video.purelywrestling/"
BADGE_ART = "special://skin/media/rocos-badge-gold.png"


def _params(query):
    if query.startswith("?"):
        query = query[1:]
    return dict(parse_qsl(query))


def build_years(handle, events):
    """One item per year, ascending; each is a folder into that year's
    events (its own ?mode=year path). Label2 carries the era, labeled
    era-correct: WWF for the pre-rename years, WWE after (Eric,
    2026-10-24 02:49). Returns the item count."""
    count = 0
    for year, num in rc.timeline_years(events):
        item = xbmcgui.ListItem(label=str(year))
        item.setLabel2("%s - %d EVENTS" % (rc.timeline_year_era(year), num))
        item.setProperty("year", str(year))
        item.setProperty("era", rc.timeline_year_era(year))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(
            handle, "plugin://script.rocui/?mode=year&year=%s" % year,
            item, True)
        count += 1
    return count


def build_year(handle, events, year):
    """One year's events in date order. Returns the item count."""
    count = 0
    for event in rc.timeline_events_for_year(events, year):
        pretty = rc.format_event_date(event["date"])
        item = xbmcgui.ListItem(label=str(event["name"]))
        item.setLabel2("%s - %s" % (pretty, event.get("promotion", "")))
        item.setProperty("date", str(event["date"]))
        item.setProperty("promotion", str(event.get("promotion", "")))
        item.setArt({"icon": BADGE_ART})
        xbmcplugin.addDirectoryItem(handle, PURELY_ROOT, item, True)
        count += 1
    return count


# ---------------------------------------------------------------------------
# v3.4.0 — THE LOOK PASS: stage Collections row + history shelves.
#
#   ?mode=collections&cat=home|movies|tv|wrestling|toonime|sports|music
#       -> Eric's named collections for that stage category (rocui_common
#          COLLECTIONS: his Trakt lists, the Classics catalog, the
#          wrestling eras, horror, Herbie — nothing he didn't name).
#   ?mode=collection&id=<id>
#       -> one collection's members: named titles via TMDb Helper
#          search, era years via the timeline's own year folders.
#   ?mode=movierow&list=upcoming|now_playing
#       -> the Movies hub's COMING SOON / IN THEATERS NOW rows,
#          date-gated on each title's primary release_date
#          (0.5.15; see rocui_common.movie_row_items).
#   ?mode=history&src=<tokens>   -> the per-profile playback history
#   ?mode=continue&src=<tokens>  -> the same store, unfinished only
#       (Adult shelves pass src=cumination; the stage's per-category
#       Continue Watching passes its addons' tokens.)
# ---------------------------------------------------------------------------
def build_collections(handle, cat):
    count = 0
    for tile in rc.collections_for(cat):
        item = xbmcgui.ListItem(label=tile["label"])
        item.setLabel2(tile["sub"])
        item.setInfo("video", {"plot": tile["plot"]})
        # The badge stays as the icon/fallback; the stage rows render
        # Art(poster)/Art(thumb), so the tile's real art must ride
        # along or the tile paints nothing (0.5.0 defect).
        art = {"icon": BADGE_ART}
        art.update(tile.get("art") or {})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(handle, tile["path"], item, True)
        count += 1
    return count


def build_collection(handle, cid, events):
    count = 0
    for row in rc.collection_detail(cid, events):
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        art = {"icon": BADGE_ART}
        art.update(row.get("art") or {})
        item.setArt(art)
        if row.get("tmdb_id"):
            # 0.5.12: a title poster whose click opens its title.
            # The row carries the title's TMDB identity as item
            # properties (the same properties the stage's
            # stage_open reads off Helper-fed rows) and is served
            # as a FOLDER into this plugin's own detail mode —
            # because in the Videos window (10025) a click is
            # Kodi's built-in activation, which dispatches folders
            # and playable leaves only. The 0.5.7 leaf carrying
            # the Helper details route was neither (no IsPlayable
            # property, and the details route only ever returns
            # Helper's basedir listing), so its clicks were inert
            # on hardware (Loops 110/118/119b). The folder lands
            # in rocui_common.open_collection_title, which performs
            # the stage_open-identical RocStage publish into the
            # detail window (1124). (0.5.6's folders pointed at
            # the Helper route itself: the click navigated into a
            # directory listing — the room-stick folder loop.
            # The dispatch was never the problem; the
            # destination was.)
            item.setProperty("tmdb_id", str(row["tmdb_id"]))
            item.setProperty("tmdb_type", row.get("tmdb_type") or "")
            item.setInfo("video", {"title": row["label"]})
            xbmcplugin.addDirectoryItem(
                handle,
                "plugin://script.rocui/?mode=detail&coll=%s"
                "&tmdb_id=%s&tmdb_type=%s"
                % (cid, row["tmdb_id"], row.get("tmdb_type") or ""),
                item, True)
        else:
            xbmcplugin.addDirectoryItem(handle, row["path"], item,
                                        True)
        count += 1
    return count


def build_movie_row(handle, list_name):
    """0.5.15 (Player Fix Lane, Hand A): one date-gated Movies-hub
    row (COMING SOON / IN THEATERS NOW) from rocui_common.
    movie_row_items -- the Helper's verbatim /movie/upcoming and
    /movie/now_playing pass-through carries decades-old titles on
    the strength of regional re-release dates, and nothing in the
    old chain ever gated on the title's primary release_date.
    Rows are served exactly like collection title rows: folders
    into this plugin's own detail mode (coll=movierow-<list>),
    which open_collection_title resolves from the title's TMDB
    record, so a click opens the title's detail page by the proven
    dispatch. Skin wiring (coordinator/other hand): hub content
    plugin://script.rocui/?mode=movierow&list=upcoming and
    ?mode=movierow&list=now_playing replace the Helper
    info=upcoming / info=now_playing content paths."""
    count = 0
    for row in rc.movie_row_items(list_name):
        item = xbmcgui.ListItem(label=row["label"])
        item.setLabel2(row["sub"])
        art = {"icon": BADGE_ART}
        art.update(row.get("art") or {})
        item.setArt(art)
        item.setProperty("tmdb_id", str(row["tmdb_id"]))
        item.setProperty("tmdb_type", row.get("tmdb_type") or "")
        item.setInfo("video", {"title": row["label"]})
        xbmcplugin.addDirectoryItem(
            handle,
            "plugin://script.rocui/?mode=detail&coll=movierow-%s"
            "&tmdb_id=%s&tmdb_type=%s"
            % (list_name, row["tmdb_id"],
               row.get("tmdb_type") or ""),
            item, True)
        count += 1
    return count


def build_history(handle, src, continue_only):
    count = 0
    for entry in rc.history_filtered(src, continue_only):
        snap = entry.get("snap") or {}
        label = rc.snapshot_display(snap) or snap.get("title") or ""
        if not label:
            continue
        pct = float(entry.get("pct") or 0)
        when = ""
        try:
            import datetime as _dt
            when = _dt.datetime.fromtimestamp(
                float(entry.get("ts") or 0)).strftime("%b %d")
        except Exception:
            when = ""
        label2 = "LEFT OFF %s OF %s%s" % (
            rc.fmt_clock(entry.get("position") or 0),
            rc.fmt_clock(entry.get("duration") or 0),
            (" - " + when) if when else "")
        if pct >= 97.0:
            label2 = "WATCHED IN FULL%s" % ((" - " + when) if when else "")
        item = xbmcgui.ListItem(label=label)
        item.setLabel2(label2)
        item.setProperty("IsPlayable", "true")
        art = {}
        if snap.get("thumb"):
            art["thumb"] = snap["thumb"]
        if snap.get("fanart"):
            art["fanart"] = snap["fanart"]
        if art:
            item.setArt(art)
        xbmcplugin.addDirectoryItem(handle, snap.get("path") or "",
                                    item, False)
        count += 1
    return count


def _directory_content(mode, params):
    """Kodi content type for one plugin directory (Loop 117).

    Collection title pages MUST declare movies/tvshows, not "videos":
    skin.rocos panel 50 (the primary Videos list) is visible only for
    movies/tvshows/musicvideos/actors/sets/seasons content, and its
    files branch explicitly excludes plugin:// folder paths -- with
    "videos" panel 50 is invisible, the window's defaultcontrol 50
    fails ("Control 50 in window 10025 has been asked to focus, but
    it can't", Loop 110 log 05:26:13 at the collection open), and
    the fallback 550 view's items do not activate on ENTER or
    DPAD_CENTER (Loop 110 step 5 caveat A: screenshots 62/65 show
    focus moving over the Love Bug shelf while clicks stay dead
    with no log lines). Declaring the collection's own media type
    puts the page on panel 50, the skin's standard, proven list.
    Path-based collections (one folder row to a Trakt/discover
    destination) and all other modes keep "videos": their rows are
    folders, and no dead-click evidence exists for them.
    """
    if mode == "collection":
        c = rc._COLLECTIONS_BY_ID.get(params.get("id", ""))
        if c and c.get("titles"):
            return "movies" if rc._coll_tmdb_type(c) == "movie" else "tvshows"
        return "videos"
    if mode == "collections":
        if params.get("cat") == "movies":
            return "movies"
        if params.get("cat") == "tv":
            return "tvshows"
        return "videos"
    if mode == "movierow":
        return "movies"
    return "videos"


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    handle = int(argv[1]) if len(argv) > 1 else -1
    params = _params(argv[2] if len(argv) > 2 else "")
    events = rc.load_timeline()
    mode = params.get("mode")
    xbmcplugin.setContent(handle, _directory_content(mode, params))
    if mode == "year":
        build_year(handle, events, params.get("year"))
    elif mode == "collections":
        build_collections(handle, params.get("cat", "home"))
    elif mode == "collection":
        build_collection(handle, params.get("id", ""), events)
    elif mode == "movierow":
        build_movie_row(handle, params.get("list", ""))
    elif mode == "detail":
        # 0.5.13: the handle goes in so open_collection_title can
        # end the directory BEFORE activating 1124 (see its
        # docstring); it ends it on every path, so main must not
        # end it again below.
        try:
            rc.open_collection_title(params, handle)
        except Exception:
            try:
                xbmcplugin.endOfDirectory(handle, succeeded=False)
            except Exception:
                pass
        return
    elif mode == "emptyrow":
        # PM-2 rotation B (merge run 2026-11-07): the skin's
        # Trakt-fed row contents resolve through Includes.xml
        # variables; in kid profiles (RocProfiles.NoTrakt) they
        # resolve HERE instead of to the Helper's Trakt routes.
        # An intentionally empty directory: no provider is
        # queried, so the Helper's 401 auth dialog can never
        # fire from a kid profile's rows. (The shared
        # endOfDirectory below closes the listing.)
        pass
    elif mode == "history":
        build_history(handle, params.get("src", ""), False)
    elif mode == "continue":
        build_history(handle, params.get("src", ""), True)
    else:
        build_years(handle, events)
    xbmcplugin.endOfDirectory(handle, succeeded=(mode != "detail"))


if __name__ == "__main__":
    main()
