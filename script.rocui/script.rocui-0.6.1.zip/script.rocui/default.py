# -*- coding: utf-8 -*-
"""
script.rocui — script entry point (RunScript actions from the Roc OS skin).

Actions:
  action=adult_gate[,target=plugin.video.cumination]  PIN gate, then open
  action=reset_pin                                    change the PIN
  action=mode_cycle                                   dock light button:
                                                      manual override pick
  action=mode_set,mode=Day|Midday|Night               set the light mode
                                                      directly (v3.3.0)
  action=sync_daypart                                 apply clock daypart now
  action=vpn_refresh                                  re-check + publish VPN
  action=roc_log                                      open the Roc Log
                                                      window (1126) (G7)
  action=discover                                     publish discovery
                                                      rows (G24)
  action=proton_vpn                                   launch Proton VPN
                                                      (G27)
  action=install_app,profile=E-Roc|Nue|Jama|August  family app route
                                                      (G26)
  action=gate_dialog                                  gate notice modal,
                                                      raised HERE (one-shot
                                                      process) at the service
                                                      loop's dispatch — never
                                                      on the service thread
                                                      (wedge fix, 2026-11-08)
"""
import sys

import rocui_common as rc


def _params(argv):
    params = {}
    for arg in argv:
        if arg.startswith("?"):
            # plugin-style invocation (e.g. JSON-RPC
            # Addons.ExecuteAddon): one query string, ?k=v&k=v
            for pair in arg[1:].split("&"):
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    params[key.strip()] = value.strip()
        elif "=" in arg:
            key, value = arg.split("=", 1)
            params[key.strip()] = value.strip()
    return params


def main():
    params = _params(sys.argv[1:])
    action = params.get("action", "")
    if action == "adult_gate":
        rc.adult_gate(params.get("target", "plugin.video.cumination"))
    elif action == "reset_pin":
        rc.reset_pin()
    elif action == "mode_cycle":
        rc.mode_cycle()
    elif action == "mode_set":
        rc.mode_set(params.get("mode", ""))
    elif action == "roc_log":
        rc.show_roc_log()
    elif action == "discover":
        rc.discover()
    elif action == "proton_vpn":
        rc.proton_vpn()
    elif action == "install_app":
        rc.install_app(params.get("profile", ""))
    elif action == "sync_daypart":
        rc.sync_daypart()
    elif action == "vpn_refresh":
        rc.publish_vpn_state()
    elif action == "stage_open":
        rc.stage_open(params.get("cid", ""))
    elif action == "detail_main_play":
        import rocui_playback
        rocui_playback.detail_main_play()
    elif action == "detail_resume_play":
        import rocui_playback
        rocui_playback.detail_resume_play()
    elif action == "detail_seasons":
        import rocui_playback
        rocui_playback.detail_seasons()
    elif action == "stage_folder":
        rc.stage_folder(params.get("cid", ""))
    elif action == "view_more":
        rc.view_more(params.get("path", ""))
    elif action == "timeline_prime":
        rc.timeline_prime()
    elif action == "timeline_jump":
        rc.timeline_jump()
    elif action == "adult_guard":
        rc.adult_guard()
    elif action == "stereo_select":
        rc.stereo_select()
    elif action == "gate_dialog":
        import rocui_gate
        rocui_gate.route_gate_refuse()
    elif action == "source_select":
        import rocui_gate
        if rocui_gate.route_gate_open():
            import rocui_playback
            rocui_playback.source_select()
        else:
            rocui_gate.route_gate_refuse()
    elif action == "resume_play":
        import rocui_gate
        if rocui_gate.route_gate_open():
            import rocui_playback
            rocui_playback.resume_play()
        else:
            rocui_gate.route_gate_refuse()
    elif action == "resume_clear":
        import rocui_playback
        rocui_playback.resume_clear()
    elif action == "episodes_panel":
        import rocui_playback
        rocui_playback.episodes_panel()
    else:
        rc.log("default.py called with unknown action: %r" % action)


if __name__ == "__main__":
    main()
