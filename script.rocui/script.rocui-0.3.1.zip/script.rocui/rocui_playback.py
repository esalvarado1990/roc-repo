# -*- coding: utf-8 -*-
"""
script.rocui playback tools (v3.2.0, Eric 2026-10-24 16:36-16:39):

  source_select  — OSD SOURCES button: re-pick the playing title's
                   source. Re-runs the originating addon's play entry
                   when its plugin path is recoverable (its own
                   source-select screen shows the full grouped list);
                   otherwise hands the title to TMDb Helper's player
                   selection by ID. The service seeks back to the
                   stored position when the new source starts.
                   Honest limit (research report Q5): playback always
                   restarts; Scrubs V2 / The Crew expose no documented
                   re-entry, so they take the TMDb Helper fallback.
  resume_play    — play the resume checkpoint (Resume Keeper), seek
                   applied by the service.
  resume_clear   — dismiss the checkpoint.
  episodes_panel — OSD EPISODES / COLLECTION button: Netflix-style
                   season/episode list for TV, TMDB collection parts
                   in order for movies; a pick plays through the
                   originating addon's rules first (its play entry /
                   TMDb Helper player), the same source/quality
                   behavior pack he runs.
"""
import re
from six.moves import urllib_parse

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover - importable outside Kodi
    xbmc = xbmcgui = xbmcvfs = None

import rocui_common as rc

TMDBH = "plugin://plugin.video.themoviedb.helper/"


def _tmdb_play_path(snap, tmdb_id=None, season=None, episode=None):
    tmdb_id = tmdb_id or rc.snapshot_tmdb_id(snap)
    is_tv = bool(snap.get("showtitle")) or snap.get("type") == "episode"
    if tmdb_id:
        if is_tv:
            s = season if season is not None else snap.get("season", -1)
            e = episode if episode is not None else snap.get("episode", -1)
            path = ("%s?info=play&tmdb_type=tv&tmdb_id=%s"
                    % (TMDBH, tmdb_id))
            if s is not None and s >= 0:
                path += "&season=%d" % s
            if e is not None and e >= 0:
                path += "&episode=%d" % e
            return path
        return "%s?info=play&tmdb_type=movie&tmdb_id=%s" % (TMDBH, tmdb_id)
    if snap.get("imdb"):
        return "%s?info=play&tmdb_type=%s&imdb_id=%s" % (
            TMDBH, "tv" if is_tv else "movie", snap["imdb"])
    return ""


def _open_path(path, stop_first=False):
    if stop_first:
        try:
            xbmc.Player().stop()
        except Exception:
            pass
    if "info=play" in path or path.startswith("plugin://"):
        xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % path)
    else:
        xbmc.executebuiltin("PlayMedia(%s)" % path)


# ----------------------------------------------------------------------
# source re-pick (item 2)
# ----------------------------------------------------------------------
def source_select():
    snap = rc.now_playing_snapshot()
    if not snap:
        rc.notify("Nothing is playing to re-pick")
        return
    try:
        pos = xbmc.Player().getTime()
    except Exception:
        pos = 0
    if pos > 5:
        rc.seek_arm(pos, rc.snapshot_display(snap))
    path = snap.get("path") or ""
    if path.startswith("plugin://"):
        # The originating addon's own play entry: re-running it makes
        # the addon rescrape and show its source list (Seren-family
        # getSources; Crew/Scrubs show their lists at play).
        rc.log("source_select: re-running origin %s" % path[:120])
        xbmc.executebuiltin("PlayMedia(%s)" % path)
        rc.notify("Re-picking sources - same title, full list")
        return
    tmdb_path = _tmdb_play_path(snap)
    if tmdb_path:
        rc.log("source_select: TMDb Helper fallback for %s"
               % rc.snapshot_display(snap))
        _open_path(tmdb_path, stop_first=True)
        rc.notify("Pick a player - its full source list opens")
        return
    if snap.get("title"):
        query = urllib_parse.quote_plus(snap["title"])
        _open_path("%s?info=search&query=%s" % (TMDBH, query),
                   stop_first=True)
        rc.notify("Pick the title - then a player for sources")
        return
    rc.notify("This one cannot be re-picked")


# ----------------------------------------------------------------------
# resume keeper actions (item 3)
# ----------------------------------------------------------------------
def resume_play():
    data = rc.resume_load()
    snap = data.get("snap") or {}
    if not snap or not data.get("position"):
        rc.notify("Nothing saved to resume")
        return
    rc.seek_arm(data["position"], rc.snapshot_display(snap))
    path = snap.get("path") or ""
    if path.startswith("plugin://"):
        addon_id = path.split("/")[2] if len(path.split("/")) > 2 else ""
        if addon_id and xbmc.getCondVisibility(
                "System.HasAddon(%s)" % addon_id):
            xbmc.executebuiltin("PlayMedia(%s)" % path)
            rc.notify("Resuming %s" % rc.snapshot_display(snap)[:60])
            return
    if path and not path.startswith(("http://", "https://")) \
            and xbmcvfs.exists(path):
        xbmc.executebuiltin("PlayMedia(%s)" % path)
        rc.notify("Resuming %s" % rc.snapshot_display(snap)[:60])
        return
    tmdb_path = _tmdb_play_path(snap)
    if tmdb_path:
        _open_path(tmdb_path)
        rc.notify("Pick the player - it resumes at your spot")
        return
    rc.notify("This one cannot be re-opened automatically")


def resume_clear():
    rc.resume_delete()
    rc.log("resume checkpoint cleared by user")


# ----------------------------------------------------------------------
# episodes / collection panel (item 4)
# ----------------------------------------------------------------------
def _library_watched():
    """Watched-state sets from the local library: IMDb ids of watched
    movies, (title, year) of watched movies, and (showtitle, season,
    episode) of watched episodes. Watched state is only marked where
    this data actually exists — plugin plays leave no trace here."""
    watched_ids, watched_eps, watched_titles = set(), set(), set()
    try:
        res = rc._rpc("VideoLibrary.GetMovies", {
            "properties": ["imdbnumber", "playcount", "title", "year"]})
        for m in (res.get("movies") or []):
            if m.get("playcount", 0) > 0:
                if m.get("imdbnumber"):
                    watched_ids.add(str(m["imdbnumber"]))
                watched_titles.add(((m.get("title") or "").lower(),
                                    m.get("year", 0)))
        res = rc._rpc("VideoLibrary.GetEpisodes", {
            "properties": ["showtitle", "season", "episode", "playcount"]})
        for e in (res.get("episodes") or []):
            if e.get("playcount", 0) > 0:
                watched_eps.add(((e.get("showtitle") or "").lower(),
                                 e.get("season", -1), e.get("episode", -1)))
    except Exception as exc:
        rc.log("watched lookup failed: %s" % exc)
    return watched_ids, watched_eps, watched_titles


def _pick_dialog(heading, items):
    """items: list of (label, label2, icon). Returns index or -1."""
    lis = []
    for label, label2, icon in items:
        li = xbmcgui.ListItem(label=label, label2=label2)
        if icon:
            li.setArt({"thumb": icon})
        lis.append(li)
    return xbmcgui.Dialog().select(heading, lis, useDetails=True)


def _origin_template_play(snap, season=None, episode=None, tmdb_id=None):
    """Play a sibling (another episode / another collection part)
    through the ORIGINATING addon's play entry when its URL pattern
    is recoverable: substitute the season/episode or tmdb_id params
    in the path the current title was launched with. Returns True
    when a route fired."""
    path = snap.get("path") or ""
    if not path.startswith("plugin://"):
        return False
    new = path
    if season is not None:
        new2 = re.sub(r"([?&]season=)\d+", r"\g<1>%d" % season, new)
        new2 = re.sub(r"([?&]s=)\d+", r"\g<1>%d" % season, new2)
        if new2 != new:
            new = new2
    if episode is not None:
        new2 = re.sub(r"([?&]episode=)\d+", r"\g<1>%d" % episode, new)
        new2 = re.sub(r"([?&]e=)\d+", r"\g<1>%d" % episode, new2)
        if new2 != new:
            new = new2
    if tmdb_id is not None:
        new2 = re.sub(r"([?&]tmdb_id=)\d+", r"\g<1>%s" % tmdb_id, new)
        if new2 != new:
            new = new2
    if new != path:
        rc.log("episodes_panel: origin template %s" % new[:120])
        xbmc.executebuiltin("PlayMedia(%s)" % new)
        return True
    if "plugin.video.themoviedb.helper" in path:
        # Launched via TMDb Helper but params didn't match the
        # substitution patterns; its canonical play path is the
        # same door with the same rules.
        tp = _tmdb_play_path(snap, tmdb_id=tmdb_id,
                              season=season, episode=episode)
        if tp:
            _open_path(tp)
            return True
    return False


def _panel_tv(snap):
    tmdb_id = rc.snapshot_tmdb_id(snap)
    if not tmdb_id:
        rc.notify("No show data for this one")
        return
    show = rc.tmdb_get("tv/%s" % tmdb_id)
    if not show:
        rc.notify("Show data did not load")
        return
    seasons = [s for s in (show.get("seasons") or [])
               if s.get("season_number", 0) > 0]
    seasons.sort(key=lambda s: s["season_number"])
    if not seasons:
        rc.notify("No seasons found")
        return
    cur_s = snap.get("season", -1)
    items = []
    for s in seasons:
        mark = "  (you are here)" if s["season_number"] == cur_s else ""
        items.append(("Season %d%s" % (s["season_number"], mark),
                      "%d episodes" % (s.get("episode_count") or 0), ""))
    idx = _pick_dialog(show.get("name") or snap["showtitle"], items)
    if idx < 0:
        return
    season_no = seasons[idx]["season_number"]
    data = rc.tmdb_get("tv/%s/season/%d" % (tmdb_id, season_no))
    episodes = (data or {}).get("episodes") or []
    if not episodes:
        rc.notify("Episodes did not load")
        return
    _, watched_eps, _ = _library_watched()
    show_key = (snap.get("showtitle") or show.get("name") or "").lower()
    items = []
    for ep in episodes:
        eno = ep.get("episode_number", 0)
        label = "%d. %s" % (eno, ep.get("name") or "Episode %d" % eno)
        if season_no == cur_s and eno == snap.get("episode", -1):
            label += "  (playing)"
        elif (show_key, season_no, eno) in watched_eps:
            label += "  (watched)"
        still = ep.get("still_path") or ""
        icon = ("https://image.tmdb.org/t/p/w300" + still) if still else ""
        items.append((label, ep.get("air_date") or "", icon))
    idx = _pick_dialog("Season %d" % season_no, items)
    if idx < 0:
        return
    ep_no = episodes[idx].get("episode_number", 0)
    if season_no == cur_s and ep_no == snap.get("episode", -1):
        return
    if _origin_template_play(snap, season=season_no, episode=ep_no):
        return
    tp = _tmdb_play_path(snap, tmdb_id=tmdb_id,
                         season=season_no, episode=ep_no)
    if tp:
        _open_path(tp)
        return
    rc.notify("This episode cannot be opened from here")


def _panel_movie(snap):
    tmdb_id = rc.snapshot_tmdb_id(snap)
    if not tmdb_id:
        rc.notify("No collection data for this one")
        return
    detail = rc.tmdb_get("movie/%s" % tmdb_id)
    coll = (detail or {}).get("belongs_to_collection") or {}
    if not coll.get("id"):
        rc.notify("This movie is not part of a collection")
        return
    data = rc.tmdb_get("collection/%d" % coll["id"])
    parts = [p for p in ((data or {}).get("parts") or [])
             if p.get("release_date")]
    parts.sort(key=lambda p: p["release_date"])
    if len(parts) < 2:
        rc.notify("No other parts in this collection")
        return
    _, _, watched_titles = _library_watched()
    items = []
    for p in parts:
        label = p.get("title") or ""
        if str(p.get("id")) == str(tmdb_id):
            label += "  (playing)"
        elif ((p.get("title") or "").lower(),
              int((p.get("release_date") or "0")[:4] or 0)) in watched_titles:
            label += "  (watched)"
        poster = p.get("poster_path") or ""
        icon = ("https://image.tmdb.org/t/p/w185" + poster) if poster else ""
        items.append((label, (p.get("release_date") or "")[:4], icon))
    idx = _pick_dialog(coll.get("name") or "Collection", items)
    if idx < 0:
        return
    part = parts[idx]
    if str(part.get("id")) == str(tmdb_id):
        return
    if _origin_template_play(snap, tmdb_id=str(part["id"])):
        return
    tp = _tmdb_play_path({"title": part.get("title") or "",
                          "showtitle": "", "type": "movie"},
                         tmdb_id=str(part["id"]))
    if tp:
        _open_path(tp)
        return
    rc.notify("That part cannot be opened from here")


def episodes_panel():
    snap = rc.now_playing_snapshot()
    if not snap:
        rc.notify("Nothing is playing")
        return
    if snap.get("showtitle") or snap.get("type") == "episode":
        _panel_tv(snap)
    else:
        _panel_movie(snap)
