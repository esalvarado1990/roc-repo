# -*- coding: utf-8 -*-
"""
Roc UI helper (script.rocui) — shared logic for Roc OS Phase 2.

Owns the three things skin XML cannot do honestly:
  1. The Adult PIN gate (salted PBKDF2 hash only — the PIN itself is never
     stored, never logged, and is set by Eric on the device at first use).
  2. The Day/Midday/Night clock (automatic by local time; the dock button
     becomes a manual override that holds until the next light change).
  3. Focus memory (last focused control per window, restored on return) and
     the VPN status surface hook (see the marked section below).

Kodi imports are guarded so this module can be imported and unit-tested
outside Kodi (validation harness) without crashing.
"""
import base64
import datetime
import hashlib
import hmac
import json
import os
import re
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:  # outside Kodi (tests) — functions degrade to no-ops
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None

ADDON_ID = "script.rocui"
SKIN_ID = "skin.rocos"
MODE_SKIN_STRING = "RocOS.Mode"           # Night | Midday | Day (Phase 1 string)
MODE_SOURCE_STRING = "RocOS.ModeSource"   # Auto | Manual (Phase 2)
HOME_WINDOW_ID = 10000

# Daypart bands (local time): Day 07:00-15:59, Midday 16:00-19:59,
# Night 20:00-06:59. "Midday" is the warm transitional band in this house.
DAYPART_BOUNDARIES = [(7, "Day"), (16, "Midday"), (20, "Night")]

PIN_ITERATIONS = 200000
PIN_MIN_LEN = 4
PIN_MAX_LEN = 8

# Windows where focus restore is pointless or harmful (fullscreen players,
# busy/startup surfaces). Everything else gets focus memory.
FOCUS_SKIP_WINDOWS = {0, 12005, 12006, 12009, 12900}


# --------------------------------------------------------------------------
# small utilities
# --------------------------------------------------------------------------
def log(msg, level=None):
    if xbmc is None:
        return
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg),
                 xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


def _data_dir():
    """Addon profile data dir (created on demand). '' when not in Kodi."""
    if xbmcvfs is None:
        return ""
    try:
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(path):
            os.makedirs(path)
        return path
    except Exception as exc:
        log("data dir failed: %s" % exc)
        return ""


def _master_data_dir():
    """Addon MASTER-profile data dir (created on demand). Identical
    from every profile context — special://masterprofile always
    resolves to the master profile's directory, while
    special://profile follows the currently loaded profile."""
    if xbmcvfs is None:
        return ""
    try:
        path = xbmcvfs.translatePath(
            "special://masterprofile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(path):
            os.makedirs(path)
        return path
    except Exception as exc:
        log("master data dir failed: %s" % exc)
        return ""


def _read_json(name):
    path = os.path.join(_data_dir(), name) if _data_dir() else ""
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        log("read %s failed: %s" % (name, exc))
        return {}


def _write_json(name, data):
    path = os.path.join(_data_dir(), name) if _data_dir() else ""
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log("write %s failed: %s" % (name, exc))
        return False


def notify(message, ms=4500):
    """Plain-words notification. NOTE: builtin args split on commas —
    messages here must never contain one."""
    if xbmc is None:
        return
    try:
        xbmc.executebuiltin("Notification(Roc OS,%s,%d)" % (message, ms))
    except Exception:
        pass


# --------------------------------------------------------------------------
# skin strings (the skin's own settings store — same place Skin.SetString
# writes, so XML conditions and this helper always agree)
# --------------------------------------------------------------------------
def get_skin_string(name):
    if xbmc is not None:
        try:
            value = xbmc.getInfoLabel("Skin.String(%s)" % name)
            if value:
                return value
        except Exception:
            pass
    if xbmcaddon is not None:
        try:
            return xbmcaddon.Addon(SKIN_ID).getSetting(name) or ""
        except Exception:
            pass
    return ""


def set_skin_string(name, value):
    if xbmc is None:
        return
    try:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (name, value))
    except Exception as exc:
        log("Skin.SetString %s failed: %s" % (name, exc))


# --------------------------------------------------------------------------
# Day / Midday / Night
# --------------------------------------------------------------------------
def daypart_for(moment):
    """moment: datetime.datetime -> 'Day' | 'Midday' | 'Night'."""
    hour = moment.hour
    if 7 <= hour < 16:
        return "Day"
    if 16 <= hour < 20:
        return "Midday"
    return "Night"


def next_boundary(moment):
    """Epoch seconds of the next daypart change strictly after `moment`."""
    candidates = []
    for day_offset in (0, 1):
        day = (moment + datetime.timedelta(days=day_offset)).date()
        for hour, _name in DAYPART_BOUNDARIES:
            cand = datetime.datetime.combine(
                day, datetime.time(hour=hour), tzinfo=moment.tzinfo)
            if cand > moment:
                candidates.append(cand)
    return int(min(candidates).timestamp())


def _state():
    return _read_json("rocui-state.json")


def _save_state(state):
    return _write_json("rocui-state.json", state)


def manual_override(now=None):
    """Active manual mode dict {'mode':..., 'until': epoch} or None."""
    now = time.time() if now is None else now
    manual = _state().get("manual") or {}
    try:
        if manual.get("mode") and float(manual.get("until", 0)) > now:
            return manual
    except Exception:
        pass
    return None


def sync_daypart(now_dt=None):
    """Apply the automatic daypart unless a manual override is alive.

    Returns the effective mode. Safe to call often (service loop + Home
    onload); only writes skin strings when something actually changes.
    """
    now_dt = now_dt or datetime.datetime.now().astimezone()
    manual = manual_override(now_dt.timestamp())
    if manual:
        if get_skin_string(MODE_SOURCE_STRING) != "Manual":
            set_skin_string(MODE_SOURCE_STRING, "Manual")
        if get_skin_string(MODE_SKIN_STRING) != manual["mode"]:
            set_skin_string(MODE_SKIN_STRING, manual["mode"])
        return manual["mode"]
    # override expired (or never existed): clear it and go automatic
    state = _state()
    if state.get("manual"):
        state.pop("manual", None)
        _save_state(state)
    auto = daypart_for(now_dt)
    if get_skin_string(MODE_SOURCE_STRING) != "Auto":
        set_skin_string(MODE_SOURCE_STRING, "Auto")
    if get_skin_string(MODE_SKIN_STRING) != auto:
        set_skin_string(MODE_SKIN_STRING, auto)
    return auto


def mode_cycle():
    """Dock light button: advance the mode and hold it as a manual
    override until the next automatic light change."""
    order = {"Night": "Midday", "Midday": "Day", "Day": "Night"}
    now_dt = datetime.datetime.now().astimezone()
    current = get_skin_string(MODE_SKIN_STRING) or daypart_for(now_dt)
    new_mode = order.get(current, "Night")
    state = _state()
    state["manual"] = {"mode": new_mode, "until": next_boundary(now_dt)}
    _save_state(state)
    set_skin_string(MODE_SKIN_STRING, new_mode)
    set_skin_string(MODE_SOURCE_STRING, "Manual")
    notify("Light set to %s - manual until the next light change" % new_mode,
           3000)
    return new_mode


# --------------------------------------------------------------------------
# Adult PIN gate — the PIN is Eric's, set on-device at first use.
# Only a salted PBKDF2-HMAC-SHA256 hash is stored (addon profile data).
# --------------------------------------------------------------------------
def derive_pin(pin, salt, iterations=PIN_ITERATIONS):
    return hashlib.pbkdf2_hmac(
        "sha256", pin.encode("utf-8"), salt, int(iterations), dklen=32)


def _read_json_from(dirpath, name):
    if not dirpath:
        return {}
    path = os.path.join(dirpath, name)
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        log("read %s failed: %s" % (name, exc))
        return {}


def _pin_record():
    """v3.2.0 (Eric flag, 2026-10-24: 'wouldn't take my PIN numbers —
    more than once, both of them'). The record used to live ONLY in
    the current profile's addon_data: set it under one profile context
    and the gate running under another saw no PIN, ran the set flow
    again (a SECOND PIN), and from then on each PIN verified only in
    its own context. The canonical store now lives in the MASTER
    profile (same from everywhere); the per-profile file stays as a
    legacy fallback read so a PIN set by an older build still works."""
    rec = _read_json_from(_master_data_dir(), "pin.json")
    if rec.get("hash") and rec.get("salt"):
        return rec
    return _read_json("pin.json")


def pin_is_set():
    rec = _pin_record()
    return bool(rec.get("hash") and rec.get("salt"))


def _save_pin(pin):
    salt = os.urandom(16)
    rec = {
        "version": 1,
        "kdf": "pbkdf2_sha256",
        "iterations": PIN_ITERATIONS,
        "salt": base64.b64encode(salt).decode("ascii"),
        "hash": base64.b64encode(
            derive_pin(pin, salt, PIN_ITERATIONS)).decode("ascii"),
        "created": int(time.time()),
    }
    # Write the canonical (master profile) store AND the per-profile
    # copy, so no profile context can ever drift onto a different PIN.
    ok = False
    master = _master_data_dir()
    if master:
        try:
            path = os.path.join(master, "pin.json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(rec, fh)
            os.replace(tmp, path)
            ok = True
        except Exception as exc:
            log("write master pin.json failed: %s" % exc)
    if _write_json("pin.json", rec):
        ok = True
    return ok


def verify_pin(pin, rec=None):
    rec = rec if rec is not None else _pin_record()
    if not rec.get("hash"):
        return False
    try:
        salt = base64.b64decode(rec["salt"])
        expected = base64.b64decode(rec["hash"])
        actual = derive_pin(pin, salt, rec.get("iterations", PIN_ITERATIONS))
        return hmac.compare_digest(actual, expected)
    except Exception as exc:
        log("verify_pin failed: %s" % exc)
        return False


def _prompt_pin(heading):
    """Masked PIN prompt. Returns the entered string, or None on cancel."""
    if xbmcgui is None:
        return None
    dialog = xbmcgui.Dialog()
    try:
        input_type = getattr(xbmcgui, "INPUT_PASSWORD", None)
        if input_type is not None:
            value = dialog.input(heading, type=input_type)
        else:
            value = dialog.numeric(0, heading)
    except Exception as exc:
        log("pin prompt failed: %s" % exc)
        return None
    if value is None or value == "":
        return None
    return value.strip()


def _valid_new_pin(pin):
    return bool(pin) and pin.isdigit() and PIN_MIN_LEN <= len(pin) <= PIN_MAX_LEN


def _set_pin_flow():
    """First use: Eric sets his own PIN (entered twice)."""
    notify("First use - set your own PIN for the adult door", 5000)
    first = _prompt_pin("Set your PIN (4-8 digits)")
    if first is None:
        return False
    if not _valid_new_pin(first):
        notify("PIN must be 4 to 8 digits - nothing was set", 5000)
        return False
    second = _prompt_pin("Enter that PIN again to confirm")
    if second is None:
        return False
    if second != first:
        notify("Those PINs did not match - nothing was set", 5000)
        return False
    if not _save_pin(first):
        notify("Could not save the PIN on this device", 5000)
        return False
    notify("PIN set - the adult door is yours now", 4000)
    return True


def _verify_pin_flow():
    pin = _prompt_pin("Enter your PIN")
    if pin is None:
        return False
    if verify_pin(pin):
        return True
    notify("Wrong PIN - the door stays shut", 4000)
    return False


_ADDON_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


def adult_gate(target="plugin.video.cumination"):
    """Route the Home adult tile/dock stop through the PIN gate.

    First use sets the PIN, later uses verify it; only then does the
    adult addon open. `target` is an addon id, never a path.
    """
    target = (target or "").strip()
    if not _ADDON_ID_RE.match(target):
        log("adult_gate refused malformed target: %r" % target)
        notify("That adult door is not wired right - nothing opened", 5000)
        return False
    if not pin_is_set():
        if not _set_pin_flow():
            return False
    elif not _verify_pin_flow():
        return False
    if xbmc is not None:
        if target == "plugin.video.cumination":
            # v3.2.0: the gate lands on the Adult HUB (window 1123) —
            # the browse-style room that mixes the sources — and
            # stamps the session the hub's guard re-checks.
            adult_session_open()
            xbmc.executebuiltin("ActivateWindow(%d)" % ADULT_WINDOW_ID)
        else:
            xbmc.executebuiltin(
                "ActivateWindow(Videos,plugin://%s/,return)" % target)
    return True


def reset_pin():
    """Change the PIN: current PIN first, then the set flow."""
    if pin_is_set() and not _verify_pin_flow():
        return False
    return _set_pin_flow()


# --------------------------------------------------------------------------
# Focus memory — last focused control per window, restored on return.
# Stored in the addon profile data; the service owns reads/writes.
# --------------------------------------------------------------------------
def load_focus_memory():
    data = _read_json("focus-memory.json")
    return data if isinstance(data, dict) else {}


def save_focus_memory(memory):
    return _write_json("focus-memory.json", memory)


def current_window_and_focus():
    """(window_id, focus_id) or (None, None) when the API is unavailable."""
    if xbmcgui is None:
        return None, None
    try:
        win_id = xbmcgui.getCurrentWindowId()
        if not win_id:
            return None, None
        focus_id = xbmcgui.Window(win_id).getFocusId()
        return int(win_id), int(focus_id or 0)
    except Exception:
        return None, None


def restore_focus(win_id, focus_id):
    if xbmcgui is None or not focus_id:
        return False
    try:
        xbmcgui.Window(int(win_id)).setFocusId(int(focus_id))
        return True
    except Exception as exc:
        log("restore_focus %s/%s failed: %s" % (win_id, focus_id, exc))
        return False


# ==========================================================================
# VPN STATUS HOOK — Phase 2 preparation ONLY.
#
# detect_vpn_state() is the single, clearly-marked place that decides what
# the dock shield shows. Contract: it returns ("on" | "off" | "unknown",
# source-string). It may only say "on" when a tunnel interface is actually
# present (and up, where the platform exposes state). When the platform
# exposes nothing readable it returns "unknown" — and the skin renders
# "unknown" with the OFF shield, never the lit one. No fake ON, ever.
#
# Signals, in order:
#   1. /sys/class/net (Linux + Android): tun*/tap*/wg*/ppp* interfaces,
#      with operstate/carrier checked where readable.
#   2. /proc/net/dev (Linux + Android fallback): tunnel interface present.
#   3. Anything else (incl. Windows): "unknown" — adapter enumeration is
#      deliberately NOT faked here; it lands with the on-device phase,
#      where the R26 both-states hardware gate also lives.
# ==========================================================================
_TUN_PREFIXES = ("tun", "tap", "wg", "ppp")


def _tun_names_from_listing(names):
    return [n for n in names if n.startswith(_TUN_PREFIXES)]


def detect_vpn_state():
    if os.name == "nt":
        return "unknown", "windows-adapter-enumeration-not-implemented"
    sysfs = "/sys/class/net"
    try:
        if os.path.isdir(sysfs):
            names = os.listdir(sysfs)
            tuns = _tun_names_from_listing(names)
            if not tuns:
                return "off", "sysfs:no-tunnel-interface"
            for name in tuns:
                state = ""
                try:
                    with open(os.path.join(sysfs, name, "operstate"),
                              "r", encoding="utf-8") as fh:
                        state = fh.read().strip().lower()
                except Exception:
                    state = ""
                if state in ("", "up", "unknown"):
                    # Android often reports operstate 'unknown' for a live
                    # tun; presence + not-down is the honest positive here.
                    if state != "down":
                        return "on", "sysfs:%s(%s)" % (name, state or "?")
            return "off", "sysfs:tunnel-interface-down"
    except Exception as exc:
        log("vpn sysfs check failed: %s" % exc)
    try:
        with open("/proc/net/dev", "r", encoding="utf-8") as fh:
            names = []
            for line in fh:
                if ":" in line:
                    names.append(line.split(":", 1)[0].strip())
            tuns = _tun_names_from_listing(names)
            if tuns:
                return "on", "proc-net-dev:%s" % tuns[0]
            if names:
                return "off", "proc-net-dev:no-tunnel-interface"
    except Exception as exc:
        log("vpn /proc check failed: %s" % exc)
    return "unknown", "no-readable-network-signal"


# ==========================================================================
# WWE TIMELINE ENGINE (Phase 3) — serves the 447-event PPV/PLE index
# (1990-2026, main roster, true date order) to the War Room scrubber.
#
# Data: resources/data/ppv_events.json ships inside this addon (copied at
# build time from the canonical set in ~/workspace/kodi-build/timeline/ —
# see that folder's SOURCES.md for provenance). The index is PPV/PLE
# events ONLY: the weekly-show weave (RAW/SmackDown/B-shows) is not in
# this dataset and is not faked here. The pure functions below take the
# event list as an argument so the validator can test them offline.
# ==========================================================================
WAR_ROOM_WINDOW_ID = 1113
TIMELINE_YEARS_CONTAINER = 640     # War Room years-scrubber container id
TIMELINE_YEAR_PROPERTY = "RocTimeline.Year"
TIMELINE_REST_SECONDS = 0.35       # scrub focus must rest before pane swaps

_MONTHS = ("January", "February", "March", "April", "May", "June", "July",
           "August", "September", "October", "November", "December")
_WEEKDAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
             "Saturday", "Sunday")


def _timeline_path():
    """Path to the shipped ppv_events.json (module-relative: works in
    Kodi, where the addon dir is readable, and in the offline tests)."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "resources", "data", "ppv_events.json")


def load_timeline(path=None):
    """Load + defensively sort the event index. Returns [] on any
    failure — an empty timeline renders as an honest empty pane."""
    try:
        with open(path or _timeline_path(), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        events = [e for e in data
                  if isinstance(e, dict) and e.get("date") and e.get("name")]
        events.sort(key=lambda e: e["date"])
        return events
    except Exception as exc:
        log("timeline load failed: %s" % exc)
        return []


def timeline_years(events):
    """[(year:int, count:int), ...] ascending by year."""
    counts = {}
    for e in events:
        try:
            year = int(str(e["date"])[:4])
        except Exception:
            continue
        counts[year] = counts.get(year, 0) + 1
    return sorted(counts.items())


def timeline_events_for_year(events, year):
    """One year's events in date order (ISO dates sort chronologically).
    Unknown/blank year -> the latest year in the index (the scrubber's
    honest default before Eric has rested on a year)."""
    years = timeline_years(events)
    if not years:
        return []
    valid = {y for y, _c in years}
    try:
        year = int(year)
    except Exception:
        year = None
    if year not in valid:
        year = years[-1][0]
    return [e for e in events if str(e["date"]).startswith("%04d" % year)]


def timeline_default_year(events):
    years = timeline_years(events)
    return years[-1][0] if years else None


def format_event_date(iso):
    """'1990-01-21' -> 'Sunday, January 21, 1990'. Falls back to the raw
    string when the date does not parse — never invents a date."""
    try:
        dt = datetime.datetime.strptime(str(iso), "%Y-%m-%d")
        return "%s, %s %d, %d" % (_WEEKDAYS[dt.weekday()],
                                  _MONTHS[dt.month - 1], dt.day, dt.year)
    except Exception:
        return str(iso)


def timeline_year_era(year):
    """WWF through May 4 2002, WWE from May 19 2002 (the rename boundary
    the dataset itself uses) — era label for the scrubber."""
    try:
        return "WWF ERA" if int(year) <= 2002 else "WWE ERA"
    except Exception:
        return ""


_TIMELINE_PENDING = {"year": None, "since": 0.0, "applied": None}


def timeline_tick(win_id, focus_id):
    """Service hook (Phase 3): while Eric rests focus on a year in the
    War Room scrubber, publish it as Window(1113).Property(RocTimeline
    .Year) after a short rest — the events pane's content path reads that
    property, so the pane follows the scrubber but never churns while he
    is skimming years, and it stays put when he moves into the events
    (the property persists; Container(640).ListItem would not)."""
    if xbmc is None or xbmcgui is None:
        return
    if win_id != WAR_ROOM_WINDOW_ID or focus_id != TIMELINE_YEARS_CONTAINER:
        return
    try:
        year = xbmc.getInfoLabel(
            "Container(%d).ListItem.Property(year)" % TIMELINE_YEARS_CONTAINER)
        if not year:
            return
        now = time.time()
        if _TIMELINE_PENDING["year"] != year:
            _TIMELINE_PENDING["year"] = year
            _TIMELINE_PENDING["since"] = now
            return
        if now - _TIMELINE_PENDING["since"] < TIMELINE_REST_SECONDS:
            return
        if _TIMELINE_PENDING["applied"] == year:
            return
        window = xbmcgui.Window(WAR_ROOM_WINDOW_ID)
        if window.getProperty(TIMELINE_YEAR_PROPERTY) != year:
            window.setProperty(TIMELINE_YEAR_PROPERTY, year)
        _TIMELINE_PENDING["applied"] = year
    except Exception as exc:
        log("timeline tick failed: %s" % exc)


def publish_vpn_state():
    """Write the VPN surface properties onto the Home window (10000).

    Skin reads Window(10000).Property(RocVPN.State) etc. 'unknown' is a
    real published state — the skin maps it to the OFF shield + 'VPN ?'.
    """
    state, source = detect_vpn_state()
    if xbmcgui is not None:
        try:
            home = xbmcgui.Window(HOME_WINDOW_ID)
            home.setProperty("RocVPN.State", state)
            home.setProperty("RocVPN.On", "true" if state == "on" else "false")
            home.setProperty("RocVPN.Source", source)
            home.setProperty(
                "RocVPN.Label",
                {"on": "VPN ON", "off": "VPN OFF"}.get(state, "VPN ?"))
            home.setProperty("RocVPN.Checked", str(int(time.time())))
        except Exception as exc:
            log("publish_vpn_state failed: %s" % exc)
    return state, source


# ==========================================================================
# v3.2.0 — Detail Window, View More, timeline click, adult session,
# weather + notification publish, 3D select. (Eric's fix pass,
# 2026-10-24: stick flags 1/2/8/13/19/30/33 + Dell flags 2/3.)
# ==========================================================================
DETAIL_WINDOW_ID = 1124
ADULT_WINDOW_ID = 1123
ADULT_SESSION_SECONDS = 1800

_STAGE_FIELDS = [
    # (property, infolabel template on the source container)
    ("Title", "Title"), ("Plot", "Plot"), ("Year", "Year"),
    ("Genre", "Genre"), ("Duration", "Duration"), ("MPAA", "MPAA"),
    ("Director", "Director"), ("Studio", "Studio"),
    ("Country", "Country"), ("Trailer", "Trailer"),
    ("Path", "FileNameAndPath"), ("DBType", "DBType"),
    ("TVShowTitle", "TVShowTitle"), ("Season", "Season"),
    ("Episode", "Episode"), ("Cast", "Cast"),
]


def _info(fmt, *args):
    if xbmc is None:
        return ""
    try:
        return xbmc.getInfoLabel(fmt % args) or ""
    except Exception:
        return ""


def stage_open(cid):
    """Poster click -> Roc Detail Window (1124). Reads the clicked
    item out of its container on the current window and republishes
    it as Window(1124) properties the window renders. This route is
    fully Roc-owned: it cannot die the silent way the v3.1.0
    Action(Info) -> DialogVideoInfo route did on Eric's hardware."""
    if xbmc is None or xbmcgui is None:
        return False
    try:
        cid = int(cid)
    except Exception:
        return False
    prefix = "Container(%d).ListItem" % cid
    values = {}
    for prop, field in _STAGE_FIELDS:
        values[prop] = _info("%s.%s", prefix, field)
    if not values.get("Title"):
        values["Title"] = _info("%s.Label", prefix)
    if not values.get("Title"):
        notify("That title has no details to show yet", 3500)
        return False
    values["TmdbId"] = _info("%s.Property(tmdb_id)", prefix)
    values["TmdbType"] = _info("%s.Property(tmdb_type)", prefix)
    values["Poster"] = _info("%s.Art(poster)", prefix) or _info(
        "%s.Art(thumb)", prefix)
    values["Thumb"] = _info("%s.Art(thumb)", prefix)
    values["Fanart"] = _info("%s.Art(fanart)", prefix) or values["Thumb"]
    for prop, names in (("RatingIMDb", ("imdb", "imdb_rating")),
                        ("RatingRT", ("rottentomatoes",
                                      "rottentomatoes_rating")),
                        ("RatingMC", ("metacritic", "metacritic_rating")),
                        ("RatingTMDB", ("themoviedb", None))):
        val = _info("%s.Rating(%s)", prefix, names[0])
        if not val and names[1]:
            val = _info("%s.Property(%s)", prefix, names[1])
        values[prop] = val
    resumable = _info("%s.IsResumable", prefix)
    values["Resumable"] = "true" if resumable == "true" else ""
    pct = _info("%s.PercentPlayed", prefix)
    try:
        pct = "%d%%" % int(float(pct)) if pct else ""
    except Exception:
        pct = ""
    values["PercentPlayed"] = ("- " + pct + " watched") if pct else ""
    win = xbmcgui.Window(DETAIL_WINDOW_ID)
    for prop, val in values.items():
        try:
            win.setProperty("RocStage." + prop, val or "")
        except Exception:
            pass
    xbmc.executebuiltin("ActivateWindow(%d)" % DETAIL_WINDOW_ID)
    return True


def view_more(path):
    """VIEW MORE: open a plugin path as a full Videos page and put it
    in the wall/grid view (view 54 in this skin family)."""
    if xbmc is None:
        return False
    path = (path or "").strip()
    if not path.startswith("plugin://"):
        log("view_more refused non-plugin path: %r" % path)
        return False
    xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % path)
    if xbmcgui is not None:
        monitor = xbmc.Monitor()
        for _ in range(10):
            if monitor.waitForAbort(0.25):
                break
            try:
                if xbmcgui.getCurrentWindowId() == 10006:
                    xbmc.executebuiltin("Container.SetViewMode(54)")
                    return True
            except Exception:
                break
    return True


def timeline_prime():
    """War Room onload: make sure the events pane has a year (the
    latest in the index) before Eric touches the scrubber."""
    if xbmcgui is None:
        return
    try:
        win = xbmcgui.Window(WAR_ROOM_WINDOW_ID)
        if not win.getProperty(TIMELINE_YEAR_PROPERTY):
            year = timeline_default_year(load_timeline())
            if year:
                win.setProperty(TIMELINE_YEAR_PROPERTY, str(year))
    except Exception as exc:
        log("timeline_prime failed: %s" % exc)


def timeline_jump():
    """Year CLICK (the rest-publish in timeline_tick covers scrubbing;
    a click must land NOW): publish the clicked year and move focus
    into the events pane."""
    if xbmc is None or xbmcgui is None:
        return
    try:
        year = xbmc.getInfoLabel(
            "Container(%d).ListItem.Property(year)" % TIMELINE_YEARS_CONTAINER)
        if year:
            xbmcgui.Window(WAR_ROOM_WINDOW_ID).setProperty(
                TIMELINE_YEAR_PROPERTY, year)
            _TIMELINE_PENDING["year"] = year
            _TIMELINE_PENDING["applied"] = year
        xbmc.executebuiltin("SetFocus(%d)" % 650)
    except Exception as exc:
        log("timeline_jump failed: %s" % exc)


def adult_session_open():
    """Stamp the adult session on the Home window (the hub window
    re-checks it via adult_guard)."""
    if xbmcgui is None:
        return
    try:
        xbmcgui.Window(HOME_WINDOW_ID).setProperty(
            "RocAdult.Until", str(int(time.time()) + ADULT_SESSION_SECONDS))
    except Exception as exc:
        log("adult session stamp failed: %s" % exc)


def adult_guard():
    """Adult hub onload: without a live gate session, bounce home.
    The PIN gate is the door; this keeps the hub from being a
    walk-in via a stale window reference."""
    if xbmc is None or xbmcgui is None:
        return True
    try:
        until = xbmcgui.Window(HOME_WINDOW_ID).getProperty("RocAdult.Until")
        if until and float(until) > time.time():
            return True
    except Exception:
        pass
    notify("Locked - open Adult from the dock and enter your PIN", 4500)
    xbmc.executebuiltin("ActivateWindow(home)")
    return False


def stereo_select():
    """Dedicated 3D button: Kodi's own stereoscopic-mode picker."""
    if xbmc is None:
        return
    try:
        xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"GUI.SetStereoscopicMode",'
            '"params":{"mode":"select"},"id":1}')
    except Exception as exc:
        log("stereo_select failed: %s" % exc)


# --------------------------------------------------------------------------
# Weather (dock right-end): Open-Meteo, Mesa AZ — keyless, the same
# source the BAR uses. Published to Home window properties; offline
# or failed fetches leave the properties empty and the dock slot
# hides (honest absence).
# --------------------------------------------------------------------------
_WEATHER_CODES = [
    (0, "Clear"), (1, "Mostly clear"), (2, "Partly cloudy"),
    (3, "Cloudy"), (45, "Fog"), (48, "Fog"), (51, "Drizzle"),
    (53, "Drizzle"), (55, "Drizzle"), (56, "Drizzle"), (57, "Drizzle"),
    (61, "Rain"), (63, "Rain"), (65, "Heavy rain"), (66, "Rain"),
    (67, "Rain"), (71, "Snow"), (73, "Snow"), (75, "Snow"),
    (77, "Snow"), (80, "Showers"), (81, "Showers"), (82, "Showers"),
    (85, "Snow"), (86, "Snow"), (95, "Thunderstorm"),
    (96, "Thunderstorm"), (99, "Thunderstorm"),
]
WEATHER_URL = (
    "https://api.open-meteo.com/v1/forecast?latitude=33.4152"
    "&longitude=-111.8315&current=temperature_2m,weather_code"
    "&daily=temperature_2m_max,temperature_2m_min"
    "&temperature_unit=fahrenheit&timezone=America%2FPhoenix"
    "&forecast_days=1")


def _weather_label(code):
    try:
        code = int(code)
    except Exception:
        return ""
    best = ""
    for known, label in _WEATHER_CODES:
        if code == known:
            return label
        if code > known:
            best = label
    return best


def publish_weather():
    if xbmcgui is None:
        return False
    try:
        import urllib.request
        req = urllib.request.Request(
            WEATHER_URL, headers={"User-Agent": "RocOS/3.2"})
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        cur = data.get("current") or {}
        daily = data.get("daily") or {}
        temp = cur.get("temperature_2m")
        if temp is None:
            return False
        cond = _weather_label(cur.get("weather_code"))
        hi = (daily.get("temperature_2m_max") or [None])[0]
        lo = (daily.get("temperature_2m_min") or [None])[0]
        home = xbmcgui.Window(HOME_WINDOW_ID)
        home.setProperty("RocWeather.Temp", "%d°" % int(round(temp)))
        home.setProperty("RocWeather.Cond", cond)
        if hi is not None and lo is not None:
            home.setProperty("RocWeather.HiLo",
                             "H %d  L %d" % (int(round(hi)), int(round(lo))))
        home.setProperty("RocWeather.Checked", str(int(time.time())))
        return True
    except Exception as exc:
        log("weather fetch failed: %s" % exc)
        return False


def publish_notification(title, text):
    """Dock notification flip: the service's monitor calls this for
    real Kodi notifications; the service clears them when stale."""
    if xbmcgui is None:
        return
    try:
        home = xbmcgui.Window(HOME_WINDOW_ID)
        home.setProperty("RocNotify.Title", title or "")
        home.setProperty("RocNotify.Text", text or "")
    except Exception as exc:
        log("notify publish failed: %s" % exc)


def clear_notification():
    if xbmcgui is None:
        return
    try:
        home = xbmcgui.Window(HOME_WINDOW_ID)
        home.setProperty("RocNotify.Title", "")
        home.setProperty("RocNotify.Text", "")
    except Exception:
        pass


# --------------------------------------------------------------------------
# playback snapshot / resume keeper / source re-pick support (v3.2.0,
# Eric 2026-10-24 16:36-16:39: resume on any launch after a sudden
# shutdown, an OSD source re-pick, and an Episodes/Collection panel).
# The resume checkpoint is PER-PROFILE on purpose (special://profile):
# each household profile keeps its own last spot. It carries title +
# IMDb/TMDb/TVDb IDs + season/episode so another device running the
# build can re-resolve the same title; the cross-device progress leg
# itself rides Trakt (his sign-in, never baked in here).
# --------------------------------------------------------------------------
import re as _re
import time as _time

try:
    import urllib.request as _urlreq
except Exception:  # pragma: no cover
    _urlreq = None

RESUME_FILE = "resume.json"
SEEK_FILE = "pending_seek.json"


def _rpc(method, params):
    if xbmc is None:
        return {}
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        out = xbmc.executeJSONRPC(json.dumps(req))
        return (json.loads(out) or {}).get("result") or {}
    except Exception as exc:
        log("rpc %s failed: %s" % (method, exc))
        return {}


def now_playing_snapshot():
    """Identity of the playing item, or None. JSON-RPC Player.GetItem
    is the reliable source (unique IDs included); the info tag is the
    fallback. Never raises."""
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            return None
        snap = {"title": "", "showtitle": "", "season": -1, "episode": -1,
                "year": 0, "type": "", "path": "", "imdb": "", "tmdb": "",
                "tvdb": "", "dbid": -1}
        try:
            snap["path"] = player.getPlayingFile() or ""
        except Exception:
            pass
        players = _rpc("Player.GetActivePlayers", {})
        pid = None
        for p in players if isinstance(players, list) else []:
            if p.get("type") == "video":
                pid = p.get("playerid")
                break
        item = {}
        if pid is not None:
            res = _rpc("Player.GetItem", {
                "playerid": pid,
                "properties": ["title", "showtitle", "season", "episode",
                               "year", "file", "uniqueid", "type", "id"]})
            item = res.get("item") or {}
        if item:
            snap["title"] = item.get("title") or ""
            snap["showtitle"] = item.get("showtitle") or ""
            snap["season"] = item.get("season", -1) or -1
            snap["episode"] = item.get("episode", -1) or -1
            snap["year"] = item.get("year", 0) or 0
            snap["type"] = item.get("type") or ""
            snap["dbid"] = item.get("id", -1) or -1
            if item.get("file"):
                snap["path"] = item["file"]
            uid = item.get("uniqueid") or {}
            snap["imdb"] = str(uid.get("imdb") or "")
            snap["tmdb"] = str(uid.get("tmdb") or "")
            snap["tvdb"] = str(uid.get("tvdb") or "")
        if not snap["title"]:
            tag = player.getVideoInfoTag()
            snap["title"] = tag.getTitle() or ""
            snap["showtitle"] = tag.getTVShowTitle() or ""
            snap["season"] = tag.getSeason()
            snap["episode"] = tag.getEpisode()
            snap["year"] = tag.getYear()
            snap["imdb"] = str(tag.getIMDBNumber() or "")
        if snap["showtitle"] and snap["type"] in ("", "unknown"):
            snap["type"] = "episode"
        return snap
    except Exception as exc:
        log("snapshot failed: %s" % exc)
        return None


def snapshot_display(snap):
    if not snap:
        return ""
    if snap.get("showtitle"):
        label = snap["showtitle"]
        if snap.get("season", -1) >= 0 and snap.get("episode", -1) >= 0:
            label += " S%02dE%02d" % (snap["season"], snap["episode"])
        if snap.get("title") and snap["title"] != snap["showtitle"]:
            label += " - " + snap["title"]
        return label
    label = snap.get("title") or ""
    if snap.get("year"):
        label += " (%d)" % snap["year"]
    return label


def fmt_clock(seconds):
    try:
        seconds = int(max(0, seconds))
    except Exception:
        seconds = 0
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


# ---- resume checkpoint (per-profile store) ----

def resume_save(snap, position, duration):
    if not snap:
        return False
    data = {"snap": snap, "position": float(position),
            "duration": float(duration), "saved_at": _time.time()}
    return _write_json(RESUME_FILE, data)


def resume_load():
    return _read_json(RESUME_FILE)


def resume_delete():
    try:
        path = os.path.join(_data_dir(), RESUME_FILE)
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass
    publish_resume_props()


def publish_resume_props():
    """Mirror the checkpoint into Home window properties the skin's
    RESUME strip reads. Called on service start (a checkpoint left by
    a crashed/killed session is offered on the next launch), after
    every checkpoint write, and on clear."""
    if xbmcgui is None:
        return
    try:
        win = xbmcgui.Window(HOME_WINDOW_ID)
        data = resume_load()
        snap = data.get("snap") or {}
        if snap and data.get("position"):
            win.setProperty("RocResume.Ready", "1")
            win.setProperty("RocResume.Title", snapshot_display(snap))
            win.setProperty(
                "RocResume.Detail",
                "Left off at %s of %s" % (fmt_clock(data["position"]),
                                          fmt_clock(data.get("duration", 0))))
        else:
            win.setProperty("RocResume.Ready", "")
            win.setProperty("RocResume.Title", "")
            win.setProperty("RocResume.Detail", "")
    except Exception as exc:
        log("publish resume props failed: %s" % exc)


# ---- pending seek (armed by one-shot actions, applied by the service) ----

def seek_arm(seconds, title_hint=""):
    return _write_json(SEEK_FILE, {"time": float(seconds),
                                   "title": title_hint,
                                   "ts": _time.time()})


def seek_peek():
    data = _read_json(SEEK_FILE)
    return data if data.get("time") else None


def seek_clear():
    try:
        path = os.path.join(_data_dir(), SEEK_FILE)
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass


# ---- TMDB mini-client (collection / season data for the panel) ----
# The API key is TMDb Helper's own bundled key, read from its files at
# runtime — nothing of Eric's is stored or baked into rocui.

_TMDB_KEY_CACHE = [None]


def tmdb_key():
    if _TMDB_KEY_CACHE[0] is not None:
        return _TMDB_KEY_CACHE[0]
    key = ""
    try:
        path = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.themoviedb.helper/"
            "resources/tmdbhelper/lib/api/api_keys/tmdb.py")
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            m = _re.search(r"API_KEY\s*=\s*['\"]([^'\"]+)['\"]", fh.read())
        if m:
            key = m.group(1)
    except Exception as exc:
        log("tmdb key read failed: %s" % exc)
    _TMDB_KEY_CACHE[0] = key
    return key


def tmdb_get(path):
    key = tmdb_key()
    if not key or _urlreq is None:
        return None
    try:
        url = "https://api.themoviedb.org/3/%s%sapi_key=%s" % (
            path, "&" if "?" in path else "?", key)
        req = _urlreq.Request(url, headers={"User-Agent": "RocOS"})
        with _urlreq.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        log("tmdb get %s failed: %s" % (path, exc))
        return None


def tmdb_find_tmdb_id(snap):
    """Resolve a TMDb id from an IMDb id via TMDB's /find endpoint."""
    imdb = (snap or {}).get("imdb") or ""
    if not imdb:
        return ""
    is_tv = bool((snap or {}).get("showtitle")) or \
        (snap or {}).get("type") == "episode"
    data = tmdb_get("find/%s?external_source=imdb_id" % imdb)
    if not data:
        return ""
    bucket = "tv_results" if is_tv else "movie_results"
    rows = data.get(bucket) or []
    if rows and rows[0].get("id"):
        return str(rows[0]["id"])
    return ""


def snapshot_tmdb_id(snap):
    if not snap:
        return ""
    if snap.get("tmdb"):
        return str(snap["tmdb"])
    found = tmdb_find_tmdb_id(snap)
    if found:
        snap["tmdb"] = found
    return found
