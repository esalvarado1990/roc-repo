# -*- coding: utf-8 -*-
"""
script.rocui — script entry point (RunScript actions from the Roc OS skin).

Actions:
  action=adult_gate[,target=plugin.video.cumination]  PIN gate, then open
  action=reset_pin                                    change the PIN
  action=mode_cycle                                   dock light button:
                                                      manual override pick
  action=sync_daypart                                 apply clock daypart now
  action=vpn_refresh                                  re-check + publish VPN
"""
import sys

import rocui_common as rc


def _params(argv):
    params = {}
    for arg in argv:
        if "=" in arg:
            key, value = arg.split("=", 1)
            params[key.strip()] = value.strip()
    return params


def main():
    params = _params(sys.argv[1:])
    action = params.get("action", "")
    if action == "adult_gate":
        rc.adult_gate(params.get("target", "plugin.video.cumination"))
    elif action == "reset_pin":
        rc.reset_pin()
    elif action == "mode_cycle":
        rc.mode_cycle()
    elif action == "sync_daypart":
        rc.sync_daypart()
    elif action == "vpn_refresh":
        rc.publish_vpn_state()
    elif action == "stage_open":
        rc.stage_open(params.get("cid", ""))
    elif action == "view_more":
        rc.view_more(params.get("path", ""))
    elif action == "timeline_prime":
        rc.timeline_prime()
    elif action == "timeline_jump":
        rc.timeline_jump()
    elif action == "adult_guard":
        rc.adult_guard()
    elif action == "stereo_select":
        rc.stereo_select()
    elif action == "source_select":
        import rocui_playback
        rocui_playback.source_select()
    elif action == "resume_play":
        import rocui_playback
        rocui_playback.resume_play()
    elif action == "resume_clear":
        import rocui_playback
        rocui_playback.resume_clear()
    elif action == "episodes_panel":
        import rocui_playback
        rocui_playback.episodes_panel()
    else:
        rc.log("default.py called with unknown action: %r" % action)


if __name__ == "__main__":
    main()
