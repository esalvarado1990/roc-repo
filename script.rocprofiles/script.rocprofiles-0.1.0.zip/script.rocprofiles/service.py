# Roc Profiles service — runs inside whichever Kodi profile is loaded.
# August: enforce the addon blocklist on profile load and keep him out of
# settings / file manager / addon browser (best-effort window guard; his
# real protection is the whitelist — his menu and sources carry nothing else).
# Nue / Jamama: keep the adult addon disabled (adult section is E-Roc-only).
# E-Roc: no enforcement (master).
import xbmc
import rocprofiles_common as rp

try:
    import xbmcgui
except Exception:
    xbmcgui = None

monitor = xbmc.Monitor()
last_profile = None
enforced_for = None
applied_hide_ratings = None

while not monitor.abortRequested():
    profile = rp.current_profile()
    if profile != last_profile:
        last_profile = profile
        enforced_for = None
    fl = rp.flags()
    # Ratings gate (v3.0): profiles flagged hide_ratings (August) get the
    # RocProfiles.HideRatings window property, which the skin's home/hub
    # preview popup checks before drawing any rating chip. Ratings stay
    # available on the parent-facing detail stage.
    want_hide = bool(fl and fl.get("hide_ratings"))
    if xbmcgui is not None and want_hide != applied_hide_ratings:
        try:
            win = xbmcgui.Window(10000)
            if want_hide:
                win.setProperty("RocProfiles.HideRatings", "true")
            else:
                win.clearProperty("RocProfiles.HideRatings")
            applied_hide_ratings = want_hide
            rp.log("ratings gate %s for profile %s"
                   % ("ON (chips hidden)" if want_hide else "off", profile))
        except Exception as exc:
            rp.log("ratings gate error: %s" % exc)
    if fl and fl.get("profile") == profile and enforced_for != profile:
        if fl.get("disable_addons"):
            rp.enforce_disable_list(fl)
        enforced_for = profile
    if fl.get("window_guard"):
        try:
            import xbmcgui
            wid = xbmcgui.getCurrentWindowId()
            if wid in rp.GUARDED_WINDOWS:
                xbmc.executebuiltin("ActivateWindow(home)")
                xbmc.executebuiltin("Notification(Roc Kids,That corner is for grown-ups,3000)")
                rp.log("window guard bounced window %s in profile %s" % (wid, profile))
        except Exception as exc:
            rp.log("window guard error: %s" % exc)
    if monitor.waitForAbort(3):
        break
