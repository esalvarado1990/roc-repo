# Roc Profiles — shared helpers.
# Data model: every Kodi profile carries its own addon_data, so
# special://profile/addon_data/script.rocprofiles/profile.json always
# describes the profile that is currently loaded. The payload seeds one
# per profile (master E-Roc's lives in userdata/addon_data).
import json
import xbmc
import xbmcvfs

ADDON_ID = "script.rocprofiles"
DATA = "special://profile/addon_data/script.rocprofiles/"

# Windows a locked-down profile must never sit in:
# 10003 file manager, 10004 settings, 10040 addon browser.
GUARDED_WINDOWS = {10003, 10004, 10040}


def log(msg):
    xbmc.log("[script.rocprofiles] %s" % msg, xbmc.LOGINFO)


def read_json(path):
    try:
        fh = xbmcvfs.File(path)
        raw = fh.read()
        fh.close()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        return json.loads(raw) if raw else {}
    except Exception as exc:
        log("read_json failed for %s: %s" % (path, exc))
        return {}


def flags():
    return read_json(DATA + "profile.json")


def current_profile():
    """Name of the loaded Kodi profile via JSON-RPC, '' if unknown."""
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": "Profiles.GetCurrentProfile",
               "params": {"properties": ["label"]}}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        return (resp.get("result") or {}).get("label", "") or ""
    except Exception as exc:
        log("current_profile failed: %s" % exc)
        return ""


def jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception as exc:
        log("jsonrpc %s failed: %s" % (method, exc))
        return {}


def set_addon_enabled(addon_id, enabled):
    return jsonrpc("Addons.SetAddonEnabled",
                   {"addonid": addon_id, "enabled": bool(enabled)})


def enforce_disable_list(fl=None):
    """Disable this profile's blocklist addons (per-profile addon state —
    Kodi keeps enable/disable per profile, installs are shared)."""
    fl = fl if fl is not None else flags()
    done = []
    for addon_id in fl.get("disable_addons", []):
        res = set_addon_enabled(addon_id, False)
        if "error" not in res:
            done.append(addon_id)
    if done:
        log("disabled for profile %s: %s" % (fl.get("profile", "?"), ", ".join(done)))
    return done
