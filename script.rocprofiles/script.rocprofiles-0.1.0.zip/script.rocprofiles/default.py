# Roc Profiles script — manual actions.
#   (no action) / action=status   : show loaded profile + its rule flags
#   action=enforce                : re-run this profile's addon blocklist
#   action=setup_locks            : explain the on-device lock setup (no PIN
#                                   is ever entered into, or stored by, code)
#   action=apply                  : copy the bundled payload into userdata
#                                   (profiles.xml + profiles/<Name>/) and
#                                   prompt a restart. Run ONCE from the
#                                   master profile on a v2.2.1 build. The
#                                   current userdata should be backed up
#                                   first (Roc Builds Installer does this
#                                   automatically before any build apply).
import os
import shutil
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import rocprofiles_common as rp

ADDON = xbmcaddon.Addon(rp.ADDON_ID)


def _params(argv):
    out = {}
    for part in argv[2].split("&") if len(argv) > 2 else []:
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _copy_tree(src, dst):
    for root, _dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        target = dst if rel == "." else os.path.join(dst, rel)
        xbmcvfs.mkdirs(target)
        for name in files:
            s = os.path.join(root, name)
            d = os.path.join(target, name)
            with open(s, "rb") as fh:
                data = fh.read()
            out = xbmcvfs.File(d, "wb")
            out.write(data)
            out.close()


def apply_payload():
    payload = os.path.join(ADDON.getAddonInfo("path"), "resources", "payload")
    home_userdata = xbmcvfs.translatePath("special://home/userdata/")
    if not xbmcgui.Dialog().yesno(
            "Roc Profiles",
            "Apply the household profiles (E-Roc / Nue / Jamama / August)?\n"
            "This writes profiles.xml and the profile folders, then Kodi must restart.\n"
            "Your current setup stays as the E-Roc (master) profile."):
        return
    xbmcvfs.copy(os.path.join(payload, "profiles.xml"),
                 os.path.join(home_userdata, "profiles.xml"))
    _copy_tree(os.path.join(payload, "profiles"),
               os.path.join(home_userdata, "profiles"))
    _copy_tree(os.path.join(payload, "master-userdata"), home_userdata)
    xbmcgui.Dialog().ok(
        "Roc Profiles",
        "Profiles written. Kodi will now restart — pick your name on the\n"
        "login screen. Set profile lock codes on-device (Settings > Profiles)\n"
        "and the adult PIN inside E-Roc when prompted. Nothing was stored here.")
    xbmc.executebuiltin("RestartApp")


def main():
    action = _params(sys.argv).get("action", "status")
    if action == "apply":
        apply_payload()
    elif action == "enforce":
        done = rp.enforce_disable_list()
        xbmcgui.Dialog().notification("Roc Profiles",
                                      "Blocklist enforced: %d addons" % len(done))
    elif action == "setup_locks":
        xbmcgui.Dialog().ok(
            "Roc Profiles — lock setup",
            "On-device only, set by Eric — never in chat, never in a file:\n"
            "1) Settings > Profiles: set a lock code on E-Roc and Nue.\n"
            "2) Jamama: lock settings / sources / addons (technical only).\n"
            "3) August needs no code — his whitelist is the protection.\n"
            "4) Adult door (E-Roc only): first tap asks Eric to set the PIN;\n"
            "   only a salted hash is kept, by script.rocui.")
    else:
        fl = rp.flags()
        xbmcgui.Dialog().ok(
            "Roc Profiles",
            "Profile: %s\nAdult section: %s\nFringe section: %s\nMenu: %s"
            % (rp.current_profile() or fl.get("profile", "?"),
               "yes (PIN-gated)" if fl.get("adult_section") else "absent",
               "yes" if fl.get("fringe_section") else "no",
               fl.get("menu", "?")))


if __name__ == "__main__":
    main()
