import json, os, sys, urllib.parse, urllib.request, zipfile
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
BASE = "https://esalvarado1990.github.io/roc-repo/"
HOME = xbmcvfs.translatePath("special://home/")
PREVIEWS = os.path.join(ADDON_PATH, "resources", "previews")

# theme folder under resources/previews, keyed by build title from builds.json
THEMES = {
    "Roc Gold": "rocgold",
    "Haunted": "haunted",
    "Night Route": "nightroute",
    "Noir Raven": "noirraven",
    "Sesh Lounge": "sesh",
}

def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))

def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f %s" % (n, u)
        n /= 1024.0
    return "%.1f GB" % n

def theme_key(b):
    if b.get("build") in THEMES:
        return THEMES[b["build"]]
    return (b.get("id") or "").rsplit("-", 1)[0].replace("-", "")

def preview_files(theme):
    folder = os.path.join(PREVIEWS, theme)
    out = []
    if os.path.isdir(folder):
        for fn in sorted(os.listdir(folder)):
            if fn.lower().endswith((".jpg", ".jpeg", ".png")):
                out.append(os.path.join(folder, fn))
    return out

def apply_art(li, shots):
    """Give a ListItem real art: first screenshot everywhere the skin looks,
    plus every screenshot as available fanart so supporting skins can cycle.
    setAvailableFanart is guarded -- older APIs without it must never break
    the list, the setArt art above always applies."""
    if not shots:
        return
    first = shots[0]
    li.setArt({"thumb": first, "icon": first, "fanart": first,
               "poster": first, "landscape": first, "clearart": first})
    if len(shots) > 1:
        fan = [{"image": s, "preview": s} for s in shots]
        try:
            li.setAvailableFanart(fan)
        except Exception:
            pass
        try:
            li.getVideoInfoTag().setAvailableFanart(fan)
        except Exception:
            pass

def list_builds(handle):
    try:
        manifest = fetch_json(BASE + "builds.json")
    except Exception as e:
        xbmcgui.Dialog().ok("Roc Builds", "Could not reach Roc Repo.\n%s" % e)
        return
    xbmcplugin.setContent(handle, "videos")
    for b in manifest["builds"]:
        label = "%s - %s  (%s)" % (b["build"], b["tier"], human(b["size"]))
        theme = theme_key(b)
        shots = preview_files(theme)
        li = xbmcgui.ListItem(label=label)
        plot = b["desc"]
        if shots:
            plot += "\n\n%d preview screenshots inside -- open to view them, then install from there." % len(shots)
        li.setInfo("video", {"title": label, "plot": plot})
        apply_art(li, shots)
        q = urllib.parse.urlencode({
            "mode": "gallery", "theme": theme, "bname": label,
            "iurl": b["url"], "idesc": b["desc"],
        })
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, True)
    xbmcplugin.endOfDirectory(handle)

def gallery(handle, params):
    theme = params.get("theme", "")
    bname = params.get("bname", "build")
    shots = preview_files(theme)
    xbmcplugin.setContent(handle, "images")
    # the install action, clearly labeled, first in the folder
    li = xbmcgui.ListItem(label="▶ Install %s" % bname)
    li.setInfo("video", {"title": "Install %s" % bname, "plot": params.get("idesc", "")})
    apply_art(li, shots)
    q = urllib.parse.urlencode({"mode": "install", "url": params.get("iurl", ""),
                                "name": bname})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, False)
    # one item per screenshot; the screenshot itself is the item's full art,
    # and opening it jumps to the Pictures window on this theme's folder
    for i, shot in enumerate(shots, 1):
        label = "%s — screenshot %d" % (bname, i)
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": label,
                             "plot": "Preview %d of %d for %s. Open to view full screen." % (i, len(shots), bname)})
        apply_art(li, [shot])
        q = urllib.parse.urlencode({"mode": "view", "theme": theme})
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, False)
    xbmcplugin.endOfDirectory(handle)

def view(params):
    folder = os.path.join(PREVIEWS, params.get("theme", ""))
    if os.path.isdir(folder):
        xbmc.executebuiltin("ActivateWindow(Pictures,%s,return)" % folder)

def install(url, name):
    dlg = xbmcgui.Dialog()
    if not dlg.yesno("Install build", "Install %s?\n\nThis replaces the current Kodi setup on this device (addons, menus, settings). Your media files are not touched." % name):
        return
    tmp = os.path.join(HOME, "roc-build-download.zip")
    prog = xbmcgui.DialogProgressBG()
    prog.create("Roc Builds", "Downloading " + name)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
        with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    prog.update(int(done * 100 / total), "Roc Builds", "Downloading " + name)
        prog.update(100, "Roc Builds", "Installing...")
        with zipfile.ZipFile(tmp) as z:
            for info in z.infolist():
                target = os.path.normpath(os.path.join(HOME, info.filename))
                if not target.startswith(os.path.normpath(HOME)):
                    continue
                z.extract(info, HOME)
    except Exception as e:
        prog.close()
        dlg.ok("Roc Builds", "Install failed:\n%s" % e)
        return
    prog.close()
    try:
        os.remove(tmp)
    except OSError:
        pass
    if dlg.yesno("Roc Builds", "Build installed. Restart Kodi now to wear it?"):
        xbmc.executebuiltin("RestartApp")

def router():
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode = params.get("mode")
    if mode == "install":
        install(params["url"], params.get("name", "build"))
    elif mode == "gallery":
        gallery(handle, params)
    elif mode == "view":
        view(params)
    else:
        list_builds(handle)

router()
