"""Roc Builds Installer 2.0.0 — plugin.program.rocbuilds

v2 changes over 1.1.0:
- Package integrity: downloads are SHA-256 verified against builds.json
  before anything is extracted (SEC5). A mismatch is refused with a
  plain-language error (R24) — a corrupt package never touches the setup.
- Setup-preserving: the current userdata is backed up to
  special://home/roc-backups/ before a build is applied (R22).
- Installer finalization (R5): after extraction the installer runs an
  addon enable pass over Addons33.db (everything the package shipped,
  EXCEPT script.trakt — Trakt ships installed but OFF on purpose, R2:
  sign-ins happen once, in one sitting, after the build settles), asks
  Kodi to rescan local addons, and re-applies the critical settings
  (skin, services lockdown) through Kodi's own settings API so they
  survive the restart.
- "Finalize / repair current build" root entry: the deterministic,
  supported-API version of the same pass, for after a restart.
- Gallery/previews from 1.1.0 are unchanged.
"""
import hashlib, json, os, sqlite3, sys, time, urllib.parse, urllib.request, zipfile
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
BASE = "https://esalvarado1990.github.io/roc-repo/"
HOME = xbmcvfs.translatePath("special://home/")
PREVIEWS = os.path.join(ADDON_PATH, "resources", "previews")
TARGET_SKIN = "skin.rocos"
# R2: these ship in every package but stay DISABLED after an install.
SKIP_ENABLE = ("script.trakt",)

THEMES = {
    "Roc Gold": "rocgold",
    "Grin": "haunted",
    "Night Route": "nightroute",
    "Noir Raven": "noirraven",
    "Sesh Lounge": "sesh",
}

# ---------------------------------------------------------------- pure helpers
def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f %s" % (n, u)
        n /= 1024.0
    return "%.1f GB" % n

def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1048576)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def verify_file(path, expected_sha256, expected_size):
    """Return (ok, message). Pure python — unit-tested offline."""
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return False, "The downloaded file could not be read (%s)." % e
    if expected_size:
        try:
            if size != int(expected_size):
                return False, ("The download is the wrong size (%s arrived, %s expected). "
                               "Nothing was installed." % (human(size), human(int(expected_size))))
        except (TypeError, ValueError):
            pass
    if expected_sha256:
        got = sha256_of(path)
        if got.lower() != str(expected_sha256).lower():
            return False, ("The download does not match the fingerprint in Roc Repo "
                           "(SHA-256 mismatch). It may be corrupted, so nothing was "
                           "installed. Your current setup was not touched.")
        return True, ""
    return True, "size-only check (this manifest entry carries no fingerprint)"

def find_addons_db(home):
    dbdir = os.path.join(home, "userdata", "Database")
    best = None
    if os.path.isdir(dbdir):
        for fn in os.listdir(dbdir):
            if fn.startswith("Addons") and fn.endswith(".db"):
                if best is None or fn > best:
                    best = fn
    return os.path.join(dbdir, best) if best else None

def enable_pass(home, skip=SKIP_ENABLE):
    """Enable every addon folder present under home/addons in the addons DB,
    except the skip list. Returns (enabled_count, note). Pure sqlite/os."""
    addons_dir = os.path.join(home, "addons")
    db = find_addons_db(home)
    if not db:
        return 0, "no addons database yet — Kodi will register the addons on restart"
    if not os.path.isdir(addons_dir):
        return 0, "no addons folder found"
    ids = [d for d in sorted(os.listdir(addons_dir))
           if os.path.isdir(os.path.join(addons_dir, d)) and d not in skip]
    if not ids:
        return 0, "nothing to enable"
    try:
        con = sqlite3.connect(db, timeout=15)
        try:
            con.execute("PRAGMA busy_timeout=15000")
            cur = con.cursor()
            n = 0
            for aid in ids:
                cur.execute("UPDATE installed SET enabled=1 WHERE addonID=?", (aid,))
                n += cur.rowcount if cur.rowcount > 0 else 0
            con.commit()
            return n, ""
        finally:
            con.close()
    except Exception as e:
        return 0, "addons database was busy (%s) — use Finalize / repair after the restart" % e

# ---------------------------------------------------------------- xbmc glue
def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))

def theme_key(b):
    # v2.2.2: per-tier preview sets win when they exist (GRIN ships a
    # gallery per tier — haunted-lite / haunted-medium /
    # haunted-powerhouse); every other build keeps its identity folder.
    bid = b.get("id") or ""
    if bid and os.path.isdir(os.path.join(PREVIEWS, bid)):
        return bid
    if b.get("build") in THEMES:
        return THEMES[b["build"]]
    return bid.rsplit("-", 1)[0].replace("-", "")

def preview_files(theme):
    folder = os.path.join(PREVIEWS, theme)
    out = []
    if os.path.isdir(folder):
        for fn in sorted(os.listdir(folder)):
            if fn.lower().endswith((".jpg", ".jpeg", ".png")):
                out.append(os.path.join(folder, fn))
    return out

def apply_art(li, shots):
    if not shots:
        return
    first = shots[0]
    li.setArt({"thumb": first, "icon": first, "fanart": first,
               "poster": first, "landscape": first, "clearart": first})
    if len(shots) > 1:
        fan = [{"image": s, "preview": s} for s in shots]
        try:
            li.setAvailableFanart(fan)
        except Exception:
            pass
        try:
            li.getVideoInfoTag().setAvailableFanart(fan)
        except Exception:
            pass

def jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "method": method, "id": 1}
    if params is not None:
        req["params"] = params
    try:
        out = xbmc.executeJSONRPC(json.dumps(req))
        return json.loads(out) if out else {}
    except Exception:
        return {}

def set_setting(setting, value):
    r = jsonrpc("Settings.SetSettingValue", {"setting": setting, "value": value})
    return r.get("result") is True

def list_builds(handle):
    try:
        manifest = fetch_json(BASE + "builds.json")
    except Exception as e:
        xbmcgui.Dialog().ok("Roc Builds", "Could not reach Roc Repo.\n%s" % e)
        return
    xbmcplugin.setContent(handle, "videos")
    ver = manifest.get("version", "?")
    li = xbmcgui.ListItem(label="— Roc Repo builds v%s —" % ver)
    li.setInfo("video", {"title": "Roc Repo builds v%s" % ver,
                         "plot": "Every build below carries the same core: Roc OS, the PIN gate, the VPN shield, the security lockdown. Tiers differ only in weight."})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?mode=none", li, False)
    li = xbmcgui.ListItem(label="✔ Finalize / repair current build")
    li.setInfo("video", {"title": "Finalize / repair current build",
                         "plot": "Run this once after a restart if anything looks stock: it switches on every addon this setup shipped (Trakt stays off on purpose), sets the Roc OS skin, and re-applies the security lockdown."})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?mode=finalize", li, False)
    li = xbmcgui.ListItem(label="⟳ Check for updates")
    li.setInfo("video", {"title": "Check for updates",
                         "plot": "Ask Kodi to re-read Roc Repo right now, so a newer installer or addon update is offered without waiting."})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?mode=updates", li, False)
    for b in manifest["builds"]:
        label = "%s - %s  (%s)" % (b["build"], b["tier"], human(b["size"]))
        theme = theme_key(b)
        shots = preview_files(theme)
        li = xbmcgui.ListItem(label=label)
        plot = b["desc"]
        if shots:
            plot += "\n\n%d preview screenshots inside -- open to view them, then install from there." % len(shots)
        li.setInfo("video", {"title": label, "plot": plot})
        apply_art(li, shots)
        q = urllib.parse.urlencode({
            "mode": "gallery", "theme": theme, "bname": label,
            "iurl": b["url"], "idesc": b["desc"],
            "isha": b.get("sha256", ""), "isize": b.get("size", ""),
        })
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, True)
    xbmcplugin.endOfDirectory(handle)

def gallery(handle, params):
    theme = params.get("theme", "")
    bname = params.get("bname", "build")
    shots = preview_files(theme)
    xbmcplugin.setContent(handle, "images")
    li = xbmcgui.ListItem(label="▶ Install %s" % bname)
    li.setInfo("video", {"title": "Install %s" % bname, "plot": params.get("idesc", "")})
    apply_art(li, shots)
    q = urllib.parse.urlencode({"mode": "install", "url": params.get("iurl", ""),
                                "name": bname, "sha": params.get("isha", ""),
                                "size": params.get("isize", "")})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, False)
    for i, shot in enumerate(shots, 1):
        label = "%s — screenshot %d" % (bname, i)
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": label,
                             "plot": "Preview %d of %d for %s. Open to view full screen." % (i, len(shots), bname)})
        apply_art(li, [shot])
        q = urllib.parse.urlencode({"mode": "view", "theme": theme})
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, False)
    xbmcplugin.endOfDirectory(handle)

def view(params):
    folder = os.path.join(PREVIEWS, params.get("theme", ""))
    if os.path.isdir(folder):
        xbmc.executebuiltin("ActivateWindow(Pictures,%s,return)" % folder)

def backup_userdata():
    """Best-effort backup of the current userdata before an apply (R22).
    Thumbnails are a regenerable cache and are left out."""
    src = os.path.join(HOME, "userdata")
    if not os.path.isdir(src):
        return None
    dst_dir = os.path.join(HOME, "roc-backups")
    try:
        os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, "userdata-%s.zip" % time.strftime("%Y%m%d-%H%M%S"))
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as z:
            for root, dirs, files in os.walk(src):
                if os.path.relpath(root, src).startswith("Thumbnails"):
                    dirs[:] = []
                    continue
                for fn in files:
                    full = os.path.join(root, fn)
                    z.write(full, os.path.relpath(full, HOME))
        return dst
    except Exception:
        return None

def apply_critical_settings():
    """Re-apply the load-bearing settings through Kodi's own API so the
    running instance agrees with the package on disk (SEC3 lockdown)."""
    set_setting("lookandfeel.skin", TARGET_SKIN)
    for s in ("services.webserver", "services.upnpserver", "services.upnpcontrol",
              "services.upnpplayer", "services.upnprenderer", "services.zeroconf",
              "services.airplay", "services.esallinterfaces"):
        set_setting(s, False)

def install(url, name, sha, size):
    dlg = xbmcgui.Dialog()
    if not dlg.yesno("Install build", "Install %s?\n\nThis replaces the current Kodi setup on this device (addons, menus, settings). Your media files are not touched. Your current settings are backed up first." % name):
        return
    prog = xbmcgui.DialogProgressBG()
    prog.create("Roc Builds", "Backing up current setup...")
    backup = backup_userdata()
    tmp = os.path.join(HOME, "roc-build-download.zip")
    prog.update(0, "Roc Builds", "Downloading " + name)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
        with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    prog.update(int(done * 100 / total), "Roc Builds", "Downloading " + name)
        prog.update(100, "Roc Builds", "Checking the download...")
        ok, msg = verify_file(tmp, sha, size)
        if not ok:
            prog.close()
            try:
                os.remove(tmp)
            except OSError:
                pass
            dlg.ok("Roc Builds", "Install stopped — nothing was changed.\n\n%s" % msg)
            return
        prog.update(100, "Roc Builds", "Installing...")
        with zipfile.ZipFile(tmp) as z:
            for info in z.infolist():
                target = os.path.normpath(os.path.join(HOME, info.filename))
                if not target.startswith(os.path.normpath(HOME)):
                    continue
                z.extract(info, HOME)
    except Exception as e:
        prog.close()
        dlg.ok("Roc Builds", "Install failed:\n%s" % e)
        return
    prog.close()
    try:
        os.remove(tmp)
    except OSError:
        pass
    # finalization: enable pass + rescan + critical settings (R5)
    enabled, note = enable_pass(HOME)
    xbmc.executebuiltin("UpdateLocalAddons")
    apply_critical_settings()
    lines = "Build installed: %s" % name
    if backup:
        lines += "\nPrevious setup backed up to roc-backups."
    if enabled:
        lines += "\n%d addons switched on." % enabled
    if note:
        lines += "\n(%s)" % note
    lines += ("\n\nTrakt is installed but OFF on purpose — sign in once, in one "
              "sitting, after the build settles: Add-ons -> My add-ons -> "
              "Services -> Trakt -> Enable, then authorize.")
    lines += ("\n\nAfter the restart, if anything looks stock, open Roc Builds "
              "Installer -> Finalize / repair current build — one tap finishes the job.")
    if dlg.yesno("Roc Builds", lines + "\n\nRestart Kodi now to wear it?"):
        xbmc.executebuiltin("RestartApp")

def finalize():
    """Post-restart deterministic pass, supported APIs only."""
    dlg = xbmcgui.Dialog()
    addons_root = os.path.join(HOME, "addons")
    r = jsonrpc("Addons.GetAddons", {"properties": ["path", "enabled"]})
    enabled, already, failed = 0, 0, 0
    for a in (r.get("result") or {}).get("addons", []):
        aid = a.get("addonid")
        path = xbmcvfs.translatePath(a.get("path", "") or "")
        if not aid or aid in SKIP_ENABLE:
            continue
        if not path.startswith(addons_root):
            continue
        if a.get("enabled"):
            already += 1
            continue
        rr = jsonrpc("Addons.SetAddonEnabled", {"addonid": aid, "enabled": True})
        if rr.get("result") == "OK":
            enabled += 1
        else:
            failed += 1
    apply_critical_settings()
    xbmc.executebuiltin("UpdateLocalAddons")
    msg = ("Finalize complete.\n\n%d addons switched on, %d already on." % (enabled, already))
    if failed:
        msg += "\n%d could not be switched on — tell Roc which screen you saw." % failed
    msg += ("\nSkin set to Roc OS and the security lockdown re-applied.\n"
            "Trakt stays off on purpose until its one sign-in sitting.")
    dlg.ok("Roc Builds", msg)

def check_updates():
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmcgui.Dialog().ok("Roc Builds", "Kodi is re-reading Roc Repo now.\nIf a newer Roc addon exists, Kodi will offer the update in Add-ons.")

def router():
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode = params.get("mode")
    if mode == "install":
        install(params["url"], params.get("name", "build"),
                params.get("sha", ""), params.get("size", ""))
    elif mode == "gallery":
        gallery(handle, params)
    elif mode == "view":
        view(params)
    elif mode == "finalize":
        finalize()
    elif mode == "updates":
        check_updates()
    elif mode == "none":
        xbmcplugin.endOfDirectory(handle)
    else:
        list_builds(handle)

if __name__ == "__main__":
    router()
