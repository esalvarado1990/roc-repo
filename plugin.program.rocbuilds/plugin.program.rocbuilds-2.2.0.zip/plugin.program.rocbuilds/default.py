"""Roc Builds Installer 2.0.0 — plugin.program.rocbuilds

v2 changes over 1.1.0:
- Package integrity: downloads are SHA-256 verified against builds.json
  before anything is extracted (SEC5). A mismatch is refused with a
  plain-language error (R24) — a corrupt package never touches the setup.
- Setup-preserving: the current userdata is backed up to
  special://home/roc-backups/ before a build is applied (R22).
- Installer finalization (R5): after extraction the installer runs an
  addon enable pass over Addons33.db (everything the package shipped,
  EXCEPT script.trakt — Trakt ships installed but OFF on purpose, R2:
  sign-ins happen once, in one sitting, after the build settles), asks
  Kodi to rescan local addons, and re-applies the critical settings
  (skin, services lockdown) through Kodi's own settings API so they
  survive the restart.
- "Finalize / repair current build" root entry: the deterministic,
  supported-API version of the same pass, for after a restart.
- Gallery/previews from 1.1.0 are unchanged.
"""
import hashlib, json, os, shutil, sqlite3, sys, time, urllib.parse, urllib.request, zipfile
import xml.etree.ElementTree as ET
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
BASE = "https://esalvarado1990.github.io/roc-repo/"
HOME = xbmcvfs.translatePath("special://home/")
PREVIEWS = os.path.join(ADDON_PATH, "resources", "previews")
TARGET_SKIN = "skin.rocos"
# R2: these ship in every package but stay DISABLED after an install.
SKIP_ENABLE = ("script.trakt",)

THEMES = {
    "Roc Gold": "rocgold",
    "Grin": "haunted",
    "Night Route": "nightroute",
    "Noir Raven": "noirraven",
    "Sesh Lounge": "sesh",
}

# ---------------------------------------------------------------- pure helpers
def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f %s" % (n, u)
        n /= 1024.0
    return "%.1f GB" % n

def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1048576)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def verify_file(path, expected_sha256, expected_size):
    """Return (ok, message). Pure python — unit-tested offline."""
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return False, "The downloaded file could not be read (%s)." % e
    if expected_size:
        try:
            if size != int(expected_size):
                return False, ("The download is the wrong size (%s arrived, %s expected). "
                               "Nothing was installed." % (human(size), human(int(expected_size))))
        except (TypeError, ValueError):
            pass
    if expected_sha256:
        got = sha256_of(path)
        if got.lower() != str(expected_sha256).lower():
            return False, ("The download does not match the fingerprint in Roc Repo "
                           "(SHA-256 mismatch). It may be corrupted, so nothing was "
                           "installed. Your current setup was not touched.")
        return True, ""
    return True, "size-only check (this manifest entry carries no fingerprint)"

def _version_tuple(v):
    """'2.10.1' -> (2, 10, 1); junk parts count as 0. Pure/offline."""
    out = []
    for part in str(v or "").replace("-", ".").split("."):
        digits = ""
        for ch in part:
            if ch.isdigit():
                digits += ch
            else:
                break
        out.append(int(digits) if digits else 0)
    return tuple(out) or (0,)


def _version_lt(a, b):
    ta, tb = _version_tuple(a), _version_tuple(b)
    n = max(len(ta), len(tb))
    return ta + (0,) * (n - len(ta)) < tb + (0,) * (n - len(tb))


# Settings files whose device values must survive a build swap (G22/6):
# Trakt sign-ins and API keys live in these files, and a package must
# never clobber them.
PROTECTED_SETTINGS = (
    "addon_data/plugin.video.scrubsv2/settings.xml",
    "addon_data/plugin.video.thecrew/settings.xml",
    "addon_data/plugin.video.themoviedb.helper/settings.xml",
)
_AUTHISH = ("trakt", "token", "auth")


def _is_authish(setting_id):
    low = str(setting_id or "").lower()
    return any(k in low for k in _AUTHISH)


def _settings_map(root):
    """id -> element for every <setting> in the tree."""
    out = {}
    for el in root.iter("setting"):
        sid = el.get("id")
        if sid and sid not in out:
            out[sid] = el
    return out


def merge_settings_trees(device_root, pkg_root):
    """Merge package settings INTO the device's view: package values
    win EXCEPT (a) keys only the device has are kept, and (b) keys
    containing trakt/token/auth always keep the DEVICE value.
    Returns the merged root (a copy of the package tree, patched)."""
    import copy as _copy
    merged = _copy.deepcopy(pkg_root)
    dev = _settings_map(device_root)
    pkg = _settings_map(merged)
    parents = {c: par for par in merged.iter() for c in par}
    for sid, dev_el in dev.items():
        if sid not in pkg:
            merged.append(_copy.deepcopy(dev_el))
        elif _is_authish(sid):
            pkg_el = pkg[sid]
            parent = parents.get(pkg_el)
            if parent is not None:
                idx = list(parent).index(pkg_el)
                parent.remove(pkg_el)
                parent.insert(idx, _copy.deepcopy(dev_el))
    return merged


def merge_userdata_settings(home, pkg_userdata):
    """Trakt-token-safe settings merge (item 6). For each protected
    settings.xml: merge the package copy at pkg_userdata/<rel> with
    the device copy at home/userdata/<rel> and write the result to
    the DEVICE path. Package-only -> copied; device-only -> left
    alone; unparseable device file -> package file is NOT allowed to
    clobber auth keys blindly, so the device file is kept as-is.
    Returns {rel: note}. Pure file IO — unit-testable offline."""
    notes = {}
    for rel in PROTECTED_SETTINGS:
        pkg_path = os.path.join(pkg_userdata, rel)
        dev_path = os.path.join(home, "userdata", rel)
        if not os.path.isfile(pkg_path):
            continue
        if not os.path.isfile(dev_path):
            try:
                os.makedirs(os.path.dirname(dev_path), exist_ok=True)
                shutil.copyfile(pkg_path, dev_path)
                notes[rel] = "copied (no device file)"
            except Exception as e:
                notes[rel] = "copy failed: %s" % e
            continue
        try:
            dev_root = ET.parse(dev_path).getroot()
            pkg_root = ET.parse(pkg_path).getroot()
        except Exception as e:
            notes[rel] = "kept device file (parse failed: %s)" % e
            continue
        try:
            merged = merge_settings_trees(dev_root, pkg_root)
            ET.ElementTree(merged).write(
                dev_path, encoding="utf-8", xml_declaration=True)
            notes[rel] = "merged (device auth keys preserved)"
        except Exception as e:
            notes[rel] = "merge failed: %s" % e
    return notes


OMDB_SETTING_ID = "omdb_apikey"  # TMDb Helper resources/settings.xml:402


def apply_omdb_key(home):
    """G28: private OMDb route. Reads the device-local private file
    userdata/addon_data/script.rocui/omdb.key; if present, writes its
    contents into TMDb Helper's omdb_apikey setting (settings API
    first, settings.xml merge as fallback). Absent -> skip silently.
    The key value is NEVER logged or printed. Returns True/False."""
    key_path = os.path.join(
        home, "userdata", "addon_data", "script.rocui", "omdb.key")
    try:
        if not os.path.isfile(key_path):
            return False
        with open(key_path, "r", encoding="utf-8") as fh:
            key = fh.read().strip()
    except Exception:
        return False
    if not key:
        return False
    try:
        ad = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        ad.setSetting(OMDB_SETTING_ID, key)
        return True
    except Exception:
        pass
    try:
        spath = os.path.join(
            home, "userdata", "addon_data",
            "plugin.video.themoviedb.helper", "settings.xml")
        if os.path.isfile(spath):
            root = ET.parse(spath).getroot()
        else:
            os.makedirs(os.path.dirname(spath), exist_ok=True)
            root = ET.Element("settings", {"version": "2"})
        found = None
        for el in root.iter("setting"):
            if el.get("id") == OMDB_SETTING_ID:
                found = el
                break
        if found is None:
            found = ET.SubElement(root, "setting", {"id": OMDB_SETTING_ID})
        found.text = key
        if "default" in found.attrib:
            del found.attrib["default"]
        ET.ElementTree(root).write(
            spath, encoding="utf-8", xml_declaration=True)
        return True
    except Exception:
        return False


def _install_state_path(home):
    return os.path.join(home, "roc-install-state.json")


def write_install_state(home, state, url="", name="", sha="", size=""):
    try:
        with open(_install_state_path(home), "w", encoding="utf-8") as fh:
            json.dump({"state": state, "url": url, "name": name,
                       "sha": sha, "size": size,
                       "updated": int(time.time())}, fh)
    except Exception:
        pass


def read_install_state(home):
    try:
        with open(_install_state_path(home), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def download_with_resume(url, part_path, prog=None, name=""):
    """Download url -> part_path, resuming with an HTTP Range request
    when a partial file already exists and the server answers 206;
    otherwise restarts cleanly. Returns the final byte count."""
    existing = 0
    try:
        existing = os.path.getsize(part_path)
    except OSError:
        existing = 0
    headers = {"User-Agent": "Kodi"}
    mode = "wb"
    if existing > 0:
        headers["Range"] = "bytes=%d-" % existing
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=120) as r:
        status = getattr(r, "status", None) or r.getcode()
        if existing > 0 and status == 206:
            mode = "ab"
        else:
            existing = 0
        total = int(r.headers.get("Content-Length") or 0)
        grand = existing + total if total else 0
        done = existing
        with open(part_path, mode) as f:
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if prog is not None and grand:
                    prog.update(int(done * 100 / grand),
                                "Roc Builds", "Downloading " + name)
    return done


def find_addons_db(home):
    dbdir = os.path.join(home, "userdata", "Database")
    best = None
    if os.path.isdir(dbdir):
        for fn in os.listdir(dbdir):
            if fn.startswith("Addons") and fn.endswith(".db"):
                if best is None or fn > best:
                    best = fn
    return os.path.join(dbdir, best) if best else None

def enable_pass(home, skip=SKIP_ENABLE):
    """Enable every addon folder present under home/addons in the addons DB,
    except the skip list. Returns (enabled_count, note). Pure sqlite/os."""
    addons_dir = os.path.join(home, "addons")
    db = find_addons_db(home)
    if not db:
        return 0, "no addons database yet — Kodi will register the addons on restart"
    if not os.path.isdir(addons_dir):
        return 0, "no addons folder found"
    ids = [d for d in sorted(os.listdir(addons_dir))
           if os.path.isdir(os.path.join(addons_dir, d)) and d not in skip]
    if not ids:
        return 0, "nothing to enable"
    try:
        con = sqlite3.connect(db, timeout=15)
        try:
            con.execute("PRAGMA busy_timeout=15000")
            cur = con.cursor()
            n = 0
            for aid in ids:
                cur.execute("UPDATE installed SET enabled=1 WHERE addonID=?", (aid,))
                n += cur.rowcount if cur.rowcount > 0 else 0
            con.commit()
            return n, ""
        finally:
            con.close()
    except Exception as e:
        return 0, "addons database was busy (%s) — use Finalize / repair after the restart" % e

# ---------------------------------------------------------------- xbmc glue
def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))

def theme_key(b):
    # v2.2.2: per-tier preview sets win when they exist (GRIN ships a
    # gallery per tier — haunted-lite / haunted-medium /
    # haunted-powerhouse); every other build keeps its identity folder.
    bid = b.get("id") or ""
    if bid and os.path.isdir(os.path.join(PREVIEWS, bid)):
        return bid
    if b.get("build") in THEMES:
        return THEMES[b["build"]]
    return bid.rsplit("-", 1)[0].replace("-", "")

_PREVIEW_CACHE = {}


def preview_files(theme):
    """Local preview listing for a theme, cached after first read.

    Lag fix (7b): previews were ALWAYS local files — the lag was this
    function re-running os.listdir() for every build on every list
    render (plus theme_key()'s isdir stat per build) on slow Fire TV
    flash, serially, before any art could attach. The listing is now
    scanned once per theme per process and served from cache, and
    list_builds() preloads every theme up front so art is set
    synchronously at ListItem creation — no per-item FS or network
    work at render time at all."""
    if theme in _PREVIEW_CACHE:
        return _PREVIEW_CACHE[theme]
    folder = os.path.join(PREVIEWS, theme)
    out = []
    if os.path.isdir(folder):
        for fn in sorted(os.listdir(folder)):
            if fn.lower().endswith((".jpg", ".jpeg", ".png")):
                out.append(os.path.join(folder, fn))
    _PREVIEW_CACHE[theme] = out
    return out


def preload_previews(manifest):
    """Warm the preview cache for every build in the manifest."""
    for b in (manifest or {}).get("builds", []):
        try:
            preview_files(theme_key(b))
        except Exception:
            pass

def apply_art(li, shots):
    if not shots:
        return
    first = shots[0]
    li.setArt({"thumb": first, "icon": first, "fanart": first,
               "poster": first, "landscape": first, "clearart": first})
    if len(shots) > 1:
        fan = [{"image": s, "preview": s} for s in shots]
        try:
            li.setAvailableFanart(fan)
        except Exception:
            pass
        try:
            li.getVideoInfoTag().setAvailableFanart(fan)
        except Exception:
            pass

def jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "method": method, "id": 1}
    if params is not None:
        req["params"] = params
    try:
        out = xbmc.executeJSONRPC(json.dumps(req))
        return json.loads(out) if out else {}
    except Exception:
        return {}

def set_setting(setting, value):
    r = jsonrpc("Settings.SetSettingValue", {"setting": setting, "value": value})
    return r.get("result") is True

def list_builds(handle):
    try:
        manifest = fetch_json(BASE + "builds.json")
    except Exception as e:
        xbmcgui.Dialog().ok("Roc Builds", "Could not reach Roc Repo.\n%s" % e)
        return
    # G22 self-announce: tell Eric when THIS installer is out of date
    # versus the version Roc Repo advertises in builds.json.
    try:
        advertised = manifest.get("installer_version")
        current = ADDON.getAddonInfo("version")
        if advertised and _version_lt(current, advertised):
            xbmcgui.Dialog().notification(
                "Roc Builds Installer update available",
                "Reopen the installer from Roc Repo to update",
                "", 10000)
    except Exception:
        pass
    preload_previews(manifest)
    xbmcplugin.setContent(handle, "videos")
    ver = manifest.get("version", "?")
    li = xbmcgui.ListItem(label="— Roc Repo builds v%s —" % ver)
    li.setInfo("video", {"title": "Roc Repo builds v%s" % ver,
                         "plot": "Every build below carries the same core: Roc OS, the PIN gate, the VPN shield, the security lockdown. Tiers differ only in weight."})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?mode=none", li, False)
    li = xbmcgui.ListItem(label="✔ Finalize / repair current build")
    li.setInfo("video", {"title": "Finalize / repair current build",
                         "plot": "Run this once after a restart if anything looks stock: it switches on every addon this setup shipped (Trakt stays off on purpose), sets the Roc OS skin, and re-applies the security lockdown."})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?mode=finalize", li, False)
    li = xbmcgui.ListItem(label="⟳ Check for updates")
    li.setInfo("video", {"title": "Check for updates",
                         "plot": "Ask Kodi to re-read Roc Repo right now, so a newer installer or addon update is offered without waiting."})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?mode=updates", li, False)
    for b in manifest["builds"]:
        label = "%s - %s  (%s)" % (b["build"], b["tier"], human(b["size"]))
        theme = theme_key(b)
        shots = preview_files(theme)
        li = xbmcgui.ListItem(label=label)
        plot = b["desc"]
        if shots:
            plot += "\n\n%d preview screenshots inside -- open to view them, then install from there." % len(shots)
        li.setInfo("video", {"title": label, "plot": plot})
        apply_art(li, shots)
        q = urllib.parse.urlencode({
            "mode": "gallery", "theme": theme, "bname": label,
            "iurl": b["url"], "idesc": b["desc"],
            "isha": b.get("sha256", ""), "isize": b.get("size", ""),
        })
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, True)
    xbmcplugin.endOfDirectory(handle)

def gallery(handle, params):
    theme = params.get("theme", "")
    bname = params.get("bname", "build")
    shots = preview_files(theme)
    xbmcplugin.setContent(handle, "images")
    li = xbmcgui.ListItem(label="▶ Install %s" % bname)
    li.setInfo("video", {"title": "Install %s" % bname, "plot": params.get("idesc", "")})
    apply_art(li, shots)
    q = urllib.parse.urlencode({"mode": "install", "url": params.get("iurl", ""),
                                "name": bname, "sha": params.get("isha", ""),
                                "size": params.get("isize", "")})
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, False)
    for i, shot in enumerate(shots, 1):
        label = "%s — screenshot %d" % (bname, i)
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": label,
                             "plot": "Preview %d of %d for %s. Open to view full screen." % (i, len(shots), bname)})
        apply_art(li, [shot])
        q = urllib.parse.urlencode({"mode": "view", "theme": theme})
        xbmcplugin.addDirectoryItem(handle, sys.argv[0] + "?" + q, li, False)
    xbmcplugin.endOfDirectory(handle)

def view(params):
    folder = os.path.join(PREVIEWS, params.get("theme", ""))
    if os.path.isdir(folder):
        xbmc.executebuiltin("ActivateWindow(Pictures,%s,return)" % folder)

def backup_userdata():
    """Best-effort backup of the current userdata before an apply (R22).
    Thumbnails are a regenerable cache and are left out."""
    src = os.path.join(HOME, "userdata")
    if not os.path.isdir(src):
        return None
    dst_dir = os.path.join(HOME, "roc-backups")
    try:
        os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, "userdata-%s.zip" % time.strftime("%Y%m%d-%H%M%S"))
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as z:
            for root, dirs, files in os.walk(src):
                if os.path.relpath(root, src).startswith("Thumbnails"):
                    dirs[:] = []
                    continue
                for fn in files:
                    full = os.path.join(root, fn)
                    z.write(full, os.path.relpath(full, HOME))
        return dst
    except Exception:
        return None

def apply_critical_settings():
    """Re-apply the load-bearing settings through Kodi's own API so the
    running instance agrees with the package on disk (SEC3 lockdown)."""
    set_setting("lookandfeel.skin", TARGET_SKIN)
    for s in ("services.webserver", "services.upnpserver", "services.upnpcontrol",
              "services.upnpplayer", "services.upnprenderer", "services.zeroconf",
              "services.airplay", "services.esallinterfaces"):
        set_setting(s, False)

def install(url, name, sha, size):
    dlg = xbmcgui.Dialog()
    # G22 self-announce: say exactly what is about to happen first.
    if not dlg.yesno("Install build",
                     "About to install %s - your current setup will be backed up first.\n\n"
                     "This replaces the current Kodi setup on this device (addons, menus, settings). "
                     "Your media files are not touched." % name):
        return
    prog = xbmcgui.DialogProgressBG()
    prog.create("Roc Builds", "Backing up current setup...")
    backup = backup_userdata()
    # Resumable/verified apply (7c): download to a .part file, verify
    # SHA-256 before anything is applied, apply via a staging dir,
    # and record install-state.json at each step so a re-run after an
    # interruption resumes instead of starting over.
    part = os.path.join(HOME, "roc-build-download.zip.part")
    final_zip = os.path.join(HOME, "roc-build-download.zip")
    state = read_install_state(HOME)
    have_verified = False
    if (state.get("url") == url and state.get("state") in ("verified", "downloaded")
            and os.path.isfile(final_zip)):
        ok0, _msg0 = verify_file(final_zip, sha, size)
        have_verified = ok0
        if have_verified:
            prog.update(100, "Roc Builds", "Download already verified - resuming install...")
    if not have_verified:
        if state.get("url") != url:
            for stale in (part, final_zip):
                try:
                    os.remove(stale)
                except OSError:
                    pass
        prog.update(0, "Roc Builds", "Downloading " + name)
        write_install_state(HOME, "downloading", url, name, sha, size)
        try:
            download_with_resume(url, part, prog, name)
        except Exception as e:
            # A partial .part is kept on purpose: the next run resumes.
            write_install_state(HOME, "downloading", url, name, sha, size)
            prog.close()
            dlg.ok("Roc Builds", "Download interrupted:\n%s\n\nNothing was installed. "
                   "Run the install again and it will pick up where it left off." % e)
            return
        try:
            if os.path.isfile(final_zip):
                os.remove(final_zip)
            os.replace(part, final_zip)
        except OSError:
            final_zip = part
        write_install_state(HOME, "downloaded", url, name, sha, size)
        prog.update(100, "Roc Builds", "Checking the download...")
        ok, msg = verify_file(final_zip, sha, size)
        if not ok:
            prog.close()
            for stale in (final_zip, part):
                try:
                    os.remove(stale)
                except OSError:
                    pass
            write_install_state(HOME, "", url, name, sha, size)
            dlg.ok("Roc Builds", "Install stopped - nothing was changed.\n\n%s" % msg)
            return
        write_install_state(HOME, "verified", url, name, sha, size)
    # Apply: extract to staging, then swap into HOME. The protected
    # settings files never swap raw — they go through the Trakt-safe
    # merge so a build swap can never wipe a sign-in (item 6).
    prog.update(100, "Roc Builds", "Installing...")
    staging = os.path.join(HOME, "roc-staging")
    try:
        if os.path.isdir(staging):
            shutil.rmtree(staging, ignore_errors=True)
        os.makedirs(staging, exist_ok=True)
        protected_norm = set()
        for rel in PROTECTED_SETTINGS:
            protected_norm.add(os.path.normpath(
                os.path.join("userdata", rel)))
        with zipfile.ZipFile(final_zip) as z:
            for info in z.infolist():
                target = os.path.normpath(os.path.join(staging, info.filename))
                if not target.startswith(os.path.normpath(staging)):
                    continue
                z.extract(info, staging)
        for root, _dirs, files in os.walk(staging):
            for fn in files:
                src = os.path.join(root, fn)
                rel = os.path.relpath(src, staging)
                if os.path.normpath(rel) in protected_norm:
                    continue
                dst = os.path.join(HOME, rel)
                if not os.path.normpath(dst).startswith(os.path.normpath(HOME)):
                    continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copyfile(src, dst)
        merge_notes = merge_userdata_settings(
            HOME, os.path.join(staging, "userdata"))
        shutil.rmtree(staging, ignore_errors=True)
    except Exception as e:
        prog.close()
        dlg.ok("Roc Builds", "Install failed:\n%s" % e)
        return
    write_install_state(HOME, "applied", url, name, sha, size)
    prog.close()
    try:
        os.remove(final_zip)
    except OSError:
        pass
    # finalization: enable pass + rescan + critical settings (R5)
    enabled, note = enable_pass(HOME)
    xbmc.executebuiltin("UpdateLocalAddons")
    apply_critical_settings()
    omdb_done = apply_omdb_key(HOME)
    lines = "Build installed: %s" % name
    if backup:
        lines += "\nPrevious setup backed up to roc-backups."
    if enabled:
        lines += "\n%d addons switched on." % enabled
    if note:
        lines += "\n(%s)" % note
    if omdb_done:
        lines += "\nYour private OMDb key was applied to TMDb Helper."
    lines += ("\n\nTrakt is installed but OFF on purpose - sign in once, in one "
              "sitting, after the build settles: Add-ons -> My add-ons -> "
              "Services -> Trakt -> Enable, then authorize.")
    lines += ("\n\nAfter the restart, if anything looks stock, open Roc Builds "
              "Installer -> Finalize / repair current build - one tap finishes the job.")
    if dlg.yesno("Roc Builds", lines + "\n\nRestart Kodi now to wear it?"):
        xbmc.executebuiltin("RestartApp")

def finalize():
    """Post-restart deterministic pass, supported APIs only."""
    dlg = xbmcgui.Dialog()
    addons_root = os.path.join(HOME, "addons")
    r = jsonrpc("Addons.GetAddons", {"properties": ["path", "enabled"]})
    enabled, already, failed = 0, 0, 0
    for a in (r.get("result") or {}).get("addons", []):
        aid = a.get("addonid")
        path = xbmcvfs.translatePath(a.get("path", "") or "")
        if not aid or aid in SKIP_ENABLE:
            continue
        if not path.startswith(addons_root):
            continue
        if a.get("enabled"):
            already += 1
            continue
        rr = jsonrpc("Addons.SetAddonEnabled", {"addonid": aid, "enabled": True})
        if rr.get("result") == "OK":
            enabled += 1
        else:
            failed += 1
    apply_critical_settings()
    xbmc.executebuiltin("UpdateLocalAddons")
    apply_omdb_key(HOME)
    msg = ("Finalize complete.\n\n%d addons switched on, %d already on." % (enabled, already))
    if failed:
        msg += "\n%d could not be switched on — tell Roc which screen you saw." % failed
    msg += ("\nSkin set to Roc OS and the security lockdown re-applied.\n"
            "Trakt stays off on purpose until its one sign-in sitting.")
    dlg.ok("Roc Builds", msg)

def check_updates():
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmcgui.Dialog().ok("Roc Builds", "Kodi is re-reading Roc Repo now.\nIf a newer Roc addon exists, Kodi will offer the update in Add-ons.")

def router():
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode = params.get("mode")
    if mode == "install":
        install(params["url"], params.get("name", "build"),
                params.get("sha", ""), params.get("size", ""))
    elif mode == "gallery":
        gallery(handle, params)
    elif mode == "view":
        view(params)
    elif mode == "finalize":
        finalize()
    elif mode == "updates":
        check_updates()
    elif mode == "none":
        xbmcplugin.endOfDirectory(handle)
    else:
        list_builds(handle)

if __name__ == "__main__":
    router()
