import json, os, sys, urllib.request, zipfile
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

ADDON = xbmcaddon.Addon()
BASE = "https://esalvarado1990.github.io/roc-repo/"
HOME = xbmcvfs.translatePath("special://home/")

def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))

def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f %s" % (n, u)
        n /= 1024.0
    return "%.1f GB" % n

def list_builds(handle):
    try:
        manifest = fetch_json(BASE + "builds.json")
    except Exception as e:
        xbmcgui.Dialog().ok("Roc Builds", "Could not reach Roc Repo.\n%s" % e)
        return
    for b in manifest["builds"]:
        label = "%s - %s  (%s)" % (b["build"], b["tier"], human(b["size"]))
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": label, "plot": b["desc"]})
        url = sys.argv[0] + "?mode=install&url=" + urllib.parse.quote(b["url"]) + \
              "&name=" + urllib.parse.quote(label)
        xbmcplugin.addDirectoryItem(handle, url, li, False)
    xbmcplugin.endOfDirectory(handle)

def install(url, name):
    dlg = xbmcgui.Dialog()
    if not dlg.yesno("Install build", "Install %s?\n\nThis replaces the current Kodi setup on this device (addons, menus, settings). Your media files are not touched." % name):
        return
    tmp = os.path.join(HOME, "roc-build-download.zip")
    prog = xbmcgui.DialogProgressBG()
    prog.create("Roc Builds", "Downloading " + name)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
        with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    prog.update(int(done * 100 / total), "Roc Builds", "Downloading " + name)
        prog.update(100, "Roc Builds", "Installing...")
        with zipfile.ZipFile(tmp) as z:
            for info in z.infolist():
                target = os.path.normpath(os.path.join(HOME, info.filename))
                if not target.startswith(os.path.normpath(HOME)):
                    continue
                z.extract(info, HOME)
    except Exception as e:
        prog.close()
        dlg.ok("Roc Builds", "Install failed:\n%s" % e)
        return
    prog.close()
    try:
        os.remove(tmp)
    except OSError:
        pass
    if dlg.yesno("Roc Builds", "Build installed. Restart Kodi now to wear it?"):
        xbmc.executebuiltin("RestartApp")

def router():
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    if params.get("mode") == "install":
        install(params["url"], params.get("name", "build"))
    else:
        list_builds(handle)

import urllib.parse
router()
