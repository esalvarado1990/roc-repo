# -*- coding: utf-8 -*-
"""
service.rocsync — plugin entry point (the reader/player side).

  ?mode=cw&type=all|movie|tv|anime   the Continue Watching
      directory (type=anime added by the CW-IN-CATEGORIES lane,
      2026-11-17: the Toonime/Anime hubs' CW row — animation of
      any language, partitioned OUT of the movie/tv rows so a
      title lives in exactly one category)
      behind the Home CW row + the Movies/TV hub rows (skin
      2.0.32 points the RocTraktOnDeck* variables here). Reads
      THIS profile's store read-only — the plugin never writes
      the store (Design A: the service is the single writer);
      CW = the store's progress[] sorted by recency, nothing
      else feeds it.
  ?mode=play&key=<identity>     resume one CW item: arm the
      service's pending seek with the store's position for that
      item, then hand the title to Roc Play (auto=1 — press
      play, it plays; no source picking, Eric's law). The
      service lands the playhead at the checkpoint.

Items carry the exact contract rocui's stage_open consumes
(tmdb_id / tmdb_type properties, resume_point + progress
properties for its resume layer 2, PercentPlayed for the skin
progress bar, poster/thumb/fanart art), so a click on a CW item
stages the house detail page exactly like a Helper item did —
and the detail PLAY/RESUME buttons PlayMedia this route, which
is what arms the Roc Sync seek.
  ?mode=maint_test_cleanup      one-shot test-residue cleanup
      (0.1.2, carried into 0.1.4): purge battery-created
      progress/shows rows and restore mutated family entries
      per test_cleanup.json in this profile's data dir — see
      maint_test_cleanup() and rocsync_cleanup.py. All writes
      via save_store().
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import rocsync_common as rcommon
import rocsync_store as store_mod
import rocsync_cleanup as cleanup_mod

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE = "plugin://service.rocsync/"


def _params():
    q = sys.argv[2][1:] if len(sys.argv) > 2 \
        and sys.argv[2].startswith("?") else ""
    return {k: v[0] for k, v in urllib.parse.parse_qs(q).items()}


def _rocplay_url(row):
    q = {"action": "play", "auto": "1"}
    ids = row.get("ids") or {}
    if row.get("type") == "episode":
        q["tvshowtitle"] = row.get("tvshowtitle") \
            or row.get("title") or ""
        q["title"] = row.get("episode_title") or q["tvshowtitle"]
        if row.get("season") is not None:
            q["season"] = row["season"]
        if row.get("episode_number") is not None:
            q["episode"] = row["episode_number"]
    else:
        q["title"] = row.get("title") or ""
    if row.get("year"):
        q["year"] = row["year"]
    if ids.get("imdb"):
        q["imdb"] = ids["imdb"]
    if ids.get("tmdb"):
        q["tmdb"] = ids["tmdb"]
    return "plugin://plugin.video.rocplay/?%s" % urllib.parse.urlencode(
        {k: str(v) for k, v in q.items() if v != ""})


def build_cw(type_filter):
    slug = rcommon.profile_slug()
    store = store_mod.load_readonly(rcommon.data_dir(), slug)
    if store is None:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    base = type_filter if type_filter in ("movie", "tv") \
        else "all"
    rows = store_mod.cw_rows(store, base)
    # FLEET CATCH-UP 2026-11-16 (Jama Fix A, un-scoped from the
    # august-only rule it replaces): an inherited row - progress
    # mirrored from the shared account's other viewers - is not
    # THIS profile's watching, on ANY profile; and a tombstoned
    # item never renders. (Eric's own rows are unflagged - his
    # Oct 28 Deadpool & Wolverine viewing is his and stays.)
    rows = [r for r in rows
            if not r.get("inherited_from_account")
            and not store_mod.is_excluded(store, r)]
    cache = rcommon.load_art_cache()
    dirty = False
    if type_filter in ("movie", "tv", "anime"):
        # CW-IN-CATEGORIES partition (2026-11-17): classify every
        # candidate BEFORE the 25-row render slice, so a filtered
        # row never starves the bucket behind it. Classification
        # rides the art cache TMDB payloads (rocsync_common
        # ._classify via art_for); an unclassifiable row reads
        # animation=False and stays in its base bucket.
        kept = []
        for row in rows:
            key = store_mod.identity_key(row)
            had = cache.get(key)
            art = rcommon.art_for(row, cache)
            if had is None or "animation" not in had:
                dirty = True
            anim = bool(art.get("animation"))
            if type_filter == "anime":
                if anim:
                    kept.append(row)
            elif anim:
                continue  # animated: lives in the Toonime bucket
            else:
                kept.append(row)
        rows = kept
    xbmcplugin.setContent(HANDLE, "videos")
    for row in rows[:25]:
        key = store_mod.identity_key(row)
        before = key in cache
        art = rcommon.art_for(row, cache)
        if not before:
            dirty = True
        ids = row.get("ids") or {}
        is_ep = row.get("type") == "episode"
        show = row.get("tvshowtitle") or row.get("title") or ""
        title = row.get("title") or ""
        if is_ep:
            title = row.get("episode_title") \
                or art.get("episode_title") or title
        li = xbmcgui.ListItem(label=title)
        pos = float(row.get("position_seconds") or 0)
        dur = float(row.get("runtime_seconds") or 0)
        pct = float(row.get("progress_percent") or 0)
        if dur > 0 and pos > 0:
            pct = pos / dur * 100.0
        info = {"title": title,
                "mediatype": "episode" if is_ep else "movie",
                "plot": art.get("plot") or ""}
        if is_ep:
            info["tvshowtitle"] = show
            if row.get("season") is not None:
                info["season"] = int(row["season"])
            if row.get("episode_number") is not None:
                info["episode"] = int(row["episode_number"])
        year = art.get("year") or row.get("year")
        if year:
            try:
                info["year"] = int(year)
            except Exception:
                pass
        if dur > 0:
            info["duration"] = int(dur)
        li.setInfo("video", info)
        uids = {}
        if ids.get("tmdb"):
            uids["tmdb"] = str(ids["tmdb"])
        if ids.get("imdb"):
            uids["imdb"] = str(ids["imdb"])
        if uids:
            li.setUniqueIDs(uids, "tmdb" if "tmdb" in uids
                            else "imdb")
        artmap = {}
        if art.get("poster"):
            artmap["poster"] = art["poster"]
        if art.get("fanart"):
            artmap["fanart"] = art["fanart"]
        if art.get("thumb"):
            artmap["thumb"] = art["thumb"]
        if artmap:
            li.setArt(artmap)
        # stage_open resume layer 2 + the skin progress bar
        if pos > 0:
            li.setProperty("resume_point", str(int(pos)))
        if pct > 0:
            li.setProperty("progress", "%.2f" % pct)
        if ids.get("tmdb"):
            li.setProperty("tmdb_id", str(ids["tmdb"]))
        li.setProperty("tmdb_type", "episode" if is_ep else "movie")
        li.setProperty("IsPlayable", "true")
        url = "%s?mode=play&key=%s" % (
            BASE, urllib.parse.quote(key, safe=""))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    if dirty:
        rcommon.save_art_cache(cache)
    xbmcplugin.endOfDirectory(HANDLE)


def play(key):
    slug = rcommon.profile_slug()
    store = store_mod.load_readonly(rcommon.data_dir(), slug)
    row = None
    if store is not None:
        for cand in store.get("progress") or []:
            if store_mod.identity_key(cand) == key:
                row = cand
                break
    if row is None:
        xbmcgui.Dialog().notification(
            "Roc Sync", "That spot is no longer saved",
            xbmcgui.NOTIFICATION_WARNING, 4000)
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    pos = float(row.get("position_seconds") or 0)
    if pos > 0 and row.get("type") in store_mod.VIDEO_TYPES:
        hint = row.get("tvshowtitle") or row.get("title") or ""
        rcommon.seek_arm(pos, key, hint)
    if row.get("type") == "song":
        # Music lives in other apps in this house; when the
        # capture recorded a Kodi path that still resolves, play
        # it back, else say so plainly.
        path = row.get("path") or ""
        if path:
            xbmc.executebuiltin("PlayMedia(%s)" % path)
        else:
            xbmcgui.Dialog().notification(
                "Roc Sync", "Music resumes in its own app",
                xbmcgui.NOTIFICATION_INFO, 4000)
    else:
        xbmc.executebuiltin("PlayMedia(%s)" % _rocplay_url(row))
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# ----------------------------------------------------------------------
# maint_test_cleanup (rocsync 0.1.2) — defined above main() so the
# dispatch below never forward-references it.
# ----------------------------------------------------------------------
# slug -> Kodi profile directory name (reverse of
# rcommon.PROFILE_SLUGS). The master profile (eric) has no
# profiles/<Name> directory: its data lives directly under
# userdata/, i.e. special://masterprofile/.
_SLUG_PROFILE_DIR = {slug: name for name, slug
                     in rcommon.PROFILE_SLUGS.items()}


def _profile_data_dir(slug, profile_dir=None):
    """Another profile's service.rocsync data dir, resolved from
    any running session: special://masterprofile always resolves
    to the master profile's root (the route rocui_common's
    _master_data_dir / _august_music_profile_dirs use), and named
    profiles live under its profiles/<Name>/ tree. House layout
    (fleet-proven, see work/stores.py): eric is the master
    profile on every stick, so his data dir is the master root
    itself; every other slug lives under profiles/<Name>/.
    None when the slug is unknown and the spec named no profile
    dir for it."""
    name = profile_dir or _SLUG_PROFILE_DIR.get(slug)
    if name is None:
        return None
    try:
        master = xbmcvfs.translatePath("special://masterprofile/")
    except Exception:
        return None
    if not master:
        return None
    base = master if slug == "eric" else os.path.join(
        master, "profiles", name)
    return os.path.join(base, "addon_data", rcommon.ADDON_ID) \
        + os.sep


def maint_test_cleanup():
    """One-shot maintenance (rocsync 0.1.2, Eric's housekeeping
    law 2026-11-17 04:01): clear the test batteries' own residue
    from the stores named in a spec file, and restore any family
    entry a battery mutated to its pre-pass snapshot — all writes
    through save_store() so the SHA-256 chain stays valid.

    Spec: test_cleanup.json in the RUNNING profile's own data dir
    (special://profile/addon_data/service.rocsync/ — on the
    master session that is userdata/addon_data/service.rocsync/).
    Its own store is cleaned via its own data dir; other profiles'
    stores are reached cross-profile via special://masterprofile
    (see _profile_data_dir). Shape:
      {"purge": {"<slug>": ["<title>", ...]},
       "restore": {"<slug>": [<full progress entry>, ...]},
       "purge_shows": {"<slug>": ["<title>", ...]},
       "profile_dirs": {"<slug>": "<Kodi profile dir name>"}}
    (profile_dirs optional — for slugs outside PROFILE_SLUGS.)
    Missing spec = no-op with a log line. Result lands next to
    the spec as test_cleanup_result.json. Idempotent. Invoked
    per stick from the master (E-Roc) session via its plugin URL,
    exactly like maint_suppress_inherited."""
    own_dir = rcommon.data_dir()
    spec_path = os.path.join(own_dir, cleanup_mod.SPEC_NAME)
    profile_dirs = {}
    spec, status = cleanup_mod.load_spec(spec_path)
    if status == "ok":
        raw = spec.get("profile_dirs") or {}
        if isinstance(raw, dict):
            profile_dirs = {str(k): str(v) for k, v in raw.items()}

    def resolve(slug):
        if slug == rcommon.profile_slug():
            return own_dir
        return _profile_data_dir(slug, profile_dirs.get(slug))

    cleanup_mod.run_cleanup(spec_path, resolve, log=rcommon.log)
    xbmcplugin.endOfDirectory(HANDLE)


def main():
    p = _params()
    mode = p.get("mode", "")
    if mode == "maint_suppress_inherited":
        maint_suppress_inherited()
    elif mode == "maint_test_cleanup":
        maint_test_cleanup()
    elif mode == "cw":
        build_cw(p.get("type", "all"))
    elif mode == "play":
        play(p.get("key", ""))
    else:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    main()


def maint_suppress_inherited():
    """One-shot maintenance (fleet catch-up 2026-11-16, Jama Fix A):
    move this profile's inherited rows out of progress[] into
    inherited_suppressed[], written back through the store's own
    save path (chain + head stamps intact). Idempotent - a second
    run moves nothing. Invoked per profile via its plugin URL."""
    slug = rcommon.profile_slug()
    data_dir = rcommon.data_dir()
    store = store_mod.load_store(data_dir, slug)
    if store is None:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    keep, moved = [], []
    for row in store.get("progress") or []:
        if isinstance(row, dict) and row.get("inherited_from_account"):
            moved.append(row)
        else:
            keep.append(row)
    if moved:
        store["progress"] = keep
        store.setdefault("inherited_suppressed", []).extend(moved)
        store_mod.save_store(data_dir, slug, store)
        xbmc.log("[service.rocsync] maint: suppressed %d inherited "
                 "row(s) for %s" % (len(moved), slug), xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(HANDLE)
