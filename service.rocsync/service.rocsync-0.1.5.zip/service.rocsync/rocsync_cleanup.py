# -*- coding: utf-8 -*-
"""
service.rocsync — test-residue cleanup core (rocsync 0.1.2).

PURE PYTHON apart from rocsync_store: no xbmc imports, so the
whole cleanup discipline is testable off-stick (tests_offline.py).
default.py's maint_test_cleanup() is a thin Kodi wrapper around
run_cleanup(): it resolves the spec/result paths and the
per-slug data dirs (running profile via special://profile, other
profiles via special://masterprofile — see default.py), and this
module does the rest.

Why this exists (Eric's housekeeping law, 2026-11-17 04:01): the
fleet test batteries play real titles; those plays write real
Continue Watching / resume entries into per-profile Roc Sync
stores. After each test pass the batteries' OWN residue is cleared
from every profile so the family never inherits test history —
and a pre-existing family entry a battery mutated is RESTORED to
its pre-pass snapshot values, never deleted.

Discipline (mirrors the store's own rules):
  * All writes go through rocsync_store.save_store() — external
    JSON edits would break the prev_sha256 / .head chain, so a
    store is only ever mutated in memory and saved by the store
    module itself. After every save, verify_store() must pass.
  * Untouched stores are never rewritten (bytes stay identical) —
    in particular a profile not named in the spec (e.g. August)
    keeps its store byte-identical.
  * Only slugs / titles / entries named in the spec are touched.
    Nothing else in a named store is modified.
  * Idempotent: a second run over the same spec changes nothing
    (no save, zero counts).
  * A store whose chain does not verify BEFORE the cleanup is
    never edited — recovery is load_store()'s job (the service),
    not the cleanup's. It is reported skipped with its pre-check
    result, so the damage stays visible instead of being papered
    over.
"""
import copy
import json
import os

import rocsync_store as store_mod

SPEC_NAME = "test_cleanup.json"
RESULT_NAME = "test_cleanup_result.json"


def _noop_log(msg):
    pass


# ----------------------------------------------------------------------
# title matching — the store's own identity helpers, never raw
# string equality on the raw spec text
# ----------------------------------------------------------------------
def _title_probe(entry):
    """A minimal row built from a spec entry: a plain title string,
    or a dict entry (used verbatim, so a spec that carries ids
    matches on ids through identity_key)."""
    if isinstance(entry, dict):
        return entry
    return {"type": "movie", "title": entry or ""}


def matches_title(row, entry):
    """True when a store row is the item a spec entry names.

    Match order:
      1. store_mod._same_item(row, probe) — the store's identity
         (tmdb/imdb for movies, tmdb+season+episode or normalised
         title for episodes, artist+title for songs). This is the
         authoritative path whenever the row and the probe share
         an identity basis.
      2. Normalised-title equality via store_mod._norm on the
         row's title OR tvshowtitle — the path that matters for
         the common spec shape (a plain title string) against a
         live row that carries a tmdb id: identity_key() of the
         probe is 'movie:title:...' while the row's is
         'movie:tmdb:...', so _same_item alone can never see them
         as the same item. _norm makes case/punctuation variants
         of the battery's title ('Rudolph the Red-Nosed
         Reindeer!') match the stored row.

    No substring/containment matching: a purge names whole titles,
    and a partial match could delete a family entry the spec never
    named."""
    if not isinstance(row, dict):
        return False
    probe = _title_probe(entry)
    try:
        if store_mod._same_item(row, probe):
            return True
    except Exception:
        pass
    want = store_mod._norm(probe.get("title")
                           or probe.get("tvshowtitle"))
    if not want:
        return False
    for field in ("title", "tvshowtitle"):
        if store_mod._norm(row.get(field)) == want:
            return True
    return False


def _matches_any(row, entries):
    return any(matches_title(row, e) for e in entries)


# ----------------------------------------------------------------------
# in-memory application (pure — unit-testable without files)
# ----------------------------------------------------------------------
def apply_cleanup(store, purge_entries, restore_entries,
                  purge_show_entries):
    """Apply one slug's spec slice to a parsed store, in memory.
    Order: purge progress, purge shows, then restore — restore
    runs last so a slug named in both purge and restore ends with
    the exact snapshot entry in place (the mutated battery copy is
    removed, the family original reinstated).
    Returns (counts, changed) where counts has purged /
    purged_shows / restored. `changed` is False when nothing
    differed — the caller must not save in that case."""
    counts = {"purged": 0, "purged_shows": 0, "restored": 0}

    if purge_entries:
        rows = store.get("progress") or []
        keep = [r for r in rows
                if not _matches_any(r, purge_entries)]
        counts["purged"] = len(rows) - len(keep)
        if counts["purged"]:
            store["progress"] = keep

    if purge_show_entries:
        rows = store.get("shows") or []
        keep = [r for r in rows
                if not _matches_any(r, purge_show_entries)]
        counts["purged_shows"] = len(rows) - len(keep)
        if counts["purged_shows"]:
            store["shows"] = keep

    for entry in restore_entries or []:
        if not isinstance(entry, dict):
            continue
        snapshot = copy.deepcopy(entry)
        key = store_mod.identity_key(snapshot)
        rows = store.setdefault("progress", [])
        for i, row in enumerate(rows):
            if isinstance(row, dict) \
                    and store_mod.identity_key(row) == key:
                if row != snapshot:
                    rows[i] = snapshot
                    counts["restored"] += 1
                break
        else:
            rows.append(snapshot)
            counts["restored"] += 1

    changed = any(counts.values())
    return counts, changed


# ----------------------------------------------------------------------
# spec handling
# ----------------------------------------------------------------------
def _spec_slice(spec, section, slug):
    rows = (spec.get(section) or {}).get(slug) or []
    return rows if isinstance(rows, list) else []


def spec_slugs(spec):
    """Every slug named anywhere in the spec, in spec order."""
    out = []
    for section in ("purge", "purge_shows", "restore"):
        for slug in (spec.get(section) or {}):
            if slug not in out:
                out.append(slug)
    return out


def load_spec(spec_path):
    """(spec, status): status 'ok' | 'missing' | 'invalid'."""
    if not spec_path or not os.path.isfile(spec_path):
        return None, "missing"
    try:
        with open(spec_path, "r", encoding="utf-8") as fh:
            spec = json.load(fh)
    except Exception:
        return None, "invalid"
    if not isinstance(spec, dict):
        return None, "invalid"
    return spec, "ok"


def _atomic_write_json(path, payload):
    data = json.dumps(payload, ensure_ascii=False, indent=1,
                      sort_keys=True).encode("utf-8")
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


# ----------------------------------------------------------------------
# the run
# ----------------------------------------------------------------------
def run_cleanup(spec_path, resolve_data_dir, log=None,
                result_path=None):
    """Run one maint_test_cleanup pass.

    spec_path        — the test_cleanup.json to read.
    resolve_data_dir — callable(slug) -> that profile's
                       service.rocsync data dir, or None when the
                       slug cannot be resolved on this stick.
    log              — callable(msg); default.py passes
                       rocsync_common.log (adds the
                       [service.rocsync] prefix in xbmc.log).
    result_path      — where test_cleanup_result.json goes
                       (default: next to the spec).

    Returns the result dict. A missing/invalid spec is a no-op:
    a log line, no store touched, no result file written."""
    log = log or _noop_log
    spec, status = load_spec(spec_path)
    if status == "missing":
        log("maint_test_cleanup: no spec at %s - no-op" % spec_path)
        return {"mode": "maint_test_cleanup", "spec_found": False,
                "stores": {}}
    if status != "ok":
        log("maint_test_cleanup: spec at %s is not a JSON object - "
            "no-op" % spec_path)
        return {"mode": "maint_test_cleanup", "spec_found": False,
                "stores": {}}

    if result_path is None:
        result_path = os.path.join(os.path.dirname(spec_path),
                                   RESULT_NAME)
    result = {"mode": "maint_test_cleanup", "spec_found": True,
              "ran_at": store_mod.now_iso(), "stores": {}}
    totals = {"purged": 0, "purged_shows": 0, "restored": 0}

    for slug in spec_slugs(spec):
        entry = {"purged": 0, "purged_shows": 0, "restored": 0,
                 "touched": False, "verified": False,
                 "skipped": False, "error": None}
        result["stores"][slug] = entry
        data_dir = resolve_data_dir(slug)
        if not data_dir:
            entry["skipped"] = True
            entry["error"] = "slug_not_resolvable"
            log("maint_test_cleanup: %s skipped - no data dir "
                "resolves for this slug" % slug)
            continue
        path = store_mod.store_path(data_dir, slug)
        if not os.path.isfile(path):
            entry["skipped"] = True
            entry["error"] = "store_missing"
            log("maint_test_cleanup: %s skipped - no store file at "
                "%s" % (slug, path))
            continue
        if not store_mod.verify_store(data_dir, slug):
            # Chain already broken before we arrived: never edit.
            entry["skipped"] = True
            entry["error"] = "chain_broken_pre"
            log("maint_test_cleanup: %s skipped - store chain does "
                "not verify before cleanup; left for the service "
                "to recover" % slug)
            continue
        store = store_mod.load_readonly(data_dir, slug)
        if store is None:
            entry["skipped"] = True
            entry["error"] = "store_unreadable"
            continue

        counts, changed = apply_cleanup(
            store,
            _spec_slice(spec, "purge", slug),
            _spec_slice(spec, "restore", slug),
            _spec_slice(spec, "purge_shows", slug))
        entry.update(counts)
        for k in totals:
            totals[k] += counts[k]
        if changed:
            store_mod.save_store(data_dir, slug, store)
            entry["touched"] = True
            entry["verified"] = bool(
                store_mod.verify_store(data_dir, slug))
            if not entry["verified"]:
                entry["error"] = "chain_broken_post"
        else:
            # Untouched stores are not rewritten; the pre-check
            # above already proved the chain, re-assert it so the
            # result's boolean always describes the final state.
            entry["verified"] = bool(
                store_mod.verify_store(data_dir, slug))
        log("maint_test_cleanup: %s purged=%d purged_shows=%d "
            "restored=%d touched=%s verified=%s"
            % (slug, entry["purged"], entry["purged_shows"],
               entry["restored"], entry["touched"],
               entry["verified"]))

    result["totals"] = totals
    try:
        _atomic_write_json(result_path, result)
    except Exception as exc:
        log("maint_test_cleanup: result write failed: %s" % exc)
    log("maint_test_cleanup: done purged=%d purged_shows=%d "
        "restored=%d (result: %s)"
        % (totals["purged"], totals["purged_shows"],
           totals["restored"], result_path))
    return result
