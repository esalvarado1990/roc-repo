# -*- coding: utf-8 -*-
"""
service.rocsync — service entry point (starts at login, per
profile). THE single writer of the Roc Sync tracking store
(Design A). Duties:

  * Load this profile's store at start — importing its genesis
    seed on first run, recovering from the .bak / seed when the
    hash chain says the file was damaged — and re-verify the
    chain every minute.
  * Capture playback for the ACTIVE profile only, into this
    profile's own store (special://profile — Kodi mounts no
    other profile's subtree, so a leak sideways has no path).

    ERIC'S MECHANISM (2026-11-16 01:14, his words: "that press
    from pause to play is the log") is the PRIMARY capture: the
    viewer pauses (position held), then presses play — THAT
    press writes the checkpoint (title + the position where it
    was paused) to the store and appends the press to
    checkpoints.jsonl. Shows, movies AND songs. Supporting saves
    are secondary: a stop save at the leave position, a safety
    save every 60 s of continuous play (a crash or power cut
    must not lose the spot), and near-end = mark watched.

  * Apply pending seeks armed by the plugin's CW play route
    (RocSync.PendingSeek window property), with the house
    applier discipline: apply once the stream is > 3 s in and
    behind the target, re-apply across source failovers, clear
    only when the playhead is confirmed at/past the target,
    on a plain title mismatch (after 120 s), or at 1200 s.

Everything is guarded: a failure in any tick is logged and the
loop keeps running — this service never takes the shell down.
"""
import json
import os
import time

import xbmc
import xbmcgui

import rocsync_common as rcommon
import rocsync_store as store_mod

POLL_SECONDS = 0.3
SAFETY_EVERY = 60.0     # seconds of play between safety saves
VERIFY_EVERY = 60.0     # seconds between store chain verifications

SOURCES = {
    "pause_play": "Roc Sync pause->play checkpoint (Eric's "
                  "mechanism, 2026-11-16)",
    "stop": "Roc Sync stop save",
    "safety": "Roc Sync safety save",
}


def _num(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


class RocSyncService(object):
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.slug = rcommon.profile_slug()
        self.data_dir = rcommon.data_dir()
        self.store = None
        self.store_status = ""
        # playback tracking
        self.cur_file = ""
        self.cur_entry = None        # entry-shaped snapshot dict
        self.cur_since = 0.0
        self.last_pos = 0.0
        self.last_dur = 0.0
        self.was_paused = False
        self.pause_pending = None    # {entry, position, paused_at}
        self.last_safety = 0.0
        self.last_verify = 0.0

    # ------------------------------------------------------------ store
    def _load(self):
        self.store, self.store_status = store_mod.load_store(
            self.data_dir, self.slug,
            seed_bytes=rcommon.seed_bytes(self.slug),
            display=rcommon.profile_name())
        rcommon.log("store %s: %s" % (self.slug, self.store_status))

    def _save(self):
        store_mod.save_store(self.data_dir, self.slug, self.store)

    def _record(self, entry, trigger):
        """One capture write through the store's single door.
        Returns the outcome string; saves only on a real write."""
        if self.store is None:
            return "no_store"
        outcome = store_mod.record_play(self.store, entry, trigger)
        if outcome not in ("excluded", "below_floor"):
            self._save()
        return outcome

    def _log_checkpoint(self, entry, position, outcome):
        """checkpoints.jsonl — the literal log of Eric's press.
        Every pause->play press is appended (even one the store
        floors or tombstones refuse — the log is the log)."""
        try:
            line = {
                "ts": store_mod.now_iso(),
                "trigger": "pause_play_press",
                "profile": self.slug,
                "type": entry.get("type") or "",
                "title": entry.get("title") or "",
                "tvshowtitle": entry.get("tvshowtitle") or "",
                "season": entry.get("season"),
                "episode": entry.get("episode_number"),
                "position_seconds": round(float(position), 3),
                "runtime_seconds": round(
                    float(entry.get("runtime_seconds") or 0), 3),
                "outcome": outcome,
            }
            path = os.path.join(self.data_dir, "checkpoints.jsonl")
            with open(path, "a") as fh:
                fh.write(json.dumps(line, ensure_ascii=False) + "\n")
        except Exception as exc:
            rcommon.log("checkpoint log failed: %s" % exc)

    # --------------------------------------------------------- snapshot
    def _snapshot(self, player, playing_file):
        """Entry-shaped identity for what is playing now, or None
        when it carries no usable identity (bare URLs, previews
        with no metadata — the floors would refuse them anyway,
        this keeps them out of the log entirely)."""
        try:
            if player.isPlayingVideo():
                tag = player.getVideoInfoTag()
                if tag is None:
                    return None
                title = tag.getTitle() or ""
                show = tag.getTVShowTitle() or ""
                mediatype = (tag.getMediaType() or "").lower()
                ids = {}
                for kind in ("tmdb", "imdb", "tvdb"):
                    try:
                        val = tag.getUniqueID(kind)
                    except Exception:
                        val = ""
                    if val:
                        ids[kind] = int(val) if kind != "imdb" \
                            and str(val).isdigit() else val
                if not title and not show and not ids:
                    return None
                if title.startswith(("http://", "https://")) \
                        and not ids:
                    return None
                entry = {"ids": ids, "path": playing_file,
                         "year": tag.getYear() or None}
                if mediatype == "episode" or show:
                    entry["type"] = "episode"
                    entry["title"] = show or title
                    entry["tvshowtitle"] = show or title
                    entry["season"] = tag.getSeason()
                    entry["episode_number"] = tag.getEpisode()
                    if title and title != show:
                        entry["episode_title"] = title
                    if entry["season"] is not None \
                            and entry["episode_number"] is not None:
                        entry["episode"] = "S%sE%s" % (
                            entry["season"], entry["episode_number"])
                else:
                    entry["type"] = "movie"
                    entry["title"] = title
                return entry
            if player.isPlayingAudio():
                tag = player.getMusicInfoTag()
                if tag is None:
                    return None
                title = tag.getTitle() or ""
                if not title:
                    return None
                artists = tag.getArtist() or []
                artist = ", ".join(artists) if isinstance(
                    artists, (list, tuple)) else str(artists)
                return {"type": "song", "title": title,
                        "artist": artist,
                        "album": tag.getAlbum() or "",
                        "ids": {}, "path": playing_file}
        except Exception as exc:
            rcommon.log("snapshot failed: %s" % exc)
        return None

    def _entry_at(self, position):
        entry = dict(self.cur_entry)
        entry["position_seconds"] = round(float(position), 3)
        entry["runtime_seconds"] = round(float(self.last_dur), 3)
        entry["paused_at"] = store_mod.now_iso()
        return entry

    # ------------------------------------------------------------- ticks
    def _final_save(self, trigger="stop"):
        """The leave-position save for the current item (stop /
        file change). Uses the last known playhead — after a stop
        the player can no longer be asked."""
        if not self.cur_entry or self.last_pos <= 0:
            return
        entry = self._entry_at(self.last_pos)
        entry["sources"] = [SOURCES[trigger]]
        outcome = self._record(entry, trigger)
        rcommon.log("capture %s: %s %s @ %.0fs (%s)" % (
            trigger, entry.get("type"), entry.get("title"),
            self.last_pos, outcome))

    def _playback_tick(self, now):
        player = xbmc.Player()
        playing = False
        playing_file = ""
        paused = False
        try:
            playing = player.isPlaying()
            if playing:
                playing_file = player.getPlayingFile() or ""
                paused = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            playing = False

        if not playing or not playing_file:
            if self.cur_file:
                self._final_save("stop")
            self.cur_file = ""
            self.cur_entry = None
            self.pause_pending = None
            self.was_paused = False
            self.last_pos = 0.0
            self.last_dur = 0.0
            return

        if playing_file != self.cur_file:
            if self.cur_file and self.cur_entry:
                self._final_save("stop")
            self.cur_file = playing_file
            self.cur_since = now
            self.cur_entry = self._snapshot(player, playing_file)
            self.pause_pending = None
            self.was_paused = paused
            self.last_safety = now
            self.last_pos = 0.0
            self.last_dur = 0.0

        # playhead (readable while paused too — the held position)
        try:
            self.last_pos = float(player.getTime())
            self.last_dur = float(player.getTotalTime())
        except Exception:
            pass
        if self.cur_entry is None:
            self.cur_entry = self._snapshot(player, playing_file)

        # ---- Eric's mechanism: the pause -> play press ----------
        if paused and not self.was_paused:
            # pause begins: hold the position where he paused
            if self.cur_entry:
                self.pause_pending = {
                    "entry": dict(self.cur_entry),
                    "position": self.last_pos,
                    "duration": self.last_dur,
                    "paused_at": store_mod.now_iso(),
                }
        elif not paused and self.was_paused \
                and self.pause_pending is not None:
            # THE PRESS: playback resumes from pause -> write the
            # checkpoint at the position where it was paused (the
            # live playhead now IS that held position, including
            # any seek made while paused).
            pending = self.pause_pending
            self.pause_pending = None
            position = self.last_pos or pending["position"]
            entry = dict(pending["entry"])
            entry["position_seconds"] = round(float(position), 3)
            entry["runtime_seconds"] = round(
                float(pending["duration"] or self.last_dur), 3)
            entry["paused_at"] = pending["paused_at"]
            entry["sources"] = [SOURCES["pause_play"]]
            outcome = self._record(entry, "pause_play")
            self._log_checkpoint(entry, position, outcome)
            rcommon.log("checkpoint pause->play: %s %s @ %.0fs (%s)"
                        % (entry.get("type"), entry.get("title"),
                           position, outcome))
        self.was_paused = paused

        # ---- supporting save: periodic safety ------------------
        if not paused and now - self.last_safety >= SAFETY_EVERY \
                and self.cur_entry and self.last_pos > 0:
            self.last_safety = now
            entry = self._entry_at(self.last_pos)
            entry["sources"] = [SOURCES["safety"]]
            outcome = self._record(entry, "safety")
            if outcome not in ("below_floor", "excluded"):
                rcommon.log("capture safety: %s %s @ %.0fs (%s)"
                            % (entry.get("type"),
                               entry.get("title"), self.last_pos,
                               outcome))

        # ---- pending seek applier (video only) -----------------
        if self.cur_entry and self.cur_entry.get("type") \
                in store_mod.VIDEO_TYPES:
            self._seek_tick(player, now)

    def _seek_tick(self, player, now):
        pending = rcommon.seek_peek()
        if not pending:
            return
        age = time.time() - _num(pending.get("ts"))
        if age > 1200:
            rcommon.seek_clear()
            return
        target = _num(pending.get("position"))
        # identity: exact store key when the snapshot carries ids,
        # else the house normalised-title containment.
        cur_key = store_mod.identity_key(self.cur_entry)
        match = (pending.get("key") and pending["key"] == cur_key)
        if not match:
            hint = store_mod._norm(pending.get("title") or "")
            disp = store_mod._norm(
                self.cur_entry.get("tvshowtitle")
                or self.cur_entry.get("title") or "")
            match = bool(hint and disp
                         and (hint in disp or disp in hint))
        if not match:
            if age > 120:
                rcommon.seek_clear()
            return
        try:
            pos = float(player.getTime())
        except Exception:
            return
        if pos >= target - 10:
            rcommon.seek_clear()
            rcommon.log("pending seek confirmed at %.0fs" % pos)
        elif now - self.cur_since > 3.0 and pos < target - 10:
            try:
                player.seekTime(target)
                rcommon.log("pending seek applied: %.0fs" % target)
            except Exception as exc:
                rcommon.log("pending seek failed: %s" % exc)

    def _verify_tick(self, now):
        if now - self.last_verify < VERIFY_EVERY:
            return
        self.last_verify = now
        path = store_mod.store_path(self.data_dir, self.slug)
        if not os.path.exists(path):
            return
        if not store_mod.verify_store(self.data_dir, self.slug):
            rcommon.log("store chain BROKEN for %s — recovering"
                        % self.slug)
            self._load()
            rcommon.log("store recovery outcome: %s"
                        % self.store_status)

    # --------------------------------------------------------------- run
    def run(self):
        rcommon.log("service starting (profile %s / slug %s)"
                    % (rcommon.profile_name(), self.slug))
        try:
            self._load()
        except Exception as exc:
            rcommon.log("store load failed: %s" % exc)
            self.store = None
        self.last_verify = time.monotonic()
        while not self.monitor.abortRequested():
            now = time.monotonic()
            try:
                self._playback_tick(now)
            except Exception as exc:
                rcommon.log("playback tick failed: %s" % exc)
            try:
                self._verify_tick(now)
            except Exception as exc:
                rcommon.log("verify tick failed: %s" % exc)
            if self.monitor.waitForAbort(POLL_SECONDS):
                break
        # a stop the poll loop never saw (Kodi going down mid-play)
        try:
            if self.cur_file and self.cur_entry:
                self._final_save("stop")
        except Exception:
            pass
        rcommon.log("service stopped")


if __name__ == "__main__":
    RocSyncService().run()
