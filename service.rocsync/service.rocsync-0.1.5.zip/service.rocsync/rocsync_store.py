# -*- coding: utf-8 -*-
"""
service.rocsync — the Roc Sync tracking store (Design A, locked
2026-11-13, LAUNCH-DESIGN-20261113.md). PURE PYTHON: no xbmc
imports, so the whole store discipline is testable off-stick.

Design A invariants implemented here:
  * One JSON file per profile, in that profile's own userdata
    subtree: <data_dir>/tracking/<slug>.json. Kodi mounts only the
    active profile's subtree, so isolation is by construction.
  * SINGLE WRITER: only the service calls save(). Plugin/script
    processes read (load_readonly) and never write the store.
  * Atomic writes: write .tmp, fsync, rename. The previous file is
    retained as <slug>.bak before every overwrite.
  * SHA-256 chain: every save stamps prev_sha256 = sha256 of the
    previous file's bytes, and a head sidecar (<slug>.head) holds
    sha256 of the current file's bytes. On load, a mismatch means
    corruption/tamper: recover from .bak when the chain link
    proves it genuine (sha256(.bak) == the store's prev_sha256),
    else reseed from the shipped genesis seed and quarantine the
    damaged file. Nothing is silently trusted.
  * Tombstones: exclusions[] is checked before ANY progress /
    watched write — a removed item can never resurrect.
  * Provenance: every row the service writes carries sources[].

Eric's capture mechanism (2026-11-16 01:14, his words: "that press
from pause to play is the log"): the primary checkpoint is written
by the service when playback transitions pause -> play, carrying
the position where it was paused. The service also appends every
such press to checkpoints.jsonl (the log). Stop / periodic safety
saves are secondary triggers recorded on the row as last_trigger.
"""
import hashlib
import json
import os
import re
import time
from datetime import datetime

SCHEMA_VERSION = 1

# Genesis seed integrity — sha256 of the shipped seed files
# (roc-sync-migration-20261112/seeds/MANIFEST.json, verified
# 2026-11-13, re-verified at build 2026-11-16). A seed whose bytes
# do not match is refused, never imported.
SEED_SHA256 = {
    "eric": "25e2a68b322c35db10111b7933228ec21a36922b10d87e861a780ce69a5cd498",
    "nue": "d3a6e21334a9fce7937e1cbc2987b280bd4595d2a99cbbb0fdac68db7abfc709",
    "jama": "66a4d311e5e9a4c6e13fd62de7d190d56444444794bb0650d43940f69dd21ec1",
    "august": "f8d135646687ec4f45c5d510dfa7e674c7fdcd1c77a83193da3e6635b26204c8",
}

# House floors (rocui SHOW_PROGRESS_* constants — the build's own
# proven thresholds): a blip under 45 s AND under 2% is not
# progress; a title with <= 90 s left or >= 97% played is finished.
FLOOR_POS = 45.0
FLOOR_PCT = 2.0
FINISHED_REMAIN = 90.0
FINISHED_PCT = 97.0
# Eric's pause->play press is a deliberate act: its checkpoint
# lands in the store from 10 s in (the log records EVERY press
# regardless — see checkpoints.jsonl).
PAUSE_PLAY_FLOOR_POS = 10.0

VIDEO_TYPES = ("movie", "episode")


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _norm(text):
    return re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).strip()


def parse_ts(value):
    """Epoch seconds from a stored timestamp in any of the shapes
    the seeds / this service write ('2026-11-11T18:38:44 MST',
    ISO with offset, epoch number). 0 when unparseable."""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return 0.0
    try:
        return float(text)
    except Exception:
        pass
    text = re.sub(r"\s+[A-Z]{2,5}$", "", text)
    try:
        return datetime.fromisoformat(text).timestamp()
    except Exception:
        return 0.0


# ----------------------------------------------------------------------
# identity
# ----------------------------------------------------------------------
def identity_key(row):
    """Stable per-item key (Design B merge semantics, kept by the
    launch decision: episodes tmdb+season+episode; movies tmdb
    else imdb; path/title only as last resort)."""
    rtype = row.get("type") or "movie"
    ids = row.get("ids") or {}
    tmdb = ids.get("tmdb")
    if rtype == "episode":
        season = row.get("season")
        epnum = row.get("episode_number")
        if epnum is None and row.get("episode"):
            m = re.search(r"S(\d+)E(\d+)", str(row["episode"]), re.I)
            if m:
                season, epnum = int(m.group(1)), int(m.group(2))
        if tmdb:
            return "episode:tmdb:%s:S%sE%s" % (tmdb, season, epnum)
        show = _norm(row.get("tvshowtitle") or row.get("title"))
        return "episode:title:%s:S%sE%s" % (show, season, epnum)
    if rtype == "song":
        return "song:%s|%s" % (_norm(row.get("artist")),
                               _norm(row.get("title")))
    if tmdb:
        return "movie:tmdb:%s" % tmdb
    if ids.get("imdb"):
        return "movie:imdb:%s" % ids["imdb"]
    return "movie:title:%s|%s" % (_norm(row.get("title")),
                                  row.get("year") or "")


def _same_item(a, b):
    return identity_key(a) == identity_key(b)


# ----------------------------------------------------------------------
# file discipline
# ----------------------------------------------------------------------
def tracking_dir(data_dir):
    return os.path.join(data_dir, "tracking")


def store_path(data_dir, slug):
    return os.path.join(tracking_dir(data_dir), slug + ".json")


def _atomic_write(path, data_bytes):
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(data_bytes)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def _read_bytes(path):
    try:
        with open(path, "rb") as fh:
            return fh.read()
    except Exception:
        return None


def empty_store(slug, display=""):
    return {
        "schema_version": SCHEMA_VERSION,
        "profile": slug,
        "display": display or slug,
        "kind": "personal",
        "updated_at": now_iso(),
        "prev_sha256": None,
        "seed": {"source_file": None,
                 "source_lane": "service.rocsync first run (no seed "
                                "for this profile)"},
        "shows": [],
        "progress": [],
        "played_no_position": [],
        "watchlist": [],
        "collections": [],
        "exclusions": [],
        "inherited_suppressed": [],
    }


def _verify_seed(slug, seed_bytes):
    want = SEED_SHA256.get(slug)
    if want is None:
        return False
    return sha256_bytes(seed_bytes) == want


def load_store(data_dir, slug, seed_bytes=None, display=""):
    """Load (and if needed seed / recover) the store for `slug`.
    Returns (store_dict, status) where status is one of:
    'ok', 'seeded', 'fresh', 'recovered_bak', 'recovered_seed',
    'recovered_fresh'. ONLY the service may call this (it writes
    on seed/recovery); readers use load_readonly()."""
    tdir = tracking_dir(data_dir)
    os.makedirs(tdir, exist_ok=True)
    path = store_path(data_dir, slug)
    head_path = path + ".head"
    bak_path = path + ".bak"
    raw = _read_bytes(path)

    if raw is None:
        # First run for this profile on this stick: import the
        # genesis seed byte-identical (its chain header is the
        # chain's start), or start an empty store.
        if seed_bytes is not None and _verify_seed(slug, seed_bytes):
            _atomic_write(path, seed_bytes)
            _atomic_write(head_path,
                          sha256_bytes(seed_bytes).encode())
            store = json.loads(seed_bytes.decode("utf-8"))
            return store, "seeded"
        store = empty_store(slug, display)
        save_store(data_dir, slug, store)
        return store, "fresh"

    # Existing file: verify against the head sidecar.
    head = _read_bytes(head_path)
    head_ok = (head is not None
               and head.decode("utf-8", "replace").strip()
               == sha256_bytes(raw))
    store = None
    if head_ok:
        try:
            store = json.loads(raw.decode("utf-8"))
        except Exception:
            store = None
    if store is not None:
        return store, "ok"

    # Corruption / tamper path: the damaged bytes are quarantined,
    # never silently overwritten.
    quarantine = path + ".corrupt-%d" % int(time.time())
    try:
        os.replace(path, quarantine)
    except Exception:
        pass
    bak = _read_bytes(bak_path)
    if bak is not None:
        try:
            bak_store = json.loads(bak.decode("utf-8"))
        except Exception:
            bak_store = None
        if bak_store is not None:
            # The .bak is the genuine previous version: restore it
            # as the live store and re-stamp the head.
            _atomic_write(path, bak)
            _atomic_write(head_path, sha256_bytes(bak).encode())
            return bak_store, "recovered_bak"
    if seed_bytes is not None and _verify_seed(slug, seed_bytes):
        _atomic_write(path, seed_bytes)
        _atomic_write(head_path, sha256_bytes(seed_bytes).encode())
        return json.loads(seed_bytes.decode("utf-8")), "recovered_seed"
    store = empty_store(slug, display)
    save_store(data_dir, slug, store)
    return store, "recovered_fresh"


def load_readonly(data_dir, slug):
    """Read the store without writing anything (plugin processes).
    Returns the parsed store, or None when missing/corrupt — the
    service owns recovery, readers just serve what is sound."""
    raw = _read_bytes(store_path(data_dir, slug))
    if raw is None:
        return None
    head = _read_bytes(store_path(data_dir, slug) + ".head")
    if head is not None and \
            head.decode("utf-8", "replace").strip() != sha256_bytes(raw):
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return None


def verify_store(data_dir, slug):
    """True when the on-disk store parses and matches its head
    sidecar. The service polls this so a damaged file is caught
    (and recovered via load_store) even between writes."""
    raw = _read_bytes(store_path(data_dir, slug))
    if raw is None:
        return False
    head = _read_bytes(store_path(data_dir, slug) + ".head")
    if head is None or \
            head.decode("utf-8", "replace").strip() != sha256_bytes(raw):
        return False
    try:
        json.loads(raw.decode("utf-8"))
        return True
    except Exception:
        return False


def save_store(data_dir, slug, store):
    """The single writer's write path: stamp the chain, retain the
    previous file as .bak, atomic replace, stamp the head."""
    tdir = tracking_dir(data_dir)
    os.makedirs(tdir, exist_ok=True)
    path = store_path(data_dir, slug)
    prev = _read_bytes(path)
    if prev is not None:
        _atomic_write(path + ".bak", prev)
        store["prev_sha256"] = sha256_bytes(prev)
    store["schema_version"] = SCHEMA_VERSION
    store["updated_at"] = now_iso()
    data = json.dumps(store, ensure_ascii=False, indent=1,
                      sort_keys=True).encode("utf-8")
    _atomic_write(path, data)
    _atomic_write(path + ".head", sha256_bytes(data).encode())
    return sha256_bytes(data)


# ----------------------------------------------------------------------
# tombstones
# ----------------------------------------------------------------------
def is_excluded(store, row):
    """True when a tombstone covers this item. Importers and the
    capture path check this FIRST — a removed item never
    resurrects. Matches on ids when the tombstone carries them,
    else on normalised title (the aggregate junk tombstone names
    its titles inside one string, so containment counts)."""
    ids = row.get("ids") or {}
    title = _norm(row.get("title"))
    show = _norm(row.get("tvshowtitle") or "")
    for ex in store.get("exclusions") or []:
        ex_ids = ex.get("ids") or {}
        for kind in ("tmdb", "imdb", "tvdb"):
            if ex_ids.get(kind) and ids.get(kind) \
                    and str(ex_ids[kind]) == str(ids[kind]):
                return True
        ex_title = _norm(ex.get("title"))
        if ex_title and title and (title in ex_title
                                   or ex_title in title):
            return True
        if ex_title and show and show in ex_title:
            return True
    return False


# ----------------------------------------------------------------------
# progress writes (the capture path)
# ----------------------------------------------------------------------
def is_finished(position, duration):
    if duration and duration > 0:
        if duration - position <= FINISHED_REMAIN:
            return True
        if position / duration * 100.0 >= FINISHED_PCT:
            return True
    return False


def passes_floor(position, duration, trigger):
    pct = (position / duration * 100.0) if duration else 0.0
    if trigger == "pause_play":
        return position >= PAUSE_PLAY_FLOOR_POS or pct >= FLOOR_PCT
    return position > FLOOR_POS or pct >= FLOOR_PCT


def upsert_progress(store, entry):
    """Insert or replace the progress row for entry's identity.
    Caller has already checked tombstones + floors. Sources merge,
    never duplicate. Returns the stored row."""
    key = identity_key(entry)
    rows = store.setdefault("progress", [])
    for i, row in enumerate(rows):
        if identity_key(row) == key:
            merged = dict(row)
            merged.update(entry)
            srcs = list(row.get("sources") or [])
            for s in entry.get("sources") or []:
                if s not in srcs:
                    srcs.append(s)
            merged["sources"] = srcs
            rows[i] = merged
            return merged
    rows.append(entry)
    return entry


def remove_progress(store, key):
    rows = store.get("progress") or []
    store["progress"] = [r for r in rows if identity_key(r) != key]


def _show_row(store, entry):
    ids = entry.get("ids") or {}
    title = entry.get("tvshowtitle") or entry.get("title") or ""
    for show in store.get("shows") or []:
        s_ids = show.get("ids") or {}
        if ids.get("tmdb") and s_ids.get("tmdb") \
                and str(ids["tmdb"]) == str(s_ids["tmdb"]):
            return show
        if _norm(show.get("title")) == _norm(title) and title:
            return show
    show = {"type": "show", "title": title, "ids": dict(ids),
            "watched_episodes": [], "next_episode": None,
            "sources": list(entry.get("sources") or [])}
    store.setdefault("shows", []).append(show)
    return show


def mark_watched(store, entry):
    """A finished play: episodes join the show's watched set (and
    the next-episode pointer advances past them); movies and songs
    land in played_no_position as completed plays. The progress
    row is removed either way. Returns a short outcome string."""
    key = identity_key(entry)
    remove_progress(store, key)
    when = entry.get("paused_at") or now_iso()
    if entry.get("type") == "episode":
        show = _show_row(store, entry)
        tag = "S%sE%s" % (entry.get("season"),
                          entry.get("episode_number"))
        watched = show.setdefault("watched_episodes", [])
        if tag not in watched:
            watched.append(tag)
        # Next-episode pointer: just past the newest watched tag
        # in the same season when it pointed at/below this one.
        try:
            s_no = int(entry.get("season") or 0)
            e_no = int(entry.get("episode_number") or 0)
            show["next_episode"] = "S%dE%d" % (s_no, e_no + 1)
        except Exception:
            pass
        srcs = list(show.get("sources") or [])
        for s in entry.get("sources") or []:
            if s not in srcs:
                srcs.append(s)
        show["sources"] = srcs
        return "watched_episode"
    played = {"type": entry.get("type") or "movie",
              "title": entry.get("title") or "",
              "ids": dict(entry.get("ids") or {}),
              "completed": True,
              "watched_at": when,
              "sources": list(entry.get("sources") or [])}
    if entry.get("type") == "song":
        played["artist"] = entry.get("artist") or ""
        played["album"] = entry.get("album") or ""
    if entry.get("year"):
        played["year"] = entry["year"]
    store.setdefault("played_no_position", []).append(played)
    return "watched_" + played["type"]


def record_play(store, entry, trigger):
    """The capture path's single door. entry carries position /
    duration; trigger is 'pause_play' (Eric's press), 'stop' or
    'safety'. Returns one of: 'excluded', 'below_floor',
    'progress', 'watched_episode', 'watched_movie', 'watched_song'.
    The caller saves the store when the outcome is a write."""
    if is_excluded(store, entry):
        return "excluded"
    position = float(entry.get("position_seconds") or 0)
    duration = float(entry.get("runtime_seconds") or 0)
    if is_finished(position, duration):
        return mark_watched(store, entry)
    if not passes_floor(position, duration, trigger):
        return "below_floor"
    row = dict(entry)
    row["progress_percent"] = (round(position / duration * 100.0, 5)
                               if duration else 0.0)
    row["last_trigger"] = trigger
    row["last_ts"] = time.time()
    upsert_progress(store, row)
    return "progress"


# ----------------------------------------------------------------------
# Continue Watching read model
# ----------------------------------------------------------------------
def cw_rows(store, type_filter="all"):
    """Progress rows for the Home CW row: video only, newest
    first. Seed rows (percent-only, no position) still serve —
    they are Eric's sanctioned starting state; the write floors
    keep new junk out."""
    out = []
    for row in store.get("progress") or []:
        rtype = row.get("type") or "movie"
        if rtype not in VIDEO_TYPES:
            continue
        if type_filter == "movie" and rtype != "movie":
            continue
        if type_filter == "tv" and rtype != "episode":
            continue
        pos = float(row.get("position_seconds") or 0)
        pct = float(row.get("progress_percent") or 0)
        if pos <= 0 and pct <= 0:
            continue
        out.append(row)
    def _recency(row):
        ts = row.get("last_ts")
        if ts:
            return float(ts)
        return parse_ts(row.get("paused_at"))
    out.sort(key=_recency, reverse=True)
    return out
