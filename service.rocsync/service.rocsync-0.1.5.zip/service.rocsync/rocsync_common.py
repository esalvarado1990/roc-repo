# -*- coding: utf-8 -*-
"""
service.rocsync — shared helpers for the service (writer) and the
plugin (reader/player). Everything xbmc-facing lives here; the
store discipline itself is rocsync_store (pure python).
"""
import json
import os
import re
import sys
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover - importable outside Kodi
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rocsync_store as store_mod

ADDON_ID = "service.rocsync"
SEEK_PROPERTY = "RocSync.PendingSeek"

# Kodi profile name -> seed/store slug (the four house profiles).
PROFILE_SLUGS = {"E-Roc": "eric", "Nue": "nue", "Jama": "jama",
                 "August": "august"}

_TMDB_KEY_CACHE = [None]
_TMDB_IMG = "https://image.tmdb.org/t/p/"


def log(msg):
    try:
        xbmc.log("[service.rocsync] %s" % msg, xbmc.LOGINFO)
    except Exception:
        pass


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def data_dir():
    """This profile's own addon_data dir for the service (Kodi
    mounts only the ACTIVE profile's subtree under special://
    profile — the Design A isolation seam)."""
    path = xbmcvfs.translatePath(
        "special://profile/addon_data/%s/" % ADDON_ID)
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def profile_name():
    try:
        return xbmc.getInfoLabel("System.ProfileName") or ""
    except Exception:
        return ""


def profile_slug():
    name = profile_name()
    if name in PROFILE_SLUGS:
        return PROFILE_SLUGS[name]
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "master"


def seed_bytes(slug):
    """The shipped genesis seed for this slug, or None. Seeds ride
    inside the addon (resources/seeds/<slug>.json); the store
    module verifies their sha256 against the migration MANIFEST
    before anything is imported."""
    try:
        path = os.path.join(
            xbmcvfs.translatePath(addon().getAddonInfo("path")),
            "resources", "seeds", slug + ".json")
        with open(path, "rb") as fh:
            return fh.read()
    except Exception:
        return None


# ----------------------------------------------------------------------
# TMDb art (metadata only — the Helper's own key file, read the
# same way rocui reads it; no Trakt anything, no token)
# ----------------------------------------------------------------------
def _tmdb_key():
    if _TMDB_KEY_CACHE[0] is not None:
        return _TMDB_KEY_CACHE[0]
    key = ""
    try:
        base = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.themoviedb.helper/")
        path = os.path.join(
            base, "resources", "tmdbhelper", "lib", "api",
            "api_keys", "tmdb.py")
        with open(path, "r") as fh:
            text = fh.read()
        m = re.search(r"API_KEY\s*=\s*['\"]([^'\"]+)['\"]", text) \
            or re.search(r"['\"]([0-9a-f]{32})['\"]", text)
        if m:
            key = m.group(1)
    except Exception:
        key = ""
    _TMDB_KEY_CACHE[0] = key
    return key


def tmdb_get(path):
    """One TMDb API read (details/art only), or None. Same mini-
    client shape as rocui_common.tmdb_get."""
    key = _tmdb_key()
    if not key:
        return None
    try:
        import urllib.request
        sep = "&" if "?" in path else "?"
        url = "https://api.themoviedb.org/3/%s%sapi_key=%s" % (
            path, sep, key)
        req = urllib.request.Request(
            url, headers={"User-Agent": "RocSync/0.1"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def _img(path, size="w500"):
    if not path:
        return ""
    return _TMDB_IMG + size + path


def _classify(out, payload):
    """Category classification from a TMDB tv/movie payload
    (CW-IN-CATEGORIES lane, 2026-11-17): animation = genre 16
    (Animation) among the payload's genres; anime = animation
    whose original language is Japanese — the house badge rule
    (rocui's _usearch_badge). A payload TMDB could not serve
    never reaches here, so an unclassifiable row keeps the
    False defaults and stays in its base movie/tv bucket."""
    try:
        genres = payload.get("genres") or []
        out["animation"] = any(
            int(g.get("id") or 0) == 16
            for g in genres if isinstance(g, dict))
    except Exception:
        out["animation"] = False
    out["anime"] = bool(out["animation"]) and \
        (payload.get("original_language") or "") == "ja"


def art_for(row, cache):
    """Art + display enrichment for one CW row, cached per
    identity in art_cache.json (a disposable cache — NOT the
    store). Returns dict with poster/fanart/thumb/plot/episode
    title where TMDb knows them; empty strings when it doesn't —
    the row still serves, the label carries it."""
    key = store_mod.identity_key(row)
    hit = cache.get(key)
    if hit is not None and "animation" in hit:
        return hit
    # A pre-0.1.3 cache entry lacks the category classification
    # (CW-IN-CATEGORIES lane, 2026-11-17): fall through and
    # refetch once so the entry is upgraded in place.
    out = {"poster": "", "fanart": "", "thumb": "", "plot": "",
           "episode_title": "", "year": row.get("year") or "",
           "animation": False, "anime": False}
    ids = row.get("ids") or {}
    tmdb = ids.get("tmdb")
    if tmdb:
        if row.get("type") == "episode":
            show = tmdb_get("tv/%s" % tmdb)
            if show:
                _classify(out, show)
                out["poster"] = _img(show.get("poster_path"))
                out["fanart"] = _img(show.get("backdrop_path"),
                                     "w780")
                out["plot"] = show.get("overview") or ""
                if not out["year"] and show.get("first_air_date"):
                    out["year"] = int(show["first_air_date"][:4])
            season = row.get("season")
            epnum = row.get("episode_number")
            if season is not None and epnum is not None:
                ep = tmdb_get("tv/%s/season/%s/episode/%s"
                              % (tmdb, season, epnum))
                if ep:
                    out["episode_title"] = ep.get("name") or ""
                    out["thumb"] = _img(ep.get("still_path"), "w500")
                    if not out["plot"]:
                        out["plot"] = ep.get("overview") or ""
            if not out["thumb"]:
                out["thumb"] = out["fanart"] or out["poster"]
        else:
            movie = tmdb_get("movie/%s" % tmdb)
            if movie:
                _classify(out, movie)
                out["poster"] = _img(movie.get("poster_path"))
                out["fanart"] = _img(movie.get("backdrop_path"),
                                     "w780")
                out["thumb"] = out["fanart"] or out["poster"]
                out["plot"] = movie.get("overview") or ""
                if not out["year"] and movie.get("release_date"):
                    out["year"] = int(movie["release_date"][:4])
    cache[key] = out
    return out


def load_art_cache():
    try:
        path = os.path.join(data_dir(), "art_cache.json")
        with open(path, "r") as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_art_cache(cache):
    try:
        path = os.path.join(data_dir(), "art_cache.json")
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(cache, fh)
        os.replace(tmp, path)
    except Exception:
        pass


# ----------------------------------------------------------------------
# pending seek (armed by the plugin's play route, applied by the
# service — the rocui seek-applier discipline, our own channel)
# ----------------------------------------------------------------------
def seek_arm(position, identity, title_hint):
    try:
        payload = json.dumps({"position": float(position),
                              "key": identity,
                              "title": title_hint or "",
                              "ts": time.time()})
        xbmcgui.Window(10000).setProperty(SEEK_PROPERTY, payload)
    except Exception as exc:
        log("seek arm failed: %s" % exc)


def seek_peek():
    try:
        raw = xbmcgui.Window(10000).getProperty(SEEK_PROPERTY)
        if not raw:
            return None
        data = json.loads(raw)
        return data if data.get("position") else None
    except Exception:
        return None


def seek_clear():
    try:
        xbmcgui.Window(10000).setProperty(SEEK_PROPERTY, "")
    except Exception:
        pass
