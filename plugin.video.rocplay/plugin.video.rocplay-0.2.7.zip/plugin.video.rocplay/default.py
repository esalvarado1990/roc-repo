# -*- coding: utf-8 -*-
"""
plugin.video.rocplay — the Roc OS playback chain (next version).

WHY THIS EXISTS (Dell pre-test 2026-10-25, REPORT.md §7/§9): the
shipped route — poster -> TMDb Helper player template -> Scrubs/Crew
— is dead at two seams: TMDb Helper 5.4.16 executes single-step
player templates WITHOUT substituting {title}/{year}/{imdb}/{tmdb}
(see the contract test in nextver/tests/), and both downstream
players scrape to zero / die silently. Roc OS now owns the chain:

  * SAME entry contract as the old players, so TMDb Helper and
    rocui can drive it identically:
      ?action=play&title&year&imdb&tmdb[&tvshowtitle&season&episode
      &premiered][&auto=1]
  * Asks EVERY well at once (wellcore), merges the pour, watches
    each well's health (roll-in item 29).
  * NO SOURCE PICKING by default (Eric's law, 2026-11-01): PLAY
    resolves the best working source itself and starts playback;
    the merged source list picker appears ONLY when the addon's
    "choose_source" setting is ON (default OFF). auto=1 (August's
    profile, resume flows) still forces no dialog. (The gate was
    dropped in 0.2.4, leaving the bare auto flag as the only thing
    between Eric and the picker; restored in 0.2.6, player lane
    2026-11-12.)
  * ESSENTIALS ONLY (Eric, 2026-11-12): no foreign-addon fallback
    floor (the Scrubs V2 / The Crew entries are gone from the
    picker and from the end of the ladder), no queue, no cache
    features. The path is: find sources -> (picker, if gated on)
    -> play with failover -> an honest toast when nothing works.
  * FAILOVER (roll-in, August's error law §4 + pre-test CARRY §9.3):
    if the chosen source doesn't start and advance within the start
    window, the chain advances to the next source on its own.
  * Every step is written to the flight recorder (roll-in item 4):
    addon_data/plugin.video.rocplay/rocplay_events.jsonl.
  * The playing ListItem carries title/year/season/episode +
    IMDb/TMDB unique IDs, so script.rocui's service keeps doing
    history/resume/continue-watching exactly as before.
"""
import os
import re
import sys
import urllib.parse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "resources", "lib"))
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import wellcore

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
START_WINDOW_S = 30      # a source that hasn't advanced by now is dead.
# FIX BATCH 2026-11-10: was 90. A dead source burned the FULL window
# even when its player died in the first second (demuxer death fires
# onPlayBackStopped, never onPlayBackFailed/Ended), so a 12-source
# cascade could sit on "Content Loading" for ~18 minutes (bedroom
# stick, 2026-11-10 21:18-21:36 logcat). Healthy sources prove
# advance in ~19 s; 30 s is generous headroom, and the stopped-break
# in _try_source now ends a try at the death itself.
                         # 60 originally (not 20): cold first contact
                         # with a well's edge CDN (fresh DNS + TLS to
                         # rotating hosts) measured 19s+ in Kodi's
                         # demuxer on the Dell while every hop answered
                         # curl in <1.5s; warm starts land in ~5s.
                         # Raised to 90 (2026-10-27, Eric-delegated
                         # decision): the resume leg needs TWO cold
                         # starts and VixSrc's latency tail crosses
                         # 60 — diag4's reopen was stamped
                         # source_failed at exactly +60s while sibling
                         # tries that night visibly rolled past the
                         # mark. Per-path budgets (resume-only 120)
                         # are unclean here: this window sits behind
                         # the single TMDBH player definition, and the
                         # resume reopen is built by rocui from its
                         # stored snapshot through that same
                         # definition — no per-invocation channel
                         # reaches the reopen without also moving
                         # first plays. So the window moves globally,
                         # per the decision's fallback. Cost: a truly
                         # dead source now bounds failover at 90s.
ADVANCE_CHECK_S = 6      # ...checked this long after first frame

# --- AUTO-TAILOR ceiling (Phase 2 spec, door-build-20261102.md) -----
# Light tier (AFTSSS / mt8695-class, ~1 GB RAM, 1080p-capped panel):
# sources above 1080p are removed from the ladder AND the picker.
# The 2160p lead killed Kodi on this chassis twice in one night
# (door-build F3 on .159; fleet lane A Dune pick 1 on .161). Eric,
# Nov 2 23:16: "take 4k out — all he needs is 1080." Detection is
# per-device at runtime: ro.product.model (best effort, build.prop)
# + MemTotal from /proc/meminfo. Only a source with a POSITIVE
# >1080p signal (label text / URL marker) is dropped — a source
# with no readable resolution signal stays.
CAP_LIGHT_MEM_KB = 1100 * 1024   # ~1.1 GB
_CAP_LABEL_RE = re.compile(r"(?i)\b(2160p?|4k|uhd)\b")
_CAP_URL_RE = re.compile(r"(?i)(2160p|s2160|2160x|[-_/]2160[-_/])")


def _read_text(path):
    try:
        fh = xbmcvfs.File(path)
        try:
            data = fh.read()
        finally:
            fh.close()
        if isinstance(data, bytes):
            data = data.decode("utf-8", "replace")
        return data or ""
    except Exception:
        pass
    try:
        with open(path, "r") as fh:
            return fh.read()
    except Exception:
        return ""


def _infolabel_mem_kb():
    """Total RAM via Kodi's own memory InfoLabels (fallback when
    /proc/meminfo is not readable from inside the addon — Android
    app sandboxes can deny it). 0 when the labels don't parse."""
    total = 0
    for name in ("free", "used"):
        try:
            raw = xbmc.getInfoLabel("System.Memory(%s)" % name) or ""
        except Exception:
            return 0
        m = re.match(r"\s*([\d.]+)\s*(GB|MB|kB|KB|B)", raw)
        if not m:
            return 0
        val = float(m.group(1))
        unit = m.group(2).upper()
        total += int(val * {"GB": 1048576, "MB": 1024,
                            "KB": 1, "B": 0}.get(unit, 0) if unit != "B"
                     else val // 1024)
    return total


def _device_class():
    """(model, mem_total_kb, is_light_tier, probe) for THIS device.
    probe carries the raw read lengths so a silent detection
    failure is visible in the flight recorder instead of hiding."""
    prop = _read_text("/system/build.prop")
    model = ""
    for line in prop.splitlines():
        if line.startswith("ro.product.model="):
            model = line.split("=", 1)[1].strip()
            break
    meminfo = _read_text("/proc/meminfo")
    mem_kb = 0
    m = re.search(r"MemTotal:\s+(\d+)\s*kB", meminfo)
    if m:
        mem_kb = int(m.group(1))
    mem_src = "meminfo" if mem_kb else ""
    if not mem_kb:
        mem_kb = _infolabel_mem_kb()
        mem_src = "infolabel" if mem_kb else ""
    light = (model == "AFTSSS") or (0 < mem_kb <= CAP_LIGHT_MEM_KB)
    probe = {"prop_len": len(prop), "meminfo_len": len(meminfo),
             "mem_src": mem_src}
    return model, mem_kb, light, probe


def _over_cap(source):
    """True only on a positive >1080p signal. Three arms, in the
    order the wells actually carry them:
      1. source['quality'] — the well's own numeric height (Movy
         carries it; its label is just 'Movy' and its CDN URL need
         not carry a marker, so this arm is load-bearing).
      2. Label text (2160p / 4K / UHD).
      3. URL markers (s2160p, rendition=2160, /2160/ ...).
    A source with no readable signal in any arm STAYS."""
    q = source.get("quality")
    if isinstance(q, (int, float)):
        if q > 1080:
            return True
    elif isinstance(q, str):
        digits = "".join(ch for ch in q if ch.isdigit())
        if digits and int(digits) > 1080:
            return True
    if _CAP_LABEL_RE.search(source.get("label") or ""):
        return True
    return bool(_CAP_URL_RE.search(source.get("url") or ""))


def _store_dir():
    # xbmc.translatePath was removed in Kodi 21 (Omega) — it lives in
    # xbmcvfs since Kodi 19. The legacy call crashed every in-Kodi
    # play() at WellCore construction (Dell trunk battery 2026-10-26:
    # AttributeError in kodi.log, no fan-out ever ran).
    return xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def _params():
    q = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    return {k: v[0] for k, v in urllib.parse.parse_qs(q).items()}


def _play_url(source):
    """Kodi pipe-header format so the CDN sees the headers the well
    recipe requires (Referer / User-Agent)."""
    url = source["url"]
    hdrs = source.get("headers") or {}
    if hdrs:
        url += "|" + "&".join(
            "%s=%s" % (k, urllib.parse.quote(str(v), safe=""))
            for k, v in hdrs.items())
    return url


def _listitem(req, source=None):
    li = xbmcgui.ListItem(label=req.get("title") or "Play")
    info = {"title": req.get("title") or "",
            "year": int(req.get("year") or 0),
            "mediatype": "episode" if req.get("tmdb_type") == "tv" else "movie"}
    if req.get("tmdb_type") == "tv":
        info.update({"tvshowtitle": req.get("showtitle") or req.get("title") or "",
                     "season": int(req.get("season") or 0),
                     "episode": int(req.get("episode") or 0)})
        if req.get("premiered"):
            info["premiered"] = req["premiered"]
    li.setInfo("video", info)
    ids = {}
    if req.get("imdb"):
        ids["imdb"] = str(req["imdb"])
    if req.get("tmdb_id"):
        ids["tmdb"] = str(req["tmdb_id"])
    if ids:
        li.setUniqueIDs(ids, "imdb" if "imdb" in ids else "tmdb")
    return li


class _ChainPlayer(xbmc.Player):
    def __init__(self):
        super(_ChainPlayer, self).__init__()
        self.failed = False
        self.ended = False
        self.stopped = False

    def onPlayBackFailed(self):
        self.failed = True

    def onPlayBackError(self):
        self.failed = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackStopped(self):
        # FIX BATCH 2026-11-10: a demuxer death (playlist verified,
        # segments dead) ends the player WITHOUT firing Failed or
        # Ended — Stopped is the only callback it sends (measured on
        # the test stick, kodi.log 2026-11-10 21:37:34). Without this
        # the try loop below waited out the whole start window on a
        # corpse.
        self.stopped = True


def _try_source(core, req, source):
    """Play one source; True only when playback starts AND the
    playhead advances (the trunk program's definition of 'plays')."""
    core.event("source_try", well=source["well"], label=source["label"],
               url=source["url"][:160])
    player = _ChainPlayer()
    monitor = xbmc.Monitor()
    player.play(_play_url(source), _listitem(req, source))
    elapsed = 0.0
    first_time = None
    while elapsed < START_WINDOW_S:
        if monitor.abortRequested() or player.failed:
            break
        if player.isPlayingVideo():
            try:
                t = player.getTime()
            except Exception:
                t = 0
            if first_time is None:
                first_time = (elapsed, t)
            elif elapsed - first_time[0] >= ADVANCE_CHECK_S:
                ok = t > first_time[1]
                core.event("source_ok" if ok else "source_stalled",
                           well=source["well"], label=source["label"],
                           advanced=bool(ok))
                return ok
        if player.ended and elapsed > 2:
            break
        if player.stopped and elapsed > 2:
            # Player died without failing/ending (demuxer death) —
            # the source is dead NOW, not at the window's end.
            break
        monitor.waitForAbort(0.5)
        elapsed += 0.5
    core.event("source_failed", well=source["well"], label=source["label"])
    try:
        player.stop()
    except Exception:
        pass
    return False


class _Busy(object):
    """xbmcgui.DialogBusy was removed in Kodi 21 (Omega) — the busy
    spinner is Kodi's own now. Shim: use the class where it exists,
    no-op where it doesn't. (Second removed-API crash on the play
    path: Dell trunk play re-run 2026-10-26, AttributeError at
    play() before the fan-out could start.)"""

    def __init__(self):
        cls = getattr(xbmcgui, "DialogBusy", None)
        self._dlg = cls() if cls is not None else None

    def create(self):
        if self._dlg is not None:
            self._dlg.create()

    def close(self):
        if self._dlg is not None:
            self._dlg.close()


class _PlayStatus(object):
    """CHAIN FIX (Phase-2 audit, 2026-11-08): the fanout's old modal
    xbmcgui progress dialog ("Roc Play — Finding sources…") is GONE
    from the play path. CHAIN-BLOCK-DIAGNOSIS: raising that modal
    over detail window 1124, ~2 s after a fullscreen teardown and
    while the GUI thread is still completing the PlayMedia plugin
    hand-off, parks the GUI thread — no source is ever attempted
    and the box needs a force-stop. This is the wedge pattern
    (WEDGE-DIAGNOSIS §4) applied to rocplay: never a modal here.

    Replacement, all non-modal:
      * a toast at fanout start, same wording the modal carried
        ("Roc Play" / "Finding sources…") — Dialog().notification()
        is the fire-and-forget KaiToast queue, the same call the
        no-sources / all-failed paths already use below;
      * Window(10000) properties a skin MAY render later (nothing
        in the skin reads them yet; publishing is the whole job):
          RocPlay.Status     finding | playing |
                             no_sources | all_failed | cancelled |
                             fanout_failed
          RocPlay.StatusText human line for the current status
          RocPlay.Title      the title being played
    Failure is still signalled by the pre-existing warning toasts
    on the no_sources / all_failed paths (unchanged); success is
    signalled by playback itself starting."""

    def _publish(self, status, text, req):
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("RocPlay.Status", status)
            win.setProperty("RocPlay.StatusText", text or "")
            win.setProperty("RocPlay.Title",
                            (req or {}).get("title") or "")
        except Exception:
            pass

    def start(self, req):
        self._publish("finding", "Finding sources…", req)
        try:
            xbmcgui.Dialog().notification(
                "Roc Play", "Finding sources…",
                xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass

    def finish(self, status, text, req):
        self._publish(status, text, req)


def _picker_enabled():
    """The source picker is opt-in only (Eric, 2026-11-01): it may
    appear solely when the 'choose_source' addon setting is ON.
    Default (setting absent or OFF) = picker can never appear and
    PLAY goes straight to the best working source. Any read failure
    also lands on OFF — the gate fails closed, never open.
    (Restored 0.2.6 from the Joe-era loop82 build; 0.2.4 had dropped
    the gate entirely.)"""
    try:
        return bool(ADDON.getSettingBool("choose_source"))
    except Exception:
        return (ADDON.getSetting("choose_source") or "").lower() == "true"


def play(req, auto=False):
    core = wellcore.WellCore(_store_dir())
    busy = _Busy()
    busy.create()
    status = _PlayStatus()
    status.start(req)
    try:
        sources = core.fanout(req)
    except Exception:
        status.finish("fanout_failed", "Finding sources failed", req)
        raise
    finally:
        busy.close()
    # AUTO-TAILOR ceiling: on a light-tier device nothing above
    # 1080p is offered (picker) or tried (ladder). See _device_class.
    # The check is logged on EVERY play: detection that fails
    # silently is indistinguishable from a cap that never fired.
    model, mem_kb, light, probe = _device_class()
    core.event("cap_check", model=model, mem_kb=mem_kb,
               light=bool(light), probe=probe)
    if light and sources:
        kept = [s for s in sources if not _over_cap(s)]
        if len(kept) != len(sources):
            dropped_detail = [{"well": s.get("well"),
                               "quality": s.get("quality")}
                              for s in sources if _over_cap(s)]
            core.event("cap_filter", ceiling="1080p", model=model,
                       mem_kb=mem_kb, dropped=len(sources) - len(kept),
                       kept=len(kept), dropped_detail=dropped_detail)
        sources = kept
    if not sources:
        core.event("no_sources", title=req.get("title"))
        status.finish("no_sources", "No sources right now", req)
        xbmcgui.Dialog().notification(
            "Roc Play", "No sources right now — it's logged, try again soon",
            xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    order = list(range(len(sources)))
    if not auto and _picker_enabled() and len(sources) > 1:
        labels = ["%s — %s" % (s["well"], s["label"]) for s in sources]
        pick = xbmcgui.Dialog().select(
            req.get("title") or "Sources", labels)
        if pick < 0:
            core.event("user_cancelled", title=req.get("title"))
            status.finish("cancelled", "", req)
            return
        order = [pick] + [i for i in order if i != pick]
    for pos, i in enumerate(order):
        if pos:
            # CHAIN SETTLE (0.2.6, from the Brave Little Toaster
            # flight record, patio 2026-11-12): after a source burned
            # the full start window, the next three sources — across
            # two other CDNs, one of them the same URL family that
            # played this title in another run — each died at the
            # ~2.5 s demuxer-death check, the signature of Kodi's
            # player core still tearing down the stalled attempt
            # rather than three independently dead sources. Give the
            # core a beat to finish teardown before the next try.
            core.event("chain_settle", after_well=sources[order[pos - 1]]["well"],
                       next_well=sources[i]["well"])
            if xbmc.Monitor().waitForAbort(1.0):
                core.event("chain_aborted", title=req.get("title"))
                status.finish("cancelled", "", req)
                return
        if _try_source(core, req, sources[i]):
            core.event("playing", well=sources[i]["well"],
                       label=sources[i]["label"], title=req.get("title"))
            status.finish("playing", "%s — %s" % (sources[i]["well"],
                          sources[i]["label"]), req)
            return
    core.event("all_failed", title=req.get("title"))
    status.finish("all_failed", "Those sources wouldn't start", req)
    xbmcgui.Dialog().notification(
        "Roc Play", "Those sources wouldn't start — it's logged",
        xbmcgui.NOTIFICATION_WARNING, 5000)


def main():
    p = _params()
    if p.get("action") != "play":
        xbmcplugin.endOfDirectory(HANDLE)
        return
    req = {
        "title": p.get("tvshowtitle") if p.get("tvshowtitle") else p.get("title", ""),
        "showtitle": p.get("tvshowtitle", ""),
        "year": int(p["year"]) if p.get("year", "").isdigit() else p.get("year"),
        "imdb": p.get("imdb", ""),
        "tmdb_id": int(p["tmdb"]) if p.get("tmdb", "").isdigit() else None,
        "tmdb_type": "tv" if ("season" in p or "tvshowtitle" in p) else "movie",
        "season": int(p["season"]) if p.get("season", "").isdigit() else None,
        "episode": int(p["episode"]) if p.get("episode", "").isdigit() else None,
        "premiered": p.get("premiered", ""),
    }
    if req["tmdb_type"] == "tv" and not req["showtitle"]:
        req["showtitle"] = req["title"]
    play(req, auto=p.get("auto") == "1")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == "__main__":
    main()
