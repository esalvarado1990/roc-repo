# -*- coding: utf-8 -*-
"""
rocplay well core — the DOOR SYSTEM (Door Doctrine build, 2026-11-02).

Eric's order (2026-11-02 19:53): "Add a few doors. Add a few of our own
doors. Put a real decoy door in there which serves a purpose, multiple
purpose. But put some hidden ones in there too. We need more than one
door." Plus the all-directions addendum (19:54): exit doors, entrance
doors, both-ways, above, underneath.

Design law carried over (Eric, 2026-10-26 02:16):
  * Ask every FRONT door at the same time — never one, never in sequence.
  * A dry or dead door drops off silently; the screen never breaks.
  * Every door is WATCHED: health record per door in the addon data dir.

The tiers:
  FRONT doors — asked on every play, in parallel (ENTRANCE):
    VixSrc    role DECOY — the famous front door. A real, working well
              that also takes the heat/attention/rate-limits.
    Movy      the wecollege protocol, re-derived from Cinema HQ's DEX.
    VidZee    core.vidzee.wtf, selector recovered from Cinema HQ's DEX.
    VidMario  api.vidmario.net — 111movies' own current service.
  RESERVE doors — the hidden tier (UNDERNEATH), engaged ONLY when the
  front set returns total zero (tonight's no_sources case). They stay
  un-burned and off the visible list; their results are still logged
  when they fire — receipts beat secrecy inside our own logs:
    VidSrc    the full token chain (single-use, IP-bound JWTs — the
              expensive door; reserve keeps it un-burned).
    MP4Hydra  slug-keyed JSON API, held back by doctrine.

Directions:
  EXIT — every well_result carries a verdict classified from the
  well's own stage evidence (stagelog): "sources", "answered_zero"
  (every hop answered, shelf empty — the window on this exit is shut),
  or "no_answer" (transport failure / window timeout — door trouble).
  fanout_done carries exit_window_suspect=true when ALL front doors
  answered_zero: the Nov 2 signature (VixSrc zeroed from a verified NL
  exit on .161 while serving on .159). A signal, not a verdict.
  BOTH-WAYS — the wells verify their own candidates before returning
  them (content-sniffed playlists, ranged ftyp checks).
  ABOVE — browser-grade fallback path: mapped in the door report,
  deliberately not implemented in this build.
"""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutTimeout

import stagelog
from wells import movy, mp4hydra, vidmario, vidsrc, vidzee, vixsrc

FRONT_WELLS = [vixsrc, movy, vidzee, vidmario]
RESERVE_WELLS = [vidsrc, mp4hydra]
WELLS = FRONT_WELLS  # compat: the front set is "the wells" day to day
# Trusted-provider rank for the merged sort (SKIN PASS PUSH,
# 2026-11-12). Eric's standing source order — the SOURCE PROBLEMS
# protocol (2026-11-02) is Movy first, then the full trusted set —
# plus his walkthrough words (2026-11-12): "if they could sort
# them by the most recommended source or link". Before this, the
# merged order was well health then quality only, so a healthy
# VidZee could sit above Movy in both the picker and the autoplay
# ladder. Rank now leads; health and quality still order sources
# inside each provider.
TRUSTED_RANK = {"movy": 0, "vixsrc": 1, "vidzee": 2,
                "vidmario": 3, "vidsrc": 4, "mp4hydra": 5}
FANOUT_WINDOW = 45   # seconds; raised 2026-11-03 (Joe finish, 0.2.3):
                     # Nov 3 11:15 on .161 the front wells answered at
                     # +27s (VixSrc), +34s (VidZee), +43s (Movy) — all
                     # past the old 20s window, so the fanout recorded
                     # front_total_zero and played nothing even though
                     # sources existed. as_completed returns early when
                     # every well answers, so the fast case is unharmed.
RESERVE_WINDOW = 90  # seconds; raised with it (0.2.3): the VidSrc
                     # multi-hop WASM chain measured ~83s from reserve
                     # start on Nov 3 (11:15:43 -> done 11:17:06).


def _classify(name, count, timed_out):
    """Evidence-based verdict for one well's run (see module docstring)."""
    if count > 0:
        return "sources"
    if timed_out:
        return "no_answer"
    if stagelog.evidence(name) == "transport":
        return "no_answer"
    return "answered_zero"


class WellCore(object):
    def __init__(self, store_dir):
        self.store_dir = store_dir
        self._lock = threading.Lock()
        try:
            os.makedirs(store_dir, exist_ok=True)
        except Exception:
            pass
        self.health_path = os.path.join(store_dir, "well_health.json")
        self.events_path = os.path.join(store_dir, "rocplay_events.jsonl")
        self.health = self._load_health()

    # ------------------------------------------------------------ io
    def _load_health(self):
        try:
            with open(self.health_path, "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_health(self):
        try:
            tmp = self.health_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(self.health, f)
            os.replace(tmp, self.health_path)
        except Exception:
            pass

    def event(self, kind, **fields):
        """Flight-recorder line (roll-in item 4): one JSON object per
        event, appended locally. Nothing leaves the device."""
        rec = {"ts": round(time.time(), 3), "kind": kind}
        rec.update(fields)
        try:
            with self._lock:
                with open(self.events_path, "a") as f:
                    f.write(json.dumps(rec) + "\n")
        except Exception:
            pass
        return rec

    # ------------------------------------------------------------ health
    def _record(self, name, ok, ms, count, tier=None):
        with self._lock:
            h = self.health.setdefault(
                name, {"ok": 0, "fail": 0, "last_ok": 0, "avg_ms": 0})
            if tier:
                h["tier"] = tier
            if ok:
                h["ok"] += 1
                h["last_ok"] = time.time()
            else:
                h["fail"] += 1
            h["avg_ms"] = int((h.get("avg_ms", 0) * 4 + ms) / 5)
            h["last_count"] = count
            self._save_health()

    def score(self, name):
        """Higher = healthier. Used ONLY for ordering — never to
        exclude a well from being asked."""
        h = self.health.get(name) or {}
        ok, fail = h.get("ok", 0), h.get("fail", 0)
        if ok + fail == 0:
            return 0.5  # unknown wells start mid-pack
        return ok / float(ok + fail)

    # ------------------------------------------------------------ fan-out
    def _ask(self, well, req, tier):
        stagelog.begin(well.NAME)
        t0 = time.time()
        try:
            sources = well.fetch(req) or []
        except Exception as exc:  # a well must never break the pour
            self.event("well_error", well=well.NAME, tier=tier,
                       error=str(exc)[:200])
            sources = []
        ms = int((time.time() - t0) * 1000)
        for src in sources:
            src.setdefault("well", well.NAME)
            src.setdefault("tier", tier)
        verdict = _classify(well.NAME, len(sources), timed_out=False)
        self._record(well.NAME, bool(sources), ms, len(sources), tier=tier)
        self.event("well_result", well=well.NAME, tier=tier,
                   ok=bool(sources), count=len(sources), ms=ms,
                   verdict=verdict)
        return sources, verdict

    def _run_set(self, wells, req, tier, window_s):
        """One tier of doors, all at once. Returns (merged, verdicts)."""
        merged, verdicts = [], {}
        pool = ThreadPoolExecutor(max_workers=max(2, len(wells)))
        try:
            futures = {pool.submit(self._ask, w, req, tier): w
                       for w in wells}
            try:
                for fut in as_completed(futures, timeout=window_s):
                    got, verdict = fut.result() or ([], "answered_zero")
                    merged.extend(got)
                    verdicts[futures[fut].NAME] = verdict
            except FutTimeout:
                for fut, w in futures.items():
                    if not fut.done():
                        verdicts[w.NAME] = "no_answer"
                        self.event("well_timeout", well=w.NAME, tier=tier,
                                   window_s=window_s, verdict="no_answer")
                        self._record(w.NAME, False, window_s * 1000, 0,
                                     tier=tier)
        finally:
            pool.shutdown(wait=False)
        return merged, verdicts

    def fanout(self, req):
        """Front doors at once; reserve doors only on a front total
        zero. Returns the merged source list, healthiest wells first,
        best quality first inside a well."""
        stagelog.set_sink(self.event)
        self.event("fanout_start", title=req.get("title"),
                   tmdb_id=req.get("tmdb_id"), tmdb_type=req.get("tmdb_type"),
                   season=req.get("season"), episode=req.get("episode"))
        t0 = time.time()
        merged, front_verdicts = self._run_set(FRONT_WELLS, req, "front",
                                               FANOUT_WINDOW)
        reserve_verdicts = {}
        if not merged:
            self.event("reserve_engaged", reason="front_total_zero",
                       title=req.get("title"))
            extra, reserve_verdicts = self._run_set(
                RESERVE_WELLS, req, "reserve", RESERVE_WINDOW)
            merged.extend(extra)
        merged.sort(key=lambda s: (TRUSTED_RANK.get(
            str(s["well"]).lower(), 99),
            -self.score(s["well"]),
            -int(s.get("quality") or 0)))
        exit_window_suspect = bool(front_verdicts) and all(
            v == "answered_zero" for v in front_verdicts.values())
        self.event("fanout_done", sources=len(merged),
                   ms=int((time.time() - t0) * 1000),
                   front=front_verdicts, reserve=reserve_verdicts,
                   exit_window_suspect=exit_window_suspect)
        return merged
