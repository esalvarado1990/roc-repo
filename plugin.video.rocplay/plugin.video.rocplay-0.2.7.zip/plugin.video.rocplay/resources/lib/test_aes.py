# -*- coding: utf-8 -*-
"""Offline proof for aes.py — run anywhere: python3 test_aes.py"""
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import aes

PT = bytes.fromhex("00112233445566778899aabbccddeeff")
FAIL = []


def check(name, got, want):
    ok = got == want
    print("%-28s %s" % (name, "PASS" if ok else "FAIL got=%s want=%s" % (got.hex(), want.hex())))
    if not ok:
        FAIL.append(name)


# FIPS-197 Appendix C block vectors
check("AES-128 block", aes.encrypt_block(bytes(range(16)), PT),
      bytes.fromhex("69c4e0d86a7b0430d8cdb78070b4c55a"))
check("AES-192 block", aes.encrypt_block(bytes(range(24)), PT),
      bytes.fromhex("dda97ca4864cdfe06eaf70a0ec0d7191"))
check("AES-256 block", aes.encrypt_block(bytes(range(32)), PT),
      bytes.fromhex("8ea2b7ca516745bfeafc49904b496089"))
check("AES-256 block decrypt",
      aes.decrypt_block(bytes(range(32)),
                        bytes.fromhex("8ea2b7ca516745bfeafc49904b496089")), PT)

# NIST SP 800-38A F.2.5 CBC-AES256, first block
key = bytes.fromhex("603deb1015ca71be2b73aef0857d7781"
                    "1f352c073b6108d72d9810a30914dff4")
iv = bytes(range(16))
pt = bytes.fromhex("6bc1bee22e409f96e93d7e117393172a")
ct = aes.cbc_encrypt(key, iv, pt, pad=False)
check("CBC-AES256 38A block1", ct,
      bytes.fromhex("f58c4c04d6e5f1ba779eabfb5f7bfbd6"))
check("CBC decrypt roundtrip", aes.cbc_decrypt(key, iv, ct, unpad=False), pt)

# PKCS7 round trip on an odd-length payload (the VidZee shape)
payload = b"https://cdn.example.net/movie/533535/master.m3u8?token=abc123"
key2 = b"A7kP9xM2Qv8Lr4Nz1Ht6Yc3Bw5Jf0DsU".ljust(32, b"\0")
iv2 = os.urandom(16)
enc = aes.cbc_encrypt(key2, iv2, payload)
check("PKCS7 roundtrip", aes.cbc_decrypt(key2, iv2, enc), payload)

# openssl cross-check (if present): decrypt our CBC output with the CLI
try:
    p = subprocess.run(
        ["openssl", "enc", "-aes-256-cbc", "-d", "-K", key2.hex(),
         "-iv", iv2.hex(), "-nopad"],
        input=enc, capture_output=True, timeout=20)
    if p.returncode == 0:
        check("openssl cross-decrypt", aes.cbc_decrypt(key2, iv2, enc, unpad=False), p.stdout)
    else:
        print("openssl present but errored: %s" % p.stderr.decode()[:120])
except FileNotFoundError:
    print("openssl not present — cross-check skipped (vectors above are authoritative)")

print("RESULT: %s" % ("ALL PASS" if not FAIL else "FAILURES: %s" % FAIL))
sys.exit(1 if FAIL else 0)
