# -*- coding: utf-8 -*-
"""
rocplay HTTP — stdlib urllib ONLY.

Zero third-party imports on purpose: the playback chain must not die
because a shared module (requests & friends) changed under it. Every
call returns None on ANY failure — wells treat None as "dry" and the
fan-out moves on. Nothing in here ever raises to the caller.
"""
import gzip as _gzip
import json as _json
import urllib.request
import urllib.error
import zlib as _zlib

UA = ("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36")


def _decode(body, headers):
    """Undo Content-Encoding (gzip/deflate) when the server used it.
    FIX 2026-11-12 (VidSrc treatment): we now ASK for gzip (see
    _prep) because identity chunked bodies from the VidSrc Cloudflare
    hosts get truncated mid-transfer on this VM's egress-proxy path
    (http.client IncompleteRead -> status 0), while the same chain
    completes identity from the house exit and completes gzip here.
    Promoted from a scratch copy verified the same night from both
    exits (VM: chain reaches the Turnstile gate; house: VidSrc
    movie 2 + TV 3 verified sources, unchanged)."""
    if not body:
        return body
    enc = ""
    try:
        enc = (headers.get("Content-Encoding") or "").lower()
    except Exception:
        pass
    try:
        if "gzip" in enc:
            return _gzip.decompress(body)
        if "deflate" in enc:
            return _zlib.decompress(body)
    except Exception:
        return body
    return body


def _prep(headers):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers:
        h.update(headers)
    # http.client silently injects "Accept-Encoding: identity" when
    # the header is absent; pin it to gzip explicitly (caller's own
    # choice always wins).
    if not any(k.lower() == "accept-encoding" for k in h):
        h["Accept-Encoding"] = "gzip"
    return h


def request(url, headers=None, data=None, timeout=12, method=None):
    """data: bytes (raw POST body) or dict (JSON body). Returns
    (status, body_bytes) or None."""
    h = _prep(headers)
    body = data
    if isinstance(data, dict):
        body = _json.dumps(data).encode("utf-8")
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, _decode(resp.read(), resp.headers)
    except Exception:
        return None


def request_status(url, headers=None, data=None, timeout=12, method=None):
    """Like request(), but NEVER collapses an HTTP error to None:
    returns (status, body_bytes) for any HTTP answer — 4xx/5xx
    included — and (0, None) only when no HTTP answer arrived at all
    (DNS / refused / TLS / timeout). stagelog rides on this so the
    diary can tell a refusal (403) from a dead path (0): the
    door-dead vs exit-window distinction the old contract erased."""
    h = _prep(headers)
    body = data
    if isinstance(data, dict):
        body = _json.dumps(data).encode("utf-8")
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, _decode(resp.read(), resp.headers)
    except urllib.error.HTTPError as e:
        try:
            return e.code, _decode(e.read(), e.headers)
        except Exception:
            return e.code, b""
    except Exception:
        return 0, None


def get(url, headers=None, timeout=12):
    r = request(url, headers=headers, timeout=timeout)
    return r[1] if r else None


def get_json(url, headers=None, timeout=12):
    raw = get(url, headers=headers, timeout=timeout)
    if raw is None:
        return None
    try:
        return _json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def post(url, headers=None, data=None, timeout=12):
    r = request(url, headers=headers, data=data, timeout=timeout)
    return r[1] if r else None


def post_json(url, headers=None, data=None, timeout=12):
    raw = post(url, headers=headers, data=data, timeout=timeout)
    if raw is None:
        return None
    try:
        return _json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def head_ok(url, headers=None, timeout=8):
    """Cheap liveness probe for a resolved stream URL: True when the
    host answers 2xx/3xx/405 to HEAD or a 1-byte range GET."""
    h = {"User-Agent": UA}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h, method="HEAD")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 400
    except urllib.error.HTTPError as e:
        if e.code in (403, 405, 416):
            # host is alive; HEAD is just refused — try a 1-byte GET
            h["Range"] = "bytes=0-0"
            req = urllib.request.Request(url, headers=h)
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    return 200 <= resp.status < 400
            except Exception:
                return False
        return False
    except Exception:
        return False
