# -*- coding: utf-8 -*-
"""
Pure-Python AES (FIPS-197) — encrypt + decrypt, CBC mode, PKCS#7.

WHY THIS EXISTS: the Roc playback wells (VidZee, 111movies) protect
their stream URLs with AES-CBC. Kodi's addon ecosystem gives us no
pycryptodome (verified: no Crypto/Cryptodome package anywhere in the
staged build tree), and adding a binary dependency for a 1 GB RAM
floor device is the wrong trade. Payloads here are ~100 bytes, so a
pure-Python AES costs microseconds of real time and zero deps.

Correctness is NOT assumed: test_aes.py in this folder checks the
FIPS-197 Appendix C AES-128/192/256 vectors, the NIST SP 800-38A
CBC vector, and a random round-trip cross-checked against openssl.
"""
# ---------------------------------------------------------------- S-box
def _make_sboxes():
    # Generate the AES S-box algorithmically (GF(2^8) inverse + affine
    # transform) so there is no 512-entry table to mistype.
    p = q = 1
    sbox = [0] * 256
    while True:
        # multiply p by 3
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        # divide q by 3
        q ^= (q << 1) & 0xFF
        q ^= (q << 2) & 0xFF
        q ^= (q << 4) & 0xFF
        q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        q &= 0xFF
        # affine transform of the inverse (q now holds p^-1)
        x = q
        s = q
        for _ in range(4):
            x = ((x << 1) | (x >> 7)) & 0xFF
            s ^= x
        sbox[p] = (s ^ 0x63) & 0xFF
        if p == 1:
            break
    sbox[0] = 0x63
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return sbox, inv


_SBOX, _INV_SBOX = _make_sboxes()

_RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36,
         0x6C, 0xD8, 0xAB, 0x4D]


def _gmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = ((a << 1) ^ (0x1B if a & 0x80 else 0)) & 0xFF
        b >>= 1
    return r


def _expand_key(key):
    """key: 16/24/32 bytes -> list of round keys (list of 16-byte lists)."""
    nk = len(key) // 4
    nr = nk + 6
    w = [list(key[4 * i:4 * i + 4]) for i in range(nk)]
    for i in range(nk, 4 * (nr + 1)):
        temp = list(w[i - 1])
        if i % nk == 0:
            temp = temp[1:] + temp[:1]              # RotWord
            temp = [_SBOX[b] for b in temp]         # SubWord
            temp[0] ^= _RCON[i // nk - 1]
        elif nk > 6 and i % nk == 4:
            temp = [_SBOX[b] for b in temp]
        w.append([w[i - nk][j] ^ temp[j] for j in range(4)])
    round_keys = []
    for r in range(nr + 1):
        rk = []
        for c in range(4):
            rk.extend(w[4 * r + c])
        round_keys.append(rk)
    return round_keys, nr


def _sub_bytes(s, box):
    return [box[b] for b in s]


def _shift_rows(s):
    # state is column-major: s[4*c + r]
    out = [0] * 16
    for r in range(4):
        for c in range(4):
            out[4 * c + r] = s[4 * ((c + r) % 4) + r]
    return out


def _inv_shift_rows(s):
    out = [0] * 16
    for r in range(4):
        for c in range(4):
            out[4 * c + r] = s[4 * ((c - r) % 4) + r]
    return out


def _mix_columns(s):
    out = [0] * 16
    for c in range(4):
        a = s[4 * c:4 * c + 4]
        out[4 * c + 0] = _gmul(a[0], 2) ^ _gmul(a[1], 3) ^ a[2] ^ a[3]
        out[4 * c + 1] = a[0] ^ _gmul(a[1], 2) ^ _gmul(a[2], 3) ^ a[3]
        out[4 * c + 2] = a[0] ^ a[1] ^ _gmul(a[2], 2) ^ _gmul(a[3], 3)
        out[4 * c + 3] = _gmul(a[0], 3) ^ a[1] ^ a[2] ^ _gmul(a[3], 2)
    return out


def _inv_mix_columns(s):
    out = [0] * 16
    for c in range(4):
        a = s[4 * c:4 * c + 4]
        out[4 * c + 0] = _gmul(a[0], 14) ^ _gmul(a[1], 11) ^ _gmul(a[2], 13) ^ _gmul(a[3], 9)
        out[4 * c + 1] = _gmul(a[0], 9) ^ _gmul(a[1], 14) ^ _gmul(a[2], 11) ^ _gmul(a[3], 13)
        out[4 * c + 2] = _gmul(a[0], 13) ^ _gmul(a[1], 9) ^ _gmul(a[2], 14) ^ _gmul(a[3], 11)
        out[4 * c + 3] = _gmul(a[0], 11) ^ _gmul(a[1], 13) ^ _gmul(a[2], 9) ^ _gmul(a[3], 14)
    return out


def _add_rk(s, rk):
    return [b ^ k for b, k in zip(s, rk)]


def encrypt_block(key, block):
    """block: exactly 16 bytes. Returns 16 bytes."""
    rk, nr = _expand_key(key)
    s = _add_rk(list(block), rk[0])
    for rnd in range(1, nr):
        s = _sub_bytes(s, _SBOX)
        s = _shift_rows(s)
        s = _mix_columns(s)
        s = _add_rk(s, rk[rnd])
    s = _sub_bytes(s, _SBOX)
    s = _shift_rows(s)
    s = _add_rk(s, rk[nr])
    return bytes(s)


def decrypt_block(key, block):
    rk, nr = _expand_key(key)
    s = _add_rk(list(block), rk[nr])
    for rnd in range(nr - 1, 0, -1):
        s = _inv_shift_rows(s)
        s = _sub_bytes(s, _INV_SBOX)
        s = _add_rk(s, rk[rnd])
        s = _inv_mix_columns(s)
    s = _inv_shift_rows(s)
    s = _sub_bytes(s, _INV_SBOX)
    s = _add_rk(s, rk[0])
    return bytes(s)


# ---------------------------------------------------------------- CBC
def cbc_encrypt(key, iv, data, pad=True):
    if pad:
        n = 16 - (len(data) % 16)
        data = data + bytes([n]) * n
    out = b""
    prev = bytes(iv)
    for i in range(0, len(data), 16):
        blk = bytes(a ^ b for a, b in zip(data[i:i + 16], prev))
        prev = encrypt_block(key, blk)
        out += prev
    return out


def cbc_decrypt(key, iv, data, unpad=True):
    out = b""
    prev = bytes(iv)
    for i in range(0, len(data), 16):
        blk = data[i:i + 16]
        dec = decrypt_block(key, blk)
        out += bytes(a ^ b for a, b in zip(dec, prev))
        prev = blk
    if unpad:
        if not out:
            raise ValueError("empty plaintext")
        n = out[-1]
        if n < 1 or n > 16 or out[-n:] != bytes([n]) * n:
            raise ValueError("bad PKCS7 padding")
        out = out[:-n]
    return out
