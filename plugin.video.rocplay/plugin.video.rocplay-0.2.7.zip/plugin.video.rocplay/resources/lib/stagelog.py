# -*- coding: utf-8 -*-
"""
stagelog — per-stage observability for Roc Play wells (Door Doctrine
build, 2026-11-02).

Every well reports each hop it makes (stage name, HTTP status, response
shape, elapsed ms) as a `well_stage` flight-recorder event, so the diary
never again collapses a failure to a bare 0 — the hole rohttp's
None-on-any-failure contract used to leave.

Stages also feed a per-well evidence registry that wellcore reads to
classify the outcome: a well whose hops all got HTTP answers but
produced no sources is "answered_zero" (the door is alive; the shelf
was empty on this exit — the exit-window signature) while a well with
transport failures (status 0 = DNS/refused/TLS/timeout) is "no_answer"
(the door or the path is in trouble). Door-dead vs exit-window-shut is
the distinction the doctrine demands, and it is only honest when it is
classified from the hops themselves.

The sink is WellCore.event, bound by WellCore.fanout per play. With no
sink bound (CLI harness), stages still land in the registry.

Stdlib only, flat module (house style: resources/lib on sys.path).
"""
import json
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rohttp

_local = threading.local()
_sink = None
_lock = threading.Lock()
_registry = {}  # well NAME -> {"transport": bool, "answered": bool, "stages": [...]}


def set_sink(fn):
    """fn(kind, **fields) — WellCore.event fits this shape."""
    global _sink
    _sink = fn


def begin(well_name):
    _local.ctx = {"well": well_name, "t0": time.time()}
    with _lock:
        _registry[well_name] = {"transport": False, "answered": False,
                                "stages": []}


def shape_of(text):
    """Short, diary-safe description of a response body."""
    if text is None:
        return "none"
    if isinstance(text, bytes):
        text = text[:400].decode("utf-8", "replace")
    t = text.strip()
    if not t:
        return "empty"
    if t.startswith("#EXTM3U"):
        return "m3u8"
    if t[0] in "[{":
        try:
            obj = json.loads(t)
            if isinstance(obj, dict):
                return "json{" + ",".join(sorted(obj.keys())[:8]) + "}"
            if isinstance(obj, list):
                return "json-array(%d)" % len(obj)
        except Exception:
            pass
    low = t[:200].lower()
    if "<html" in low or "<!doctype" in low:
        return "html"
    return "text"


def stage(name, **fields):
    ctx = getattr(_local, "ctx", None)
    if ctx is None:
        return
    well = ctx["well"]
    if "http" in fields:
        with _lock:
            reg = _registry.setdefault(
                well, {"transport": False, "answered": False, "stages": []})
            if fields["http"]:
                reg["answered"] = True
            else:
                reg["transport"] = True
    rec = {"stage": name,
           "ms": int((time.time() - ctx["t0"]) * 1000)}
    rec.update(fields)
    with _lock:
        reg = _registry.setdefault(
            well, {"transport": False, "answered": False, "stages": []})
        if len(reg["stages"]) < 60:
            reg["stages"].append(rec)
    if _sink is not None:
        try:
            _sink("well_stage", well=well, **rec)
        except Exception:
            pass


def stages_for(well_name):
    with _lock:
        reg = _registry.get(well_name) or {}
        return list(reg.get("stages") or [])


def evidence(well_name):
    """'transport' if any hop failed to connect, 'answered' if hops got
    HTTP answers, 'none' if the well made no logged hop."""
    with _lock:
        reg = _registry.get(well_name) or {}
    if reg.get("transport"):
        return "transport"
    if reg.get("answered"):
        return "answered"
    return "none"


def http(name, url, headers=None, timeout=12, data=None):
    """One HTTP hop with stage logging. Returns (status:int, text|None).

    status 0 = transport failure (rohttp returned None) — the
    distinction the old get()/get_json() erased.

    BRIDGE B1 (2026-11-12): the transport-0 one-retry rule lives here
    now, in the shared path every well funnels through — one retry on
    status 0 only (a real 4xx/5xx is an answer and is never re-asked),
    1 s sleep, logged as stage "hop_retry". This generalises the rule
    Movy (verify), VidZee (query+verify) and VidSrc (per-hop _hop)
    each hand-rolled separately; those wells inherit it from here, so
    their per-well copies are redundant. Movy's persistent-connection
    exit-pinning stays in movy.py (it does not use this path) — the
    generalised part is the retry rule, not the tunnel.
    """
    t0 = time.time()
    status, raw = rohttp.request_status(url, headers=headers, data=data,
                                        timeout=timeout)
    if status == 0:
        stage("hop_retry", hop=name)
        time.sleep(1.0)
        status, raw = rohttp.request_status(url, headers=headers, data=data,
                                            timeout=timeout)
    text = None
    if raw:
        try:
            text = raw.decode("utf-8", "replace")
        except Exception:
            text = None
    stage(name, http=status, ms_hop=int((time.time() - t0) * 1000),
          shape=shape_of(text), bytes=(len(raw) if raw else 0))
    return status, text
