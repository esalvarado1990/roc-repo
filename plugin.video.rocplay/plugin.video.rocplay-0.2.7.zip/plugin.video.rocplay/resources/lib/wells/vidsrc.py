# -*- coding: utf-8 -*-
"""
Well: VidSrc — RESERVE door; the full current token chain
(Door Doctrine build, 2026-11-02).

The chain was re-derived live from the site's own player code on
2026-11-02 and proven end-to-end on the Dell (two complete runs,
segment bytes SHA-256-identical). The old borrowed recipes (vidsrc-dlp
0.9.1 / 0.14.4) are dead at stage 2 — vidsrc.to's iframe now lands on a
JS shell with no data-hash.

  1. GET vidsrc.to/embed/...                    -> iframe (rotating host)
  2. GET <shell host>/embed/...                 -> data-api attribute
     (HTML-escaped &amp; — unescape it or vs_src 403s)
  3. GET vs_src.php (the data-api URL)          -> {src: landing} —
     top-level in some rotations, {"data": {"src": ...}} in others
  4. GET landing page -> window.CFG {playerUrl}; GET playerUrl page
     (Referer must be the LANDING URL — the shell referer 403s)
     -> window.CONFIG {api, apiToken} (single-use JWT, IP-bound).
     Older rotation: CONFIG rides the landing page itself; both are
     handled.
  5. GET CONFIG.api (api.php?type=..&tmdb=..&stream_urls) with the
     token as &api_token=<jwt> (current player.js withApiToken) AND
     as the x-vs-token header (the 19:12 generation) — each backend
     reads its own.
     -> data.stream_urls: a plain list, OR a ChaCha20-encrypted string
        (base64 nonce||ciphertext) + vs:{wasm_url|wasm} naming the
        per-5-minute-window decryptor module
  6. GET <stream host>/generate.php (imdb params, tmdb fallback)
     -> per-host JWT (4 h, bound to the egress /64), appended as
     ?token= to the playlist URL

  FIX 2026-11-10 (generate 429 investigation): generate.php now
  REQUIRES the CONFIG apiToken as &api_token=<jwt> — without it
  the origin answers 403 "invalid or mismatched api token", and
  the well's rapid token-less retries then trip the stream host's
  nginx burst limit (429). The guard only records the LAST
  generate status per request, so the record showed "generate
  429" while the real first failure was the 403. Proven live from
  the house exit: imdb+api_token -> 200 + JWT, playlist verifies
  #EXTM3U. Attempts are now spaced 1.5 s with one 5 s retry on
  429, so a burst never forms (normally the first call succeeds).

  FIX 2026-11-12 (Turnstile gate + flaky-exit retries): the player
  now GATES untrusted exits — from datacenter egresses (this VM's
  proxy pool; the sticks' Proton NL exit, proven on lab .159
  2026-11-12 18:40 MST) window.CONFIG carries apiToken:"" plus
  turnstile:true, a turnstileSiteKey and an IP-bound gateTicket;
  the apiToken is minted only by POST /embed/verify.php after a
  browser solves Cloudflare Turnstile — no stdlib path exists and
  the ticket is bound to the solving exit's IP, so a solve cannot
  be transplanted to another device. Residential house exit is
  NOT gated (full chain proven from the Dell the same night:
  movie 2 + TV 3 verified sources). The well now NAMES the gate
  (stage "gate") instead of dying as a generic player_parse
  failure. The one-retry-on-transport-0 rule for the idempotent
  hops now lives in the SHARED transport (stagelog.http, Bridge
  B1, bundle 0.2.7) — flaky exits (the VM proxy pool truncates
  chunked bodies mid-transfer at random hops) kept killing the
  chain before it could even reach the gate, and every well
  inherits the retry from there; this well carries no copy.
  Companion change in rohttp (same date): requests now pin
  Accept-Encoding: gzip and decompress transparently — the
  identity chunked bodies were the worst-truncated shape on the
  proxy path. Verified from both exits before promotion (VM:
  gate reached and named; house: 2 + 3 sources, no regression).

The step-5 decrypt hop is SOLVED in pure Python: the window WASM
(6,986 bytes) was decompiled (wabt wasm-decompile); its block function
is textbook ChaCha20 whose 8 key words are stored as the XOR of two
data-segment shares (key_word[i] = shareA[i] ^ shareB[i]).
extract_key() parses the fetched module's data segments and tries
each 32-byte segment alone, then every equal-length pair XORed,
verifying against the real blob (plaintext must start with "http").
Verified against tonight's captured window: segment@0 ^ segment@768,
counter 0 — plaintext identical to the site's own Node decryptor.
No interpreter, no Node, nothing bundled but this file.

Reserve tier: tokens are single-use and IP-bound, so this chain runs
only when the front doors total zero — fresh, from this device's own
exit, in one session.
"""
import base64
import html as _html
import json
import os
import re
import struct
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import rohttp as _http
import stagelog

NAME = "VidSrc"
TO = "https://vidsrc.to"
API_HOST = "https://data.vidsrc.sh"
UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}
JWT_RE = re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")


def _height(quality):
    if quality is None:
        return None
    if isinstance(quality, int):
        return quality
    digits = "".join(ch for ch in str(quality) if ch.isdigit())
    return int(digits) if digits else None


# ---------------------------------------------------------------- ChaCha20

def _rotl(v, c):
    return ((v << c) | (v >> (32 - c))) & 0xFFFFFFFF


def _qr(st, a, b, c, d):
    st[a] = (st[a] + st[b]) & 0xFFFFFFFF
    st[d] = _rotl(st[d] ^ st[a], 16)
    st[c] = (st[c] + st[d]) & 0xFFFFFFFF
    st[b] = _rotl(st[b] ^ st[c], 12)
    st[a] = (st[a] + st[b]) & 0xFFFFFFFF
    st[d] = _rotl(st[d] ^ st[a], 8)
    st[c] = (st[c] + st[d]) & 0xFFFFFFFF
    st[b] = _rotl(st[b] ^ st[c], 7)


def _chacha_block(key, counter, nonce):
    state = (list(struct.unpack("<4I", b"expand 32-byte k"))
             + list(struct.unpack("<8I", key))
             + [counter] + list(struct.unpack("<3I", nonce)))
    work = state[:]
    for _ in range(10):
        _qr(work, 0, 4, 8, 12)
        _qr(work, 1, 5, 9, 13)
        _qr(work, 2, 6, 10, 14)
        _qr(work, 3, 7, 11, 15)
        _qr(work, 0, 5, 10, 15)
        _qr(work, 1, 6, 11, 12)
        _qr(work, 2, 7, 8, 13)
        _qr(work, 3, 4, 9, 14)
    return struct.pack("<16I", *[(work[i] + state[i]) & 0xFFFFFFFF
                                 for i in range(16)])


def chacha20(key, nonce, data, counter0=0):
    out = bytearray()
    counter = counter0
    for off in range(0, len(data), 64):
        ks = _chacha_block(key, counter, nonce)
        counter += 1
        chunk = data[off:off + 64]
        out.extend(bytes(a ^ b for a, b in zip(chunk, ks)))
    return bytes(out)


# ------------------------------------------------------- WASM key extraction

def _uleb(buf, p):
    r = s = 0
    while True:
        b = buf[p]
        p += 1
        r |= (b & 0x7F) << s
        s += 7
        if not (b & 0x80):
            return r, p


def wasm_data_segments(buf):
    """[(offset, bytes)] for the active data segments of a wasm module."""
    if buf[:4] != b"\x00asm":
        return []
    segs = []
    pos = 8
    while pos < len(buf):
        sec = buf[pos]
        pos += 1
        size, pos = _uleb(buf, pos)
        end = pos + size
        if sec == 11:
            n, p = _uleb(buf, pos)
            for _ in range(n):
                flag, p = _uleb(buf, p)
                if flag in (0, 2):
                    if flag == 2:
                        _, p = _uleb(buf, p)  # memory index
                    if buf[p] != 0x41:  # i32.const
                        break
                    p += 1
                    off = 0
                    sh = 0
                    while True:
                        b = buf[p]
                        p += 1
                        off |= (b & 0x7F) << sh
                        sh += 7
                        if not (b & 0x80):
                            break
                    if buf[p] != 0x0B:  # end of offset expr
                        break
                    p += 1
                    ln, p = _uleb(buf, p)
                    segs.append((off, buf[p:p + ln]))
                    p += ln
                else:  # passive segment: skip its bytes
                    ln, p = _uleb(buf, p)
                    p += ln
        pos = end
    return segs


def extract_key(wasm_bytes, blob):
    """Find the window key: each 32-byte segment alone, then every pair
    XORed. Returns (key, how) or (None, why). A candidate counts only
    when it opens the real blob to a URL."""
    nonce, ct = blob[:12], blob[12:]
    segs = [(off, d) for off, d in wasm_data_segments(wasm_bytes)
            if len(d) >= 32]

    def works(key):
        return chacha20(key, nonce, ct[:16]).startswith(b"http")

    for off, d in segs:
        if works(d[:32]):
            return d[:32], "single@%d" % off
    for i in range(len(segs)):
        for j in range(i + 1, len(segs)):
            (o1, d1), (o2, d2) = segs[i], segs[j]
            key = bytes(a ^ b for a, b in zip(d1[:32], d2[:32]))
            if works(key):
                return key, "pair@%d^%d" % (o1, o2)
    return None, "no_candidate"


def decrypt_stream_urls(wasm_bytes, b64_blob):
    blob = base64.b64decode(b64_blob)
    key, how = extract_key(wasm_bytes, blob)
    if key is None:
        stagelog.stage("decrypt", ok=False, why=how)
        return []
    pt = chacha20(key, blob[:12], blob[12:])
    stagelog.stage("decrypt", ok=True, method=how)
    return [ln.strip() for ln in pt.decode("utf-8", "replace").split("\n")
            if ln.strip()]


# ------------------------------------------------------------------- chain

def _referer(url):
    parts = urllib.parse.urlsplit(url)
    return "%s://%s/" % (parts.scheme, parts.netloc)


def _extract_config(text):
    m = re.search(r"window\.CONFIG\s*=\s*(\{.*?\});", text, re.S)
    if not m:
        return None
    try:
        obj = json.loads(m.group(1))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def fetch(req):
    tmdb = req.get("tmdb_id")
    imdb = req.get("imdb")
    if not tmdb:
        stagelog.stage("skip", reason="no_tmdb")
        return []
    # The current chain keys on TMDB (embed + CONFIG.api); IMDb
    # survives only as a generate.php parameter candidate.
    season = req.get("season") or 1
    episode = req.get("episode") or 1
    gen_qs = []
    if req.get("tmdb_type") == "tv":
        embed_url = "%s/embed/tv/%s/%s/%s" % (TO, tmdb, season, episode)
        api_q = {"type": "tv", "tmdb": tmdb, "season": season,
                 "episode": episode}
        if imdb:
            gen_qs.append({"imdb": imdb, "season": season,
                           "episode": episode})
        gen_qs.append({"tmdb": tmdb, "season": season,
                       "episode": episode})
    else:
        embed_url = "%s/embed/movie/%s" % (TO, tmdb)
        api_q = {"type": "movie", "tmdb": tmdb}
        if imdb:
            gen_qs.append({"imdb": imdb})
        gen_qs.append({"tmdb": tmdb})

    status, text = stagelog.http("embed", embed_url, headers=dict(
        HEADERS, Referer=TO + "/"), timeout=12)
    if status != 200 or not text:
        return []
    m = re.search(r'<iframe[^>]+src="([^"]+)"', text)
    if not m:
        stagelog.stage("embed_parse", ok=False)
        return []
    shell_url = urllib.parse.urljoin(embed_url, _html.unescape(m.group(1)))

    status, text = stagelog.http("shell", shell_url, headers=dict(
        HEADERS, Referer=TO + "/"), timeout=12)
    if status != 200 or not text:
        return []
    m = re.search(r'data-api="([^"]+)"', text)
    if not m:
        stagelog.stage("shell_parse", ok=False)
        return []
    # The shell page HTML-escapes the attribute (&amp;) — unescape it
    # or the server sees a parameter literally named "amp;id" and 403s.
    vs_src_url = urllib.parse.urljoin(shell_url, _html.unescape(m.group(1)))

    status, text = stagelog.http("vs_src", vs_src_url, headers=dict(
        HEADERS, Referer=_referer(shell_url)), timeout=12)
    if status != 200 or not text:
        return []
    # The answer's shape rotates with the host: {"src": ...} at the
    # top level in some rotations, {"data": {"src": ...}} in others
    # (both observed live 2026-11-02). Accept either.
    try:
        obj = json.loads(text)
        src = None
        extra_headers = {}
        if isinstance(obj, dict):
            if isinstance(obj.get("src"), str):
                src = obj["src"]
                extra_headers = obj.get("headers") or {}
            elif isinstance(obj.get("data"), dict):
                src = obj["data"].get("src")
                extra_headers = obj["data"].get("headers") or {}
        if not isinstance(src, str) or not src:
            raise ValueError("no src")
    except Exception:
        stagelog.stage("vs_src_parse", ok=False,
                       shape=stagelog.shape_of(text))
        return []
    landing_url = src if src.startswith("http") else "https:" + src
    player_headers = dict(HEADERS, Referer=_referer(shell_url))
    if isinstance(extra_headers, dict):
        for k, v in extra_headers.items():
            if isinstance(v, str):
                player_headers[k] = v

    status, text = stagelog.http("landing", landing_url,
                                 headers=player_headers, timeout=12)
    if status != 200 or not text:
        return []
    # Two player generations, both live in the host rotation:
    #  A) the landing page IS the player: window.CONFIG carries
    #     apiToken + the ready-made api URL (api.php?...&stream_urls).
    #  B) the landing page carries window.CFG {playerUrl, metaApi} and
    #     the CONFIG lives one hop deeper, on the playerUrl page.
    #     (Generation B is what the rotation serves tonight; A is the
    #     shape the 19:12 proof ran against.)
    cfg = _extract_config(text)
    player_url = landing_url
    if not (cfg and cfg.get("apiToken")):
        m = re.search(r'"playerUrl"\s*:\s*"([^"]+)"', text)
        if m:
            player_url = urllib.parse.urljoin(
                landing_url, m.group(1).replace("\\/", "/"))
            # The player frame is iframed BY the landing page: with
            # the shell page as Referer this hop answers 403; with
            # the landing URL as Referer it answers 200 (both
            # observed live 2026-11-02).
            status, text = stagelog.http(
                "player", player_url,
                headers=dict(player_headers, Referer=landing_url),
                timeout=12)
            if status != 200 or not text:
                return []
            cfg = _extract_config(text)
    if not cfg or not cfg.get("apiToken"):
        # 2026-11-12: untrusted exits are GATED — CONFIG carries
        # apiToken:"" + turnstile:true + an IP-bound gateTicket,
        # and the token is minted only after a browser solves
        # Cloudflare Turnstile (POST /embed/verify.php). Name it
        # honestly instead of a generic parse failure: the door is
        # alive, this exit is being challenged. Detection also
        # scans the raw page — a gated CONFIG whose JSON shape
        # shifts must not fall back to looking like a parse error.
        gated = bool(cfg and (cfg.get("gateTicket")
                              or cfg.get("turnstile"))) or \
            ("gateTicket" in text and "turnstile" in text)
        if gated:
            stagelog.stage("gate", gated=True,
                           turnstile=bool(cfg and cfg.get("turnstile")),
                           verify=(cfg or {}).get("turnstileVerify"))
        else:
            stagelog.stage("player_parse", ok=False,
                           why="no_apiToken")
        return []
    token = cfg["apiToken"]
    stagelog.stage("token", got=True)
    api_url = cfg.get("api")
    if not (isinstance(api_url, str) and api_url.startswith("http")):
        api_url = API_HOST + "/api.php?" + \
            urllib.parse.urlencode(api_q) + "&stream_urls"

    # The token's presentation rotates with the generation: the
    # 19:12 chain took it as the x-vs-token header; the current
    # player.js (withApiToken) appends it as &api_token=<jwt>. Send
    # both — each backend reads its own and ignores the other.
    api_url_full = api_url + ("&" if "?" in api_url else "?") + \
        "api_token=" + token
    status, text = stagelog.http("api", api_url_full, headers=dict(
        HEADERS, Referer=_referer(player_url), **{"x-vs-token": token}),
        timeout=15)
    if status != 200 or not text:
        return []
    try:
        payload = json.loads(text)
    except Exception:
        stagelog.stage("api_parse", ok=False)
        return []
    data = payload.get("data") or {}
    stream_urls = data.get("stream_urls")
    if isinstance(stream_urls, str):
        vs = payload.get("vs") or {}
        wasm_bytes = None
        if vs.get("wasm_url"):
            res = _http.request(vs["wasm_url"], headers=HEADERS,
                                timeout=12)
            wstatus, wraw = res if res else (0, None)
            stagelog.stage("wasm", http=wstatus,
                           bytes=(len(wraw) if wraw else 0))
            wasm_bytes = wraw
        elif vs.get("wasm"):
            try:
                wasm_bytes = base64.b64decode(vs["wasm"])
                stagelog.stage("wasm", inline=True, bytes=len(wasm_bytes))
            except Exception:
                wasm_bytes = None
        if not wasm_bytes:
            stagelog.stage("decrypt", ok=False, why="no_wasm")
            return []
        stream_urls = decrypt_stream_urls(wasm_bytes, stream_urls)
    if not isinstance(stream_urls, list) or not stream_urls:
        stagelog.stage("api_parse", ok=False, why="no_stream_urls")
        return []
    stagelog.stage("urls", count=len(stream_urls))

    quality = _height(data.get("quality"))
    sources = []
    for url in stream_urls[:3]:
        host = urllib.parse.urlsplit(url).netloc
        jwt = None
        for gq in gen_qs:
            # 2026-11-10 FIX: generate.php requires the CONFIG
            # apiToken as &api_token=<jwt> — without it the origin
            # answers 403 "invalid or mismatched api token". Rapid
            # token-less retries then trip the stream host's nginx
            # burst limit (429). Space attempts and retry a 429
            # once after a pause; normally the first call succeeds.
            gq = dict(gq, api_token=token)
            gurl = "https://%s/generate.php?%s" % (
                host, urllib.parse.urlencode(gq))
            gheaders = dict(HEADERS, Referer="https://%s/" % host)
            gstatus, gtext = stagelog.http(
                "generate", gurl, headers=gheaders, timeout=12)
            if gstatus == 429:
                time.sleep(5)
                gstatus, gtext = stagelog.http(
                    "generate", gurl, headers=gheaders, timeout=12)
            cand = (gtext or "").strip()
            if gstatus == 200 and cand.count(".") == 2 and \
                    cand.startswith("eyJ"):
                jwt = cand
                break
            stagelog.stage("generate", ok=False, host=host,
                           params=sorted(gq.keys()))
            time.sleep(1.5)
        if not jwt:
            continue
        final = url + ("&" if "?" in url else "?") + "token=" + jwt
        vstatus, vtext = stagelog.http(
            "verify", final,
            headers=dict(HEADERS, Referer="https://%s/" % host),
            timeout=12)
        if vstatus in (200, 206) and vtext and \
                vtext.lstrip().startswith("#EXTM3U"):
            sources.append({"well": NAME, "label": NAME, "url": final,
                            "quality": quality,
                            "headers": {"Referer": "https://%s/" % host,
                                        "User-Agent": UA}})
        else:
            stagelog.stage("verify", ok=False, host=host)
    stagelog.stage("done", found=len(sources))
    return sources
