# -*- coding: utf-8 -*-
"""
Well: VixSrc (vixsrc.to) — recipe PROVEN end-to-end from Eric's
house (Dell, residential egress) 2026-10-26: API -> embed page ->
master playlist (200, real variants) -> variant playlist (200,
1,938 segments) -> segment bytes (206). Movie AND TV.

The site's own player script (vix.js) is the ground truth for the
playlist URL, and it is NOT the bare masterPlaylist.url + params:
the player appends every NON-EMPTY masterPlaylist param, then
h=1, then lang=<the embed page's own lang query param, default
'en'> (and cdn=<...> when the embed URL carries one). The previous
recipe urlencoded ALL params (including the empty asn) and never
appended h/lang — the playlist endpoint answered 403 to every
such request, which is why this well ran dry while its API and
embed hops looked healthy.

Verified flow (observed responses, trunk welldiag 2026-10-26):
  GET https://vixsrc.to/api/movie/<tmdb>
  GET https://vixsrc.to/api/tv/<tmdb>/<season>/<episode>
    -> {"src": "/embed/<id>?token=...&expires=...&lang=en&..."}
  GET https://vixsrc.to<src>                       (the embed page)
    -> JS carrying:
         window.masterPlaylist = { params: {'token': ...,
             'expires': ..., 'asn': ''},
             url: 'https://vixsrc.to/playlist/<id>' }
  Playlist URL = url + non-empty params + h=1 + lang=<lang>
  The candidate is content-sniffed (#EXTM3U) before it is
  returned. If the site changes shape, every step fails soft
  and the well reports dry.
"""
import json
import os
import re
import sys
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import rohttp as _http
import stagelog

# Door Doctrine (2026-11-02): VixSrc is the DECOY door — the famous
# front door. A real, working well (the fleet's only producer before
# this build) that also takes the heat/attention/rate-limits. Its
# hops are stage-logged like every other door's.
NAME = "VixSrc"
_BASE = "https://vixsrc.to"
_STREAMS_RE = re.compile(r"window\.streams\s*=\s*(\[.*?\]);", re.S)
_MASTER_RE = re.compile(
    r"masterPlaylist\s*=\s*\{\s*params:\s*\{(.*?)\}\s*,?\s*url:\s*'([^']+)'",
    re.S)
_PARAM_RE = re.compile(r"'([^']+)'\s*:\s*'([^']*)'")


def _is_playlist(url, headers):
    status, text = stagelog.http("variant", url, headers=headers,
                                 timeout=8)
    return bool(text) and text.lstrip().startswith("#EXTM3U")


# Rendition cap (2026-10-27, gate round 4). The master playlist's
# top rendition (1080p, labelled 4.5 Mbps) is delivered by the CDN
# edge at only ~3.6-3.8 Mbps from this house (curl-measured,
# diag5), and Kodi's player opens the top rendition's video
# stream: the stream opens, a couple of seconds decode, then the
# buffer starves ("OutputPicture - timeout waiting for buffer")
# and the try dies at the full start window -- five stalls in a
# row across the round 3/4 batteries while curl pulled the lower
# renditions at multiples of realtime. So when a candidate is a
# master playlist, hand the player the best rendition whose
# labelled bitrate stays under the cap instead of the master.
RENDITION_CAP_BPS = 2500000


def _get_body(url, headers):
    status, text = stagelog.http("playlist", url, headers=headers,
                                 timeout=8)
    if not text or not text.lstrip().startswith("#EXTM3U"):
        return None
    return text


def _pick_rendition(master_url, body, headers):
    """(label, url, height) of the best under-cap variant of a
    master playlist, or None when the body is not a master, no
    variant fits the cap, or no variant verifies as a playlist."""
    if "#EXT-X-STREAM-INF" not in body:
        return None
    lines = body.splitlines()
    variants = []
    for i, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF"):
            continue
        bw = 0
        height = 0
        attrs = line.split(":", 1)[1] if ":" in line else ""
        for part in attrs.split(","):
            part = part.strip()
            try:
                if part.startswith("BANDWIDTH="):
                    bw = int(part.split("=", 1)[1])
                elif part.startswith("RESOLUTION="):
                    height = int(part.split("=", 1)[1].split("x")[-1])
            except ValueError:
                pass
        if bw and i + 1 < len(lines) and lines[i + 1].strip():
            variants.append((bw, height,
                             urllib.parse.urljoin(master_url,
                                                  lines[i + 1].strip())))
    variants.sort(key=lambda v: v[0], reverse=True)
    for bw, height, vurl in variants:
        if bw > RENDITION_CAP_BPS:
            continue
        if _is_playlist(vurl, headers):
            label = ("%s \u00b7 %dp" % (NAME, height)) if height else NAME
            return label, vurl, height
    return None


def fetch(req):
    tmdb = req.get("tmdb_id")
    if not tmdb:
        return []
    if req.get("tmdb_type") == "tv":
        if req.get("season") is None or req.get("episode") is None:
            return []
        api = "%s/api/tv/%s/%s/%s" % (_BASE, tmdb, req["season"], req["episode"])
    else:
        api = "%s/api/movie/%s" % (_BASE, tmdb)
    headers = {"Referer": _BASE + "/"}
    status, text = stagelog.http("api", api, headers=headers, timeout=10)
    try:
        data = json.loads(text) if text else None
    except Exception:
        data = None
    if not data or not data.get("src"):
        return []
    src = data["src"].replace("\\/", "/")
    if src.startswith("/"):
        src = _BASE + src
    status, html = stagelog.http("embed", src, headers=headers,
                                 timeout=10)
    if not html:
        return []
    # The embed page is the player page: its own query params drive
    # the playlist construction (vix.js reads window.location.search).
    embed_q = urllib.parse.parse_qs(urllib.parse.urlparse(src).query)
    lang = (embed_q.get("lang") or ["en"])[0]
    play_headers = {"Referer": src, "User-Agent": _http.UA}
    candidates = []
    m = _MASTER_RE.search(html)
    if m:
        params = dict(_PARAM_RE.findall(m.group(1)))
        url = m.group(2).replace("\\/", "/")
        # vix.js, faithfully: append non-empty params in order,
        # then cdn (if the embed URL carries one), then h=1, then lang.
        q = [(k, v) for k, v in params.items() if v]
        if embed_q.get("cdn"):
            q.append(("cdn", embed_q["cdn"][0]))
        q.append(("h", "1"))
        q.append(("lang", lang))
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(q)
        candidates.append(("VixSrc", url))
    m = _STREAMS_RE.search(html)
    if m:
        try:
            for entry in json.loads(m.group(1)):
                if entry.get("url"):
                    candidates.append((entry.get("name") or "VixSrc",
                                       entry["url"].replace("\\/", "/")))
        except Exception:
            pass
    quality = 1080 if ("canPlayFHD" in src or "canPlayFHD" in html) else 0
    out = []
    for label, url in candidates:
        body = _get_body(url, play_headers)
        if body is None:
            continue
        pick = _pick_rendition(url, body, play_headers)
        if pick:
            vlabel, vurl, vheight = pick
            out.append({"well": NAME, "label": vlabel, "url": vurl,
                        "headers": dict(play_headers),
                        "quality": vheight or quality})
        else:
            out.append({"well": NAME, "label": label, "url": url,
                        "headers": dict(play_headers),
                        "quality": quality})
        break
    return out
