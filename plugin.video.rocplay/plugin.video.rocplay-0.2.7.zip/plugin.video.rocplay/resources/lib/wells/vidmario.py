# -*- coding: utf-8 -*-
"""
Well: VidMario — FRONT door (Door Doctrine build, 2026-11-02;
RECIPE FIX 2026-11-10, treatment lane — COPY, not production).

Re-derived 2026-11-10 from the site's own LIVE production bundles
(embed page serves assets/index-vmario24-ss1.js; streaming-link chunk
assets/c-vmario2-a3fe02f2b18d-vm5-vm9-vm17-obq1.js, function
fetchStreamingLink):

  movie: GET https://api.vidmario.net/movie?id=<tmdb>&mode=json[&sources=<sN>]
  tv:    GET https://api.vidmario.net/tv?id=<tmdb>&season=<s>&episode=<e>&mode=json[&sources=<sN>]
  servers (current order from /source-order?pv=2 + player fallback
  order): s1 Pythagoras, s4 Gauss, s2 Fermat, s3 Euler, s5 Riemann,
  s7 Hilbert (NEW — was absent from the Nov 2 recipe), s6 Fibonacci;
  no sources param = the service's "Best" pick.
  answer (CHANGED since Nov 2 — this is the fix):
    OLD (Nov 2): {url, manifest?, headers?, quality?} at top level.
    NOW: {meta, source, subtitles} where source is null OR
         {url, manifest?, headers?, qualities?[{quality,url,codec}], h?}
    The player reads j.source.url / j.source.manifest / j.source.headers
    and requires source.url to be an http(s) URL. The old well read
    obj["url"] at top level, which no longer exists — it could never
    return a source from the current API even if the backend answered.
  No auth/token: getApiRequestToken() in the live chunk returns "".
  Player's hevc/vh/sw params are FALLBACK re-asks only (Fermat
  vh/hevc rescue, service-worker sw=1); the primary query the player
  itself sends is the plain mode=json one below, so the well keeps it.

LIVE STATUS 2026-11-10: the API answers 200 everywhere but returns
{"meta":null,"source":null,"subtitles":[]} for EVERY title/server on
BOTH vantages (house + VM proxy) — 13 titles incl. Wicked,
Oppenheimer, John Wick 4, GoT S01E01, Stranger Things S01E01, F1,
plus all &hevc=1 / &vh=1 / &fk=0 / &sw=1 variants. Sibling endpoints
on the same host are alive (/source-order?pv=2 -> tier "busy";
/tmdb/3/movie/693134 -> full metadata; /subtitles/movie/693134 ->
real subtitle list), so this is the stream-resolution backend
returning nothing, NOT a transport/geo/title problem. This parser
fix is therefore necessary but NOT sufficient: it makes the well
correct for the current API shape so it will produce the moment the
backend returns a non-null source again; it cannot conjure streams
from source:null today.

Both-ways: a returned manifest containing #EXTM3U verifies the source
by itself; otherwise the URL is fetched and content-sniffed.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import stagelog

NAME = "VidMario"
API = "https://api.vidmario.net"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept": "application/json",
           "Referer": "https://player.vidmario.net/",
           "Origin": "https://player.vidmario.net"}
# Order = player's current fallback order (source-order?pv=2, 2026-11-10:
# ["s1","s4","s2","s3","s5","s7","s6"]); s7 Hilbert is new since Nov 2.
SERVERS = [(None, "Best"), ("s1", "Pythagoras"), ("s4", "Gauss"),
           ("s2", "Fermat"), ("s3", "Euler"), ("s5", "Riemann"),
           ("s7", "Hilbert"), ("s6", "Fibonacci")]


def _height(quality):
    if quality is None:
        return None
    if isinstance(quality, int):
        return quality
    digits = "".join(ch for ch in str(quality) if ch.isdigit())
    return int(digits) if digits else None


def _query_url(req, code):
    tmdb = req.get("tmdb_id")
    if req.get("tmdb_type") == "tv":
        url = "%s/tv?id=%s&season=%s&episode=%s&mode=json" % (
            API, tmdb, req.get("season") or 1, req.get("episode") or 1)
    else:
        url = "%s/movie?id=%s&mode=json" % (API, tmdb)
    if code:
        url += "&sources=" + code
    return url


def _extract(obj):
    """Current API shape: {meta, source:{url,manifest,headers,
    qualities,h}, subtitles}. Returns (link, manifest, headers,
    quality) or (None, ...) when source is null. Keeps a fallback to
    the Nov 2 top-level shape if the service ever reverts."""
    if not isinstance(obj, dict):
        return None, None, None, None
    src = obj.get("source")
    if isinstance(src, dict):
        link = src.get("url")
        manifest = src.get("manifest")
        headers = src.get("headers")
        quality = src.get("h")
        if quality is None:
            quals = src.get("qualities")
            if isinstance(quals, list) and quals:
                quality = quals[0].get("quality")
        return link, manifest, headers, quality
    # source:null = backend has nothing for this title/server.
    # Fall back to the old top-level shape, just in case.
    return obj.get("url"), obj.get("manifest"), obj.get("headers"), \
        obj.get("quality")


def fetch(req):
    if not req.get("tmdb_id"):
        stagelog.stage("skip", reason="no_tmdb")
        return []
    for code, name in SERVERS:
        tag = code or "best"
        status, text = stagelog.http("query:" + tag, _query_url(req, code),
                                     headers=HEADERS, timeout=10)
        if status != 200 or not text:
            continue
        try:
            obj = json.loads(text)
        except Exception:
            stagelog.stage("parse:" + tag, ok=False)
            continue
        if not isinstance(obj, dict):
            continue
        link, manifest, headers, quality = _extract(obj)
        if obj.get("source") is None and not link:
            # Current-shape null-source: backend empty for this server.
            stagelog.stage("parse:" + tag, ok=False, why="source_null")
            continue
        if not (isinstance(link, str) and link.startswith("http")):
            stagelog.stage("parse:" + tag, ok=False, why="no_url_field")
            continue
        if not isinstance(headers, dict) or not headers:
            headers = {"User-Agent": UA,
                       "Referer": "https://player.vidmario.net/"}
        if isinstance(manifest, str) and "#EXTM3U" in manifest:
            stagelog.stage("verify:" + tag, ok=True, via="manifest")
            return [{"well": NAME, "label": "VidMario - " + name,
                     "url": link, "quality": _height(quality),
                     "headers": headers}]
        vstatus, vtext = stagelog.http("verify:" + tag, link,
                                       headers=headers, timeout=10)
        if vstatus in (200, 206) and vtext and \
                vtext.lstrip().startswith("#EXTM3U"):
            return [{"well": NAME, "label": "VidMario - " + name,
                     "url": link, "quality": _height(quality),
                     "headers": headers}]
        stagelog.stage("verify:" + tag, ok=False)
    stagelog.stage("done", found=0)
    return []
