# rocplay wells — one module per provider site ("door").
# Every module exposes:  NAME, fetch(req) -> [source, ...]
# req:    {tmdb_id, tmdb_type ('movie'|'tv'), season, episode,
#          title, year, imdb}
# source: {well, label, url, headers, quality}  (quality = int height)
# A well returns [] when dry and NEVER raises (wellcore also guards).
#
# Door Doctrine tiers (2026-11-02, wellcore holds the lists):
#   FRONT:   vixsrc (decoy), movy, vidzee, vidmario
#   RESERVE: vidsrc, mp4hydra  (engaged only on a front total zero)
# Every hop is stage-logged via stagelog so the diary shows WHY a
# door answered dry — never a bare 0 again.
