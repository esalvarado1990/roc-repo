# -*- coding: utf-8 -*-
"""
Well: MP4Hydra — RESERVE door (Door Doctrine build, 2026-11-02).

Recipe from the maintained NuvioStreams provider
(providers/MP4Hydra.js, via its DeepWiki documentation): a clean
no-auth JSON API keyed by a title SLUG instead of an ID —

  POST https://mp4hydra.org/info2?v=8   (multipart/form-data)
    v = "8"
    z = [{"s": slug, "t": "movie"|"tv", "se": season, "ep": episode}]
  slug: lowercase title, non-word chars removed, spaces -> hyphens;
        movies append -<year>, TV does not.
  answer: {playlist: [{src, title, ...}], servers: {name: base-url}}
  stream URL = server base + item.src; servers used: Beta (#1),
  Beta#3 (#2). TV items are matched by an SxxExx marker in the title.

Wrong-title discipline (this door's known hazard): the slug is built
from the TMDB-verified title/year in the request, and any playlist
item carrying a title must share a word with the requested title
before its src is accepted. Item titles are logged either way.

Reserve tier: asked only when the front doors total zero.
Both-ways: every candidate gets a ranged fetch — an MP4 must answer
with an ftyp box, a playlist with #EXTM3U.
"""
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import rohttp as _http
import stagelog

NAME = "MP4Hydra"
API = "https://mp4hydra.org/info2?v=8"
UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
SERVERS = (("Beta", "#1"), ("Beta#3", "#2"))


def _slugify(title):
    t = re.sub(r"[^a-z0-9\s-]", "", (title or "").lower())
    t = re.sub(r"\s+", "-", t.strip())
    return re.sub(r"-{2,}", "-", t).strip("-")


def _height(quality):
    if quality is None:
        return None
    if isinstance(quality, int):
        return quality
    digits = "".join(ch for ch in str(quality) if ch.isdigit())
    return int(digits) if digits else None


def _multipart(fields):
    boundary = "----rocplay%d" % int(time.time() * 1000)
    parts = []
    for key, value in fields:
        parts.append("--%s\r\nContent-Disposition: form-data; "
                     "name=\"%s\"\r\n\r\n%s\r\n" % (boundary, key, value))
    body = ("".join(parts) + "--%s--\r\n" % boundary).encode("utf-8")
    return body, "multipart/form-data; boundary=" + boundary


def _verify(url, headers):
    res = _http.request(url, headers=dict(headers, Range="bytes=0-15"),
                        timeout=10)
    status, raw = res if res else (0, None)
    stagelog.stage("verify", http=status,
                   bytes=(len(raw) if raw else 0))
    if status not in (200, 206) or not raw:
        return False
    if raw.startswith(b"#EXTM3U"):
        return True
    return len(raw) >= 8 and raw[4:8] == b"ftyp"


def fetch(req):
    title = req.get("title") or ""
    slug = _slugify(title)
    if not slug:
        stagelog.stage("skip", reason="no_title")
        return []
    media_type = req.get("tmdb_type") or "movie"
    if media_type == "movie" and req.get("year"):
        slug = "%s-%s" % (slug, req["year"])
    item_req = {"s": slug, "t": media_type}
    if media_type == "tv":
        item_req["se"] = req.get("season") or 1
        item_req["ep"] = req.get("episode") or 1
    headers = {"User-Agent": UA,
               "Referer": "https://mp4hydra.org/%s/%s" % (media_type, slug)}
    body, ctype = _multipart([("v", "8"), ("z", json.dumps([item_req]))])
    res = _http.request(API, headers=dict(headers, **{"Content-Type": ctype}),
                        data=body, timeout=15, method="POST")
    status, raw = res if res else (0, None)
    text = raw.decode("utf-8", "replace") if raw else None
    stagelog.stage("query", http=status, shape=stagelog.shape_of(text),
                   bytes=(len(raw) if raw else 0), slug=slug)
    if status != 200 or not text:
        return []
    try:
        obj = json.loads(text)
    except Exception:
        stagelog.stage("parse", ok=False)
        return []
    if not isinstance(obj, dict):
        stagelog.stage("parse", ok=False, why="not_object")
        return []
    playlist = obj.get("playlist") or []
    servers = obj.get("servers") or {}
    stagelog.stage("items", count=len(playlist),
                   titles=[str(it.get("title"))[:60] for it in playlist[:3]
                           if isinstance(it, dict)])
    want_marker = None
    if media_type == "tv":
        want_marker = "S%02dE%02d" % (req.get("season") or 1,
                                      req.get("episode") or 1)
    want_words = set(_slugify(title).split("-"))
    sources = []
    for item in playlist:
        if not isinstance(item, dict):
            continue
        ititle = str(item.get("title") or "")
        if want_marker and want_marker not in ititle.replace(" ", ""):
            continue
        if ititle and want_words:
            got_words = set(_slugify(ititle).split("-"))
            if not (want_words & got_words):
                stagelog.stage("title_mismatch", item=ititle[:60])
                continue
        src = item.get("src")
        if not src:
            continue
        for sname, slabel in SERVERS:
            base = servers.get(sname)
            if not base:
                continue
            url = src if str(src).startswith("http") else \
                base.rstrip("/") + "/" + str(src).lstrip("/")
            if _verify(url, headers):
                sources.append({"well": NAME,
                                "label": "MP4Hydra " + slabel,
                                "url": url,
                                "quality": _height(item.get("quality")),
                                "headers": {"User-Agent": UA,
                                            "Referer": headers["Referer"]}})
    stagelog.stage("done", found=len(sources))
    return sources
