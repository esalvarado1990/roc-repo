# -*- coding: utf-8 -*-
"""
Well: VidZee — RE-AIMED at the service's real API (Door Doctrine
build, 2026-11-02). FRONT door.

The old recipe knocked on player.vidzee.wtf/api/server — that route
is 404 for everyone (cross-tech Leg 1, Nov 2; the MediaVanced lineage
in the old header). The live door was recovered from Cinema HQ's own
provider DEX (v40), class DynVidZeeProvider, disassembled instruction
by instruction:

  movie: GET https://core.vidzee.wtf/streams/movie/<tmdb>?s=<service>
  tv:    GET https://core.vidzee.wtf/streams/tv/<tmdb>/<season>/<episode>?s=<service>
  NOTE: do NOT append the player's &e=1 — that flag requests the
  WASM-encrypted {"c": ...} envelope; without it core returns the
  plain {"url": ...} this well reads. Verified 2026-11-10 live.
  services (from the live player bundle, player.vidzee.wtf, 2026-11-10):
      peak, dcloud, acme, tik, v4:<lang>, v6:<lang>
  request headers: desktop Chrome 131 UA, Accept application/json,
      Referer https://player.vidzee.wtf/, Origin https://player.vidzee.wtf
  answer: JSON object, direct stream in the "url" field (no decryption)
  playback headers (from the same class): UA + Referer + Origin above

The 400 "Unknown server" the deep-dive probes earned was this door
alive and validating the selector — they knocked with ?server=/?sr=;
the parameter is ?s=.

REGISTRY CHANGE 2026-11-10 (this fix): VidZee rotated its backends.
ipcloud is GONE from the registry (core answers 400 "Unknown server",
and the live player bundle no longer lists it). dcloud + tik are still
registered but their upstreams 502 (Cloudflare Bad Gateway, fast, from
BOTH the VM-proxy exit and the house WAN — origin-side failure, not
our query shape). NEW backends, all verified live 2026-11-10 with
plain "url" answers (NO &e=1 — see note above): "peak" pours movies
(vercetti.org m3u8, content-verified) but 404s TV on every title
tested (1396, 1399, 1668, 94997, 66732); "v6:English" + "v6:Hindi"
pour BOTH movie and TV (img1.hscow.com / img1.fcxmb.com m3u8s).
"acme" is listed in the player UI but core 400s it (it embeds
vaplayer.ru instead — separate recipe, open). v4:Hindi exists but was
flaky in testing (remote-closed once); not in the list. The v4/v6
"encrypted c" shape appears ONLY when &e=1 is sent — no WASM port
needed as long as the well omits it.

Both-ways: each returned playlist is fetched and content-sniffed
before it is handed back.
"""
import json
import os
import sys
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import stagelog

NAME = "VidZee"
CORE = "https://core.vidzee.wtf"
SERVICES = ("peak", "v6:English", "v6:Hindi", "dcloud", "tik")  # peak=movie, v6:*=movie+TV (live 2026-11-10); dcloud/tik fallbacks; ipcloud REMOVED (400 Unknown server)
# v3 2026-11-10: query retried once on transport 0 (proxy drops); 4xx/5xx never retried
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept": "application/json, text/plain, */*",
           "Referer": "https://player.vidzee.wtf/",
           "Origin": "https://player.vidzee.wtf"}
PLAYBACK_HEADERS = {"User-Agent": UA,
                    "Referer": "https://player.vidzee.wtf/",
                    "Origin": "https://player.vidzee.wtf"}


def _query_url(req, service):
    tmdb = req.get("tmdb_id")
    if req.get("tmdb_type") == "tv":
        return "%s/streams/tv/%s/%s/%s?s=%s" % (
            CORE, tmdb, req.get("season") or 1, req.get("episode") or 1,
            quote(service, safe=""))
    return "%s/streams/movie/%s?s=%s" % (CORE, tmdb,
                                          quote(service, safe=""))


def fetch(req):
    if not req.get("tmdb_id"):
        stagelog.stage("skip", reason="no_tmdb")
        return []
    sources = []
    for service in SERVICES:
        status, text = stagelog.http("query:" + service,
                                     _query_url(req, service),
                                     headers=HEADERS, timeout=10)
        if status == 0:
            # transport miss (the VM-proxy exit drops these often;
            # the guard log shows the same 0-flapping) — one retry,
            # mirroring the verify retry below. A real 4xx/5xx is NOT
            # retried: the backend answered, there is nothing to re-ask.
            status, text = stagelog.http(
                "query:" + service, _query_url(req, service),
                headers=HEADERS, timeout=10)
        if status != 200 or not text:
            continue
        try:
            obj = json.loads(text)
        except Exception:
            stagelog.stage("parse:" + service, ok=False)
            continue
        link = None
        if isinstance(obj, dict):
            cand = obj.get("url")
            if isinstance(cand, str) and cand.startswith("http"):
                link = cand
        if not link:
            stagelog.stage("parse:" + service, ok=False,
                           why="no_url_field")
            continue
        vstatus, vtext = stagelog.http("verify:" + service, link,
                                       headers=PLAYBACK_HEADERS,
                                       timeout=10)
        if vstatus == 0:
            vstatus, vtext = stagelog.http("verify:" + service, link,
                                           headers=PLAYBACK_HEADERS,
                                           timeout=10)
        if vstatus in (200, 206) and vtext and \
                vtext.lstrip().startswith("#EXTM3U"):
            sources.append({"well": NAME, "label": "VidZee - " + service,
                            "url": link, "quality": None,
                            "headers": dict(PLAYBACK_HEADERS)})
        else:
            stagelog.stage("verify:" + service, ok=False)
    stagelog.stage("done", found=len(sources))
    return sources
