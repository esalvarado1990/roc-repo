# -*- coding: utf-8 -*-
"""
Well: Movy (api.wecollege.net) — FRONT door, our own build
(Door Doctrine, 2026-11-02).

Re-derived 2026-11-02 two independent ways that agree byte-for-byte:
  * the open-source movysx provider client run bare on the Dell
    (cross-tech Leg 1: 7 sources for Dune, house exit, no VPN), and
  * Cinema HQ's own Movy class (DynWecollege) extracted from its DEX.

Protocol: GET /seed?mediaId=<tmdb> -> {seed}; then per city shard
GET /<city>/sources?...&enc=2&seed=<seed> -> base64url payload
XOR-decrypted with a seed+tmdb keystream (custom cipher, ported
below and verified against live shards) -> "mvm1" magic -> JSON
{sources[], subtitles[]}.

Both-ways: every candidate playlist is fetched and content-sniffed
(#EXTM3U) before it is handed back; failures drop with the stage
logged in the diary.
"""
import base64
import http.client
import json
import os
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import stagelog

NAME = "Movy"
API = "https://api.wecollege.net"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Referer": "https://www.movy.sx/",
           "Origin": "https://www.movy.sx",
           "Accept": "application/json, text/plain, */*"}
PLAYBACK_HEADERS = {"User-Agent": UA, "Referer": "https://www.movy.sx/"}
SHARDS = ("phoenix", "miami", "munich", "seattle")


def _height(quality):
    if quality is None:
        return None
    if isinstance(quality, int):
        return quality
    digits = "".join(ch for ch in str(quality) if ch.isdigit())
    return int(digits) if digits else None


# --- the provider's keystream cipher, ported line-for-line from the
# reference client (Kari's movysx provider, commit bd8446b) — the same
# code the cross-tech Leg 1 probe ran. Stateful slot machine:
# fnv/mix seeding, 61 slots, per-word next() evolution.
_M = 0xFFFFFFFF
MS = 2654435769
AX = 2779096485


def _rotl(x, r):
    r &= 31
    return x & _M if r == 0 else ((x << r) | (x >> (32 - r))) & _M


def _mix(l):
    l &= _M
    l ^= l >> 16
    l = (l * 2246822507) & _M
    l ^= l >> 13
    l = (l * 3266489909) & _M
    l ^= l >> 16
    return l


def _fnv(s):
    o = 2166136261
    for b in s.encode():
        o = ((o ^ b) * 16777619) & _M
    return _mix(o)


class Cipher:
    def __init__(self, seed, tmdb):
        self.slots = [0] * 61
        self.present = [False] * 61
        i = _mix(_fnv(seed) ^ _mix((tmdb ^ MS) & _M))
        for r in range(8):
            n = i % 61
            i = _rotl((i + MS) & _M, 7 + (r & 7))
            self.slots[n] = (i ^ _mix(i)) & _M
            self.present[n] = True
            i = _mix((i + n) & _M)
        self.acc = _mix((i ^ AX) & _M)

    def next(self, offset):
        r = self.acc % 61
        neg = 0xFFFFFFFF if self.present[r] else 0
        u = self.slots[r]
        d = (MS * (offset + 1)) & _M
        g = (self.acc ^ (u ^ d)) | (self.acc & (u ^ d) & neg)
        g = (_rotl((g + self.acc) & _M, r & 31)
             ^ _rotl(self.acc, (r * 7) & 31)) & _M
        self.acc = _mix((g + MS) & _M)
        self.slots[r] = self.acc
        self.present[r] = True
        return self.acc


def _keystream(seed, tmdb, n):
    st = Cipher(seed, tmdb)
    out = bytearray()
    off = 0
    while len(out) < n:
        d = st.next(off)
        off += 1
        for k in range(4):
            if len(out) >= n:
                break
            out.append((d >> (8 * k)) & 0xFF)
    return bytes(out)


def _decrypt_payload(enc_text, seed, tmdb):
    """Returns the payload dict, or None (stage-logged) on any failure."""
    b64 = enc_text.strip().strip('"').replace("-", "+").replace("_", "/")
    b64 += "=" * ((4 - len(b64) % 4) % 4)
    raw = bytearray(base64.b64decode(b64))
    ks = _keystream(seed, tmdb, len(raw))
    for i in range(len(raw)):
        raw[i] ^= ks[i]
    if bytes(raw[:4]) != b"mvm1":
        return None
    return json.loads(bytes(raw[4:]).decode("utf-8"))


def _verify(url):
    status, text = stagelog.http("verify", url, headers=PLAYBACK_HEADERS,
                                 timeout=10)
    if status == 0:
        # One retry on a transport failure: under fanout concurrency a
        # reset connection once cost this door a verified source
        # (Breaking Bad, 2026-11-02 harness). A refusal is not retried.
        status, text = stagelog.http("verify", url,
                                     headers=PLAYBACK_HEADERS, timeout=10)
    if status in (200, 206) and text and \
            text.lstrip().startswith("#EXTM3U"):
        return True
    # A direct file (not a playlist) that answers a fetch is still real.
    return status in (200, 206) and ".m3u8" not in url


# --- FIX 2026-11-10 (MOVY lane): one persistent connection for the
# seed + shard round-trip. Root cause, proven live 2026-11-10 12:30-12:35
# MST by cross-vantage seed tests: the seed is bound to the exit IP
# that requested it. A Dell seed 401s from the VM (STREAMCRYPTO_SEED_
# INVALID) and a VM seed 401s from the Dell, while each seed works
# from its own exit (all 4 shards 200). The VM egress proxy rotates
# exit IP per request (5 distinct IPs in 3 s), so urllib's one
# connection per request almost never puts the seed and its shards
# behind the same exit IP — the shards 401 and the well reads 0.
# One CONNECT tunnel pins one exit IP: seed + 4 shards over a single
# tunnel answered 200/200/200/200 from the VM at ~250 ms a hop
# (test 12:35 MST), where per-request calls in the same minutes gave
# 401/0/timeout.
# The tunnel honours the proxy env when present (VM guard egress)
# and goes direct otherwise (house, stick). Any failure of the
# persistent attempt falls back to the original per-request loop
# with a fresh seed, so no vantage can regress: the old path is
# still the fallback, never removed.
_API_HOST = "api.wecollege.net"


def _proxy_from_env():
    """(host, port, auth_header|None) from the https proxy env, or None
    when there is no proxy (direct egress: house, stick)."""
    raw = os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY")
    if not raw:
        return None
    try:
        u = urllib.parse.urlparse(raw)
        if not u.hostname or not u.port:
            return None
        auth = None
        if u.username:
            creds = u.username
            if u.password:
                creds += ":" + u.password
            auth = "Basic " + base64.b64encode(
                urllib.parse.unquote(creds).encode()).decode()
        return (u.hostname, u.port, auth)
    except Exception:
        return None


def _open_api_conn(timeout):
    """One HTTPS connection to the API host. Through the proxy env's
    CONNECT tunnel when a proxy is set (pins one exit IP for the
    whole connection), direct otherwise."""
    px = _proxy_from_env()
    if px is not None:
        host, port, auth = px
        conn = http.client.HTTPSConnection(host, port, timeout=timeout)
        tun = {"Proxy-Authorization": auth} if auth else {}
        conn.set_tunnel(_API_HOST, 443, headers=tun)
    else:
        conn = http.client.HTTPSConnection(_API_HOST, 443, timeout=timeout)
    conn.connect()
    return conn


def _conn_get(conn, path, headers):
    """One GET on a persistent connection. Returns (status, text|None);
    (0, None) on any transport failure. Stage-logged like
    stagelog.http so the diary keeps the same hop names."""
    t0 = time.time()
    try:
        conn.request("GET", path, headers=headers)
        resp = conn.getresponse()
        raw = resp.read()
        status = resp.status
    except Exception:
        return 0, None
    text = None
    if raw:
        try:
            text = raw.decode("utf-8", "replace")
        except Exception:
            text = None
    return status, text


def _decrypt_shard(city, text, seed, tmdb, sources):
    """Decrypt one shard payload into `sources`. Returns True when the
    shard answered 200 with a decryptable payload (a live shard)."""
    try:
        payload = _decrypt_payload(text, seed, tmdb)
    except Exception:
        payload = None
    if payload is None:
        stagelog.stage("decrypt:" + city, ok=False, why="bad_magic")
        return False
    raw_sources = payload.get("sources") or []
    stagelog.stage("decrypt:" + city, ok=True,
                   sources=len(raw_sources))
    for item in raw_sources:
        if not isinstance(item, dict):
            continue
        link = item.get("url") or item.get("file")
        if not link or not str(link).startswith("http"):
            continue
        if any(s["url"] == link for s in sources):
            continue
        sources.append({"well": NAME, "label": NAME, "url": link,
                        "quality": _height(item.get("quality")),
                        "headers": dict(PLAYBACK_HEADERS)})
    return True


def _persistent_attempt(req, tmdb, params):
    """Seed + all 4 shards over ONE connection. Returns (sources, ok):
    ok is True when at least one shard answered 200 decryptable —
    the attempt then owns the result and no fallback runs. ok False
    (seed dead / conn broke / every shard 0-or-401) means the caller
    falls back to the legacy per-request loop with a fresh seed."""
    sources = []
    conn = None
    try:
        conn = _open_api_conn(timeout=12)
        stagelog.stage("conn", mode="persistent")
        status, text = _conn_get(
            conn, "/seed?mediaId=%s" % tmdb, HEADERS)
        stagelog.stage("seed", http=status,
                       shape=stagelog.shape_of(text),
                       bytes=(len(text.encode("utf-8", "replace"))
                              if text else 0))
        if status != 200 or not text:
            return [], False
        try:
            seed = json.loads(text)["seed"]
        except Exception:
            stagelog.stage("seed_parse", ok=False)
            return [], False
        params = dict(params)
        params["enc"] = "2"
        params["seed"] = seed
        any_live = False
        for city in SHARDS:
            url = "/%s/sources?%s" % (
                city, urllib.parse.urlencode(params))
            status, text = _conn_get(conn, url, HEADERS)
            stagelog.stage("shard:" + city, http=status,
                           shape=stagelog.shape_of(text),
                           bytes=(len(text.encode("utf-8", "replace"))
                                  if text else 0))
            if status != 200 or not text:
                continue
            if _decrypt_shard(city, text, seed, tmdb, sources):
                any_live = True
        return sources, any_live
    except Exception:
        return sources, False
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def _verify_all(sources):
    """Cap + parallel-verify the merged pour (unchanged behaviour)."""
    sources = sources[:8]
    if sources:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=4) as pool:
            checks = list(pool.map(lambda s: _verify(s["url"]), sources))
        verified = [s for s, ok in zip(sources, checks) if ok]
    else:
        verified = []
    stagelog.stage("done", found=len(sources), verified=len(verified))
    return verified


def _legacy_fetch(req, tmdb, params):
    """Pre-fix behaviour, kept verbatim as the fallback: fresh seed,
    one request per shard. `params` is copied, never mutated."""
    params = dict(params)
    status, text = stagelog.http("seed", "%s/seed?mediaId=%s" % (API, tmdb),
                                 headers=HEADERS, timeout=10)
    if status != 200 or not text:
        return []
    try:
        seed = json.loads(text)["seed"]
    except Exception:
        stagelog.stage("seed_parse", ok=False)
        return []
    params["enc"] = "2"
    params["seed"] = seed
    sources = []
    for city in SHARDS:
        url = "%s/%s/sources?%s" % (
            API, city, urllib.parse.urlencode(params))
        status, text = stagelog.http("shard:" + city, url,
                                     headers=HEADERS, timeout=12)
        if status != 200 or not text:
            continue
        _decrypt_shard(city, text, seed, tmdb, sources)
        # All four shards are asked and merged (the reference client's
        # full set: 7 unique Dune sources across shards, Leg 1) — the
        # pour is bigger than any single shard's shelf.
    # Verify in parallel: sequential verifies of the full merged set
    # (7 sources) pushed this door past the front window on Dune:
    # Part Two (33 s solo, dropped from that fanout). Cap the pour at
    # 8 candidates; order is preserved.
    return _verify_all(sources)


def fetch(req):
    tmdb = req.get("tmdb_id")
    if not tmdb:
        stagelog.stage("skip", reason="no_tmdb")
        return []
    # The reference client's exact parameter set (all strings, enc and
    # seed inside the query) — the shape the live shards answer.
    params = {
        "title": req.get("title") or "",
        "mediaType": req.get("tmdb_type") or "movie",
        "year": str(req.get("year") or ""),
        "tmdbId": str(tmdb),
        "imdbId": req.get("imdb") or "",
        "episodeId": str(req.get("episode") or 1),
        "seasonId": str(req.get("season") or 1),
    }
    # Attempt 1 (FIX 2026-11-10): one persistent connection for the
    # seed + shard round-trip — the seed is exit-IP-bound, so this is
    # what makes rotating-proxy exits work at all. Any failure here
    # falls through to the legacy per-request loop below (fresh seed),
    # so the old behaviour is the fallback, never lost.
    try:
        sources, ok = _persistent_attempt(req, tmdb, params)
    except Exception:
        sources, ok = [], False
    if ok:
        return _verify_all(sources)
    # Attempt 2 (legacy): fresh seed, one request per shard — the
    # pre-fix behaviour, kept verbatim as the fallback.
    return _legacy_fetch(req, tmdb, params)
