# -*- coding: utf-8 -*-
"""
rocplay token loader — the player-layer TokenLoader equivalent
(build 2026-11-18).

WHY THIS EXISTS: VidSrc's playback contract (the site's own
player.js, read live 2026-11-18 — source treatment evidence) is
that EVERY request the player makes — master playlist, variant
playlists, segments, keys — carries the generate JWT as ?token=
(the hls.js TokenLoader stamps it per request), and playlist
requests carry the player origin as Referer (the browser sends
it cross-origin from the player page). The well hands rocplay
exactly one stamped URL (the master) plus the Referer/UA
headers. rocplay plays that URL through xbmc.Player pipe
format; Kodi's ffmpeg HLS demuxer then makes the sub-requests
itself, and the bundle prep lane's live-fire check
(bundle-install-resumefix-20261118, evidence/token-check) proved
what it does with them: the Referer rides every sub-request,
the token rides NONE of them — and the stream host answers the
tokenless variant/segment requests 403 (treatment segment
proof: 403 without the token, 200 with it, ffprobe-read
segments on both test titles). So a VidSrc source could
resolve perfectly and still die at the first variant fetch.

THE FIX: when a VidSrc source is selected, _play_url routes it
through this module's local playlist-rewriting proxy instead
of handing the demuxer the raw master URL. The proxy
(127.0.0.1, ephemeral port, this process only) fetches every
playlist in the tree itself — stamping the token onto every
same-host upstream request and sending the well's Referer/UA
on all of them, exactly the browser's contract — and rewrites
every URI in the playlist bodies (variant lines, segment
lines, URI="..." attributes for keys / media / maps) to come
back through the proxy, so every sub-request the demuxer makes
is stamped the same way. Non-playlist bodies (segments, keys)
are relayed byte-for-byte. Nothing is cached to disk; a
session lives exactly as long as its playback (default.py
holds the plugin alive on a token-loader win until the player
leaves the file, then closes the session).

Scope, deliberately: VidSrc only, and only when the
handed-back URL actually carries a token. Every other well's
play path is byte-for-byte what it was. Stdlib only, no xbmc
imports — the module is exercised offline by the lane's unit
suite and live-fire harness exactly as shipped.
"""
import gzip
import os
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

_TOKEN_PARAM = "token"
_PLAYLIST_CT = "application/vnd.apple.mpegurl"
_URI_ATTR = re.compile(r'URI="([^"]*)"')
_SNIFF_BYTES = 65536


# ------------------------------------------------------------ url tools

def _netloc(url):
    try:
        return urllib.parse.urlsplit(url).netloc.lower()
    except Exception:
        return ""


def extract_token(url):
    """The generate JWT riding a handed-back master URL, or None."""
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    except Exception:
        return None
    vals = qs.get(_TOKEN_PARAM) or []
    return vals[0] if vals else None


def stamp_url(url, token):
    """Append ?token=<jwt> (or &token=) unless a token parameter
    is already present. Mirrors player.js's TokenLoader stamp."""
    if not token:
        return url
    try:
        parts = urllib.parse.urlsplit(url)
        qs = urllib.parse.parse_qs(parts.query)
    except Exception:
        return url
    if _TOKEN_PARAM in qs:
        return url
    query = parts.query + ("&" if parts.query else "") + \
        _TOKEN_PARAM + "=" + urllib.parse.quote(str(token), safe="")
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, parts.path, query,
         parts.fragment))


def rewrite_playlist(text, base_url, wrap):
    """Rewrite every URI in an HLS playlist body. Bare URI lines
    (variants, segments) and URI="..." attributes (keys, media,
    maps) are resolved against base_url (the URL the body was
    actually fetched from, after redirects) and passed through
    wrap(); every other byte of structure is preserved."""
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            out.append(line)
        elif stripped.startswith("#"):
            def _sub(m):
                return 'URI="%s"' % wrap(
                    urllib.parse.urljoin(base_url, m.group(1)))
            out.append(_URI_ATTR.sub(_sub, line))
        else:
            out.append(wrap(urllib.parse.urljoin(base_url,
                                                 stripped)))
    return "\n".join(out) + "\n"


def _is_playlist(head):
    return head.lstrip()[:7] == b"#EXTM3U"


# ------------------------------------------------------------ upstream

def _open_upstream(url, headers, range_header):
    """One GET against the origin with the session's headers.
    Returns (status, headers, body_stream, final_url): an HTTP
    error status is a relayable answer, not an exception — the
    demuxer must see the origin's real verdict. status 0 means
    transport failure (body_stream None)."""
    req = urllib.request.Request(url)
    for k, v in (headers or {}).items():
        try:
            req.add_header(k, v)
        except Exception:
            pass
    req.add_header("Accept-Encoding", "identity")
    if range_header:
        req.add_header("Range", range_header)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        return resp.status, resp.headers, resp, resp.geturl()
    except urllib.error.HTTPError as exc:
        try:
            final = exc.geturl()
        except Exception:
            final = url
        return exc.code, exc.headers, exc, final
    except Exception:
        return 0, {}, None, url


# ------------------------------------------------------------ server

class _Session(object):
    __slots__ = ("token", "headers", "host")

    def __init__(self, token, headers, host):
        self.token = token
        self.headers = headers
        self.host = host


class _TokenHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self):
        ThreadingHTTPServer.__init__(self, ("127.0.0.1", 0),
                                     _Handler)
        self.sessions = {}


def _local_url(port, sid, target):
    return "http://127.0.0.1:%d/%s/x?u=%s" % (
        port, sid, urllib.parse.quote(target, safe=""))


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def do_GET(self):
        self._serve(send_body=True)

    def do_HEAD(self):
        self._serve(send_body=False)

    # -- plumbing -------------------------------------------------
    def _send(self, status, ctype, body, extra=None,
              send_body=True):
        try:
            self.send_response(status)
            if ctype:
                self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if send_body and body:
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _serve(self, send_body=True):
        try:
            self._serve_inner(send_body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            self._send(502, "text/plain", b"token loader error",
                       send_body=send_body)

    def _serve_inner(self, send_body):
        parsed = urllib.parse.urlsplit(self.path)
        seg = parsed.path.strip("/").split("/", 1)
        sid = seg[0] if seg else ""
        sess = self.server.sessions.get(sid)
        qs = urllib.parse.parse_qs(parsed.query)
        target = (qs.get("u") or [None])[0]
        if sess is None or not target:
            self._send(404, "text/plain", b"no such session",
                       send_body=send_body)
            return
        upstream = target
        if sess.token and _netloc(target) == sess.host:
            upstream = stamp_url(target, sess.token)
        status, headers, stream, final_url = _open_upstream(
            upstream, sess.headers, self.headers.get("Range"))
        if stream is None:
            self._send(502, "text/plain", b"upstream unreachable",
                       send_body=send_body)
            return
        ctype = None
        crange = None
        try:
            ctype = headers.get("Content-Type")
            crange = headers.get("Content-Range")
        except Exception:
            pass
        encoding = ""
        try:
            encoding = (headers.get("Content-Encoding")
                        or "").lower()
        except Exception:
            pass
        if "gzip" in encoding:
            # Playlists are the only bodies an origin gzips here;
            # they are small — decode whole and answer from bytes.
            try:
                body = gzip.decompress(stream.read())
            except Exception:
                body = b""
            self._answer(status, ctype, crange, body, final_url,
                         sid, send_body, whole=True)
            return
        head = stream.read(_SNIFF_BYTES) if status == 200 else b""
        if status == 200 and _is_playlist(head):
            body = head + stream.read()
            self._answer(status, ctype, crange, body, final_url,
                         sid, send_body, whole=True)
            return
        # Passthrough: relay the status and stream the body. A
        # known Content-Length is relayed; otherwise the body is
        # close-delimited.
        clen = None
        try:
            clen = headers.get("Content-Length")
        except Exception:
            pass
        try:
            self.send_response(status)
            self.send_header("Content-Type",
                             ctype or "application/octet-stream")
            if crange:
                self.send_header("Content-Range", crange)
            if clen is not None:
                self.send_header("Content-Length", clen)
            else:
                self.close_connection = True
            self.end_headers()
            if send_body:
                if head:
                    self.wfile.write(head)
                while True:
                    chunk = stream.read(_SNIFF_BYTES)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _answer(self, status, ctype, crange, body, final_url,
                sid, send_body, whole=False):
        """Answer from a complete in-memory body: rewrite it when
        it is a playlist, relay it untouched otherwise."""
        if status == 200 and _is_playlist(body):
            port = self.server.server_address[1]
            wrap = lambda a: _local_url(port, sid, a)
            text = body.decode("utf-8", "replace")
            data = rewrite_playlist(text, final_url,
                                    wrap).encode("utf-8")
            self._send(200, _PLAYLIST_CT, data,
                       send_body=send_body)
            return
        extra = {}
        if crange:
            extra["Content-Range"] = crange
        self._send(status, ctype or "application/octet-stream",
                   body, extra=extra, send_body=send_body)


# ------------------------------------------------------------ sessions

_LOCK = threading.Lock()
_SERVER = None


def _ensure_server():
    global _SERVER
    if _SERVER is None:
        srv = _TokenHTTPServer()
        t = threading.Thread(target=srv.serve_forever,
                             kwargs={"poll_interval": 0.1})
        t.daemon = True
        t.start()
        _SERVER = srv
    return _SERVER


def open_session(master_url, headers):
    """Start a stamping session for one handed-back master URL.
    Returns the local master URL the player should open, or None
    when the URL carries no token (nothing to stamp — the caller
    falls back to the raw URL, the pre-loader behaviour)."""
    token = extract_token(master_url)
    if not token:
        return None
    with _LOCK:
        srv = _ensure_server()
        sid = os.urandom(6).hex()
        srv.sessions[sid] = _Session(token, dict(headers or {}),
                                     _netloc(master_url))
        return _local_url(srv.server_address[1], sid, master_url)


def _sid_of(url):
    try:
        seg = urllib.parse.urlsplit(
            url.split("|")[0]).path.strip("/").split("/", 1)
        return seg[0] if seg else ""
    except Exception:
        return ""


def is_local_url(url):
    """True when url points at this process's token proxy."""
    with _LOCK:
        srv = _SERVER
    if srv is None or not url:
        return False
    base = "http://127.0.0.1:%d/" % srv.server_address[1]
    return url.split("|")[0].startswith(base)


def close_url(url):
    """Close the session a local URL belongs to. When the last
    session goes, the proxy server stops — nothing lingers
    between plays."""
    sid = _sid_of(url or "")
    srv = None
    with _LOCK:
        if _SERVER is not None:
            _SERVER.sessions.pop(sid, None)
            if not _SERVER.sessions:
                srv = _SERVER
                globals()["_SERVER"] = None
    if srv is not None:
        try:
            srv.shutdown()
            srv.server_close()
        except Exception:
            pass


def session_count():
    with _LOCK:
        return len(_SERVER.sessions) if _SERVER is not None else 0


def shutdown():
    """Stop the proxy outright (tests / plugin teardown)."""
    with _LOCK:
        srv = _SERVER
        globals()["_SERVER"] = None
    if srv is not None:
        try:
            srv.shutdown()
            srv.server_close()
        except Exception:
            pass
