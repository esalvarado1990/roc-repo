# -*- coding: utf-8 -*-
"""
stagelog — per-stage observability for Roc Play wells (Door Doctrine
build, 2026-11-02).

Every well reports each hop it makes (stage name, HTTP status, response
shape, elapsed ms) as a `well_stage` flight-recorder event, so the diary
never again collapses a failure to a bare 0 — the hole rohttp's
None-on-any-failure contract used to leave.

Stages also feed a per-well evidence registry that wellcore reads to
classify the outcome: a well whose hops all got HTTP answers but
produced no sources is "answered_zero" (the door is alive; the shelf
was empty on this exit — the exit-window signature) while a well with
transport failures (status 0 = DNS/refused/TLS/timeout) is "no_answer"
(the door or the path is in trouble). Door-dead vs exit-window-shut is
the distinction the doctrine demands, and it is only honest when it is
classified from the hops themselves.

The sink is WellCore.event, bound by WellCore.fanout per play. With no
sink bound (CLI harness), stages still land in the registry.

Stdlib only, flat module (house style: resources/lib on sys.path).
"""
import json
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rohttp

_local = threading.local()
_sink = None
_lock = threading.Lock()
# well NAME -> {"transport": bool, "answered": bool, "stages": [...],
#               "codes": {stage: {"first": int|None, "seen": [int],
#                                 "last": int|None, "count": int}},
#               "gated": bool}
# B2 (2026-11-12): "codes" keeps, per stage, the FIRST http code seen
# and the SET of codes seen — the guard used to keep only the LAST
# code per stage, which hid VidSrc's real first failure (generate
# 403, missing token) behind the later symptom (generate 429, burst
# limit) for ~2 days. "gated" is set by any stage named "gate" with
# gated=True (VidSrc Turnstile) so the probe can name the verdict.
_registry = {}


def set_sink(fn):
    """fn(kind, **fields) — WellCore.event fits this shape."""
    global _sink
    _sink = fn


def begin(well_name):
    _local.ctx = {"well": well_name, "t0": time.time()}
    with _lock:
        _registry[well_name] = {"transport": False, "answered": False,
                                "stages": [], "codes": {}, "gated": False}


def shape_of(text):
    """Short, diary-safe description of a response body."""
    if text is None:
        return "none"
    if isinstance(text, bytes):
        text = text[:400].decode("utf-8", "replace")
    t = text.strip()
    if not t:
        return "empty"
    if t.startswith("#EXTM3U"):
        return "m3u8"
    if t[0] in "[{":
        try:
            obj = json.loads(t)
            if isinstance(obj, dict):
                return "json{" + ",".join(sorted(obj.keys())[:8]) + "}"
            if isinstance(obj, list):
                return "json-array(%d)" % len(obj)
        except Exception:
            pass
    low = t[:200].lower()
    if "<html" in low or "<!doctype" in low:
        return "html"
    return "text"


def _fresh_reg():
    return {"transport": False, "answered": False, "stages": [],
            "codes": {}, "gated": False}


def stage(name, **fields):
    ctx = getattr(_local, "ctx", None)
    if ctx is None:
        return
    well = ctx["well"]
    if "http" in fields:
        with _lock:
            reg = _registry.setdefault(well, _fresh_reg())
            if fields["http"]:
                reg["answered"] = True
            else:
                reg["transport"] = True
            # B2: first failure + all codes, per stage. Never
            # overwritten by a later attempt — the first code is
            # the diagnosis, the set is the full story.
            code = fields["http"]
            entry = reg["codes"].setdefault(
                name, {"first": code, "seen": [], "last": code, "count": 0})
            entry["count"] += 1
            entry["last"] = code
            if code not in entry["seen"]:
                entry["seen"].append(code)
    if name == "gate" and fields.get("gated"):
        with _lock:
            reg = _registry.setdefault(well, _fresh_reg())
            reg["gated"] = True
    rec = {"stage": name,
           "ms": int((time.time() - ctx["t0"]) * 1000)}
    rec.update(fields)
    with _lock:
        reg = _registry.setdefault(well, _fresh_reg())
        if len(reg["stages"]) < 60:
            reg["stages"].append(rec)
    if _sink is not None:
        try:
            _sink("well_stage", well=well, **rec)
        except Exception:
            pass


def stages_for(well_name):
    with _lock:
        reg = _registry.get(well_name) or {}
        return list(reg.get("stages") or [])


def stage_codes(well_name):
    """B2: per-stage first-failure + all-codes record.
    {stage: {"first": int|None, "seen": [int, ...] (ascending),
             "last": int|None, "count": int}} — a copy; mutating it
    cannot corrupt the registry."""
    with _lock:
        reg = _registry.get(well_name) or {}
        out = {}
        for name, entry in (reg.get("codes") or {}).items():
            out[name] = {"first": entry.get("first"),
                         "seen": sorted(entry.get("seen") or []),
                         "last": entry.get("last"),
                         "count": entry.get("count", 0)}
        return out


def gated(well_name):
    """True when any stage named "gate" with gated=True fired for
    this well in the current begin() window (VidSrc Turnstile)."""
    with _lock:
        reg = _registry.get(well_name) or {}
        return bool(reg.get("gated"))


def evidence(well_name):
    """'transport' if any hop failed to connect, 'answered' if hops got
    HTTP answers, 'none' if the well made no logged hop."""
    with _lock:
        reg = _registry.get(well_name) or {}
    if reg.get("transport"):
        return "transport"
    if reg.get("answered"):
        return "answered"
    return "none"


def http(name, url, headers=None, timeout=12, data=None):
    """One HTTP hop with stage logging. Returns (status:int, text|None).

    status 0 = transport failure (rohttp returned None) — the
    distinction the old get()/get_json() erased.
    """
    t0 = time.time()
    status, raw = rohttp.request_status(url, headers=headers, data=data,
                                        timeout=timeout)
    text = None
    if raw:
        try:
            text = raw.decode("utf-8", "replace")
        except Exception:
            text = None
    stage(name, http=status, ms_hop=int((time.time() - t0) * 1000),
          shape=shape_of(text), bytes=(len(raw) if raw else 0))
    return status, text


def http_retry(name, url, headers=None, timeout=12, data=None, retries=1,
               backoff_s=1.0, retry_429=False, retry_429_after=5.0,
               pace_s=0.0):
    """http() with the shared retry policy (B1, 2026-11-12) — the
    behaviour Movy's verify, VidZee's query/verify and VidSrc's
    _hop each hand-copied, now in rohttp.request_status_retry and
    inherited by every well through this one call. One stage per
    attempt (attempt=N, retry=True on later attempts) plus a
    hop_retry stage before each retry, so the first-failure record
    (B2) sees every attempt instead of only the last. Returns
    (status, text, attempts) where attempts is the raw per-attempt
    [(status, body), ...] list. Policy, kept verbatim from the
    proven copies: retry on transport failure (status 0) only — a
    real 4xx/5xx is an answer, never re-asked; with retry_429, one
    429 gets a single retry after retry_429_after seconds; pace_s
    spaces calls to the same host (VidSrc generate's 1.5 s)."""
    status, raw, attempts = rohttp.request_status_retry(
        url, headers=headers, data=data, timeout=timeout,
        retries=retries, backoff_s=backoff_s, retry_429=retry_429,
        retry_429_after=retry_429_after, pace_s=pace_s)
    text = None
    for i, (astatus, abody) in enumerate(attempts, 1):
        if i > 1:
            stage("hop_retry", hop=name, attempt=i)
        atext = None
        if abody:
            try:
                atext = abody.decode("utf-8", "replace")
            except Exception:
                atext = None
        stage(name, http=astatus, shape=shape_of(atext),
              bytes=(len(abody) if abody else 0),
              attempt=i, retry=(i > 1))
        if i == len(attempts):
            text = atext
    return status, text, attempts
