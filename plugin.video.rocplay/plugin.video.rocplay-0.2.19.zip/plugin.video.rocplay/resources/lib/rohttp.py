# -*- coding: utf-8 -*-
"""
rocplay HTTP — stdlib urllib ONLY.

Zero third-party imports on purpose: the playback chain must not die
because a shared module (requests & friends) changed under it. Every
call returns None on ANY failure — wells treat None as "dry" and the
fan-out moves on. Nothing in here ever raises to the caller.
"""
import base64 as _base64
import gzip as _gzip
import http.client as _http_client
import json as _json
import os as _os
import threading as _threading
import time as _time
import urllib.parse as _urlparse
import urllib.request
import urllib.error
import zlib as _zlib

UA = ("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36")


def _decode(body, headers):
    """Undo Content-Encoding (gzip/deflate) when the server used it.
    FIX 2026-11-12 (VidSrc treatment): we now ASK for gzip (see
    _prep) because identity chunked bodies from the VidSrc Cloudflare
    hosts get truncated mid-transfer on this VM's egress-proxy path
    (http.client IncompleteRead -> status 0), while the same chain
    completes identity from the house exit and completes gzip here.
    Promoted from a scratch copy verified the same night from both
    exits (VM: chain reaches the Turnstile gate; house: VidSrc
    movie 2 + TV 3 verified sources, unchanged)."""
    if not body:
        return body
    enc = ""
    try:
        enc = (headers.get("Content-Encoding") or "").lower()
    except Exception:
        pass
    try:
        if "gzip" in enc:
            return _gzip.decompress(body)
        if "deflate" in enc:
            return _zlib.decompress(body)
    except Exception:
        return body
    return body


def _prep(headers):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers:
        h.update(headers)
    # http.client silently injects "Accept-Encoding: identity" when
    # the header is absent; pin it to gzip explicitly (caller's own
    # choice always wins).
    if not any(k.lower() == "accept-encoding" for k in h):
        h["Accept-Encoding"] = "gzip"
    return h


def request(url, headers=None, data=None, timeout=12, method=None):
    """data: bytes (raw POST body) or dict (JSON body). Returns
    (status, body_bytes) or None."""
    h = _prep(headers)
    body = data
    if isinstance(data, dict):
        body = _json.dumps(data).encode("utf-8")
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, _decode(resp.read(), resp.headers)
    except Exception:
        return None


def request_status(url, headers=None, data=None, timeout=12, method=None):
    """Like request(), but NEVER collapses an HTTP error to None:
    returns (status, body_bytes) for any HTTP answer — 4xx/5xx
    included — and (0, None) only when no HTTP answer arrived at all
    (DNS / refused / TLS / timeout). stagelog rides on this so the
    diary can tell a refusal (403) from a dead path (0): the
    door-dead vs exit-window distinction the old contract erased."""
    h = _prep(headers)
    body = data
    if isinstance(data, dict):
        body = _json.dumps(data).encode("utf-8")
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, _decode(resp.read(), resp.headers)
    except urllib.error.HTTPError as e:
        try:
            return e.code, _decode(e.read(), e.headers)
        except Exception:
            return e.code, b""
    except Exception:
        return 0, None


def get(url, headers=None, timeout=12):
    r = request(url, headers=headers, timeout=timeout)
    return r[1] if r else None


def get_json(url, headers=None, timeout=12):
    raw = get(url, headers=headers, timeout=timeout)
    if raw is None:
        return None
    try:
        return _json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def post(url, headers=None, data=None, timeout=12):
    r = request(url, headers=headers, data=data, timeout=timeout)
    return r[1] if r else None


def post_json(url, headers=None, data=None, timeout=12):
    raw = post(url, headers=headers, data=data, timeout=timeout)
    if raw is None:
        return None
    try:
        return _json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def proxy_from_env():
    """(host, port, auth_header|None) from the https proxy env, or
    None when there is no proxy (direct egress: house, stick).
    Moved verbatim from movy._proxy_from_env (B1, 2026-11-12) — the
    shared exit-pinning layer owns it now, so every well reads the
    proxy the same way instead of each hand-rolling it."""
    raw = _os.environ.get("https_proxy") or _os.environ.get("HTTPS_PROXY")
    if not raw:
        return None
    try:
        u = _urlparse.urlparse(raw)
        if not u.hostname or not u.port:
            return None
        auth = None
        if u.username:
            creds = u.username
            if u.password:
                creds += ":" + u.password
            auth = "Basic " + _base64.b64encode(
                _urlparse.unquote(creds).encode()).decode()
        return (u.hostname, u.port, auth)
    except Exception:
        return None


# --- B1 (2026-11-12): shared retry + pacing + exit-pinning --------
# The three behaviours below were hand-copied per well (Movy's
# persistent-connection redraw, VidSrc's hop retry + generate
# pacing, VidZee's transport-0 query/verify retry) and absent in
# VixSrc/VidMario/MP4Hydra. They now live here once, in the chassis,
# and every well inherits them through stagelog.http_retry. Rules
# the copies proved, kept verbatim: retry on transport failure
# (status 0) ONLY — a real 4xx/5xx is an answer, never re-asked;
# one 429 gets a single retry after a pause (burst-limit backoff);
# attempts to one host are spaced (burst prevention).

_pace_lock = _threading.Lock()
_pace_last = {}  # host -> time of last call (any attempt)


def _pace_wait(host, pace_s):
    """Sleep until at least pace_s have passed since the last call
    to this host. No-op when pace_s is 0."""
    if not pace_s:
        return
    with _pace_lock:
        last = _pace_last.get(host, 0.0)
        now = _time.time()
        wait = last + pace_s - now
        if wait > 0:
            _time.sleep(wait)
        _pace_last[host] = _time.time()


def request_status_retry(url, headers=None, data=None, timeout=12,
                         method=None, retries=1, backoff_s=1.0,
                         retry_429=False, retry_429_after=5.0,
                         pace_s=0.0):
    """request_status with the shared retry policy. Returns
    (status, body_bytes, attempts) where attempts is the full
    per-attempt [(status, body), ...] list — the caller (stagelog)
    stages every attempt, so the first-failure record (B2) sees
    each one instead of only the last. `retries` is the number of
    retries after the first attempt (1 = try twice total)."""
    host = _urlparse.urlparse(url).netloc
    attempts = []
    status, body = 0, None
    tries = 0
    while True:
        _pace_wait(host, pace_s)
        status, body = request_status(url, headers=headers, data=data,
                                      timeout=timeout, method=method)
        tries += 1
        attempts.append((status, body))
        if status == 429 and retry_429 and tries <= retries:
            _time.sleep(retry_429_after)
            continue
        if status == 0 and tries <= retries:
            if backoff_s:
                _time.sleep(backoff_s)
            continue
        break
    return status, body, attempts


class PinnedConnection(object):
    """One HTTPS connection for a whole multi-hop recipe — the
    exit-pinning Movy proved 2026-11-10, generalised (B1). The
    seed is bound to the exit IP that minted it, and the VM proxy
    rotates exit IP per request; one CONNECT tunnel pins one exit
    IP for the whole connection, so seed and shards (or chain hops)
    share the exit. Through the proxy env's tunnel when one is set,
    direct otherwise. Connects eagerly in __init__ (a connect
    failure raises, exactly like movy._open_api_conn before it —
    the caller falls back). Bodies are gzip-decoded like
    request_status, so a gzip hop cannot poison a decrypt step.
    Usage: conn = PinnedConnection(host); ...; conn.close()
    (or `with PinnedConnection(host) as conn:`)."""

    def __init__(self, host, port=443, timeout=12, proxy="auto"):
        self.host = host
        self.port = port
        if proxy == "auto":
            proxy = proxy_from_env()
        if proxy is not None:
            phost, pport, auth = proxy
            conn = _http_client.HTTPSConnection(phost, pport,
                                                timeout=timeout)
            tun = {"Proxy-Authorization": auth} if auth else {}
            conn.set_tunnel(host, port, headers=tun)
        else:
            conn = _http_client.HTTPSConnection(host, port,
                                                timeout=timeout)
        conn.connect()
        self._conn = conn

    def request_status(self, method, path, headers=None, body=None):
        """(status:int, body_bytes|None); (0, None) on any transport
        failure. Same contract as module-level request_status, on
        the pinned connection."""
        try:
            self._conn.request(method, path, body=body,
                               headers=headers or {})
            resp = self._conn.getresponse()
            raw = resp.read()
            return resp.status, _decode(raw, resp.headers)
        except Exception:
            return 0, None

    def close(self):
        try:
            self._conn.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def head_ok(url, headers=None, timeout=8):
    """Cheap liveness probe for a resolved stream URL: True when the
    host answers 2xx/3xx/405 to HEAD or a 1-byte range GET."""
    h = {"User-Agent": UA}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h, method="HEAD")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 400
    except urllib.error.HTTPError as e:
        if e.code in (403, 405, 416):
            # host is alive; HEAD is just refused — try a 1-byte GET
            h["Range"] = "bytes=0-0"
            req = urllib.request.Request(url, headers=h)
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    return 200 <= resp.status < 400
            except Exception:
                return False
        return False
    except Exception:
        return False
