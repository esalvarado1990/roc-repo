# -*- coding: utf-8 -*-
"""
rocplay well core — the DOOR SYSTEM (Door Doctrine build, 2026-11-02).

Eric's order (2026-11-02 19:53): "Add a few doors. Add a few of our own
doors. Put a real decoy door in there which serves a purpose, multiple
purpose. But put some hidden ones in there too. We need more than one
door." Plus the all-directions addendum (19:54): exit doors, entrance
doors, both-ways, above, underneath.

Design law carried over (Eric, 2026-10-26 02:16):
  * Ask every FRONT door at the same time — never one, never in sequence.
  * A dry or dead door drops off silently; the screen never breaks.
  * Every door is WATCHED: health record per door in the addon data dir.

The tiers:
  FRONT doors — asked on every play, in parallel (ENTRANCE):
    VixSrc    role DECOY — the famous front door. A real, working well
              that also takes the heat/attention/rate-limits.
    Movy      the wecollege protocol, re-derived from Cinema HQ's DEX.
    VidZee    core.vidzee.wtf, selector recovered from Cinema HQ's DEX.
    VidMario  api.vidmario.net — 111movies' own current service.
  RESERVE doors — the hidden tier (UNDERNEATH), engaged ONLY when the
  front set returns total zero (tonight's no_sources case). They stay
  un-burned and off the visible list; their results are still logged
  when they fire — receipts beat secrecy inside our own logs:
    VidSrc    the full token chain (single-use, IP-bound JWTs — the
              expensive door; reserve keeps it un-burned).
    MP4Hydra  slug-keyed JSON API, held back by doctrine.

Directions:
  EXIT — every well_result carries a verdict classified from the
  well's own stage evidence (stagelog): "sources", "answered_zero"
  (every hop answered, shelf empty — the window on this exit is shut),
  or "no_answer" (transport failure / window timeout — door trouble).
  fanout_done carries exit_window_suspect=true when ALL front doors
  answered_zero: the Nov 2 signature (VixSrc zeroed from a verified NL
  exit on .161 while serving on .159). A signal, not a verdict.
  BOTH-WAYS — the wells verify their own candidates before returning
  them (content-sniffed playlists, ranged ftyp checks).
  ABOVE — browser-grade fallback path: mapped in the door report,
  deliberately not implemented in this build.

SPEED PASS (2026-11-16, Eric 19:31 — Rudolph on Jama sat at
"content loading" 30-40 s before playing): the old fan-out asked
every door and then waited for EVERY door (or the full window)
before returning the pour, so one hanging dead well held playback
hostage even with good sources already in hand. Two changes:

  * HEALTH GATE — the house source watch (source-watch guard,
    240 s sweeps) classes every source up/down, but its state lives
    on the VM where the resolver cannot read it. The smallest
    stick-side cache carries the verdicts to the stick:
    `source_health_cache.json` in this addon's data dir,
    {"v": 1, "ts": <epoch>, "up": [well NAMEs], "down": [well NAMEs]}
    (~150 bytes; writer spec in the lane REPORT — the guard pushes
    it on change; a missing cache is a normal state, not an error).
    With a FRESH cache the fan-out skips wells classed down, under
    three guard rails: (1) this stick's own success for a well
    inside LOCAL_OK_TRUST_S outranks the remote verdict (the guard
    watches from the VM's exit, not the stick's — the Nov 2
    exit-window divergence); (2) the gate may thin a tier but never
    empty it — an all-down cache is distrusted for that tier and
    every well is asked; (3) a missing/stale/corrupt cache opens
    the gate entirely (the pre-pass full walk). This supersedes
    the 2026-11-02 "health orders but never excludes" line for the
    ASK SET only, on Eric's direct order; health still never
    excludes a well from the merged sort or the try ladder once
    asked and answered.
  * EARLY RETURN — once the pour holds sources, the set stops
    waiting after EARLY_GRACE_S unless a still-pending well
    OUTRANKS the best well already in hand (a pending Movy is
    worth waiting for; a pending VidMario is not worth 40 s).
    Cut wells are logged as verdict "cut", never as failures —
    we stopped waiting, we did not learn the well is bad. With
    ZERO sources in hand the full window still runs (Nov 3: the
    only sources once arrived at +43 s; a zero-in-hand cut would
    resurrect that nothing-plays failure).

  * SECOND POUR (fix lane 2026-11-17, from the .159 wells/VPN
    diagnosis): the early return + front-only reserve rule had a
    hole — a THIN pour (1-2 sources in hand) was declared complete,
    the reserve tier never engaged, the cut wells were never
    re-asked, and when the thin pour's sources each died in their
    start window the play ended all_failed with live answers still
    in flight (Rudolph on .159, Nov 16-17: VidZee's source landed
    at +111 s, after the failure had already been declared; Allen
    and The Love Bug died the same way the next day). The pool
    threads behind cut/timed-out wells keep running after
    _run_set returns, so fanout() now RETAINS their futures, and
    second_pour() — called by the player only after every in-hand
    source has failed — (1) re-joins those still-running asks,
    bounded by SECOND_POUR_REJOIN_S, and (2) engages the reserve
    tier if fanout() never did. Health-gate-skipped wells stay
    skipped (the gate is a standing guard rail, not a cut), and
    user-disabled wells stay off.
"""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutTimeout

import stagelog
from wells import movy, mp4hydra, vidmario, vidsrc, vidzee, vixsrc

FRONT_WELLS = [vixsrc, movy, vidzee, vidmario]
RESERVE_WELLS = [vidsrc, mp4hydra]
WELLS = FRONT_WELLS  # compat: the front set is "the wells" day to day
# Trusted-provider rank for the merged sort (SKIN PASS PUSH,
# 2026-11-12). Eric's standing source order — the SOURCE PROBLEMS
# protocol (2026-11-02) is Movy first, then the full trusted set —
# plus his walkthrough words (2026-11-12): "if they could sort
# them by the most recommended source or link". Before this, the
# merged order was well health then quality only, so a healthy
# VidZee could sit above Movy in both the picker and the autoplay
# ladder. Rank now leads; health and quality still order sources
# inside each provider.
TRUSTED_RANK = {"movy": 0, "vixsrc": 1, "vidzee": 2,
                "vidmario": 3, "vidsrc": 4, "mp4hydra": 5}
FANOUT_WINDOW = 45   # seconds; raised 2026-11-03 (Joe finish, 0.2.3):
                     # Nov 3 11:15 on .161 the front wells answered at
                     # +27s (VixSrc), +34s (VidZee), +43s (Movy) — all
                     # past the old 20s window, so the fanout recorded
                     # front_total_zero and played nothing even though
                     # sources existed. as_completed returns early when
                     # every well answers, so the fast case is unharmed.
RESERVE_WINDOW = 90  # seconds; raised with it (0.2.3): the VidSrc
                     # multi-hop WASM chain measured ~83s from reserve
                     # start on Nov 3 (11:15:43 -> done 11:17:06).
SECOND_POUR_REJOIN_S = 120  # seconds; the second pour's re-join
                     # budget for wells cut by the early return. The
                     # .159 evidence (2026-11-16) is a cut VidZee
                     # answer landing at +111 s from fan-out start —
                     # the budget must clear that with margin, and
                     # on a rested stick the same wells answer in
                     # tens of seconds (lifetime averages there:
                     # VidZee ~26 s).
HEALTH_CACHE_FILE = "source_health_cache.json"  # in the addon data
                     # dir, next to well_health.json (SPEED PASS).
HEALTH_CACHE_TTL_S = 900   # 15 min: the guard sweeps every 240 s, so
                     # a fresh cache is at most ~4 sweeps old; the TTL
                     # tolerates missed pushes + clock skew, and past
                     # it the gate opens rather than trusting a ghost.
LOCAL_OK_TRUST_S = 1800    # 30 min: a success THIS stick recorded
                     # inside this window outranks a cache "down".
EARLY_GRACE_S = 8          # after the first source lands, siblings
                     # get this long to join the pour before the set
                     # stops waiting (rank-aware: see _run_set).
POLL_S = 0.25              # _run_set polls completions in slices
                     # this size so the cut/window conditions are
                     # re-evaluated promptly (an as_completed call
                     # with a long timeout holds its iteration open
                     # until every future finishes or the whole
                     # timeout expires — the first build of this pass
                     # polled that way and the early return never
                     # fired; caught by the lane's offline suite).


def _classify(name, count, timed_out):
    """Evidence-based verdict for one well's run (see module docstring)."""
    if count > 0:
        return "sources"
    if timed_out:
        return "no_answer"
    if stagelog.evidence(name) == "transport":
        return "no_answer"
    return "answered_zero"


class WellCore(object):
    def __init__(self, store_dir):
        self.store_dir = store_dir
        self._lock = threading.Lock()
        try:
            os.makedirs(store_dir, exist_ok=True)
        except Exception:
            pass
        self.health_path = os.path.join(store_dir, "well_health.json")
        self.events_path = os.path.join(store_dir, "rocplay_events.jsonl")
        self.health = self._load_health()
        # SECOND POUR state (per fanout() call): futures of wells
        # still answering when their set stopped waiting, and
        # whether the reserve tier already ran for this play.
        self._inflight = {}
        self._reserve_ran = False
        # AVAILABILITY state (zero-source shelf lane, 2026-11-17):
        # the last pour's verdicts, exposed for the availability
        # check in default.py — a shelf verdict of "zero working
        # sources" may only be stamped from a COMPLETE pour (every
        # asked well definitively answered), and completeness is
        # read off these dicts, never inferred from timings.
        # Additive only: no pour behaviour reads them.
        self.last_fanout = None
        self.last_second_pour = None

    # ------------------------------------------------------------ io
    def _load_health(self):
        try:
            with open(self.health_path, "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_health(self):
        try:
            tmp = self.health_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(self.health, f)
            os.replace(tmp, self.health_path)
        except Exception:
            pass

    def event(self, kind, **fields):
        """Flight-recorder line (roll-in item 4): one JSON object per
        event, appended locally. Nothing leaves the device."""
        rec = {"ts": round(time.time(), 3), "kind": kind}
        rec.update(fields)
        try:
            with self._lock:
                with open(self.events_path, "a") as f:
                    f.write(json.dumps(rec) + "\n")
        except Exception:
            pass
        return rec

    # ------------------------------------------------------------ health
    def _record(self, name, ok, ms, count, tier=None):
        with self._lock:
            h = self.health.setdefault(
                name, {"ok": 0, "fail": 0, "last_ok": 0, "avg_ms": 0})
            if tier:
                h["tier"] = tier
            if ok:
                h["ok"] += 1
                h["last_ok"] = time.time()
            else:
                h["fail"] += 1
            h["avg_ms"] = int((h.get("avg_ms", 0) * 4 + ms) / 5)
            h["last_count"] = count
            self._save_health()

    def score(self, name):
        """Higher = healthier. Used ONLY for ordering. (Exclusion
        from the ask set is the health gate's job — _gate below —
        driven by the watch's cache, not by this score.)"""
        h = self.health.get(name) or {}
        ok, fail = h.get("ok", 0), h.get("fail", 0)
        if ok + fail == 0:
            return 0.5  # unknown wells start mid-pack
        return ok / float(ok + fail)

    # ------------------------------------------------------- health gate
    def _health_cache(self):
        """The source watch's verdicts as delivered to this stick.
        Returns (state, up, down, age_s): state is "fresh" only when
        the file parses and its stamp is inside HEALTH_CACHE_TTL_S;
        "stale" / "missing" / "corrupt" all leave the gate open."""
        path = os.path.join(self.store_dir, HEALTH_CACHE_FILE)
        try:
            with open(path, "r") as f:
                data = json.load(f)
            ts = float(data.get("ts") or 0)
            if not ts:
                return "corrupt", set(), set(), None
            age = time.time() - ts
            if age < 0:
                age = 0  # clock skew: a future stamp is fresh, not stale
            up = set(str(n).lower() for n in (data.get("up") or []))
            down = set(str(n).lower() for n in (data.get("down") or []))
            state = "fresh" if age <= HEALTH_CACHE_TTL_S else "stale"
            return state, up, down, int(age)
        except Exception:
            return "missing", set(), set(), None

    def _gate(self, wells, cache, disabled=frozenset()):
        """F5 (fleet catch-up 2026-11-16): wells the user switched
        OFF in Roc Play's settings are cut before anything else -
        absolutely, not subject to the cache guard rail below
        (turning every well off is the user's explicit choice and
        honestly yields no sources)."""
        """Split one tier into (live, skipped) by the health cache.
        A well is skipped only when the cache is fresh AND classes
        it down AND this stick's own record shows no success for it
        inside LOCAL_OK_TRUST_S. Guard rail: the gate may thin a
        tier but never empty it — if every well would be skipped,
        the cache is distrusted for that tier and all are asked."""
        if disabled:
            off = [w for w in wells if w.NAME.lower() in disabled]
            for w in off:
                self.event("well_cut", well=w.NAME, tier="gate",
                           why="user_off")
            wells = [w for w in wells
                     if w.NAME.lower() not in disabled]
            if not wells:
                return [], off
        state, _up, down, _age = cache
        if state != "fresh" or not down:
            return list(wells), []
        now = time.time()
        live, skipped = [], []
        for w in wells:
            h = self.health.get(w.NAME) or {}
            try:
                last_ok = float(h.get("last_ok") or 0)
            except Exception:
                last_ok = 0
            local_ok = (now - last_ok) <= LOCAL_OK_TRUST_S
            if w.NAME.lower() in down and not local_ok:
                skipped.append(w)
            else:
                live.append(w)
        if not live:
            return list(wells), []
        return live, skipped

    # ------------------------------------------------------------ fan-out
    def _ask(self, well, req, tier):
        stagelog.begin(well.NAME)
        t0 = time.time()
        try:
            sources = well.fetch(req) or []
        except Exception as exc:  # a well must never break the pour
            self.event("well_error", well=well.NAME, tier=tier,
                       error=str(exc)[:200])
            sources = []
        ms = int((time.time() - t0) * 1000)
        for src in sources:
            src.setdefault("well", well.NAME)
            src.setdefault("tier", tier)
        verdict = _classify(well.NAME, len(sources), timed_out=False)
        self._record(well.NAME, bool(sources), ms, len(sources), tier=tier)
        self.event("well_result", well=well.NAME, tier=tier,
                   ok=bool(sources), count=len(sources), ms=ms,
                   verdict=verdict)
        return sources, verdict

    def _run_set(self, wells, req, tier, window_s):
        """One tier of doors, all at once. Returns (merged,
        verdicts, inflight): inflight maps the futures of wells
        still answering when the set stopped waiting to their well
        modules — their pool threads keep running, and the second
        pour re-joins them (see the module docstring).

        SPEED PASS early return: once the pour holds sources, stop
        waiting after EARLY_GRACE_S — unless a still-pending well
        outranks the best well already in hand (rank leads the
        merged sort, so a pending higher-ranked well can still
        improve the ladder's head; a pending lower-ranked one only
        adds depth the grace already gave siblings time to add).
        Wells cut this way get verdict "cut" and are NOT recorded
        as failures. With zero in hand the full window runs, as
        before — late answers with the only sources are a
        documented case (Nov 3, +43 s)."""
        merged, verdicts, inflight = [], {}, {}
        pool = ThreadPoolExecutor(max_workers=max(2, len(wells)))
        try:
            futures = {pool.submit(self._ask, w, req, tier): w
                       for w in wells}
            pending = set(futures)
            t0 = time.time()
            deadline = t0 + window_s
            first_hit = None   # when the first source landed
            best_rank = 99     # best trusted rank in hand so far
            while pending:
                now = time.time()
                remaining = deadline - now
                if remaining <= 0:
                    break
                wait = remaining
                if first_hit is not None:
                    better_pending = any(
                        TRUSTED_RANK.get(futures[f].NAME.lower(), 99)
                        < best_rank for f in pending)
                    if not better_pending:
                        wait = min(wait, max(
                            0.0, first_hit + EARLY_GRACE_S - now))
                        if wait <= 0:
                            break  # early cut: pour is good enough
                wait = min(wait, POLL_S)
                try:
                    for fut in as_completed(list(pending), timeout=wait):
                        pending.discard(fut)
                        got, verdict = fut.result() or ([], "answered_zero")
                        verdicts[futures[fut].NAME] = verdict
                        if got:
                            if first_hit is None:
                                first_hit = time.time()
                            rank = TRUSTED_RANK.get(
                                futures[fut].NAME.lower(), 99)
                            if rank < best_rank:
                                best_rank = rank
                        merged.extend(got)
                except FutTimeout:
                    pass  # loop re-evaluates cut / window conditions
            for fut in list(pending):
                w = futures[fut]
                if merged:
                    verdicts[w.NAME] = "cut"
                    self.event("well_cut", well=w.NAME, tier=tier,
                               reason="early_return", verdict="cut")
                else:
                    verdicts[w.NAME] = "no_answer"
                    self.event("well_timeout", well=w.NAME, tier=tier,
                               window_s=window_s, verdict="no_answer")
                    self._record(w.NAME, False, window_s * 1000, 0,
                                 tier=tier)
            inflight = {fut: futures[fut] for fut in pending}
        finally:
            pool.shutdown(wait=False)
        return merged, verdicts, inflight

    def fanout(self, req):
        """Front doors at once; reserve doors only on a front total
        zero. Returns the merged source list, healthiest wells first,
        best quality first inside a well."""
        stagelog.set_sink(self.event)
        self.event("fanout_start", title=req.get("title"),
                   tmdb_id=req.get("tmdb_id"), tmdb_type=req.get("tmdb_type"),
                   season=req.get("season"), episode=req.get("episode"))
        t0 = time.time()
        # Second-pour state is per play: a fresh fan-out starts
        # with nothing in flight and the reserve tier un-run.
        self._inflight = {}
        self._reserve_ran = False
        cache = self._health_cache()
        disabled = frozenset(
            str(n).lower()
            for n in (req.get("disabled_wells") or []))
        front_live, front_skipped = self._gate(FRONT_WELLS, cache,
                                               disabled)
        self.event("health_gate", tier="front", cache=cache[0],
                   cache_age_s=cache[3],
                   live=[w.NAME for w in front_live],
                   skipped=[w.NAME for w in front_skipped])
        merged, front_verdicts, front_inflight = self._run_set(
            front_live, req, "front", FANOUT_WINDOW)
        self._inflight.update(front_inflight)
        reserve_verdicts = {}
        if not merged:
            self._reserve_ran = True
            self.event("reserve_engaged", reason="front_total_zero",
                       title=req.get("title"))
            reserve_live, reserve_skipped = self._gate(
                RESERVE_WELLS, cache, disabled)
            self.event("health_gate", tier="reserve", cache=cache[0],
                       cache_age_s=cache[3],
                       live=[w.NAME for w in reserve_live],
                       skipped=[w.NAME for w in reserve_skipped])
            extra, reserve_verdicts, reserve_inflight = self._run_set(
                reserve_live, req, "reserve", RESERVE_WINDOW)
            self._inflight.update(reserve_inflight)
            merged.extend(extra)
        merged.sort(key=lambda s: (TRUSTED_RANK.get(
            str(s["well"]).lower(), 99),
            -self.score(s["well"]),
            -int(s.get("quality") or 0)))
        exit_window_suspect = bool(front_verdicts) and all(
            v == "answered_zero" for v in front_verdicts.values())
        self.event("fanout_done", sources=len(merged),
                   ms=int((time.time() - t0) * 1000),
                   front=front_verdicts, reserve=reserve_verdicts,
                   exit_window_suspect=exit_window_suspect)
        # AVAILABILITY (zero-source shelf lane): stash the verdicts
        # for default.py's completeness test (see __init__).
        self.last_fanout = {"front": dict(front_verdicts),
                            "reserve": dict(reserve_verdicts),
                            "sources": len(merged)}
        self.last_second_pour = None
        return merged

    def second_pour(self, req, exclude_urls=frozenset()):
        """The second pour (fix lane 2026-11-17; see the module
        docstring). Called by the player ONLY after every source
        from fanout() failed its start window. Two moves, in
        order:

          1. RE-JOIN — await the wells that were still answering
             when their set stopped waiting (cut by the early
             return, or past the window with nothing in hand),
             bounded by SECOND_POUR_REJOIN_S, and collect whatever
             they bring. Their _ask threads have been running the
             whole time; this just stops throwing their answers
             away.
          2. RESERVE — if the reserve tier never ran in fanout()
             (it only runs on a front total zero), run it now,
             gated and windowed exactly as fanout() runs it.

        Returns NEW sources only — anything whose URL is in
        exclude_urls (the first pour's ladder: already tried,
        already failed) or already collected here is dropped —
        sorted by fanout()'s merged key. An empty return means
        the second pour found nothing and the caller declares
        all_failed exactly as it did before this method existed.
        """
        seen = set(exclude_urls or ())
        self.event("second_pour_start", title=req.get("title"),
                   inflight=len(self._inflight),
                   reserve_ran=bool(self._reserve_ran))
        t0 = time.time()
        fresh = []

        def _take(got):
            for src in got or ():
                url = src.get("url")
                if url:
                    if url in seen:
                        continue
                    seen.add(url)
                fresh.append(src)

        # 1. Re-join: poll the still-running asks in slices, so
        # one slow well never blocks the wells behind it.
        deadline = t0 + SECOND_POUR_REJOIN_S
        while self._inflight and time.time() < deadline:
            done = [f for f in self._inflight if f.done()]
            if not done:
                time.sleep(POLL_S)
                continue
            for fut in done:
                well = self._inflight.pop(fut)
                try:
                    got, _verdict = fut.result() or ([], "answered_zero")
                except Exception:
                    got = []
                if got:
                    self.event("second_pour_rejoin", well=well.NAME,
                               count=len(got))
                    _take(got)
        rejoin_timeout = []
        if self._inflight:
            rejoin_timeout = [w.NAME
                              for w in self._inflight.values()]
            self.event("second_pour_rejoin_timeout",
                       wells=rejoin_timeout,
                       window_s=SECOND_POUR_REJOIN_S)
            self._inflight = {}

        # 2. Reserve tier, if fanout() never engaged it.
        reserve_verdicts = {}
        if not self._reserve_ran:
            self._reserve_ran = True
            self.event("reserve_engaged", reason="second_pour",
                       title=req.get("title"))
            cache = self._health_cache()
            disabled = frozenset(
                str(n).lower()
                for n in (req.get("disabled_wells") or []))
            reserve_live, reserve_skipped = self._gate(
                RESERVE_WELLS, cache, disabled)
            self.event("health_gate", tier="reserve", cache=cache[0],
                       cache_age_s=cache[3],
                       live=[w.NAME for w in reserve_live],
                       skipped=[w.NAME for w in reserve_skipped])
            extra, reserve_verdicts, reserve_inflight = self._run_set(
                reserve_live, req, "reserve", RESERVE_WINDOW)
            self._inflight.update(reserve_inflight)
            _take(extra)

        fresh.sort(key=lambda s: (TRUSTED_RANK.get(
            str(s["well"]).lower(), 99),
            -self.score(s["well"]),
            -int(s.get("quality") or 0)))
        self.event("second_pour_done", sources=len(fresh),
                   ms=int((time.time() - t0) * 1000),
                   reserve=reserve_verdicts)
        # AVAILABILITY (zero-source shelf lane): a non-empty
        # rejoin_timeout means at least one asked well never
        # answered even inside the re-join budget — the pour is
        # NOT complete and no zero verdict may be stamped from it.
        self.last_second_pour = {"reserve": dict(reserve_verdicts),
                                 "rejoin_timeout": rejoin_timeout}
        return fresh
