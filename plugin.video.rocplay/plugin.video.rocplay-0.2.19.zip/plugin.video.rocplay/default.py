# -*- coding: utf-8 -*-
"""
plugin.video.rocplay — the Roc OS playback chain (next version).

WHY THIS EXISTS (Dell pre-test 2026-10-25, REPORT.md §7/§9): the
shipped route — poster -> TMDb Helper player template -> Scrubs/Crew
— is dead at two seams: TMDb Helper 5.4.16 executes single-step
player templates WITHOUT substituting {title}/{year}/{imdb}/{tmdb}
(see the contract test in nextver/tests/), and both downstream
players scrape to zero / die silently. Roc OS now owns the chain:

  * SAME entry contract as the old players, so TMDb Helper and
    rocui can drive it identically:
      ?action=play&title&year&imdb&tmdb[&tvshowtitle&season&episode
      &premiered][&auto=1]
  * Asks EVERY well at once (wellcore), merges the pour, watches
    each well's health (roll-in item 29).
  * NO SOURCE PICKING by default (Eric's law, 2026-11-01): PLAY
    resolves the best working source itself and starts playback;
    the merged source list picker appears ONLY when the addon's
    "choose_source" setting is ON (default OFF). auto=1 (August's
    profile, resume flows) still forces no dialog. (The gate was
    dropped in 0.2.4, leaving the bare auto flag as the only thing
    between Eric and the picker; restored in 0.2.6, player lane
    2026-11-12.)
  * ESSENTIALS ONLY (Eric, 2026-11-12): no foreign-addon fallback
    floor (the Scrubs V2 / The Crew entries are gone from the
    picker and from the end of the ladder), no queue, no cache
    features. The path is: find sources -> (picker, if gated on)
    -> play with failover -> an honest toast when nothing works.
  * FAILOVER (roll-in, August's error law §4 + pre-test CARRY §9.3):
    if the chosen source doesn't start and advance within the start
    window, the chain advances to the next source on its own.
  * SECOND POUR (fix lane 2026-11-17, .159 wells diagnosis F1):
    when EVERY in-hand source has failed, the chain does not stop
    at the first pour: wellcore re-joins the wells the fan-out cut
    while they were still answering and engages the reserve tier
    (which the first pour only runs on a front total zero), and
    the new sources walk the same ladder. Nothing new is shown to
    the user — the walk just gets longer. Only a second pour that
    also comes up empty lands in the honest all_failed toast.
  * FAILURE REASONS (same lane, diagnosis F2): every dead source's
    source_failed event now records WHY it died (reason: timeout /
    http_error / no_audio / stalled / player_stopped /
    player_ended / aborted / other, plus the playhead state at
    death) — post-mortems read the cause off the recorder instead
    of inferring it from timing.
  * AVAILABILITY VERDICTS + SOURCE DEATH MARKS (zero-source
    shelf lane, 2026-11-17): every completed pour for a title
    leaves a per-DEVICE verdict (working sources: how many, or a
    proven zero) in the master-profile data dir, where
    script.rocui's shelf filter reads it — a title with zero
    WORKING sources comes off the browse shelves until a re-check
    finds sources again. "Working" discounts sources carrying an
    established death record (negative learning, deep-dive F-10):
    per-title failure marks written by _try_source, with the
    death bar and revival rule in the section below. A dedicated
    action=avail_check runs the same full pour (fanout + second
    pour) for one title and stamps the verdict without playing
    anything. The ladder itself is unchanged: marks never remove
    a source from a pour or a try — a marked source that starts
    clears its own marks (revival), which is how a title earns
    its way back onto the shelf.
  * REMEMBERED SOURCE FIRST (stale-URL fix lane, 2026-11-17):
    rocui's per-title source memory (the URL that played last
    time) used to be replayed by rocui directly, with a start
    verification that walked away after the first seconds — a
    remembered URL whose signature had aged out could start,
    take the resume seek, and die seconds later with nobody
    watching (The Odyssey, Breaking Bad, .159 2026-11-17).
    rocui now hands the URL in as remembered_url and play()
    tries it FIRST, before the fan-out, through _try_source's
    full contract: a fast death is an ordinary source_failed
    (F2 reason + death mark) and the play falls through to the
    full well hunt on its own; a source that plays is a win
    exactly as the direct route was — no fan-out runs first,
    so a healthy remembered play gains no delay.
  * VIDSRC TOKEN LOADER (2026-11-18): a VidSrc source's generate
    token rides only its master URL, and Kodi's ffmpeg demuxer
    does not propagate it to the variant/segment requests the
    stream host then 403s. VidSrc sources therefore play through
    a local playlist-rewriting proxy (resources/lib/
    tokenloader.py) that stamps the token + the well's
    Referer/UA onto every sub-request — the site's own
    TokenLoader contract — and play() holds the plugin alive on
    a token-loader win until the player leaves the file, so the
    proxy outlives every playlist re-read (seeks included).
  * RESUME FAILOVER (0.2.19, 2026-11-18): a source can be
    healthy for linear play and still die ON the resume seek —
    proven on .155 with the Movy goldenkite 2160p HLS stream,
    which plays cleanly through the resume region but EOFs
    ~1 s after ANY seek landing from this exit (controlled lone
    seek, no addon involvement). The hold loop's
    resume_hold_player_stopped outcome therefore fails the
    play over to the next source in the same fan-out order and
    re-applies the SAME checkpoint there — Eric's day-1
    autoplay law applied to resume (press play walks down the
    line itself). Bounded by the source line exactly like
    normal autoplay (remembered leg, first pour, second pour;
    no loops); every step is flight-recorded (resume_failover /
    resume_failover_recovered / resume_failover_exhausted).
    If the whole line dies on the seek the play stops cleanly
    with an honest toast — and NO source picker ever comes out
    of this path (the picker law is unchanged: only a
    whole-line PLAY failure may show one, and never on August).
  * Every step is written to the flight recorder (roll-in item 4):
    addon_data/plugin.video.rocplay/rocplay_events.jsonl.
  * The playing ListItem carries title/year/season/episode +
    IMDb/TMDB unique IDs, so script.rocui's service keeps doing
    history/resume/continue-watching exactly as before.
"""
import json
import os
import re
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "resources", "lib"))
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import tokenloader
import wellcore

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
START_WINDOW_S = 30      # a source that hasn't advanced by now is dead.
# FIX BATCH 2026-11-10: was 90. A dead source burned the FULL window
# even when its player died in the first second (demuxer death fires
# onPlayBackStopped, never onPlayBackFailed/Ended), so a 12-source
# cascade could sit on "Content Loading" for ~18 minutes (bedroom
# stick, 2026-11-10 21:18-21:36 logcat). Healthy sources prove
# advance in ~19 s; 30 s is generous headroom, and the stopped-break
# in _try_source now ends a try at the death itself.
                         # 60 originally (not 20): cold first contact
                         # with a well's edge CDN (fresh DNS + TLS to
                         # rotating hosts) measured 19s+ in Kodi's
                         # demuxer on the Dell while every hop answered
                         # curl in <1.5s; warm starts land in ~5s.
                         # Raised to 90 (2026-10-27, Eric-delegated
                         # decision): the resume leg needs TWO cold
                         # starts and VixSrc's latency tail crosses
                         # 60 — diag4's reopen was stamped
                         # source_failed at exactly +60s while sibling
                         # tries that night visibly rolled past the
                         # mark. Per-path budgets (resume-only 120)
                         # are unclean here: this window sits behind
                         # the single TMDBH player definition, and the
                         # resume reopen is built by rocui from its
                         # stored snapshot through that same
                         # definition — no per-invocation channel
                         # reaches the reopen without also moving
                         # first plays. So the window moves globally,
                         # per the decision's fallback. Cost: a truly
                         # dead source now bounds failover at 90s.
ADVANCE_CHECK_S = 6      # ...checked this long after first frame

# --- AUTO-TAILOR ceiling (Phase 2 spec, door-build-20261102.md) -----
# Light tier (AFTSSS / mt8695-class, ~1 GB RAM, 1080p-capped panel):
# sources above 1080p are removed from the ladder AND the picker.
# The 2160p lead killed Kodi on this chassis twice in one night
# (door-build F3 on .159; fleet lane A Dune pick 1 on .161). Eric,
# Nov 2 23:16: "take 4k out — all he needs is 1080." Detection is
# per-device at runtime: ro.product.model (best effort, build.prop)
# + MemTotal from /proc/meminfo. Only a source with a POSITIVE
# >1080p signal (label text / URL marker) is dropped — a source
# with no readable resolution signal stays.
CAP_LIGHT_MEM_KB = 1100 * 1024   # ~1.1 GB
_CAP_LABEL_RE = re.compile(r"(?i)\b(2160p?|4k|uhd)\b")
_CAP_URL_RE = re.compile(r"(?i)(2160p|s2160|2160x|[-_/]2160[-_/])")


def _read_text(path):
    try:
        fh = xbmcvfs.File(path)
        try:
            data = fh.read()
        finally:
            fh.close()
        if isinstance(data, bytes):
            data = data.decode("utf-8", "replace")
        return data or ""
    except Exception:
        pass
    try:
        with open(path, "r") as fh:
            return fh.read()
    except Exception:
        return ""


def _infolabel_mem_kb():
    """Total RAM via Kodi's own memory InfoLabels (fallback when
    /proc/meminfo is not readable from inside the addon — Android
    app sandboxes can deny it). 0 when the labels don't parse."""
    total = 0
    for name in ("free", "used"):
        try:
            raw = xbmc.getInfoLabel("System.Memory(%s)" % name) or ""
        except Exception:
            return 0
        m = re.match(r"\s*([\d.]+)\s*(GB|MB|kB|KB|B)", raw)
        if not m:
            return 0
        val = float(m.group(1))
        unit = m.group(2).upper()
        total += int(val * {"GB": 1048576, "MB": 1024,
                            "KB": 1, "B": 0}.get(unit, 0) if unit != "B"
                     else val // 1024)
    return total


def _device_class():
    """(model, mem_total_kb, is_light_tier, probe) for THIS device.
    probe carries the raw read lengths so a silent detection
    failure is visible in the flight recorder instead of hiding."""
    prop = _read_text("/system/build.prop")
    model = ""
    for line in prop.splitlines():
        if line.startswith("ro.product.model="):
            model = line.split("=", 1)[1].strip()
            break
    meminfo = _read_text("/proc/meminfo")
    mem_kb = 0
    m = re.search(r"MemTotal:\s+(\d+)\s*kB", meminfo)
    if m:
        mem_kb = int(m.group(1))
    mem_src = "meminfo" if mem_kb else ""
    if not mem_kb:
        mem_kb = _infolabel_mem_kb()
        mem_src = "infolabel" if mem_kb else ""
    light = (model == "AFTSSS") or (0 < mem_kb <= CAP_LIGHT_MEM_KB)
    probe = {"prop_len": len(prop), "meminfo_len": len(meminfo),
             "mem_src": mem_src}
    return model, mem_kb, light, probe


def _over_cap(source):
    """True only on a positive >1080p signal. Three arms, in the
    order the wells actually carry them:
      1. source['quality'] — the well's own numeric height (Movy
         carries it; its label is just 'Movy' and its CDN URL need
         not carry a marker, so this arm is load-bearing).
      2. Label text (2160p / 4K / UHD).
      3. URL markers (s2160p, rendition=2160, /2160/ ...).
    A source with no readable signal in any arm STAYS."""
    q = source.get("quality")
    if isinstance(q, (int, float)):
        if q > 1080:
            return True
    elif isinstance(q, str):
        digits = "".join(ch for ch in q if ch.isdigit())
        if digits and int(digits) > 1080:
            return True
    if _CAP_LABEL_RE.search(source.get("label") or ""):
        return True
    return bool(_CAP_URL_RE.search(source.get("url") or ""))


def _store_dir():
    # xbmc.translatePath was removed in Kodi 21 (Omega) — it lives in
    # xbmcvfs since Kodi 19. The legacy call crashed every in-Kodi
    # play() at WellCore construction (Dell trunk battery 2026-10-26:
    # AttributeError in kodi.log, no fan-out ever ran).
    return xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def _params():
    q = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    return {k: v[0] for k, v in urllib.parse.parse_qs(q).items()}


# TOKEN LOADER (2026-11-18): the local URL of the VidSrc source
# that won the current play, if any. Set by _try_source at the
# win, consumed and cleared by _hold_token_proxy in play().
_TOKEN_WINNER_URL = None


def _play_url(source):
    """Kodi pipe-header format so the CDN sees the headers the well
    recipe requires (Referer / User-Agent).

    TOKEN LOADER (2026-11-18): a VidSrc source's URL carries the
    generate token on the master only, and Kodi's ffmpeg demuxer
    does not propagate it to the variant/segment requests (which
    the stream host then 403s — see tokenloader.py). Route those
    sources through the local playlist-rewriting proxy, which
    stamps every sub-request the way the site's own TokenLoader
    does. A failure to open the proxy session falls back to the
    raw URL — exactly the pre-loader behaviour."""
    url = source["url"]
    if str(source.get("well") or "") == "VidSrc":
        try:
            local = tokenloader.open_session(
                url, source.get("headers") or {})
        except Exception:
            local = None
        if local:
            url = local
    hdrs = source.get("headers") or {}
    if hdrs:
        url += "|" + "&".join(
            "%s=%s" % (k, urllib.parse.quote(str(v), safe=""))
            for k, v in hdrs.items())
    return url


def _listitem(req, source=None):
    li = xbmcgui.ListItem(label=req.get("title") or "Play")
    info = {"title": req.get("title") or "",
            "year": int(req.get("year") or 0),
            "mediatype": "episode" if req.get("tmdb_type") == "tv" else "movie"}
    if req.get("tmdb_type") == "tv":
        info.update({"tvshowtitle": req.get("showtitle") or req.get("title") or "",
                     "season": int(req.get("season") or 0),
                     "episode": int(req.get("episode") or 0)})
        if req.get("premiered"):
            info["premiered"] = req["premiered"]
    li.setInfo("video", info)
    ids = {}
    if req.get("imdb"):
        ids["imdb"] = str(req["imdb"])
    if req.get("tmdb_id"):
        ids["tmdb"] = str(req["tmdb_id"])
    if ids:
        li.setUniqueIDs(ids, "imdb" if "imdb" in ids else "tmdb")
    return li


class _ChainPlayer(xbmc.Player):
    def __init__(self):
        super(_ChainPlayer, self).__init__()
        self.failed = False
        self.ended = False
        self.stopped = False

    def onPlayBackFailed(self):
        self.failed = True

    def onPlayBackError(self):
        self.failed = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackStopped(self):
        # FIX BATCH 2026-11-10: a demuxer death (playlist verified,
        # segments dead) ends the player WITHOUT firing Failed or
        # Ended — Stopped is the only callback it sends (measured on
        # the test stick, kodi.log 2026-11-10 21:37:34). Without this
        # the try loop below waited out the whole start window on a
        # corpse.
        self.stopped = True


def _audio_present(player):
    """True when the playing item has at least one audio stream.
    Polls for up to ~4 s (0.5 s steps). A probe that errors reads as
    PRESENT - the gate may only fail a source on positive evidence
    of silence, never on a broken probe."""
    import json as _json
    for _i in range(9):
        try:
            streams = player.getAvailableAudioStreams()
            if streams:
                return True
        except Exception:
            pass
        try:
            raw = xbmc.executeJSONRPC(_json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "Player.GetProperties",
                "params": {"playerid": 1,
                           "properties": ["audiostreams"]}}))
            props = (_json.loads(raw).get("result") or {})
            if props.get("audiostreams"):
                return True
        except Exception:
            return True
        if _i < 8:
            xbmc.Monitor().waitForAbort(0.5)
    return False


def _try_source(core, req, source):
    """Play one source; True only when playback starts AND the
    playhead advances (the trunk program's definition of 'plays')."""
    global _TOKEN_WINNER_URL
    core.event("source_try", well=source["well"], label=source["label"],
               url=source["url"][:160])
    player = _ChainPlayer()
    monitor = xbmc.Monitor()
    play_url = _play_url(source)
    # TOKEN LOADER (2026-11-18): when this try plays through the
    # playlist proxy, a failure closes the session on the spot
    # (in _fail, which every failure exit passes through exactly
    # once); a win hands the session to play()'s hold.
    token_url = play_url.split("|")[0] \
        if tokenloader.is_local_url(play_url) else None
    if token_url:
        core.event("token_loader", well=source["well"],
                   label=source["label"])
    player.play(play_url, _listitem(req, source))
    elapsed = 0.0
    first_time = None
    started = False
    last_t = None

    def _fail(reason, playhead=None):
        # TOKEN LOADER (2026-11-18): this try is dead — its proxy
        # session dies with it, so a dead source never leaves a
        # stamped session (or the proxy server) lingering.
        if token_url:
            tokenloader.close_url(token_url)
        # F2 (fix lane 2026-11-17, .159 wells diagnosis): a dead
        # source says WHY it died. Until now source_failed carried
        # no reason, so every post-mortem had to infer the cause
        # from timing alone (the Rudolph deaths: was the +30.0 s
        # failure a stall, an edge refusal, a slow demux? —
        # unanswerable from the record). started/playhead carry
        # the player state at the moment of death.
        core.event("source_failed", well=source["well"],
                   label=source["label"], reason=reason,
                   elapsed_s=round(elapsed, 1), started=started,
                   playhead=(None if playhead is None
                             else round(float(playhead), 1)))
        # DEATH MARK (zero-source shelf lane, 2026-11-17): the
        # failure joins this source's per-title record — the
        # negative-learning memory the shelf's working-source
        # count reads. An abort is the user/system walking away,
        # never the source's fault, so it is not marked.
        if reason != "aborted":
            _mark_failure(req, source, reason)

    while elapsed < START_WINDOW_S:
        if monitor.abortRequested() or player.failed:
            break
        if player.isPlayingVideo():
            try:
                t = player.getTime()
            except Exception:
                t = 0
            started = True
            last_t = t
            if first_time is None:
                first_time = (elapsed, t)
            elif elapsed - first_time[0] >= ADVANCE_CHECK_S:
                ok = t > first_time[1]
                if not ok:
                    core.event("source_stalled",
                               well=source["well"], label=source["label"],
                               advanced=False)
                    _fail("stalled", playhead=t)
                    return False
                # AUDIO-PRESENCE GATE (fleet catch-up 2026-11-16,
                # Eric 20:06): a source that starts video with NO
                # audio stream is a FAILED source (the MobLand
                # failure: a video-only encode played mute). Poll
                # briefly - some demuxers publish the audio stream a
                # beat after the picture - then walk the ladder.
                if not _audio_present(player):
                    core.event("source_no_audio",
                               well=source["well"], label=source["label"])
                    _fail("no_audio", playhead=t)
                    try:
                        player.stop()
                    except Exception:
                        pass
                    return False
                core.event("source_ok",
                           well=source["well"], label=source["label"],
                           advanced=True)
                # REVIVAL (zero-source shelf lane): a source that
                # starts — playing, advancing, audible — clears
                # its own death record on the spot. This is the
                # only revival: merely being listed by a well
                # again proves nothing (wells re-list dead links
                # as a matter of routine — the memoryless-ladder
                # problem, deep-dive F-10).
                _mark_success(req, source)
                # TOKEN LOADER (2026-11-18): a proxied win keeps
                # its session — play() holds the proxy alive for
                # exactly this playback (see _hold_token_proxy).
                if token_url:
                    _TOKEN_WINNER_URL = token_url
                return True
        if player.ended and elapsed > 2:
            break
        if player.stopped and elapsed > 2:
            # Player died without failing/ending (demuxer death) —
            # the source is dead NOW, not at the window's end.
            break
        monitor.waitForAbort(0.5)
        elapsed += 0.5
    if monitor.abortRequested():
        _fail_reason = "aborted"
    elif player.failed:
        # Kodi refused/failed the open itself (the HTTP-error
        # class: 403/404/edge refusal surfaces here, not as a
        # timeout).
        _fail_reason = "http_error"
    elif player.ended:
        _fail_reason = "player_ended"
    elif player.stopped:
        _fail_reason = "player_stopped"
    elif elapsed >= START_WINDOW_S:
        _fail_reason = "timeout"
    else:
        _fail_reason = "other"
    _fail(_fail_reason, playhead=last_t)
    try:
        player.stop()
    except Exception:
        pass
    return False


class _Busy(object):
    """xbmcgui.DialogBusy was removed in Kodi 21 (Omega) — the busy
    spinner is Kodi's own now. Shim: use the class where it exists,
    no-op where it doesn't. (Second removed-API crash on the play
    path: Dell trunk play re-run 2026-10-26, AttributeError at
    play() before the fan-out could start.)"""

    def __init__(self):
        cls = getattr(xbmcgui, "DialogBusy", None)
        self._dlg = cls() if cls is not None else None

    def create(self):
        if self._dlg is not None:
            self._dlg.create()

    def close(self):
        if self._dlg is not None:
            self._dlg.close()


class _PlayStatus(object):
    """CHAIN FIX (Phase-2 audit, 2026-11-08): the fanout's old modal
    xbmcgui progress dialog ("Roc Play — Finding sources…") is GONE
    from the play path. CHAIN-BLOCK-DIAGNOSIS: raising that modal
    over detail window 1124, ~2 s after a fullscreen teardown and
    while the GUI thread is still completing the PlayMedia plugin
    hand-off, parks the GUI thread — no source is ever attempted
    and the box needs a force-stop. This is the wedge pattern
    (WEDGE-DIAGNOSIS §4) applied to rocplay: never a modal here.

    Replacement, all non-modal:
      * a toast at fanout start, same wording the modal carried
        ("Roc Play" / "Finding sources…") — Dialog().notification()
        is the fire-and-forget KaiToast queue, the same call the
        no-sources / all-failed paths already use below;
      * Window(10000) properties a skin MAY render later (nothing
        in the skin reads them yet; publishing is the whole job):
          RocPlay.Status     finding | playing |
                             no_sources | all_failed | cancelled |
                             fanout_failed
          RocPlay.StatusText human line for the current status
          RocPlay.Title      the title being played
    Failure is still signalled by the pre-existing warning toasts
    on the no_sources / all_failed paths (unchanged); success is
    signalled by playback itself starting."""

    def _publish(self, status, text, req):
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("RocPlay.Status", status)
            win.setProperty("RocPlay.StatusText", text or "")
            win.setProperty("RocPlay.Title",
                            (req or {}).get("title") or "")
        except Exception:
            pass

    def start(self, req):
        self._publish("finding", "Finding sources…", req)
        try:
            xbmcgui.Dialog().notification(
                "Roc Play", "Finding sources…",
                xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass

    def finish(self, status, text, req):
        self._publish(status, text, req)


# --- RESUME CHECKPOINT (fix lane 2026-11-17) -----------------------
# The defect: pressing RESUME on a Continue Watching detail page
# arms rocui's pending seek (script.rocui's pending_seek.json, via
# rocui_playback.detail_resume_play -> rocui_common.seek_arm) and
# then PlayMedia()s the Helper path, which invokes THIS addon. The
# checkpoint was addressed to rocui's service-side applier, but on
# the proven .159 run (kodi.log 2026-11-17 10:21-10:22, Dune Part
# Two, checkpoint 48.294 s) the stream opened and played from ~0
# with no seek attempt logged by anyone: the handoff dropped the
# resume point between rocui and the player. So the player now
# consumes the armed checkpoint ITSELF, at the one moment it knows
# the stream can accept a seek: after _try_source has confirmed
# the winning source is playing AND advancing AND has audio.
# The arm's lifecycle stays rocui's (the service applier remains
# the backstop for non-RocPlay routes and later file changes);
# RocPlay never writes or clears the file. Every failure here is
# non-fatal: worst case is the pre-fix behaviour, playback from
# wherever the playhead is.
RESUME_ARM_MAX_AGE_S = 1200    # mirrors the service applier's expiry
RESUME_MIN_TARGET_S = 10.0     # a checkpoint this small is a start
# RESUME HOLD (play-side fix lane 2026-11-18): after the win, the
# seek is HELD, not just fired. The proven Dune failure shape
# (chooser route, slow HLS spin-up) is a stream that reopens
# mid-start (CloseFile/OpenFile) and throws the playhead back to
# ~0 AFTER a one-shot seek has landed — or before it ever could.
# _apply_resume therefore keeps watching the playhead for a
# bounded window: a landing must HOLD at/past the target, and a
# reset (playhead back near the start after a landing, or the
# playing file swapped while still behind the target) earns a
# re-seek, bounded in count and total time. A plugin invocation
# cannot leave a thread behind, so the hold lives inside the
# call, exactly like _try_source's own start window does.
RESUME_HOLD_S = 60.0           # total hold budget after the win
RESUME_HOLD_TICKS_S = 5        # seconds at/past target = held
RESUME_MAX_RESEEKS = 3         # re-seeks per play, worst case
RESUME_RESET_CEIL_S = 10.0     # a reset lands the playhead ~here


def _norm_title(text):
    """rocui's _norm_show_title rule, duplicated (addons never
    import each other): lower-case, non-alphanumerics -> single
    spaces, stripped."""
    return re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).strip()


def _resume_target(core, req):
    """The armed resume checkpoint for THIS title, in seconds, or
    None. Reads script.rocui's pending_seek.json from the active
    profile's addon data (the same file seek_arm writes and the
    service applier peeks). Title match is the applier's own rule:
    normalised containment either way between the arm's hint and
    this play's display form."""
    try:
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/script.rocui/"
            "pending_seek.json")
        raw = _read_text(path)
        if not raw:
            return None
        data = json.loads(raw)
        if not isinstance(data, dict):
            return None
        target = float(data.get("time") or 0)
        if target <= RESUME_MIN_TARGET_S:
            return None
        age = time.time() - float(data.get("ts") or 0)
        if age < 0 or age > RESUME_ARM_MAX_AGE_S:
            core.event("resume_arm_stale", age=int(age),
                       target=target)
            return None
        hint = _norm_title(data.get("title") or "")
        if hint:
            cands = []
            title = req.get("title") or ""
            show = req.get("showtitle") or ""
            if req.get("tmdb_type") == "tv":
                # Episodes match ONLY in S/E-qualified form: the
                # bare show title would also "match" a DIFFERENT
                # episode's checkpoint (containment either way),
                # and resuming episode 1 at episode 2's spot is a
                # wrongful seek. Every TV arm rocui writes carries
                # the S/E (snapshot_display / "Title S01E02" forms).
                base = show or title
                s, e = req.get("season"), req.get("episode")
                if base and s is not None and e is not None:
                    cands.append("%s s%02de%02d" % (
                        _norm_title(base), int(s), int(e)))
            else:
                cands.append(title)
                if req.get("year"):
                    cands.append("%s %s" % (title, req["year"]))
            ok = False
            for cand in cands:
                c = _norm_title(cand)
                if c and (hint in c or c in hint):
                    ok = True
                    break
            if not ok:
                core.event("resume_arm_other_title",
                           hint=(data.get("title") or "")[:60],
                           title=title[:60])
                return None
        core.event("resume_arm_found", target=target,
                   hint=(data.get("title") or "")[:60])
        return target
    except Exception as exc:
        try:
            core.event("resume_arm_read_failed", error=str(exc)[:120])
        except Exception:
            pass
        return None


def _apply_resume(core, req, target):
    """Seek the now-playing stream to the checkpoint — and HOLD
    it there. Called ONLY after _try_source confirmed playback
    (playing + advancing + audio present), so the stream can
    accept a seek. The first seek confirms by poll as before;
    then the hold loop (RESUME_HOLD_S budget) watches for the
    mid-start reopen reset that stranded the Dune resume on two
    sticks: the playhead landing and then reappearing near the
    start, or the playing file being swapped while still behind
    the target. A detected reset earns a re-seek (bounded by
    RESUME_MAX_RESEEKS); a landing that stays at/past the target
    for RESUME_HOLD_TICKS_S ends the hold early. Every outcome
    is logged to the flight recorder; never raises, never stops
    playback.

    Returns the outcome string (0.2.19 — the resume failover
    walk in play() classifies on it): "held", "already_there",
    "player_stopped" (the player died inside the hold window —
    the stream is dead FOR SEEKING), "exhausted" (re-seeks
    spent, stream still resetting), "unheld" (budget out with a
    landing that never accumulated the ticks), "unconfirmed"
    (no landing ever registered), "aborted", "failed"."""
    try:
        player = xbmc.Player()
        try:
            pos = float(player.getTime())
        except Exception:
            pos = 0.0
        if pos >= target - 10:
            core.event("resume_already_there", target=target,
                       pos=round(pos, 1))
            return "already_there"
        try:
            win_file = player.getPlayingFile() or ""
        except Exception:
            win_file = ""
        player.seekTime(target)
        monitor = xbmc.Monitor()
        started = time.time()
        landed = None
        held_ticks = 0
        reseeks = 0
        last_file = win_file
        exit_why = "budget"
        while time.time() - started < RESUME_HOLD_S:
            if monitor.waitForAbort(1.0):
                exit_why = "abort"
                break
            try:
                if not player.isPlayingVideo():
                    exit_why = "player_stopped"
                    break
                now_pos = float(player.getTime())
            except Exception:
                continue
            try:
                now_file = player.getPlayingFile() or ""
            except Exception:
                now_file = last_file
            if now_pos >= target - 10:
                if landed is None:
                    landed = now_pos
                    core.event("resume_applied", target=target,
                               landed=round(now_pos, 1),
                               title=req.get("title"))
                held_ticks += 1
                if held_ticks >= RESUME_HOLD_TICKS_S:
                    core.event("resume_held", target=target,
                               pos=round(now_pos, 1),
                               reseeks=reseeks)
                    return "held"
            else:
                held_ticks = 0
                reset = False
                if landed is not None \
                        and now_pos <= RESUME_RESET_CEIL_S:
                    reset = True    # landed, then back at the start
                elif now_file and last_file \
                        and now_file != last_file:
                    reset = True    # file swapped while behind
                if reset and reseeks < RESUME_MAX_RESEEKS:
                    reseeks += 1
                    core.event("resume_reseek", target=target,
                               pos=round(now_pos, 1), n=reseeks,
                               title=req.get("title"))
                    try:
                        player.seekTime(target)
                    except Exception:
                        pass
                    landed = None
                elif reset:
                    # Budget spent and the stream threw the
                    # landing away again — nothing more this
                    # call can do; the service appliers keep
                    # their own chase from here.
                    core.event("resume_hold_exhausted",
                               target=target, reseeks=reseeks,
                               title=req.get("title"))
                    return "exhausted"
            if now_file:
                last_file = now_file
        if landed is None:
            core.event("resume_seek_unconfirmed", target=target,
                       title=req.get("title"))
            # 0.2.19: a player that died before any landing
            # registered is still dead FOR SEEKING — the
            # failover walk keys on the outcome, not on which
            # event the hold happened to record.
            if exit_why == "player_stopped":
                return "player_stopped"
            if exit_why == "abort":
                return "aborted"
            return "unconfirmed"
        elif exit_why == "player_stopped":
            # 0.2.18: terminal events for the hold's silent exits.
            # On .155 (2026-11-18) the player EOF'd ~1 s after
            # the landing and the record showed nothing after
            # resume_applied — the diagnosis needed a kodi.log
            # pull. The hold behaved correctly (a dead player
            # cannot be held); it just never said so.
            core.event("resume_hold_player_stopped", target=target,
                       landed=round(landed, 1),
                       after_s=round(time.time() - started, 1),
                       held_ticks=held_ticks, reseeks=reseeks,
                       title=req.get("title"))
            return "player_stopped"
        elif exit_why == "abort":
            core.event("resume_hold_aborted", target=target,
                       landed=round(landed, 1),
                       after_s=round(time.time() - started, 1),
                       held_ticks=held_ticks, reseeks=reseeks,
                       title=req.get("title"))
            return "aborted"
        elif exit_why == "budget":
            core.event("resume_hold_unheld", target=target,
                       landed=round(landed, 1),
                       held_ticks=held_ticks, reseeks=reseeks,
                       title=req.get("title"))
            return "unheld"
        return "unconfirmed"
    except Exception as exc:
        try:
            core.event("resume_seek_failed", target=target,
                       error=str(exc)[:120])
        except Exception:
            pass
        return "failed"


def _drop_token_win():
    """TOKEN LOADER (0.2.19): close and forget any proxy
    session a win was holding (see _hold_token_proxy). Used
    when the win dies on the resume seek and the chain walks
    on — the dead source's session must not linger, and the
    next win's session takes the slot."""
    global _TOKEN_WINNER_URL
    url = _TOKEN_WINNER_URL
    _TOKEN_WINNER_URL = None
    if url:
        try:
            tokenloader.close_url(url)
        except Exception:
            pass


def _resume_outcome(core, req, target, source, seek_deaths):
    """RESUME FAILOVER (0.2.19): apply the armed checkpoint on
    a fresh win and classify the result for the failover walk.

    Returns True when this play is DONE — playback continues on
    this source (held, already there, alive but unheld, or the
    user aborted: autoplay law, never break a live start over
    a resume). Returns False only when the player DIED inside
    the hold window: that stream is dead FOR SEEKING, so the
    chain walks to the next source and re-applies the SAME
    checkpoint there (the keyed applier applies it once per
    arm+file, exactly as on the first win). Every step is
    flight-recorded: resume_failover when a source dies on the
    seek; resume_failover_recovered when a later source's
    resume survives after one or more seek deaths."""
    outcome = _apply_resume(core, req, target)
    if outcome == "player_stopped":
        core.event("resume_failover", target=target,
                   from_well=source.get("well"),
                   from_label=source.get("label"),
                   title=req.get("title"))
        _drop_token_win()
        return False
    if seek_deaths:
        core.event("resume_failover_recovered", target=target,
                   well=source.get("well"),
                   label=source.get("label"),
                   outcome=outcome, seek_deaths=seek_deaths,
                   title=req.get("title"))
    return True


def _hold_token_proxy(core, req):
    """TOKEN LOADER (2026-11-18): the playlist proxy lives in THIS
    process, and play() normally returns the moment a source is
    confirmed playing — which would take the proxy down with it
    and strand every later playlist re-read (seeks, variant
    re-opens). On a token-loader win, hold the plugin alive until
    the player leaves the proxied file — playback ends, the user
    stops it, or another file takes over — then close the
    session. A no-op for every other play: nothing here runs
    unless _try_source marked a proxied winner."""
    global _TOKEN_WINNER_URL
    url = _TOKEN_WINNER_URL
    _TOKEN_WINNER_URL = None
    if not url:
        return
    core.event("token_hold_start", title=req.get("title"))
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    idle = 0
    try:
        while not monitor.abortRequested():
            try:
                playing_file = player.getPlayingFile() or ""
            except Exception:
                playing_file = ""
            if playing_file and playing_file != url:
                break  # another file took over the player
            try:
                playing = bool(player.isPlaying())
            except Exception:
                playing = False
            if playing:
                idle = 0
            else:
                idle += 1
                if idle >= 3:
                    break  # stopped / ended and not replaced
            if monitor.waitForAbort(1.0):
                break
    finally:
        tokenloader.close_url(url)
        core.event("token_hold_end", title=req.get("title"))


def _picker_enabled():
    """The source picker is opt-in only (Eric, 2026-11-01): it may
    appear solely when the 'choose_source' addon setting is ON.
    Default (setting absent or OFF) = picker can never appear and
    PLAY goes straight to the best working source. Any read failure
    also lands on OFF — the gate fails closed, never open.
    (Restored 0.2.6 from the Joe-era loop82 build; 0.2.4 had dropped
    the gate entirely.)"""
    try:
        return bool(ADDON.getSettingBool("choose_source"))
    except Exception:
        return (ADDON.getSetting("choose_source") or "").lower() == "true"


# F5 (fleet catch-up 2026-11-16): per-well user switches from the
# add-on's own settings (Roc Settings -> Sources). Default/absent =
# ON. An OFF well is handed to the fan-out as disabled and is never
# attempted. VidFast is not listed - it stays banned, not optional.
_WELL_TOGGLES = (("well_movy", "movy"), ("well_vixsrc", "vixsrc"),
                 ("well_vidzee", "vidzee"),
                 ("well_vidmario", "vidmario"),
                 ("well_vidsrc", "vidsrc"),
                 ("well_mp4hydra", "mp4hydra"))


def _disabled_wells():
    off = []
    for setting, name in _WELL_TOGGLES:
        try:
            on = ADDON.getSettingBool(setting)
        except Exception:
            on = (ADDON.getSetting(setting) or "true").lower() == "true"
        if not on:
            off.append(name)
    return off


# --- SOURCE DEATH MARKS + AVAILABILITY VERDICTS -------------------
# (zero-source shelf lane, 2026-11-17; Eric's order 13:18 + the
# 13:19 extension: "sources that don't work count too" — the shelf
# test is zero WORKING sources, not zero listed sources.)
#
# Two device-level files, both in this addon's MASTER-profile data
# dir (a title's source truth is a property of this device and its
# exit — the .159 diagnosis proved shelves differ per exit — never
# of one profile, so every profile on the stick reads the same
# verdicts; nothing here is shared across devices):
#
#   source_marks.json   per-title failure marks (negative
#                       learning, deep-dive F-10), written by
#                       _try_source on every real try.
#   availability.json   per-title shelf verdicts {state: ok|zero,
#                       working, checked, via}, written by play()
#                       and by action=avail_check, READ by
#                       script.rocui's shelf filter. rocui never
#                       writes it; rocplay never reads rocui's
#                       queue (the service tick fires this addon's
#                       avail_check action instead).
#
# THE DEATH BAR (exact — a source is DEAD for a title when ALL of
# these hold):
#   * at least DEATH_MIN_FAILS (3) recorded start failures for
#     this (title, source) — one failure per play session at most,
#     because a play tries a given source at most once;
#   * those failures SPAN at least DEATH_SPAN_S (24 h) from first
#     to last — repeated failure OVER TIME. Three deaths in one
#     bad evening on a strangled stick do not make a death (the
#     Rudolph signature: same source, +30.0 s, twice in 8 minutes,
#     while the stick was memory-starved — the source was never
#     proven dead, and under this bar it is not);
#   * the newest failure is inside DEATH_WINDOW_S (7 days) —
#     older marks lapse (F-10's expiry): a source nobody has
#     failed lately counts as working again at the next check;
#   * no successful start since — structural: a success DELETES
#     the source's marks (revival, in _try_source), so a dead
#     source that later answers a try with a real start is alive
#     again from that moment and can restore its title.
# A single stall/timeout is one mark, never a death. Marks never
# touch the ladder: a marked source is still poured and still
# tried (that is how revival can happen); the marks only feed the
# working-source COUNT the shelf verdict reads.
#
# Source identity: the URL with its query string stripped
# (scheme://host/path). The wells' stable URLs (VixSrc playlist
# ids, Movy/VidZee links) keep their identity across pours;
# token-in-path URLs (VidSrc's single-use JWT chains) never match
# a previous mark and so can never be counted dead — conservative
# in the right direction (they keep their title on the shelf).
# TV marks are keyed per EPISODE (sources are episode-specific);
# TV shelf verdicts are keyed per SHOW (see _record_availability's
# callers for who may stamp a show zero).
MARKS_FILE = "source_marks.json"
AVAIL_FILE = "availability.json"
DEATH_MIN_FAILS = 3
DEATH_SPAN_S = 24 * 3600          # failures must span a full day
DEATH_WINDOW_S = 7 * 24 * 3600    # marks older than a week lapse
MARKS_MAX_FAILS = 12              # retained per (title, source)


def _master_store_dir():
    """This addon's MASTER-profile data dir (created on demand):
    identical from every profile context on this device. '' when
    the path cannot be resolved (verdicts then simply never
    persist — the shelf filter reads an absent cache as all
    unknown, and nothing is ever suppressed on missing data)."""
    try:
        path = xbmcvfs.translatePath(
            "special://masterprofile/addon_data/plugin.video.rocplay/")
        if path and not os.path.isdir(path):
            os.makedirs(path)
        return path or ""
    except Exception:
        return ""


def _json_load(path):
    try:
        with open(path, "r") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _json_save(path, data):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def _shelf_key(req):
    """Title-level key for availability verdicts: 'movie:<tmdb>',
    'tv:<tmdb>', or a normalised title+year fallback when a
    request carries no TMDB id."""
    t = req.get("tmdb_type") or "movie"
    if req.get("tmdb_id"):
        return "%s:%s" % (t, req["tmdb_id"])
    return "%s:title:%s:%s" % (
        t, _norm_title(req.get("title") or ""), req.get("year") or "")


def _marks_key(req):
    """Marks key: the shelf key, plus the episode for TV (a
    source belongs to one episode; its deaths must not stain
    another episode's sources)."""
    base = _shelf_key(req)
    if (req.get("tmdb_type") == "tv"
            and req.get("season") is not None
            and req.get("episode") is not None):
        return "%s:s%se%s" % (base, req["season"], req["episode"])
    return base


def _url_key(url):
    """A source's stable identity: scheme://host/path, query
    stripped (see the section header for why)."""
    try:
        p = urllib.parse.urlsplit(url or "")
        if p.scheme and p.netloc:
            return "%s://%s%s" % (p.scheme, p.netloc, p.path)
    except Exception:
        pass
    return (url or "")[:200]


def _marks_load():
    base = _master_store_dir()
    if not base:
        return {}
    return _json_load(os.path.join(base, MARKS_FILE))


def _marks_save(data):
    base = _master_store_dir()
    if not base:
        return False
    return _json_save(os.path.join(base, MARKS_FILE), data)


def _mark_failure(req, source, reason):
    """One recorded start failure for (title, source). Called by
    _try_source for every F2 reason except 'aborted'. Never
    raises; a marks write must never break a play."""
    try:
        now = time.time()
        data = _marks_load()
        marks = data.get("marks") or {}
        per_title = marks.setdefault(_marks_key(req), {})
        key = _url_key(source.get("url"))
        entry = per_title.get(key) or {"fails": []}
        fails = [float(t) for t in (entry.get("fails") or [])
                 if now - float(t) <= DEATH_WINDOW_S]
        fails.append(now)
        entry["fails"] = fails[-MARKS_MAX_FAILS:]
        entry["well"] = source.get("well") or ""
        entry["last_reason"] = reason
        per_title[key] = entry
        data["marks"] = marks
        data["v"] = 1
        _marks_save(data)
    except Exception:
        pass


def _mark_success(req, source):
    """Revival: a confirmed start deletes the source's marks for
    this title outright. Never raises."""
    try:
        data = _marks_load()
        marks = data.get("marks") or {}
        per_title = marks.get(_marks_key(req)) or {}
        key = _url_key(source.get("url"))
        if key in per_title:
            del per_title[key]
            if not per_title:
                marks.pop(_marks_key(req), None)
            data["marks"] = marks
            _marks_save(data)
    except Exception:
        pass


def source_dead(req, source, now=None, data=None):
    """The death bar (see the section header), exactly: >=
    DEATH_MIN_FAILS failures inside DEATH_WINDOW_S, spanning >=
    DEATH_SPAN_S first-to-last. A success since the last failure
    cannot exist here — success deletes the entry."""
    try:
        now = time.time() if now is None else now
        if data is None:
            data = _marks_load()
        entry = ((data.get("marks") or {}).get(_marks_key(req))
                 or {}).get(_url_key(source.get("url")))
        if not entry:
            return False
        fails = [float(t) for t in (entry.get("fails") or [])
                 if now - float(t) <= DEATH_WINDOW_S]
        if len(fails) < DEATH_MIN_FAILS:
            return False
        return (max(fails) - min(fails)) >= DEATH_SPAN_S
    except Exception:
        return False


def _working_count(req, sources, data=None):
    """Listed sources minus death-marked ones: the count the
    shelf verdict reads (Eric, 2026-11-17 13:19)."""
    if data is None:
        data = _marks_load()
    return sum(1 for s in (sources or [])
               if not source_dead(req, s, data=data))


def _pour_complete(core):
    """True when the pour behind `core` definitively asked every
    well it was going to ask: no front well left at 'no_answer'
    (transport failure / window timeout — the door never
    answered, so its shelf is UNKNOWN, not empty), and no well
    still unaccounted after the second pour's re-join. Wells the
    health gate skipped are resolved BY the gate (the standing
    guard rail classes them down; fanout's own doctrine keeps
    them skipped), and user-disabled wells are out of the ask set
    by Eric's own switches — neither blocks completeness. The
    reserve tier's own no_answer does not block either: reserve
    is the hidden bonus tier (lifetime 0-for on .159); the front
    tier's definitive total zero is the shelf test. An ask set
    that ended up EMPTY (every well disabled) proves nothing."""
    lf = getattr(core, "last_fanout", None)
    if not lf:
        return False
    front = lf.get("front") or {}
    if not front:
        return False
    for verdict in front.values():
        if verdict == "no_answer":
            return False
    sp = getattr(core, "last_second_pour", None)
    if sp is not None:
        if sp.get("rejoin_timeout"):
            return False
    elif "cut" in front.values():
        # A well was cut by the early return and no second pour
        # ever re-joined it: its answer is unknown.
        return False
    return True


def _record_availability(core, req, state, working, complete, via):
    """Stamp one title's shelf verdict in availability.json.
    Only ever called with a definitive outcome: 'ok' (working >=
    1) or 'zero' (a COMPLETE pour with working == 0). An
    incomplete pour writes nothing — the previous verdict (or
    unknown) stands, and unknown never suppresses."""
    try:
        base = _master_store_dir()
        if not base:
            return False
        path = os.path.join(base, AVAIL_FILE)
        data = _json_load(path)
        entries = data.get("titles") or {}
        entries[_shelf_key(req)] = {
            "state": state,
            "working": int(working),
            "checked": time.time(),
            "via": via,
            "complete": bool(complete),
            "title": req.get("title") or "",
            "year": req.get("year") or "",
            "episode": ("s%se%s" % (req.get("season"),
                                    req.get("episode")))
                       if req.get("tmdb_type") == "tv"
                       and req.get("season") is not None else "",
        }
        data["titles"] = entries
        data["v"] = 1
        ok = _json_save(path, data)
        core.event("avail_verdict", state=state,
                   working=int(working), via=via,
                   key=_shelf_key(req))
        return ok
    except Exception:
        return False


def avail_check(req):
    """action=avail_check: the full pour for one title, run ONLY
    to stamp its shelf verdict — nothing plays, nothing is shown
    (no status, no toast, no picker). The pour is the play path's
    own: fanout(), then — only when the first pour leaves zero
    WORKING sources, exactly the play path's trigger — the second
    pour (re-join + reserve). On a light-tier device the same
    1080p cap as play() applies: a title whose only sources sit
    above the cap has no playable source HERE. TV checks probe
    season 1 episode 1 (the entry episode — main() applies the
    default): the show-level question is whether the show is
    alive on this device at all."""
    core = wellcore.WellCore(_store_dir())
    try:
        if xbmc.Player().isPlaying():
            core.event("avail_check_skipped", reason="playing",
                       title=req.get("title"))
            return
    except Exception:
        pass
    req["disabled_wells"] = _disabled_wells()
    try:
        sources = core.fanout(req)
    except Exception as exc:
        core.event("avail_check_failed", title=req.get("title"),
                   error=str(exc)[:160])
        return
    model, mem_kb, light, probe = _device_class()
    if light and sources:
        sources = [s for s in sources if not _over_cap(s)]
    listed = list(sources)
    working = _working_count(req, listed)
    if working == 0:
        _sp = getattr(core, "second_pour", None)
        if _sp is not None:
            tried = set(s.get("url") for s in sources
                        if s.get("url"))
            try:
                extra = _sp(req, exclude_urls=tried)
            except Exception:
                core.event("second_pour_failed",
                           title=req.get("title"))
                extra = []
            if light and extra:
                extra = [s for s in extra if not _over_cap(s)]
            listed.extend(extra)
            working = _working_count(req, listed)
    complete = _pour_complete(core)
    core.event("avail_check", title=req.get("title"),
               tmdb_id=req.get("tmdb_id"),
               tmdb_type=req.get("tmdb_type"),
               listed=len(listed), working=working,
               complete=bool(complete))
    if working >= 1:
        _record_availability(core, req, "ok", working, complete,
                             via="check")
    elif complete:
        _record_availability(core, req, "zero", 0, True,
                             via="check")
    # Zero working but INCOMPLETE: no stamp. The title keeps
    # whatever verdict it had (or stays unknown and on the shelf).


def _remembered_source(req):
    """The remembered source handed in with this play (rocui's
    per-title source memory, stale-URL fix lane 2026-11-17) as a
    ladder source dict, or None. Only a plain http(s) URL is a
    remembered source; anything else is ignored and the hunt
    runs exactly as before. The stored URL is played BARE — the
    same string rocui's old direct route played — so no headers
    are attached (a pipe-format URL passes through untouched).
    The light-tier 1080p cap is NOT applied to this try: the
    remembered source is one this device already played, and
    the old direct route played it uncapped — parity."""
    url = (req.get("remembered_url") or "").strip()
    if not url.startswith(("http://", "https://")):
        return None
    return {"well": (req.get("remembered_well") or "").strip()
            or "remembered",
            "label": (req.get("remembered_label") or "").strip()
            or "Remembered source",
            "url": url, "headers": {}}


def play(req, auto=False):
    req["disabled_wells"] = _disabled_wells()
    core = wellcore.WellCore(_store_dir())
    # RESUME CHECKPOINT (fix lane 2026-11-17): capture any armed
    # checkpoint for this title BEFORE the fan-out (freshest read;
    # the value is only ever APPLIED after a source is confirmed
    # playing, in the try loop below).
    resume_target = _resume_target(core, req)
    # RESUME FAILOVER (0.2.19): how many sources have died ON
    # the resume seek so far in this play. Zero on every
    # non-resume play and on any resume that survives its first
    # source — the failover machinery is invisible until a
    # player actually dies inside the hold window.
    seek_deaths = 0
    try:
        _win = xbmcgui.Window(10000)
        _win.clearProperty("RocOS.SourceLabel")
        _win.clearProperty("RocOS.SourcePath")
        _win.clearProperty("RocPlay.Well")
    except Exception:
        pass
    busy = _Busy()
    status = _PlayStatus()
    # REMEMBERED SOURCE FIRST (stale-URL fix lane, 2026-11-17):
    # when rocui's source memory handed a URL in with this play,
    # try it BEFORE the fan-out, through _try_source's full
    # contract (playing + advancing + audible; every death path
    # records its F2 reason and a death mark). A win is the old
    # direct route's win — the fan-out never ran, so a healthy
    # remembered play gains no delay and shows nothing new. A
    # death falls through to the hunt below, which is byte-for-
    # byte the play a memory-less title gets. No picker on this
    # leg either: the picker lives behind the fan-out, and
    # remembered plays arrive with auto=1 (August's law holds).
    rem = _remembered_source(req)
    if rem is not None:
        core.event("remembered_try", well=rem["well"],
                   label=rem["label"], url=rem["url"][:160],
                   title=req.get("title"))
        if _try_source(core, req, rem):
            core.event("playing", well=rem["well"],
                       label=rem["label"], title=req.get("title"),
                       remembered=True)
            # AVAILABILITY: a confirmed start is the strongest
            # ok there is (the winner's marks were cleared by
            # _try_source's revival on the way here). Working=1:
            # the remembered source itself, proven on this try.
            _record_availability(core, req, "ok", 1, True,
                                 via="play")
            # OSD SOURCE LABEL: same stamps as a ladder win,
            # minus RocPlay.Well (no well preference is known
            # for a remembered source — the property stays
            # cleared, which autoplay-next reads as no
            # preference, exactly like a first episode).
            try:
                _win = xbmcgui.Window(10000)
                _win.setProperty("RocOS.SourceLabel",
                                 "%s - %s" % (rem["well"],
                                              rem["label"]))
                _win.setProperty("RocOS.SourcePath",
                                 rem.get("url") or "")
            except Exception:
                pass
            status.finish("playing", "%s — %s" % (rem["well"],
                          rem["label"]), req)
            # RESUME CHECKPOINT: the win is confirmed playing +
            # advancing + audible, so the armed checkpoint
            # applies exactly as on a ladder win.
            if resume_target and not _resume_outcome(
                    core, req, resume_target, rem, seek_deaths):
                # RESUME FAILOVER (0.2.19): the remembered
                # source started, then died on the resume seek —
                # dead FOR SEEKING. The hunt below is the
                # fall-through, exactly as for a remembered
                # source that dies inside its start window.
                seek_deaths += 1
                core.event("remembered_resume_fallthrough",
                           title=req.get("title"))
            else:
                # TOKEN LOADER (2026-11-18): hold the proxy for
                # this playback, if the winner plays through it.
                _hold_token_proxy(core, req)
                return
        # The remembered source died inside its start window.
        # source_failed already carries the reason; the hunt
        # below is the fall-through.
        core.event("remembered_fallthrough",
                   title=req.get("title"))
    busy.create()
    status.start(req)
    try:
        sources = core.fanout(req)
    except Exception:
        status.finish("fanout_failed", "Finding sources failed", req)
        raise
    finally:
        busy.close()
    # AUTO-TAILOR ceiling: on a light-tier device nothing above
    # 1080p is offered (picker) or tried (ladder). See _device_class.
    # The check is logged on EVERY play: detection that fails
    # silently is indistinguishable from a cap that never fired.
    model, mem_kb, light, probe = _device_class()
    core.event("cap_check", model=model, mem_kb=mem_kb,
               light=bool(light), probe=probe)
    if light and sources:
        kept = [s for s in sources if not _over_cap(s)]
        if len(kept) != len(sources):
            dropped_detail = [{"well": s.get("well"),
                               "quality": s.get("quality")}
                              for s in sources if _over_cap(s)]
            core.event("cap_filter", ceiling="1080p", model=model,
                       mem_kb=mem_kb, dropped=len(sources) - len(kept),
                       kept=len(kept), dropped_detail=dropped_detail)
        sources = kept
    # F1 PREFER-WELL (v1.1 FUSE pack, 2026-11-17): autoplay-next
    # passes prefer_well=<the well that played the episode just
    # finished> - Eric's spec: SAME well first, SAME quality first,
    # then step down the ladder. A STABLE partition: the preferred
    # well's sources move to the head keeping their merged order
    # (trusted rank, health, quality desc inside the well), and
    # every other source keeps its ladder order behind them. The
    # try loop below then walks same-well sources in quality order
    # and steps down the ordinary ladder only when they run out or
    # fail. An unknown/absent preference changes nothing.
    prefer = (req.get("prefer_well") or "").strip().lower()
    if prefer and sources:
        head = [s for s in sources
                if str(s.get("well") or "").lower() == prefer]
        if head:
            tail = [s for s in sources
                    if str(s.get("well") or "").lower() != prefer]
            sources = head + tail
            core.event("prefer_well", well=prefer,
                       head=len(head), total=len(sources))
    if not sources:
        core.event("no_sources", title=req.get("title"))
        # AVAILABILITY (zero-source shelf lane): a COMPLETE pour
        # that found nothing stamps the shelf verdict — for a
        # MOVIE. A TV episode's empty pour never stamps the show
        # zero (a different episode's sources are different
        # sources; the show-level zero comes only from
        # avail_check's entry-episode probe).
        if (req.get("tmdb_type") or "movie") != "tv" \
                and _pour_complete(core):
            _record_availability(core, req, "zero", 0, True,
                                 via="play")
        status.finish("no_sources", "No sources right now", req)
        xbmcgui.Dialog().notification(
            "Roc Play", "No sources right now — it's logged, try again soon",
            xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    order = list(range(len(sources)))
    if not auto and _picker_enabled() and len(sources) > 1:
        labels = ["%s — %s" % (s["well"], s["label"]) for s in sources]
        pick = xbmcgui.Dialog().select(
            req.get("title") or "Sources", labels)
        if pick < 0:
            core.event("user_cancelled", title=req.get("title"))
            status.finish("cancelled", "", req)
            return
        order = [pick] + [i for i in order if i != pick]
    for pos, i in enumerate(order):
        if pos:
            # CHAIN SETTLE (0.2.6, from the Brave Little Toaster
            # flight record, patio 2026-11-12): after a source burned
            # the full start window, the next three sources — across
            # two other CDNs, one of them the same URL family that
            # played this title in another run — each died at the
            # ~2.5 s demuxer-death check, the signature of Kodi's
            # player core still tearing down the stalled attempt
            # rather than three independently dead sources. Give the
            # core a beat to finish teardown before the next try.
            core.event("chain_settle", after_well=sources[order[pos - 1]]["well"],
                       next_well=sources[i]["well"])
            if xbmc.Monitor().waitForAbort(1.0):
                core.event("chain_aborted", title=req.get("title"))
                status.finish("cancelled", "", req)
                return
        status._publish("trying",
                        "Trying source %d/%d: %s"
                        % (pos + 1, len(order), sources[i]["well"]),
                        req)
        if _try_source(core, req, sources[i]):
            core.event("playing", well=sources[i]["well"],
                       label=sources[i]["label"], title=req.get("title"))
            # AVAILABILITY: a confirmed start is the strongest
            # ok there is (the winner's own marks were cleared by
            # _try_source's revival on the way here).
            _record_availability(
                core, req, "ok", _working_count(req, sources),
                True, via="play")
            # OSD SOURCE LABEL (fleet catch-up 2026-11-16, Eric
            # 20:11): stamp what is actually playing - the well and
            # its own label - for the player bar's SOURCE line.
            try:
                _win = xbmcgui.Window(10000)
                _win.setProperty("RocOS.SourceLabel",
                                 "%s - %s" % (sources[i]["well"],
                                              sources[i]["label"]))
                _win.setProperty("RocOS.SourcePath",
                                 sources[i].get("url") or "")
                # F1 (v1.1 FUSE pack): the winning well, machine-
                # readable, for rocui's autoplay-next prefer_well.
                _win.setProperty("RocPlay.Well",
                                 str(sources[i].get("well") or ""))
            except Exception:
                pass
            status.finish("playing", "%s — %s" % (sources[i]["well"],
                          sources[i]["label"]), req)
            # RESUME CHECKPOINT (fix lane 2026-11-17): the winning
            # source is confirmed playing + advancing + audible
            # (_try_source's contract) - NOW the stream can take
            # the seek. A failed/unconfirmed seek leaves playback
            # running untouched (autoplay law: never break a
            # working start over a resume).
            if resume_target and not _resume_outcome(
                    core, req, resume_target, sources[i],
                    seek_deaths):
                # RESUME FAILOVER (0.2.19): this source plays
                # but died on the resume seek — walk the line,
                # exactly like a start failure. The next source
                # gets the SAME checkpoint re-applied on its win.
                seek_deaths += 1
                continue
            # TOKEN LOADER (2026-11-18): hold the proxy for this
            # playback, if the winner plays through it.
            _hold_token_proxy(core, req)
            return
    # SECOND POUR (fix lane 2026-11-17, .159 wells diagnosis F1):
    # every in-hand source failed its start window. Before the
    # honest all_failed, pour again — wider: wellcore re-joins the
    # wells the fan-out cut while they were still answering and
    # engages the reserve tier (fanout only runs it on a front
    # total zero, so a thin 1-2 source pour never reached it).
    # The walk down the line just gets longer: no picker on this
    # leg, ever (autoplay law — and August's auto path never sees
    # a source list by construction). A second pour that finds
    # nothing playable, or whose sources also die, falls through
    # to the same all_failed below, unchanged. The getattr guard
    # keeps a skewed bundle (new default.py against an older
    # wellcore) behaving exactly as the pre-fix build.
    poured2 = []
    _second_pour = getattr(core, "second_pour", None)
    if _second_pour is not None:
        tried_urls = set(s.get("url") for s in sources if s.get("url"))
        try:
            extra = _second_pour(req, exclude_urls=tried_urls)
        except Exception:
            core.event("second_pour_failed", title=req.get("title"))
            extra = []
        if extra and light:
            kept2 = [s for s in extra if not _over_cap(s)]
            if len(kept2) != len(extra):
                core.event("cap_filter", ceiling="1080p", model=model,
                           mem_kb=mem_kb, pour=2,
                           dropped=len(extra) - len(kept2),
                           kept=len(kept2))
            extra = kept2
        poured2 = list(extra)
        if extra and prefer:
            head2 = [s for s in extra
                     if str(s.get("well") or "").lower() == prefer]
            if head2:
                tail2 = [s for s in extra
                         if str(s.get("well") or "").lower() != prefer]
                extra = head2 + tail2
                core.event("prefer_well", well=prefer, pour=2,
                           head=len(head2), total=len(extra))
        if extra:
            status.start(req)
            for pos2, src2 in enumerate(extra):
                if pos2:
                    # Same chain-settle as the first ladder (0.2.6):
                    # let the player core finish tearing down the
                    # previous dead try before the next one.
                    core.event("chain_settle",
                               after_well=extra[pos2 - 1]["well"],
                               next_well=src2["well"])
                    if xbmc.Monitor().waitForAbort(1.0):
                        core.event("chain_aborted",
                                   title=req.get("title"))
                        status.finish("cancelled", "", req)
                        return
                status._publish("trying",
                                "Trying source %d/%d: %s"
                                % (pos2 + 1, len(extra), src2["well"]),
                                req)
                if _try_source(core, req, src2):
                    core.event("playing", well=src2["well"],
                               label=src2["label"],
                               title=req.get("title"))
                    # AVAILABILITY: second-pour win, same stamp
                    # as a first-pour win.
                    _record_availability(
                        core, req, "ok",
                        _working_count(req,
                                       list(sources) + list(extra)),
                        True, via="play")
                    try:
                        _win = xbmcgui.Window(10000)
                        _win.setProperty("RocOS.SourceLabel",
                                         "%s - %s" % (src2["well"],
                                                      src2["label"]))
                        _win.setProperty("RocOS.SourcePath",
                                         src2.get("url") or "")
                        _win.setProperty("RocPlay.Well",
                                         str(src2.get("well") or ""))
                    except Exception:
                        pass
                    status.finish("playing",
                                  "%s — %s" % (src2["well"],
                                               src2["label"]), req)
                    # RESUME CHECKPOINT: a win on the second pour
                    # is still a win — the stream is confirmed
                    # playing + advancing + audible, so the armed
                    # checkpoint applies exactly as on the first
                    # pour (the resume lane's call, verbatim).
                    if resume_target and not _resume_outcome(
                            core, req, resume_target, src2,
                            seek_deaths):
                        # RESUME FAILOVER (0.2.19): died on the
                        # seek — keep walking the second pour.
                        seek_deaths += 1
                        continue
                    # TOKEN LOADER (2026-11-18): hold the proxy
                    # for this playback, if the winner plays
                    # through it.
                    _hold_token_proxy(core, req)
                    return
    # RESUME FAILOVER (0.2.19): the whole line was walked and
    # every source that started died on the resume seek (any
    # source that failed its START is an ordinary ladder death
    # and also lands here when a seek death happened earlier in
    # the walk — either way the resume survived nowhere and
    # playback is over). This is NOT the all_failed shape below
    # (those sources never started), and no picker may come out
    # of this path on any profile: the picker law reserves it
    # for a whole-line PLAY failure, and August never sees one.
    # Stop cleanly, record it, honest toast.
    if resume_target and seek_deaths:
        core.event("resume_failover_exhausted",
                   target=resume_target, seek_deaths=seek_deaths,
                   title=req.get("title"))
        status.finish("resume_failed",
                      "Resume failed on every source", req)
        xbmcgui.Dialog().notification(
            "Roc Play",
            "Couldn't resume on any source — it's logged",
            xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    # AVAILABILITY (zero-source shelf lane): every listed source
    # failed. That alone does NOT take a title off the shelf —
    # one bad evening is marks, not a verdict. Only when the
    # recount leaves zero WORKING sources (every survivor carries
    # an established death record) AND the pour was complete does
    # a MOVIE earn the zero stamp here. TV: never from the play
    # path (see the no_sources note).
    if (req.get("tmdb_type") or "movie") != "tv":
        if _working_count(req, list(sources) + poured2) == 0 \
                and _pour_complete(core):
            _record_availability(core, req, "zero", 0, True,
                                 via="play")
    core.event("all_failed", title=req.get("title"))
    status.finish("all_failed", "Those sources wouldn't start", req)
    xbmcgui.Dialog().notification(
        "Roc Play", "Those sources wouldn't start — it's logged",
        xbmcgui.NOTIFICATION_WARNING, 5000)


def main():
    p = _params()
    if p.get("action") not in ("play", "avail_check"):
        xbmcplugin.endOfDirectory(HANDLE)
        return
    req = {
        "title": p.get("tvshowtitle") if p.get("tvshowtitle") else p.get("title", ""),
        "showtitle": p.get("tvshowtitle", ""),
        "year": int(p["year"]) if p.get("year", "").isdigit() else p.get("year"),
        "imdb": p.get("imdb", ""),
        "tmdb_id": int(p["tmdb"]) if p.get("tmdb", "").isdigit() else None,
        "tmdb_type": "tv" if ("season" in p or "tvshowtitle" in p) else "movie",
        "season": int(p["season"]) if p.get("season", "").isdigit() else None,
        "episode": int(p["episode"]) if p.get("episode", "").isdigit() else None,
        "premiered": p.get("premiered", ""),
        # F1 (v1.1 FUSE pack): autoplay-next's same-well preference.
        "prefer_well": p.get("prefer_well", ""),
        # STALE-URL FIX (lane 2026-11-17): rocui's remembered
        # source for this title (0.7.11 hands it in); play()
        # tries it first, before the fan-out.
        "remembered_url": p.get("remembered_url", ""),
        "remembered_well": p.get("remembered_well", ""),
        "remembered_label": p.get("remembered_label", ""),
    }
    if req["tmdb_type"] == "tv" and not req["showtitle"]:
        req["showtitle"] = req["title"]
    if p.get("action") == "avail_check":
        # ZERO-SOURCE SHELF lane (2026-11-17): the caller
        # (script.rocui's service tick) names the type outright —
        # the play heuristic above keys TV off season/tvshowtitle
        # params a check does not carry. A TV check probes the
        # entry episode (S01E01) unless told otherwise.
        if p.get("tmdb_type") in ("movie", "tv"):
            req["tmdb_type"] = p["tmdb_type"]
        if req["tmdb_type"] == "tv":
            if req["season"] is None:
                req["season"] = 1
            if req["episode"] is None:
                req["episode"] = 1
            if not req["showtitle"]:
                req["showtitle"] = req["title"]
        avail_check(req)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    play(req, auto=p.get("auto") == "1")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == "__main__":
    main()
